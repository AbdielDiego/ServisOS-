<?php
namespace App\Core;
use App\Core\Container;

abstract class Model {
    protected $db;
    protected $table;
    protected $primaryKey = "id"; 

    public function __construct() {
        $this->db = Container::get("db");
    }

    /**
     * Buscar un registro por condiciones (columna => valor).
     * Devuelve array asociativo o null.
     */
    public function find(array $conditions) {
        $whereParts = [];
        $params = [];
        foreach ($conditions as $column => $value) {
            $whereParts[] = "{$column} = ?";
            $params[] = $value;
        }
        $sql = "SELECT * FROM {$this->table} WHERE " . implode(" AND ", $whereParts) . " LIMIT 1";
        $query = $this->db->query($sql, $params);
        return $query->fetch(\PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * Crear un registro y devolver el último ID insertado.
     */
    public function create(array $data) {
        $columns = implode(", ", array_keys($data));
        $placeholders = implode(", ", array_fill(0, count($data), "?"));
        $sql = "INSERT INTO {$this->table} ({$columns}) VALUES ({$placeholders})";
        $this->db->query($sql, array_values($data));
        return $this->db->lastInsertId();
    }

    /**
     * Actualizar registros que cumplan las condiciones.
     */
    public function update(array $conditions, array $data) {
        $setParts = [];
        $params = [];
        foreach ($data as $column => $value) {
            $setParts[] = "{$column} = ?";
            $params[] = $value;
        }
        $whereParts = [];
        foreach ($conditions as $column => $value) {
            $whereParts[] = "{$column} = ?";
            $params[] = $value;
        }
        $sql = "UPDATE {$this->table} SET " . implode(", ", $setParts) . " WHERE " . implode(" AND ", $whereParts);
        return $this->db->query($sql, $params);
    }

    /**
     * Borrar registros por condiciones.
     */
    public function delete(array $conditions) {
        $whereParts = [];
        $params = [];
        foreach ($conditions as $column => $value) {
            $whereParts[] = "{$column} = ?";
            $params[] = $value;
        }
        $sql = "DELETE FROM {$this->table} WHERE " . implode(" AND ", $whereParts);
        return $this->db->query($sql, $params);
    }
}

