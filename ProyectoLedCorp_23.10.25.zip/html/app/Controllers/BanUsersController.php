<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use PDO;
use Throwable;

class BanUsersController extends Controller
{
    private PDO $pdo;

    public function __construct()
    {
        parent::__construct();

        // Usa tu core si existe, si no, cae al usuario appuser/apppass
        if (class_exists('\App\Core\Database')) {
            $this->pdo = \App\Core\Database::getConnection();
        } else {
            $dsn  = 'mysql:host=127.0.0.1;dbname=proyutu;charset=utf8mb4';
            $user = 'appuser';   // <- evita el error 1698 de root
            $pass = 'apppass';
            $this->pdo = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        }
    }

    /**
     * GET /usuarios/baneados  (y aliases)
     */
    public function index()
    {
        $sql = "
            SELECT
                b.ban_id,
                b.user_id,
                b.username,
                b.email,
                b.reason,
                b.banned_by,
                admin.username AS banned_by_name,
                b.banned_at
            FROM BanUsers b
            LEFT JOIN Users admin ON admin.user_id = b.banned_by
            ORDER BY b.banned_at DESC, b.ban_id DESC
        ";
        $rows = $this->pdo->query($sql)->fetchAll();

        // La vista espera $datosTabla
        return $this->render('usuarios/BanUsersIndex', [
            'titulo'     => 'Usuarios baneados',
            'datosTabla' => $rows,
            // si sirves desde subcarpeta pública, puedes setear BASE = '' o '/public'
            'BASE'       => '',
        ]);
    }

    /**
     * GET/POST /unban  |  /unban/:id  |  /unban.php
     * Acepta ban_id o user_id (por query o como :id).
     */
    public function unban(array $params = [])
    {
        $banId  = null;
        $userId = null;

        if (isset($params['id']) && ctype_digit((string)$params['id'])) {
            // Podría venir ban_id o user_id: damos prioridad a ban_id si existe
            $banId = (int)$params['id'];
        }
        if (isset($_REQUEST['ban_id']) && ctype_digit((string)$_REQUEST['ban_id'])) {
            $banId = (int)$_REQUEST['ban_id'];
        }
        if (isset($_REQUEST['user_id']) && ctype_digit((string)$_REQUEST['user_id'])) {
            $userId = (int)$_REQUEST['user_id'];
        }

        if ($banId === null && $userId === null) {
            http_response_code(400);
            exit('Faltan parámetros: envía ban_id o user_id.');
        }

        try {
            if ($banId !== null) {
                $st = $this->pdo->prepare('DELETE FROM BanUsers WHERE ban_id = ?');
                $st->execute([$banId]);
            } else {
                $st = $this->pdo->prepare('DELETE FROM BanUsers WHERE user_id = ?');
                $st->execute([$userId]);
            }
        } catch (Throwable $e) {
            http_response_code(500);
            exit('No se pudo desbanear: ' . $e->getMessage());
        }

        $redir = isset($_REQUEST['redirect']) ? (string)$_REQUEST['redirect'] : '/usuarios/baneados';
        $sep   = (strpos($redir, '?') !== false) ? '&' : '?';
        header('Location: ' . $redir . $sep . 'unbanned=1');
        exit;
    }
}

