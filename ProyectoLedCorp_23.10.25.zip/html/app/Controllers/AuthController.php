<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;

// Opcionales (solo si existen en tu proyecto)
use App\Core\Session;
use App\Services\AuthService;

// Para contador de no leídos (opcional)
use App\Models\MessageRecipient;

final class AuthController extends Controller
{
    private \PDO $pdo;              // Conexión PDO
    protected $session = null;      // Manejo de sesiones (si existe)
    protected $authSvc = null;      // Servicio de autenticación (si existe)

    public function __construct()
    {
        if (method_exists('App\Core\Controller', '__construct')) parent::__construct();
        if (session_status() !== \PHP_SESSION_ACTIVE) @session_start();

        // Conexión a BD
        if (class_exists(Database::class)) {
            $this->pdo = Database::getConnection();
        } else {
            // Fallback local: ajusta credenciales si hace falta
            $dsn  = 'mysql:host=127.0.0.1;dbname=proyutu;charset=utf8mb4';
            $user = 'appuser';
            $pass = 'apppass';
            $this->pdo = new \PDO($dsn, $user, $pass);
        }
        $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
        $this->pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);

        // Opcionales
        if (class_exists(Session::class))     $this->session = new Session();
        if (class_exists(AuthService::class)) $this->authSvc = new AuthService($this->session ?? null);
    }

    /* =========================================================
     * LOGIN
     * ========================================================= */

    /** GET /login */
    public function showLogin(array $params = [])
    {
        if ($this->isAuthenticated()) {
            $next = $this->safeNext($_GET['next'] ?? '');
            return $this->redirect($next ?: '/dashboard');
        }
        $next     = $this->safeNext($_GET['next'] ?? '');
        $flashes  = $this->popFlashes(); // mostrar mensajes SOLO aquí
        return $this->view('auth/login', [
            'title'   => 'Iniciar Sesión',
            'next'    => $next,
            'flashes' => $flashes,
        ]);
    }

    /** POST /login */
    public function login(array $params = [])
    {
        if (session_status() !== \PHP_SESSION_ACTIVE) @session_start();

        // Soporta login con email O username en el mismo campo
        $identity = trim((string)($_POST['email'] ?? $_POST['username'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        $next     = $this->safeNext($_POST['next'] ?? '');

        if ($identity === '' || $password === '') {
            $this->flash('danger', 'Completa email/usuario y contraseña.');
            $flashes = $this->popFlashes();
            return $this->view('auth/login', [
                'title'   => 'Iniciar Sesión',
                'next'    => $next,
                'input'   => ['email' => $identity],
                'flashes' => $flashes,
            ]);
        }

        // 1) Si existe AuthService, úsalo, pero chequeando ban ANTES
        if ($this->authSvc && method_exists($this->authSvc, 'attempt')) {
            $st = $this->pdo->prepare("
                SELECT *
                FROM Users
                WHERE email = :e OR username = :u
                LIMIT 1
            ");
            $st->execute([':e' => $identity, ':u' => $identity]);
            $row = $st->fetch();

            if (!$row) {
                $this->flash('danger', 'Credenciales incorrectas.');
                $flashes = $this->popFlashes();
                return $this->view('auth/login', [
                    'title'=>'Iniciar Sesión', 'next'=>$next,
                    'input'=>['email'=>$identity], 'flashes'=>$flashes
                ]);
            }

            if ($this->isBannedRow($row)) {
                $this->flash('danger', 'Usted está baneado, comuníquese con el equipo técnico de ChivitaRecomienda');
                $flashes = $this->popFlashes();
                return $this->view('auth/login', [
                    'title'=>'Iniciar Sesión', 'next'=>$next,
                    'input'=>['email'=>$identity], 'flashes'=>$flashes
                ]);
            }

            // Intento de login con tu servicio usando el email real
            $userFromSvc = $this->authSvc->attempt((string)$row['email'], $password);
            if (!$userFromSvc) {
                $this->flash('danger', 'Credenciales incorrectas.');
                $flashes = $this->popFlashes();
                return $this->view('auth/login', [
                    'title'=>'Iniciar Sesión', 'next'=>$next,
                    'input'=>['email'=>$identity], 'flashes'=>$flashes
                ]);
            }

            $_SESSION['auth'] = ['check'=>true, 'user'=>$this->normalizeUser($userFromSvc)];
            $_SESSION['user'] = $_SESSION['auth']['user'];
            $this->setUnreadFlashes();

            return $this->redirect($next ?: '/dashboard');
        }

        // 2) Fallback directo a tabla Users (PDO puro)
        $st = $this->pdo->prepare("
            SELECT *
            FROM Users
            WHERE email = :e OR username = :u
            LIMIT 1
        ");
        // Dos placeholders => dos parámetros => evita HY093
        $st->execute([':e' => $identity, ':u' => $identity]);
        $row = $st->fetch();

        $ok = false;
        if ($row) {
            $hash = (string)($row['password'] ?? '');
            if ($hash !== '') {
                if (preg_match('/^\$2[ayb]\$/', $hash)) $ok = password_verify($password, $hash);
                else                                    $ok = hash_equals($hash, $password); // legacy sin hash
            }
        }

        if (!$ok) {
            $this->flash('danger', 'Credenciales inválidas.');
            $flashes = $this->popFlashes();
            return $this->view('auth/login', [
                'title'=>'Iniciar Sesión', 'next'=>$next,
                'input'=>['email'=>$identity], 'flashes'=>$flashes
            ]);
        }

        // ¿Baneado?
        if ($this->isBannedRow($row)) {
            $this->flash('danger', 'Usted está baneado, comuníquese con el equipo técnico de ChivitaRecomienda');
            $flashes = $this->popFlashes();
            return $this->view('auth/login', [
                'title'=>'Iniciar Sesión', 'next'=>$next,
                'input'=>['email'=>$identity], 'flashes'=>$flashes
            ]);
        }

        // Login OK
        $_SESSION['auth'] = [
            'check' => true,
            'user'  => [
                'user_id'    => (int)$row['user_id'],
                'username'   => (string)($row['username'] ?? ''),
                'email'      => (string)($row['email'] ?? ''),
                'rol_id'     => (int)($row['rol_id'] ?? 0),
                'created_at' => (string)($row['created_at'] ?? date('Y-m-d H:i:s')),
            ],
        ];
        $_SESSION['user'] = $_SESSION['auth']['user'];

        $this->setUnreadFlashes();

        if (!$next || $this->isLoginPath($next)) $next = '/dashboard';
        return $this->redirect($next);
    }

    /** GET /logout */
    public function logout(array $params = [])
    {
        if (session_status() !== \PHP_SESSION_ACTIVE) @session_start();
        $_SESSION = [];
        @session_destroy();
        // Mensaje solo para /login
        @session_start();
        $this->flash('success', 'Sesión cerrada.');
        return $this->redirect('/login');
    }

    /* =========================================================
     * REGISTRO
     * ========================================================= */

    /** GET /register */
    public function showRegister(array $params = [])
    {
        if ($this->isAuthenticated()) return $this->redirect('/dashboard');
        $flashes = $this->popFlashes();
        return $this->view('auth/register', ['title'=>'Registro de Usuario', 'flashes'=>$flashes]);
    }

    /** POST /register */
    public function register(array $params = [])
    {
        if (session_status() !== \PHP_SESSION_ACTIVE) @session_start();

        $name             = trim($_POST['name'] ?? '');
        $email            = trim($_POST['email'] ?? '');
        $password         = (string)($_POST['password'] ?? '');
        $password_confirm = (string)($_POST['password_confirm'] ?? '');

        $errors = [];
        if ($name === '' || mb_strlen($name) < 3)       $errors['name'] = 'Mínimo 3 caracteres';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Email inválido';
        if (mb_strlen($password) < 4)                   $errors['password'] = 'Mínimo 4 caracteres';
        if ($password_confirm !== $password)            $errors['password_confirm'] = 'No coinciden';

        if (!$errors) {
            if ($this->exists('username', $name)) $errors['name']  = 'Nombre en uso';
            if ($this->exists('email', $email))   $errors['email'] = 'Email en uso';
        }

        if ($errors) {
            $this->flash('danger', 'Revisa los errores del formulario.');
            $flashes = $this->popFlashes();
            return $this->view('auth/register', [
                'title'=>'Registro de Usuario',
                'errors'=>$errors,
                'input'=>['name'=>$name,'email'=>$email],
                'flashes'=>$flashes,
            ]);
        }

        try {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $st = $this->pdo->prepare("
                INSERT INTO Users (username, email, password, rol_id, created_at)
                VALUES (:u,:e,:p,2,NOW())
            ");
            $st->execute([':u'=>$name, ':e'=>$email, ':p'=>$hash]);
            $userId = (int)$this->pdo->lastInsertId();
        } catch (\PDOException $e) {
            if ($e->getCode() === '23000') {
                $this->flash('danger','El usuario ya está registrado.');
                $flashes = $this->popFlashes();
                return $this->view('auth/register', [
                    'title'=>'Registro de Usuario',
                    'errors'=>['name'=>'Duplicado','email'=>'Duplicado'],
                    'input'=>['name'=>$name,'email'=>$email],
                    'flashes'=>$flashes,
                ]);
            }
            throw $e;
        }

        $_SESSION['auth'] = [
            'check' => true,
            'user'  => [
                'user_id'=>$userId,
                'username'=>$name,
                'email'=>$email,
                'rol_id'=>2,
                'created_at'=>date('Y-m-d H:i:s')
            ],
        ];
        $_SESSION['user'] = $_SESSION['auth']['user'];

        $this->flash('success','Registro correcto. ¡Bienvenid@!');
        return $this->redirect('/dashboard');
    }

    /* =========================================================
     * RECUPERAR CONTRASEÑA (stubs)
     * ========================================================= */

    public function forgot(array $params = [])
    {
        $flashes = $this->popFlashes();
        return $this->view('auth/forgot', [
            'title'   => 'Recuperar contraseña',
            'flashes' => $flashes,
        ]);
    }

    public function forgotPost(array $params = [])
    {
        $this->flash('info', 'Si el email existe, recibirás un enlace para restablecer.');
        return $this->redirect('/login');
    }

    public function reset(array $params = [])
    {
        $token   = $_GET['token'] ?? '';
        $flashes = $this->popFlashes();
        return $this->view('auth/reset', [
            'title'   => 'Restablecer contraseña',
            'token'   => $token,
            'flashes' => $flashes,
        ]);
    }

    public function resetPost(array $params = [])
    {
        $this->flash('success', 'Contraseña actualizada. Iniciá sesión.');
        return $this->redirect('/login');
    }

    /* =========================================================
     * Helpers
     * ========================================================= */

    private function exists(string $field, string $value): bool
    {
        $allowed = ['username','email'];
        if (!in_array($field, $allowed, true)) return false;
        $st = $this->pdo->prepare("SELECT 1 FROM Users WHERE {$field} = :v LIMIT 1");
        $st->execute([':v'=>$value]);
        return (bool)$st->fetchColumn();
    }

    private function normalizeUser($u): array
    {
        if (is_object($u)) $u = (array)$u;
        return [
            'user_id'    => (int)($u['user_id'] ?? $u['id'] ?? 0),
            'username'   => (string)($u['username'] ?? $u['name'] ?? ''),
            'email'      => (string)($u['email'] ?? ''),
            'rol_id'     => (int)($u['rol_id'] ?? $u['role_id'] ?? 0),
            'created_at' => (string)($u['created_at'] ?? date('Y-m-d H:i:s')),
        ];
    }

    private function isAuthenticated(): bool
    {
        return (!empty($_SESSION['auth']['check']) && !empty($_SESSION['auth']['user']))
            || (!empty($_SESSION['user']));
    }

    private function isLoginPath(string $path): bool
    {
        $p = parse_url($path, \PHP_URL_PATH) ?: $path;
        return (bool)preg_match('#^/login/?$#', $p);
    }

    private function safeNext(string $next): string
    {
        $next = trim($next);
        if ($next === '' || $this->isLoginPath($next)) return '';
        $parts = parse_url($next);
        if (!$parts) return '';
        if (!empty($parts['scheme']) || !empty($parts['host'])) return '';
        $path  = $parts['path']  ?? '/dashboard';
        $query = isset($parts['query']) ? ('?'.$parts['query']) : '';
        return $path.$query;
    }

    /** Devuelve true si el usuario está baneado (por filas o por tabla BanUsers) */
    private function isBannedRow(array $row): bool
    {
        // 1) Flags dentro de Users
        $flags = [
            (int)($row['is_banned'] ?? 0) === 1,
            (int)($row['banned']    ?? 0) === 1,
            (int)($row['ban']       ?? 0) === 1,
            (isset($row['status']) && strtolower((string)$row['status']) === 'banned'),
        ];
        if (in_array(true, $flags, true)) return true;

        // 2) Tabla BanUsers (si existe)
        try {
            $chk = $this->pdo->prepare('SELECT 1 FROM BanUsers WHERE user_id = :uid OR email = :em LIMIT 1');
            $chk->execute([
                ':uid' => (int)($row['user_id'] ?? 0),
                ':em'  => (string)($row['email'] ?? ''),
            ]);
            return (bool)$chk->fetchColumn();
        } catch (\Throwable $e) {
            // Si la tabla no existe, no corta el login
            return false;
        }
    }

    /** Mensajes flash por no leídos */
    private function setUnreadFlashes(): void
    {
        $uid = (int)($_SESSION['auth']['user']['user_id'] ?? 0);
        if ($uid <= 0) return;

        $unread = 0;
        if (class_exists(MessageRecipient::class)) {
            if (method_exists(MessageRecipient::class, 'unreadCountForUser')) {
                $unread = (int)MessageRecipient::unreadCountForUser($uid);
            } elseif (method_exists(MessageRecipient::class, 'unreadCount')) {
                $unread = (int)MessageRecipient::unreadCount($uid);
            }
        }
        $_SESSION['inbox_unread'] = $unread;

        if ($unread > 0) {
            $msg = ($unread === 1) ? "Tienes 1 mensaje nuevo." : "Tienes {$unread} mensajes nuevos.";
            $this->flash('info', $msg);
        }
    }

    /* ====== Fallbacks básicos si el Controller base no los trae ====== */

    public function view($template, $data = [])
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent,'view')) return parent::view($template,$data);

        $templateName = is_string($template) ? $template : (is_array($template) ? '[array]' : strval($template));
        $base = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 2);
        $file = $base.'/app/Views/'.ltrim($templateName,'/').'.php';
        if (!is_file($file)) { 
            http_response_code(500); 
            echo "<h1>Vista no encontrada</h1><p>".htmlspecialchars($templateName,ENT_QUOTES,'UTF-8').".php</p>"; 
            return null; 
        }
        extract(is_array($data)?$data:[], \EXTR_SKIP);
        ob_start(); include $file; $out = ob_get_clean(); echo $out;
        return null;
    }

    public function redirect($url)
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent,'redirect')) return parent::redirect($url);

        if (is_array($url)) {
            $path=''; $query=[];
            if (isset($url['path'])) $path=(string)$url['path'];
            elseif (isset($url[0]))  $path=(string)$url[0];
            if (isset($url['query']) && is_array($url['query'])) $query=$url['query'];
            elseif (isset($url[1]) && is_array($url[1]))         $query=$url[1];
            $url = $path.($query?('?'.http_build_query($query)):'');
        } else $url = (string)$url;

        $current = parse_url($_SERVER['REQUEST_URI'] ?? '/', \PHP_URL_PATH) ?: '/';
        $target  = parse_url($url, \PHP_URL_PATH) ?: $url;
        if ($current === $target) {
            http_response_code(409);
            echo "<h1>No se puede redirigir</h1><p>Ya estás en <code>".htmlspecialchars($current,ENT_QUOTES,'UTF-8')."</code>.</p>";
            return null;
        }
        header('Location: '.$url); exit;
    }

    /** Guarda un flash y devuelve el array completo (no impreso). */
    public function flash(string $type, string $message): array
    {
        if (session_status() !== \PHP_SESSION_ACTIVE) @session_start();
        $_SESSION['flashes'][] = ['type'=>$type, 'message'=>$message];
        return $_SESSION['flashes'];
    }

    /** Saca y limpia todos los flashes pendientes. */
    public function popFlashes(): array
    {
        if (session_status() !== \PHP_SESSION_ACTIVE) @session_start();
        $all = $_SESSION['flashes'] ?? [];
        unset($_SESSION['flashes']);
        return $all;
    }

    public function e($v): string { 
        return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); 
    }
}

