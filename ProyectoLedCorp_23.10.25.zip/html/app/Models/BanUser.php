<?php
namespace App\Models;

use App\Core\Database;
use PDO;

class BanUser
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Database::getConnection();
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }

    /** Inserta (o actualiza si ya existe) un ban en BanUsers */
    public function banUser(int $userId, ?string $reason, ?int $adminId, ?string $adminName): void
    {
        // Tomamos username/email de Users y hacemos UPSERT por UNIQUE(user_id/email)
        $sql = "
            INSERT INTO BanUsers (user_id, username, email, reason, banned_by, banned_at)
            SELECT u.user_id, u.username, u.email, :reason, :admin, NOW()
            FROM Users u
            WHERE u.user_id = :uid
            ON DUPLICATE KEY UPDATE
               reason      = VALUES(reason),
               banned_by   = VALUES(banned_by),
               banned_at   = VALUES(banned_at),
               username    = VALUES(username),
               email       = VALUES(email)";
        $st = $this->pdo->prepare($sql);
        $st->execute([
            ':reason' => ($reason === '' ? null : $reason),
            ':admin'  => ($adminId ?: null),
            ':uid'    => $userId,
        ]);
    }

    /** Lista de baneados con filtros opcionales */
    public function list(array $filters = []): array
    {
        $sql = "SELECT
                    b.ban_id,
                    b.user_id,
                    b.username,
                    b.email,
                    b.reason,
                    b.banned_by,
                    admin.username AS banned_by_name,
                    b.banned_at
                FROM BanUsers b
                LEFT JOIN Users admin ON admin.user_id = b.banned_by
                WHERE 1=1";
        $params = [];

        if (!empty($filters['user'])) {
            $sql .= " AND b.username LIKE :user";
            $params[':user'] = '%'.$filters['user'].'%';
        }
        if (!empty($filters['email'])) {
            $sql .= " AND b.email LIKE :email";
            $params[':email'] = '%'.$filters['email'].'%';
        }
        if (!empty($filters['reason'])) {
            $sql .= " AND b.reason LIKE :reason";
            $params[':reason'] = '%'.$filters['reason'].'%';
        }

        $sql .= " ORDER BY b.banned_at DESC";

        $st = $this->pdo->prepare($sql);
        $st->execute($params);
        return $st->fetchAll();
    }

    public function unbanByUserId(int $userId): void
    {
        $st = $this->pdo->prepare("DELETE FROM BanUsers WHERE user_id = :id");
        $st->execute([':id' => $userId]);
    }

    public function unbanByBanId(int $banId): void
    {
        $st = $this->pdo->prepare("DELETE FROM BanUsers WHERE ban_id = :id");
        $st->execute([':id' => $banId]);
    }
}

