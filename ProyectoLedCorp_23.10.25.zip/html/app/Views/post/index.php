<?php
/** @var array  $posts */
/** @var string $titulo (opcional) */
/** @var string $basePath (opcional) */

$BASE = htmlspecialchars(rtrim($basePath ?? '', '/'), ENT_QUOTES, 'UTF-8');
if ($BASE === '' || $BASE === '.') { $BASE = ''; }

// Importa el widget de estrellas SIN rutas absolutas:
require_once __DIR__ . '/../components/scoring_system.php';
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title><?= htmlspecialchars($titulo ?? 'Servicios', ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS general -->
    <link rel="stylesheet" href="/css/styles.css">
    <!-- CSS de la vista (incluye estrellas) -->
    <link rel="stylesheet" href="/css/post.css">
</head>
<body>
<section class="services">
  <h1 class="page-title"><?= htmlspecialchars($titulo ?? 'Servicios', ENT_QUOTES, 'UTF-8') ?></h1>

  <?php if (empty($posts)): ?>
    <p class="empty-state">No hay servicios.</p>
  <?php else: ?>
    <ul class="service-list">
      <?php foreach ($posts as $p): ?>
        <?php
          $id      = (int)($p['post_id'] ?? 0);
          $title   = (string)($p['title']      ?? '');
          $content = (string)($p['content']    ?? '');
          $created = (string)($p['created_at'] ?? '');

          if (function_exists('mb_strimwidth')) {
              $excerpt = mb_strimwidth($content, 0, 160, '…');
          } else {
              $excerpt = (strlen($content) > 160) ? substr($content, 0, 157).'…' : $content;
          }
        ?>
        <li class="service-item">
          <div class="service-header">
            <h3><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></h3>
            <small><?= htmlspecialchars($created, ENT_QUOTES, 'UTF-8') ?></small>
          </div>

          <p class="service-excerpt"><?= nl2br(htmlspecialchars($excerpt, ENT_QUOTES, 'UTF-8')) ?></p>

          <div class="actions">
            <a class="btn"   href="<?= $BASE ?>/post/<?= $id ?>/comentar">Comentar</a>
            <a class="btn btn-2" href="<?= $BASE ?>/post/detail?id=<?= $id ?>">Ver detalles</a>
            <a class="btn btn-3" href="<?= $BASE ?>/post/<?= $id ?>">Ver comentarios</a>
            <a class="btn btn-4" href="<?= $BASE ?>/messages/contact?post_id=<?= $id ?>">Enviar un mensaje</a>

            <!-- Puntaje por estrellas (PHP puro) -->
            <div class="rating-wrap">
              <?php render_star_rating($id); ?>
            </div>
          </div>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>
</body>
</html>







