<?php
// Aseguramos que $auth siempre sea un array
if (!isset($auth) || !is_array($auth)) {
    $auth = [];
}

// Verificar si hay sesión activa (auth o sesión nativa)
$isLogged = !empty($auth['check']) || !empty($_SESSION['username']);

if ($isLogged):
?>
    <!-- Widget de esquina para accesos de Mensajes -->
    <link rel="stylesheet" href="/css/message-corner.css">

    <div class="message-corner" onclick="this.classList.toggle('open')">
        <!-- Encabezado -->
        <div class="mc-header">Mensajes</div>

        <!-- Enlaces -->
        <div class="mc-details">
            <a href="/messages/compose" class="btn-messages">Enviar un mensaje</a>
            <a href="/messages/sent" class="btn-messages">Mensajes Enviados</a>
            <a href="/messages/inbox" class="btn-messages">Ver bandeja de entrada</a>
        </div>
    </div>
<?php endif; ?>

