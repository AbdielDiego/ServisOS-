<?php
/** @var array $posts */

// Asegurar estructura iterable
$posts = is_iterable($posts ?? null) ? $posts : [];

/* ===== Helpers seguros ===== */

// Escapar SIEMPRE como string (sin warnings por null)
if (!function_exists('e')) {
    function e($v): string {
        if ($v === null) return '';
        if (is_bool($v)) return $v ? '1' : '0';
        if (is_array($v) || is_object($v)) {
            // Evita errores si por accidente llega un array/objeto
            $v = json_encode($v, JSON_UNESCAPED_UNICODE);
        }
        return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

// Fecha segura (acepta timestamp o string)
if (!function_exists('fmt_date')) {
    function fmt_date($raw): string {
        if ($raw === null || $raw === '') return '';
        if (is_numeric($raw)) {
            $ts = (int)$raw;
        } else {
            $ts = strtotime((string)$raw);
            if ($ts === false) return '';
        }
        return date('Y-m-d', $ts);
    }
}

// Extracto en texto plano con límite de ancho
if (!function_exists('excerpt')) {
    function excerpt($text, int $limit = 240): string {
        $s = (string)($text ?? '');
        $s = trim(strip_tags($s));
        if ($s === '') return '';
        if (function_exists('mb_strimwidth')) {
            return mb_strimwidth($s, 0, $limit, '…', 'UTF-8');
        }
        return substr($s, 0, $limit) . (strlen($s) > $limit ? '…' : '');
    }
}
?>
<link rel="stylesheet" href="/css/minuevo.css">

<main class="minuevo">
  <h1>Últimas Novedades</h1>
  <p>Publicaciones recientes de la comunidad.</p>

  <?php if (!empty($_SESSION['flash']['ok'])): ?>
    <div class="alert ok"><?= e($_SESSION['flash']['ok']) ?></div>
    <?php unset($_SESSION['flash']['ok']); ?>
  <?php endif; ?>

  <?php if (!empty($_SESSION['flash']['error'])): ?>
    <div class="alert error"><?= e($_SESSION['flash']['error']) ?></div>
    <?php unset($_SESSION['flash']['error']); ?>
  <?php endif; ?>

  <?php if (!empty($_SESSION['user'])): ?>
    <p><a class="btn" href="/minuevo/crear">➕ Crear novedad</a></p>
  <?php endif; ?>

  <?php if (empty($posts)): ?>
    <p>No hay publicaciones todavía.</p>
  <?php else: ?>
    <div class="list">
      <?php foreach ($posts as $p): ?>
        <?php
          // Datos con fallbacks seguros
          $slugRaw = $p['slug'] ?? ($p['post_id'] ?? ($p['id'] ?? ''));
          $slug    = e($slugRaw);

          $title   = e($p['title']   ?? $p['titulo']    ?? 'Sin título');
          $author  = e($p['author']  ?? $p['username']  ?? 'anónimo');
          $catText = e($p['category']?? $p['category_name'] ?? '');

          $fecha   = e(fmt_date($p['created_at'] ?? $p['fecha'] ?? null));

          $preview = excerpt($p['content'] ?? $p['contenido'] ?? '', 240);
          // Escapar y luego agregar <br>
          $previewHtml = nl2br(e($preview), false);
        ?>

        <article class="card">
          <h3>
            <a href="/article/<?= $slug ?>">
              <?= $title ?>
            </a>
          </h3>

          <p class="meta">
            <strong>Autor:</strong> <?= $author ?>
            <?php if ($catText !== ''): ?>
              &nbsp;|&nbsp; <strong>Categoría:</strong> <?= $catText ?>
            <?php endif; ?>
            <?php if ($fecha !== ''): ?>
              &nbsp;|&nbsp; <strong>Fecha:</strong> <?= $fecha ?>
            <?php endif; ?>
          </p>

          <p><?= $previewHtml ?></p>

          <p style="margin-top:8px;">
            <a class="btn" href="/article/<?= $slug ?>">Leer más</a>
          </p>
        </article>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</main>

