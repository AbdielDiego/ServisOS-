<?php
namespace App\Services;

use App\Models\Message;
use App\Models\MessageRecipient;

class MessageService
{
    /** Crea y envía un mensaje */
    public static function send(int $senderId, array $recipientIds, string $subject, string $body): int
    {
        $messageId = Message::create($senderId, trim($subject), trim($body));
        MessageRecipient::attach($messageId, $recipientIds);
        return $messageId;
    }
}

