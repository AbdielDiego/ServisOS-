<?php


$con = new PDO('mysql:dbname=proyutu;host=localhost','proyutu','12345678');

$datos = $con->query("Select * from users")->fetchAll();

print_r($datos);

ejecutar:
php conexion.php
