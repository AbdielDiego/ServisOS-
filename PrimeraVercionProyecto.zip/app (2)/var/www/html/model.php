<?php


class Model {

	private $con;


	public function __construct(){
	
	$dsn = 'mysql:host=localhost;dbname=proyutu';
	$user = 'proyutu';
	$password = '12345678';


		try{
			
	$this->con = new PDO($dsn, $user, $password);

	}catch(Exception $e ){

		echo $e->getMessage();
	}

	}

	public function userAll(){

	try{

		$stmt = $this->con->query("SELECT * FROM users");
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

	}catch(Exception $e){

		$e->getMessage();
	}
		return($result); 
	}



}

