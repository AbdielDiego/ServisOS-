<?php

require(__DIR__.'/../vendor/autoload.php');

session_start();




// echo $_SERVER['REQUEST_URI']; // 

//echo " <br> " .session_id(); 
//echo "<BR>SESSION ";
//print_r($_SESSION) ."  <br>";


$route = [
["GET", '/', "HomeController@index"],
["GET",'/usuarios', "AuthController@index"],
["GET",'/show/id', "AuthController@show"],
["GET",'/save/id/', "AuthController@save"],
["POST",'/auth/login', "AuthController@login"],
["POST",'/auth/logout', "AuthController@logout"],
["POST",'/cliente', "ClientesController@index"],
["GET", "/servicios", "ServiciosController@index"],
["GET", "/showservicio/id", "ServiciosController@showServicio"],


];


$datRoute = findRoute( $route, $_SERVER['REQUEST_URI'] );


if ( !empty ( $datRoute["controlador"] ) ){

//echo "<Br>Controlador " . $datRoute["controlador"];

$control = "App\\Controllers\\". $datRoute["controlador"];


		call_user_func([new $control(), 
						$datRoute["metodo"] ], 
						$datRoute["parametros"]
			);


}else{


		echo "no hay ruta";


}


function findRoute( $routes, $bus ){


$controlador = "" ;
$metodo = "" ;
$parametro = [];


	foreach($routes as $i => $val){


		if ( strpos (  $bus , $val[1] ) !== false ){

			$ejecucion = explode('@',$val[2]);

				$controlador = $ejecucion[0];
				$metodo = $ejecucion[1];
				$parametro = [];
			if ( $bus !== '/' ){
				
				$parmts = explode('/', $bus);
				
                if ( count( $parmts) == 4 ){
    				$parametro[$parmts[2]]= $parmts[3];
                }    			
            }
								
		}

	}

return ["controlador" => $controlador, "metodo" => $metodo, "parametros" => $parametro];



}


