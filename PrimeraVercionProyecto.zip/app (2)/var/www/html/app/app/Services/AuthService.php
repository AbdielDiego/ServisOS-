<?php
namespace App\Services;

class AuthService {

    public function attempt($email, $password) {
        // Simulación: acepta solo este usuario de ejemplo
        if ($email === 'admin@test.com' && $password === '1234') {
            $_SESSION['user_id'] = 1;
            return true;
        }
        return false;
    }

    public function check() {
        return isset($_SESSION['user_id']);
    }

    public function logout() {
        unset($_SESSION['user_id']);
    }

    public function register($data) {
        // Aquí deberías guardar el usuario en DB, por ahora simulo
        return rand(1000, 9999); // Devuelve un ID falso
    }
}

