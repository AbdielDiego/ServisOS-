<?php
namespace App\Models;

use App\Core\Model;
use PDO;

class User extends Model {
    protected $table = 'users';

    public function findByEmail($email) {
        $query = $this->db->query(
            "SELECT * FROM {$this->table} WHERE email = ? LIMIT 1", 
            [$email]
        );
        return $query->fetch();
    }
       
    public function checkUser($email, $password) {
    $pdo = $this->db->getPDO(); // 👈 Accedemos al PDO real

    $stmt = $pdo->prepare("SELECT * FROM {$this->table} WHERE email = :email LIMIT 1");
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        return $user;
    }

    return false;
}}

