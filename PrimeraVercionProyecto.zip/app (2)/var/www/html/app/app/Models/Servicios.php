<?php
namespace App\Models;

use App\Core\Database;

class Servicios {

    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function todosLosServicios() {
        $query = "SELECT * FROM servicios";
        return $this->db->query($query)->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function find($id) {
        $query = "SELECT * FROM servicios WHERE id = :id";
        return $this->db->query($query, ['id' => $id])->fetch(\PDO::FETCH_ASSOC);
    }

    public function buscarPorNombre($texto) {
        $sql = "SELECT * FROM servicios WHERE nombre LIKE :nombre";
        $params = ['nombre' => '%' . $texto . '%'];
        return $this->db->query($sql, $params)->fetchAll(\PDO::FETCH_ASSOC);
    }
}



