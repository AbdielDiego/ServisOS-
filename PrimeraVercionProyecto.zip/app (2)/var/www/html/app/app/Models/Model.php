<?php

namespace App\Models;

class Model {

	private $con;


	public function __construct(){
	
	$dsn = 'mysql:host=localhost;dbname=proyutu';
	$user = 'proyutu';
	$password = '12345678';


		try{
			
	$this->con = new \PDO($dsn, $user, $password);

	}catch(Exception $e ){

		echo $e->getMessage();
	}

	}

	public function userAll(){

	try{

		$stmt = $this->con->query("SELECT * FROM users");
		$result = $stmt->fetchAll(\PDO::FETCH_ASSOC);


	}catch(Exception $e){

		$e->getMessage();
	}
		return($result); 
	}

	public function userId($id){

	try{

		$stmt = $this->con->query("SELECT * FROM users WHERE id = $id");
		$result = $stmt->fetchAll(\PDO::FETCH_ASSOC);

	}catch(Exception $e){

		$e->getMessage();
	}
		return($result); 
	}


	public function checkUser($email,$password){
    $user = '';

	try{
         $sql = "SELECT username FROM users WHERE email = '".$email. "' and password = '" .$password ."'";
       
		$stmt = $this->con->query($sql);
		$result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
       
         if ( $result !== false ){
            $user = $result[0]['username'];
        }

	}catch(Exception $e){

		$e->getMessage();
	}
		return($user); 
	}





	public function userSaveId($id){

	$result = false;

	try{

		$sql = "UPDATE users set username= '".$_POST['username']."' ,email= '".$_POST['email']."' ,role= '".$_POST['role']. "' where id = ".$id;

		$result = $this->con->exec($sql);
		

	}catch(Exception $e){

		$e->getMessage();
	}
		return($result); 
	}


}
