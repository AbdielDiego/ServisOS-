<?php

require(__DIR__ . '/../../vendor/autoload.php');

if (session_status() === PHP_SESSION_NONE) { session_start(); } 


// Debug opcional (comentá cuando entregues)
echo $_SERVER['REQUEST_URI'];
echo "<br>SESSION ID: " . session_id(); 
echo "<br>SESSION DATA: ";
print_r($_SESSION);

// Rutas definidas
$route = [
    ["GET", '/', "HomeController@index"],
    ["GET", '/show/id/', "AuthController@show"],
    ["GET", '/edit/id/', "AuthController@edit"],
    ["GET", '/save/id/', "AuthController@save"],
    ["POST", '/auth/login', "AuthController@login"],
    ["POST", '/auth/logout', "AuthController@logout"],
    ["GET", "/clientes", "ClientesController@index"],
    ["POST", "/clientes", "ClientesController@index"],
    ["GET", '/usuarios', "UsuariosController@index"],
    ["POST", '/usuarios', "UsuariosController@index"],
];

// Buscar ruta
$datRoute = findRoute($route, $_SERVER['REQUEST_URI']);

// Debug opcional
print_r($datRoute);

// Ejecutar controlador si se encontró
if (!empty($datRoute["controlador"])) {
    echo "<br>Controlador: " . $datRoute["controlador"];
    $control = "App\\Controllers\\" . $datRoute["controlador"];

    call_user_func(
        [new $control(), $datRoute["metodo"]],
        $datRoute["parametros"]
    );

} else {
    echo "No hay ruta definida para esta URL.";
}

// Función mejorada para buscar ruta exacta
function findRoute($routes, $bus)
{
    foreach ($routes as $val) {
        $method = $val[0];
        $path = $val[1];
        $action = $val[2];

        // Comparación exacta de método y URL
        if ($_SERVER['REQUEST_METHOD'] === $method && $bus === $path) {
            $ejecucion = explode('@', $action);

            return [
                "controlador" => $ejecucion[0],
                "metodo" => $ejecucion[1],
                "parametros" => []
            ];
        }
    }

    return [];
}


