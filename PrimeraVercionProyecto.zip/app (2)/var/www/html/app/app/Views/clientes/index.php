<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Listado de Clientes</title>
    <link rel="stylesheet" href="/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&family=Roboto&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            background: radial-gradient(circle at top, #1a1a2e, #16213e);
            color: #fff;
            font-family: 'Roboto', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            min-height: 100vh;
        }

        header {
            padding: 40px;
            text-align: center;
            background: rgba(255, 255, 255, 0.05);
            width: 100%;
            box-shadow: 0 0 15px #0f0c29;
        }

        h1 {
            font-family: 'Orbitron', sans-serif;
            font-size: 2.5rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: #00ffe1;
            text-shadow: 0 0 10px #00ffe1;
        }

        p {
            font-size: 1.2rem;
            text-align: center;
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            padding: 20px 30px;
            margin: 20px;
            max-width: 500px;
            backdrop-filter: blur(6px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.3);
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .neon-btn {
            margin-top: 15px;
            display: inline-block;
            background: #00ffe1;
            color: #111;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            text-decoration: none;
            box-shadow: 0 0 12px #00ffe1;
            transition: background 0.3s ease;
        }

        .neon-btn:hover {
            background: #00e0c6;
        }

        footer {
            margin-top: auto;
            padding: 15px;
            text-align: center;
            color: #aaa;
            font-size: 0.9rem;
        }
        
        table {
          margin-top: 15px;
            display: inline-block;
            background: #00ffe1;
            color: #111;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            text-decoration: none;
            box-shadow: 0 0 12px #00ffe1;
            transition: background 0.3s ease;
            
        }
        
        table td, table th {
    padding: 12px 20px;
}

    </style>
</head>
<body>

<?php if (count($clientes) == 0): ?>
    <h1>NO HAY CLIENTES</h1>
<?php else: ?>

    <h1>Clientes</h1>

    <table class="tabla">
        <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Teléfono</th>
            <th>Fecha de Registro</th>
        </tr>

        <?php foreach($clientes as $indice => $valor): ?>
            <tr>
                <td><?= $valor["id"] ?></td>
                <td><?= $valor["nombre"] ?></td>
                <td><?= $valor["email"] ?></td>
                <td><?= $valor["telefono"] ?></td>
                <td><?= $valor["fecha_registro"] ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

<?php endif; ?>

</body>
</html>


