<html>


	<head>
	<link rel="stylesheet" href="/css/style.css">
	</head>
	<body>
	<h1><?= $titulo ?></h1>

	<?php foreach($datos as $i => $row):
	echo "<pre>";
	print_r($row);	
    echo "</pre>";
	?>

	<?php endforeach; ?>

	</body>
</html>


