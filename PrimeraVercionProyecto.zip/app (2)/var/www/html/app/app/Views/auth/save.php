<html>
	<head>
	</head>
	<body>
	<h1><?= $titulo ?></h1>

	<?php echo var_dump($datos); ?>



	</body>
</html>


