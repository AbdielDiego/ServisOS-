<?php echo "show clientes ";?>
