<nav>
	
	<a href="/" >Inicio</a>
    
	<?php if ( isset($_SESSION['user'] ) ): ?>
    	<a href="/Perfil" >Perfil</a>
    	<a href="/auth/logout" >Cerrar sesión</a>
	<?php else: ?>
 	<a href="/auth/login" >Login</a>
 	<a href="/app/clientes" >Clientes</a>
 	<a href="/app/servicios" >Servicios</a>
   

  <?php endif; ?>
</nav>

