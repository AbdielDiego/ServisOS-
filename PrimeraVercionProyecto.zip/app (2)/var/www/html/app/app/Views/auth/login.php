<?php


// Procesar el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Simulamos login exitoso (esto sería con DB en producción)
    if ($email === 'jvdeoli@gmail.com' && $password === 'mi password') {
        $_SESSION['usuario'] = $email;
        $_SESSION['mensaje'] = 'Cuenta logueada';
        header("Location: /login"); // Recargar la página para evitar re-envío
        exit;
    } else {
        $_SESSION['mensaje'] = 'Credenciales incorrectas';
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: radial-gradient(circle at top, #1a1a2e, #16213e);
            color: #fff;
            font-family: 'Roboto', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            min-height: 100vh;
        }

        h2 {
            margin-top: 40px;
        }

        form {
            max-width: 300px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            padding: 20px;
            backdrop-filter: blur(6px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.3);
            margin-top: 20px;
        }

        label, input {
            display: block;
            width: 100%;
            margin-bottom: 10px;
        }

        input {
            padding: 8px;
            border-radius: 5px;
            border: none;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #00ffe1;
            color: #111;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            box-shadow: 0 0 12px #00ffe1;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background-color: #00e0c6;
        }

        .mensaje {
            margin-top: 15px;
            background-color: #00ffe120;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #00ffe1;
            color: #00ffe1;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h2>Iniciar sesión</h2>

    <?php if (isset($_SESSION['mensaje'])): ?>
        <div class="mensaje"><?= $_SESSION['mensaje'] ?></div>
        <?php unset($_SESSION['mensaje']); ?>
    <?php endif; ?>

    <form method="POST">
        <div>
            <label>Email:</label>
            <input type="email" name="email" required value="jvdeoli@gmail.com">
        </div>

        <div>
            <label>Contraseña:</label>
            <input type="password" name="password" required value="mi password">
        </div>

        <button type="submit">Ingresar</button>
    </form>

</body>
</html>


