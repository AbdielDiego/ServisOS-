<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&family=Roboto&display=swap" rel="stylesheet">
    <title>Listado de Servicios</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: radial-gradient(circle at top, #1a1a2e, #16213e);
            color: #fff;
            font-family: 'Roboto', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            min-height: 100vh;
        }

        h1 {
            font-family: 'Orbitron', sans-serif;
            font-size: 2.5rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: #00ffe1;
            text-shadow: 0 0 10px #00ffe1;
            margin-top: 40px;
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            padding: 20px 30px;
            margin: 20px;
            width: 90%;
            max-width: 500px;
            backdrop-filter: blur(6px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.3);
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card p {
            margin: 10px 0;
            font-size: 1.1rem;
        }

        .rating {
            display: flex;
            justify-content: start;
            gap: 8px;
            margin-top: 10px;
        }

        .rating input {
            display: none;
        }

        .rating label {
            font-size: 25px;
            color: #555;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .rating input:checked ~ label,
        .rating label:hover,
        .rating label:hover ~ label {
            color: #00ffe1;
            text-shadow: 0 0 5px #00ffe1;
        }

        footer {
            margin-top: auto;
            padding: 15px;
            text-align: center;
            color: #aaa;
            font-size: 0.9rem;
        }

        .right-align {
            align-self: flex-end;
            margin-right: 5%;
        }

        .search-form {
            margin-bottom: 20px;
            width: 90%;
            max-width: 500px;
        }

        .search-form input {
            width: 100%;
            padding: 10px 15px;
            border-radius: 8px;
            border: none;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.15);
            color: #fff;
            box-shadow: 0 0 8px #00ffe1;
            outline: none;
        }
    </style>
</head>
<body>

    <h1>Servicios</h1>

    <form method="GET" class="search-form">
        <input 
            type="text" 
            name="buscar" 
            placeholder="Buscar servicio..." 
            value="<?= htmlspecialchars($_GET['buscar'] ?? '') ?>"
        >
    </form>

    <?php if (count($servicios) == 0): ?>
        <h1>NO HAY SERVICIOS</h1>
    <?php else: ?>
        <?php foreach ($servicios as $i => $serv): ?>
            <div class="card <?= $i === 1 ? 'right-align' : '' ?>">

                <?php
                    $imagen = '/imagenes/default.png';
                    if ($serv['nombre'] === 'Carpintería') {
                        $imagen = '/imagenes/ChivitaCarpintera.jpeg';
                    } elseif ($serv['nombre'] === 'Electricidad') {
                        $imagen = '/imagenes/ChivitaElectricista.png';
                    }
                ?>
                <img src="<?= $imagen ?>" alt="Imagen del servicio" style="width: 15%; border-radius: 10px; margin-bottom: 15px;">

                <p><strong>ID:</strong> <?= htmlspecialchars($serv["id"]) ?></p>
                <p><strong>Nombre:</strong> <?= htmlspecialchars($serv["nombre"]) ?></p>
                <p><strong>Descripción:</strong> <?= htmlspecialchars($serv["descripcion"]) ?></p>
                <p><strong>Precio:</strong> $<?= htmlspecialchars($serv["precio"]) ?></p>

                <div class="rating">
                    <?php for ($star = 5; $star >= 1; $star--): ?>
                        <input type="radio" name="rating_<?= $i ?>" id="star<?= $star ?>_<?= $i ?>" value="<?= $star ?>">
                        <label for="star<?= $star ?>_<?= $i ?>">★</label>
                    <?php endfor; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

</body>
</html>

