<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Mini Framework' ?></title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 0; 
            padding: 0;
            line-height: 1.6;
        }
        header { 
            background: #333; 
            color: white; 
            padding: 1rem;
        }
        .container { 
            width: 80%; 
            margin: 0 auto;
            padding: 20px;
        }
        nav a {
            color: white;
            text-decoration: none;
            margin-right: 15px;
        }
        nav a:hover {
            text-decoration: underline;
        }
        .active { 
            font-weight: bold; 
        }
        .error {
            color: red;
            margin-bottom: 1rem;
        }
        form div {
            margin-bottom: 1rem;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        button {
            padding: 8px 16px;
            background: #333;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background: #555;
        }
        .alert {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }

     .tabla, td, th {
            background-color: #d4edda;
            color: #155724;
            border-collapse: collapse;
            border: 1px dotted navy;
        }
   
    </style>
</head>
<body>
    <header>
        <?php require( __DIR__.'/menu.php'); ?>
    </header>

    <main class="container">
        <?php echo $content ?>
    </main>
</body>
</html>
