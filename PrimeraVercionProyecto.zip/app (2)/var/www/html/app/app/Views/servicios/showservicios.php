<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Detalle del Servicio</title>
</head>
<body>

    <h1>Detalle del Servicio</h1>

    <?php if ($servicio): ?>
        <p><strong>ID:</strong> <?= $servicio["id"] ?></p>
        <p><strong>Nombre:</strong> <?= $servicio["nombre"] ?></p>
        <p><strong>Descripción:</strong> <?= $servicio["descripcion"] ?></p>
        <p><strong>Precio:</strong> $<?= $servicio["precio"] ?></p>
    <?php else: ?>
        <p>Servicio no encontrado.</p>
    <?php endif; ?>

</body>
</html>

