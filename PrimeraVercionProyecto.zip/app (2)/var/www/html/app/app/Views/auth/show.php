<html>
	<head>
	</head>
	<body>
	<h1><?= $titulo ?></h1>

	

	<?php foreach($datos as $i => $row):
	echo "<pre>";
	print_r($row);	
	?>

	<?php endforeach; ?>

	</body>
</html>


