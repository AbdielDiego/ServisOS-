<?php

namespace App\Views;

class View{


	public function render($vista,$dat){

	
		extract($dat);

    ob_start();
	
	include(__DIR__."/$vista".".php");

    $content = ob_get_clean();

    include( __DIR__."/layouts/main.php");	


	}


}
