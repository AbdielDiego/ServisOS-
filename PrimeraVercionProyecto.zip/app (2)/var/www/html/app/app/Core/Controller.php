<?php
// Define el namespace donde se encuentra esta clase
namespace App\Core;

// Importa otras clases del core necesarias
use App\Core\View;
use App\Core\Database;
use App\Core\Model;

/**
 * Controlador base del que heredan todos los controladores
 */
class Controller {
    // Propiedades protegidas disponibles para todos los controladores que hereden
    protected $view;
    protected $db;

    /**
     * Constructor: inicializa la vista y la conexión a la base de datos
     */
    public function __construct() {
        $this->view = new View();                 // Instancia de la clase View para renderizar vistas
        $this->db = Database::getInstance();      // Obtiene una instancia única de la base de datos (patrón Singleton)
    }

    /**
     * Obtiene de forma segura un valor enviado por POST
     * Si no existe, devuelve un valor por defecto
     */
    public function input($key, $default = '') {
        return $_POST[$key] ?? $default;
    }

    /**
     * Renderiza una vista pasando datos y opcionalmente un layout
     */
    protected function render($view, $data = [], $layout = "main") {
        try {
            $this->view->render($view, $data, $layout); // Llama al renderizador de vistas
        } catch (\Exception $e) {
            error_log("Error al renderizar vista: " . $e->getMessage()); // Registra error en el log
            http_response_code(500); // Devuelve código de error HTTP 500
            // Renderiza una vista de error personalizada
            $this->view->render("errors/general", ["message" => "Ocurrió un error interno."], "error");
        }
    }

    /**
     * Redirige al usuario a otra URL dentro o fuera del sitio
     */
    protected function redirect($url) {
        // Si no tiene protocolo http/https, se construye la URL base del sitio
        if (!preg_match("/^https?:\/\//", $url)) {
            $url = $this->getBaseUrl() . ltrim($url, "/");
        }
        header("Location: {$url}"); // Redirección
        exit;                       // Finaliza el script
    }

    /**
     * Valida los campos enviados en un formulario
     * Recibe un array con reglas del tipo 'campo' => 'regla1|regla2'
     */
    public function validate(array $rules) {
        $errors = [];

        foreach ($rules as $field => $rule) {
            $value = trim($_POST[$field] ?? '');

            foreach (explode('|', $rule) as $r) {
                if ($r === 'required' && $value === '') {
                    $errors[$field] = "El campo $field es obligatorio";
                }
                if ($r === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $errors[$field] = "El campo $field debe ser un email válido";
                }
                if (str_starts_with($r, 'min:')) {
                    $min = (int)explode(':', $r)[1];
                    if (strlen($value) < $min) {
                        $errors[$field] = "El campo $field debe tener al menos $min caracteres";
                    }
                }
            }
        }

        return $errors; // Devuelve array con errores encontrados
    }

    /**
     * Verifica si hay un usuario logueado
     */
    protected function isAuthenticated() {
        return isset($_SESSION["user_id"]);
    }

    /**
     * Devuelve los datos del usuario autenticado, si existe en la sesión
     */
    protected function getAuthenticatedUser() {
        if (isset($_SESSION["user_id"])) {
            // Consulta para obtener los datos del usuario autenticado
            $user = $this->db->query(
                "SELECT id, username, email FROM users WHERE id = ?",
                [$_SESSION["user_id"]]
            )->fetch();
            return $user ?: null; // Devuelve los datos o null si no existe
        }
        return null;
    }

    /**
     * Obtiene la URL base del proyecto actual (útil para redirecciones)
     */
    private function getBaseUrl() {
        // Detecta si se está usando HTTPS o HTTP
        $protocol = isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] === "on" ? "https" : "http";
        $host = $_SERVER["HTTP_HOST"];                       // Ej: localhost o dominio
        $script = $_SERVER["SCRIPT_NAME"];                   // Ruta al archivo index.php
        $path = str_replace("index.php", "", $script);       // Quita 'index.php' de la ruta

        return "{$protocol}://{$host}{$path}";               // Devuelve la URL base del proyecto
    }
}

