<?php
// Declara el namespace del núcleo del framework
namespace App\Core;

/**
 * Clase Session: permite guardar y recuperar mensajes "flash" de sesión
 * Los mensajes flash son temporales: existen solo hasta la siguiente carga de página
 */
class Session {

    /**
     * Guarda un mensaje flash en la sesión
     * @param string $key Clave del mensaje (ej: 'success', 'error')
     * @param string $message Contenido del mensaje
     */
    public function flash($key, $message) {
        // Si la sesión no está iniciada, la inicia
        if (!isset($_SESSION)) {
            session_start();
        }

        // Guarda el mensaje en $_SESSION['flash'] bajo la clave dada
        $_SESSION['flash'][$key] = $message;
    }

    /**
     * Obtiene y elimina un mensaje flash de la sesión
     * @param string $key Clave del mensaje a recuperar
     * @return string|null El mensaje o null si no existe
     */
    public function getFlash($key) {
        // Asegura que la sesión esté activa
        if (!isset($_SESSION)) {
            session_start();
        }

        // Si existe el mensaje flash, lo devuelve y lo borra (sólo dura una vez)
        if (isset($_SESSION['flash'][$key])) {
            $msg = $_SESSION['flash'][$key];
            unset($_SESSION['flash'][$key]); // Elimina para que no se repita
            return $msg;
        }

        // Si no hay mensaje, devuelve null
        return null;
    }
}


