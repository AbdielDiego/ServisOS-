<?php
namespace App\Core;


class Model {
	protected $db;
	protected $table;
	protected $primaryKey = "id";
    
	
	public function __construct() {
    	$this->db = Database::getInstance();
	}
    
	
	public function all() {
    	$query = $this->db->query("SELECT * FROM {$this->table}");
    	return $query->fetchAll();
	}
    
	
	public function find($id) {
    	$query = $this->db->query(
        	"SELECT * FROM {$this->table} WHERE {$this->primaryKey} = ? LIMIT 1",
        	[$id]
    	);
    	return $query->fetch() ?: null;
	}

	
	public function findBy($column, $value) {
    	$query = $this->db->query(
        	"SELECT * FROM {$this->table} WHERE {$column} = ? LIMIT 1",
        	[$value]
    	);
    	return $query->fetch() ?: null;
	}
    
	
	public function create($data) {
    	$columns = implode(", ", array_keys($data));
    	$placeholders = implode(", ", array_fill(0, count($data), "?"));
   	 
    	$sql = "INSERT INTO {$this->table} ({$columns}) VALUES ({$placeholders})";
    	$this->db->query($sql, array_values($data));
   	 
    	return $this->db->lastInsertId();
	}
    
	
	public function update($id, $data) {
    	$setParts = [];
    	foreach (array_keys($data) as $column) {
        	$setParts[] = "{$column} = ?";
    	}
   	 
    	$sql = "UPDATE {$this->table} SET " . implode(", ", $setParts) . " WHERE {$this->primaryKey} = ?";
    	$params = array_merge(array_values($data), [$id]);
   	 
    	$this->db->query($sql, $params);
    	return true;
	}
    
	
	public function delete($id) {
    	$sql = "DELETE FROM {$this->table} WHERE {$this->primaryKey} = ?";
    	$this->db->query($sql, [$id]);
    	return true;
	}
}



