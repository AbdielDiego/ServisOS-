<?php
namespace App\Services;

use App\Core\Session;
use App\Models\User;

class AuthService
{
    protected $session;
    protected $userModel;

    /**
     * Clave canónica que define "usuario autenticado" en toda la app.
     */
    protected $sessionKey = 'auth_user_id';

    public function __construct(Session $session)
    {
        $this->session   = $session;
        $this->userModel = new User();
    }

    /**
     * Intentar iniciar sesión.
     * Devuelve el usuario (array) si OK, o null si falla.
     */
    public function attempt(string $email, string $password): ?array
    {
        $user = $this->userModel->findByEmail($email);

        if ($user && $this->verifyPassword($password, $user['password'])) {
            // Seteamos sesión canónica de login
            $this->session->set($this->sessionKey, $user['user_id']);

            // Datos útiles para la UI
            if (isset($user['username'])) {
                $this->session->set('username', $user['username']);
            }

            // Derivar rol para la sesión: rol_name / rol / rol_id
            $rolName = $user['rol_name']
                ?? ($user['rol']
                ?? ((isset($user['rol_id']) && (int)$user['rol_id'] === 1) ? 'Admin' : 'User'));
            $this->session->set('rol', $rolName);

            return $user;
        }

        return null;
    }

    /**
     * Registrar un usuario y devolver su ID.
     * - Normaliza campos
     * - Hashea password
     * - Mapea rol_name del formulario a rol_id (Admin=1, User=2)
     */
    public function register(array $data): ?int
    {
        // Normalizo nombres
        if (isset($data['name']) && !isset($data['username'])) {
            $data['username'] = $data['name'];
            unset($data['name']);
        }

        // Saneos mínimos
        $data['username'] = trim($data['username'] ?? '');
        $data['email']    = trim($data['email'] ?? '');
        $data['password'] = $this->hashPassword($data['password'] ?? '');

        // === Mapear rol del formulario a rol_id de la BD ===
        // Aceptamos 'rol_name' del form ("Admin" | "User") y lo convertimos.
        $rolNameFromForm = isset($data['rol_name']) ? trim((string)$data['rol_name']) : '';
        $rolIdFromForm   = isset($data['rol_id']) ? (int)$data['rol_id'] : null;

        if ($rolIdFromForm !== null) {
            // Si ya vino rol_id directo, úsalo
            $data['rol_id'] = max(1, (int)$rolIdFromForm);
        } else {
            // Mapear por nombre (Admin=1, User=2)
            $map = ['admin' => 1, 'user' => 2];
            $key = strtolower($rolNameFromForm ?: 'user');
            $data['rol_id'] = $map[$key] ?? 2;
        }

        // MUY IMPORTANTE: no intentes insertar rol_name si la tabla no lo tiene
        unset($data['rol_name']);

        // Crear en BD con columnas válidas (username, email, password, rol_id...)
        $newId = $this->userModel->create($data);
        return is_numeric($newId) ? (int)$newId : null;
    }

    /** ¿Hay usuario autenticado? */
    public function check(): bool
    {
        return $this->session->has($this->sessionKey);
    }

    /** Usuario actual desde BD */
    public function user(): ?array
    {
        if (!$this->check()) {
            return null;
        }
        return $this->userModel->find(['user_id' => $this->session->get($this->sessionKey)]);
    }

    /** Cerrar sesión */
    public function logout(): void
    {
        $this->session->remove($this->sessionKey);
        $this->session->remove('username');
        $this->session->remove('rol');
    }

    /** Helpers de password */
    protected function hashPassword(string $plain): string
    {
        return password_hash($plain, PASSWORD_BCRYPT);
    }

    protected function verifyPassword(string $plain, string $hash): bool
    {
        return password_verify($plain, $hash);
    }
}


