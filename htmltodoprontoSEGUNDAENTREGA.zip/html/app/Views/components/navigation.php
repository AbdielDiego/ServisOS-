<link rel="stylesheet" href="css/homepage.css">
<nav>
    <a href="/" class="<?= ($currentUrl === '/' || $currentUrl === '') ? 'active' : '' ?>">Inicio</a>

    <?php if ($auth['check']): ?>
        <a href="/dashboard" class="<?= (strpos($currentUrl, '/dashboard') === 0) ? 'active' : '' ?>">Dashboard</a>
        <a href="/logout">Cerrar sesión</a>
    <?php else: ?>
        <a href="/login" class="<?= ($currentUrl === '/login') ? 'active' : '' ?>">Login</a>
    <?php endif; ?>

    <?php
    //  Detectar rol Admin de varias formas:
    $user      = $auth['user'] ?? null;
    $rolName   = $user['rol_name'] ?? ($user['rol'] ?? ($_SESSION['rol'] ?? ''));
    $rolId     = isset($user['rol_id']) ? (int)$user['rol_id'] : 0;
    $isAdmin   = (strtolower((string)$rolName) === 'admin') || ($rolId === 1);

    if ($auth['check'] && $isAdmin): ?>
        <a href="/usuarios" class="<?= ($currentUrl === '/usuarios') ? 'active' : '' ?>">Usuarios</a>
    <?php endif; ?>

    <a href="/post" class="<?= ($currentUrl === '/post') ? 'active' : '' ?>">Posts</a>
    <a href="/apicategorias" class="<?= ($currentUrl === '/apicategorias') ? 'active' : '' ?>">Categorias</a>
    <a href="/register" class="<?= ($currentUrl === '/register') ? 'active' : '' ?>">Registrarse</a>
</nav>

