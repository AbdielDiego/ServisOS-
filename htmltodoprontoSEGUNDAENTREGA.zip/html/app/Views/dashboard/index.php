 <link rel="stylesheet" href="css/homepage.css">
    <h1>Dashboard</h1>
    <p>Bienvenid@ a tu area privada, <?= htmlspecialchars($user['username']) ?>.</p>
    
    <p>Datos del usuario:</p>
    <ul>
        <li>ID del Perfil: <?= $user['user_id'] ?></li>
        <li>ID 1 es Admin, 2 Es usuario Comun: <?= $user['rol_id'] ?></li>
        <li>Fecha de Creacion del perfil: <?= $user['created_at'] ?></li>
        <li>Nombre de Usuario: <?= $user['username'] ?></li>
        <li>Email: <?= htmlspecialchars($user['email']) ?></li>
    </ul>
    
   

