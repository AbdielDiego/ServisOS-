 <link rel="stylesheet" href="css/homepage.css">
    <h2>Iniciar sesión</h2>

    <form method="POST" style="max-width: 300px;">
        <div>
            <label>Email:</label>
            <input type="email" name="email" required value="admin@example.com">
            <small>Usar: admin@example.com</small>
        </div>
        
        <div>
            <label>Contraseña:</label>
            <input type="password" name="password" required value="1234">
            <small>Usar: 1234</small>
        </div>
        
        <button type="submit">Ingresar</button>
    </form>

