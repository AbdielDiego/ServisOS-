<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Post;

class PostController extends Controller
{
    private $modelo;

    public function __construct()
    {
        $this->modelo = new Post();
        parent::__construct();
    }

    /**
     * Index con soporte para params del router y/o querystring.
     * - Si la ruta es /post/paginar/:pagina, el router pasará ['pagina' => '...'].
     * - Si viene por ?pagina=, también lo toma.
     */
    public function index(array $params = []): void
    {
        // Página segura (int >= 1)
        $pagina = (int)($params['pagina'] ?? ($_GET['pagina'] ?? 1));
        $pagina = max(1, $pagina);

        // Paginación (el modelo ya castea/valida internamente también)
        $datos = $this->modelo->sqlPaginado($pagina);

        // Mensaje flash opcional
        $this->session->flash('success', 'G ');

        // Datos para la vista
        $datos['baseUrl'] = '/post/paginar';
        $datos['titulo']  = 'Todos los Post ingresados';

        // Render
        $this->render('post/index', $datos);
    }
}


// $sql = "SELECT u.username, c.name, p.title, p.content // FROM Posts p // JOIN Categories c ON p.category_id = c.category_id // JOIN Users u ON u.user_id = p.user_id // ORDER BY p.user_id, p.category_id";


