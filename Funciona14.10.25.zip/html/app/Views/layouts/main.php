<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= htmlspecialchars($title ?? 'Chivita Recomienda', ENT_QUOTES, 'UTF-8') ?></title>
<?php
  $PUBLIC_BASE = rtrim(str_replace('\\','/', dirname($_SERVER['SCRIPT_NAME'])), '/');
  if ($PUBLIC_BASE === '.' || $PUBLIC_BASE === '/') $PUBLIC_BASE = '';

  $ROOT = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 3);

  $cssMainPath = $ROOT . '/public/css/styles.css';
  $cssUCPath   = $ROOT . '/public/css/user-corner.css';
  $cssMsgPath  = $ROOT . '/public/css/message-corner.css';
  $cssMinPath  = $ROOT . '/public/css/minuevo.css';

  $cssMainVer  = @filemtime($cssMainPath) ?: time();
  $cssUCVer    = @filemtime($cssUCPath)   ?: $cssMainVer;
  $cssMsgVer   = @filemtime($cssMsgPath)  ?: $cssMainVer;
  $cssMinVer   = @filemtime($cssMinPath)  ?: $cssMainVer;
?>
<link rel="stylesheet" href="<?= $PUBLIC_BASE ?>/css/styles.css?v=<?= $cssMainVer ?>">
<link rel="stylesheet" href="<?= $PUBLIC_BASE ?>/css/user-corner.css?v=<?= $cssUCVer ?>">
<link rel="stylesheet" href="<?= $PUBLIC_BASE ?>/css/message-corner.css?v=<?= $cssMsgVer ?>">
<link rel="stylesheet" href="<?= $PUBLIC_BASE ?>/css/minuevo.css?v=<?= $cssMinVer ?>">

<body class="theme-clean minuevo">
  <header>
    <?php $this->component('navigation') ?>
  </header>

  <main class="container">
    <?php $this->component('flash-messages') ?>
    <?= $content ?>
  </main>

  <?php $this->component('user-corner') ?>
  <?php $this->component('message-corner') ?>
</body>
</html>

