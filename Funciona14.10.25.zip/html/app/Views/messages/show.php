<link rel="stylesheet" href="/css/inbox.css">
<?php
/** @var array $message */
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
$from = $message['from_name'] ?: ($message['from_email'] ?? 'Desconocido');
?>
<div>
  <h1>Mensaje</h1>

  <p><strong>De:</strong> <?= h($from) ?></p>
  <p><strong>Fecha:</strong> <?= h($message['created_at']) ?></p>

  <hr>

  <div><?= nl2br(h($message['body'])) ?></div>

  <p style="margin-top:1rem"><a href="/messages/inbox">Volver al inbox</a></p>
</div>

