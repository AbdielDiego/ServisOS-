<?php
/** @var array $post */
/** @var array $comments */

// Helper de escape
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// Datos del post
$postId  = (int)($post['post_id'] ?? 0);
$title   = h($post['title'] ?? 'Post');
$content = nl2br(h($post['content'] ?? ''));

// Base path para acciones
$bpRaw = rtrim($basePath ?? '', '/');
$bp    = h($bpRaw);

// ---- Autenticación y permisos (compat con $_SESSION / $auth / $session) ----
$viewerId = (int)(
    $auth['user']['user_id']    ?? $auth['user']['id'] ??
    ($_SESSION['user_id']       ?? ($_SESSION['user']['user_id'] ?? 0))
);

$viewerRol = (string)(
    $auth['user']['rol_name']   ?? $_SESSION['rol'] ?? ($_SESSION['user']['rol_name'] ?? '')
);
$viewerRolId = (int)(
    $_SESSION['rol_id']         ?? ($_SESSION['user']['rol_id'] ?? 0)
);

$isAdmin = ($viewerRol === 'Admin') || ($viewerRolId === 1);

$isAuth = $viewerId > 0
    || (!empty($auth['check']))
    || (isset($session) && is_object($session) && method_exists($session, 'has') && $session->has('auth_user_id'));
?>

<!-- ====== Contenido del post ====== -->
<article>
  <h1><?= $title ?></h1>
  <div class="post-body"><?= $content ?></div>
</article>

<!-- ====== Formulario: Comentar ====== -->
<h2 id="comentar">Comentar</h2>
<?php if ($isAuth): ?>
  <form action="<?= $bp ?>/comments" method="post" class="form-comentario">
    <input type="hidden" name="post_id" value="<?= $postId ?>">
    <textarea name="comment_text" rows="3" required minlength="2" placeholder="Escribe tu comentario..."></textarea>
    <button type="submit">Publicar</button>
  </form>
<?php else: ?>
  <p><a href="<?= $bp ?>/login">Inicia sesión</a> para comentar.</p>
<?php endif; ?>

<!-- ====== Listado de comentarios ====== -->
<hr id="comentarios">
<h2>Comentarios</h2>

<?php if (empty($comments)): ?>
  <p>No hay comentarios aún.</p>
<?php else: ?>
  <ul class="comentarios-lista">
    <?php foreach ($comments as $c): ?>
      <?php
        $cid    = (int)($c['comment_id'] ?? 0);
        $owner  = (int)($c['user_id'] ?? 0);
        $uname  = h($c['username'] ?? 'anónimo');
        $texto  = nl2br(h($c['comment_text'] ?? ''));
        $fecha  = h($c['created_at'] ?? '');
        $canDel = ($isAdmin || ($owner > 0 && $owner === $viewerId));
      ?>
      <li class="comentario-item">
        <div class="comentario-cab">
          <strong><?= $uname ?></strong>
          <small><?= $fecha ?></small>

          <?php if ($canDel): ?>
            <form action="<?= $bp ?>/comment/delete" method="POST" class="form-del-comentario">
              <input type="hidden" name="comment_id" value="<?= $cid ?>">
              <button type="submit" class="btn btn-delete" onclick="return confirm('¿Eliminar este comentario?')">
                Eliminar
              </button>
            </form>
          <?php endif; ?>
        </div>

        <div class="comentario-texto"><?= $texto ?></div>
      </li>
    <?php endforeach; ?>
  </ul>
<?php endif; ?>

