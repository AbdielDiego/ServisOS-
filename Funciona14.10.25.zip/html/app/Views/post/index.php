<?php
require BASE_PATH . "/app/Views/components/paginar.php";

// Fallback por si $BASE no está seteado en la vista
$BASE = isset($BASE) ? $BASE : htmlspecialchars(rtrim($basePath ?? '', '/'), ENT_QUOTES, 'UTF-8');
?>

<tbody>
<?php foreach ($posts as $p): ?>
  <?php
    $id  = (int)($p['post_id'] ?? 0);

    // Rating simple: toma cualquiera de estas columnas si viene en el SELECT
    $ratingCols = ['average_rating','avg','promedio','rating'];
    $ratingVal  = null;
    foreach ($ratingCols as $rc) {
      if (array_key_exists($rc, $p)) { $ratingVal = $p[$rc]; break; }
    }
    $rating = (int)round(is_numeric($ratingVal ?? null) ? (float)$ratingVal : 1);
    if ($rating < 1) $rating = 1;
    if ($rating > 5) $rating = 5;
  ?>
  <tr>
    <td><?= (int)$p['post_id'] ?></td>
    <td><?= (int)$p['user_id'] ?></td>
    <td><?= (int)$p['category_id'] ?></td>
    <td><?= htmlspecialchars($p['title'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
    <td><?= htmlspecialchars($p['content'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
    <td><?= htmlspecialchars($p['created_at'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
    <td><?= htmlspecialchars($p['updated_at'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>

    <!-- Acciones -->
    <td class="td-actions">
      <?php if ($id > 0): ?>
        <a class="btn btn-sm" href="<?= $BASE ?>/post/<?= $id ?>#comentar">Comentar</a>
        <!-- NUEVO: Ver detalle -->
        <a class="btn btn-sm btn-outline" href="<?= $BASE ?>/post/<?= $id ?>">Ver detalle</a>
        <a class="btn btn-sm" href="<?= $BASE ?>/post/<?= $id ?>#comentarios">Ver comentarios</a>

        <!-- Rating 1→5 -->
        <span class="rating-simple" data-id="<?= $id ?>">
          <span class="rating-value"><?= $rating ?></span>/5
          <form action="<?= $BASE ?>/api/rate/simple" method="post" class="rating-form" style="display:inline">
            <input type="hidden" name="id" value="<?= $id ?>">
            <input type="hidden" name="rating" class="rating-input" value="<?= $rating ?>">
            <button type="button" class="btn btn-sm btn-increment" title="Subir rating">➕</button>
          </form>
        </span>
      <?php else: ?>
        —
      <?php endif; ?>
    </td>
  </tr>
<?php endforeach; ?>
</tbody>

<script>
(function(){
  document.querySelectorAll('.rating-simple').forEach(function(box){
    var valueEl = box.querySelector('.rating-value');
    var inputEl = box.querySelector('.rating-input');
    var btn     = box.querySelector('.btn-increment');
    if (!btn) return;

    btn.addEventListener('click', function(){
      var val = parseInt(valueEl.textContent, 10);
      val = (val >= 5) ? 1 : (val + 1); // ciclo 1→5
      valueEl.textContent = val;
      inputEl.value = val;

      var form = btn.closest('form');
      var fd = new FormData(form);
      fetch(form.action, { method: 'POST', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(data){ if (!data.ok) alert(data.msg || "Error al guardar rating"); })
        .catch(function(err){ console.error(err); });
    });
  });
})();
</script>







