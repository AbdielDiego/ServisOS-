<?php

$datosTabla = $datosTabla ?? [];

$userId = null;
// Intentar con \App\Core\Auth NO estático
try {
    if (class_exists('\App\Core\Auth')) {
        $auth = new \App\Core\Auth();
        if (method_exists($auth, 'user')) {
            $u = $auth->user();
            if (is_array($u)) {
                if (!empty($u['user_id'])) $userId = (int)$u['user_id'];
                elseif (!empty($u['id']))  $userId = (int)$u['id'];
            } elseif (is_object($u)) {
                if (!empty($u->user_id)) $userId = (int)$u->user_id;
                elseif (!empty($u->id))  $userId = (int)$u->id;
            }
        }
    }
} catch (\Throwable $e) { /* ignorar */ }
// Fallback por sesión
if (!$userId && !empty($_SESSION['user']['user_id'])) $userId = (int)$_SESSION['user']['user_id'];
if (!$userId && !empty($_SESSION['user']['id']))      $userId = (int)$_SESSION['user']['id'];

// Obtener PDO
$pdo = null;
try {
    if (isset($this) && property_exists($this,'container') && isset($this->container['db']) && $this->container['db'] instanceof \PDO) {
        $pdo = $this->container['db'];
    }
    if (!$pdo && class_exists('\App\Core\Database') && method_exists('\App\Core\Database','getInstance')) {
        $inst = \App\Core\Database::getInstance();
        if ($inst) {
            if (method_exists($inst,'getConnection')) { $p = $inst->getConnection(); if ($p instanceof \PDO) $pdo = $p; }
            if (!$pdo && property_exists($inst,'pdo') && $inst->pdo instanceof \PDO) $pdo = $inst->pdo;
        }
    }
    if (!$pdo && class_exists('\App\Core\Model') && method_exists('\App\Core\Model','pdo')) {
        $p = \App\Core\Model::pdo(); if ($p instanceof \PDO) $pdo = $p;
    }
    if (!$pdo && function_exists('db')) {
        $p = db(); if ($p instanceof \PDO) $pdo = $p;
    }
} catch (\Throwable $e) { $pdo = null; }
/* ------------------------- fin helpers ------------------------- */

if (!empty($datosTabla)) {

    // Columnas (todas)
    if (isset($datosTabla[0]) && is_array($datosTabla[0])) {
        $columnas = array_keys($datosTabla[0]);
    } else {
        $columnas  = array_keys((array)$datosTabla);
        $datosTabla = [ $datosTabla ];
    }

    // Base pública (para armar URLs correctas)
    $BASE = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

    // Detectar mejor columna ID (usando el conjunto completo de columnas)
    $encontrarColumnaId = function(array $filas, array $cols): ?string {
        if (empty($filas)) return null;
        $esNumerica = function($v) { return is_numeric($v) && $v !== ''; };

        $scores = [];
        foreach ($cols as $c) {
            $lc = strtolower($c);
            $score = 0;
            if ($lc === 'post_id' || $lc === 'id_post') { $score += 100; }
            if (str_contains($lc, 'post') && str_contains($lc, 'id')) { $score += 80; }
            if ($lc === 'id') { $score += 60; }
            if (str_ends_with($lc, '_id')) { $score += 40; }

            $vals = [];
            $todosNumericos = true;
            foreach ($filas as $f) {
                $v = $f[$c] ?? null;
                if (!$esNumerica($v)) { $todosNumericos = false; break; }
                $vals[] = (string)$v;
            }
            if (!$todosNumericos) continue;

            $distinct = count(array_unique($vals));
            if ($distinct < max(2, (int)floor(count($vals) * 0.5))) continue;

            $scores[$c] = $score;
        }

        if (empty($scores)) return null;
        arsort($scores, SORT_NUMERIC);
        $mejor = array_key_first($scores);
        return $mejor ?: null;
    };

    $colId = $encontrarColumnaId($datosTabla, $columnas);

    // === Visibilidad / renombrado de columnas ===
    // Ocultar: post_id, user_id, category_id, created_at, updated_at (y 'user_i' por si hay typo)
    $ocultas = ['post_id','user_id','category_id','created_at','updated_at','user_i'];
    $mostrarCol = function(string $c) use ($ocultas): bool {
        return !in_array(strtolower($c), $ocultas, true);
    };
    $columnasVisibles = array_values(array_filter($columnas, $mostrarCol));

    // Mapeo de nombres a mostrar
    $labelCol = function(string $c): string {
        $lc = strtolower($c);
        if ($lc === 'title')   return 'Servicio';
        if ($lc === 'content') return 'descripcion del servicio';
        return $c;
    };
    ?>
    <table class="tabla users-table tabla-compact">
        <thead>
            <tr>
                <?php foreach ($columnasVisibles as $col): ?>
                    <th><?= htmlspecialchars($labelCol($col), ENT_QUOTES, 'UTF-8') ?></th>
                <?php endforeach; ?>
                <?php if ($colId): ?>
                    <th>Acciones</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($datosTabla as $fila): ?>
            <tr>
                <?php foreach ($columnasVisibles as $col): ?>
                    <td><?= htmlspecialchars((string)($fila[$col] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                <?php endforeach; ?>

                <?php if ($colId): ?>
                    <?php
                        $idVal = $fila[$colId] ?? null;
                        $id    = is_numeric($idVal) ? (int)$idVal : 0;

                        // Calcular $rating a mostrar
                        $ratingCols = ['average_rating','avg','promedio','rating'];
                        $ratingVal  = null;
                        foreach ($ratingCols as $rc) {
                            if (array_key_exists($rc, $fila)) { $ratingVal = $fila[$rc]; break; }
                        }
                        if (is_numeric($ratingVal)) {
                            $rating = (int)round((float)$ratingVal);
                        } else {
                            $rating = 1;
                            if ($pdo instanceof \PDO && $userId && $id > 0) {
                                try {
                                    $st = $pdo->prepare('SELECT rating FROM post_ratings WHERE post_id = ? AND user_id = ? LIMIT 1');
                                    $st->execute([$id, $userId]);
                                    $r = $st->fetch(\PDO::FETCH_ASSOC);
                                    if ($r && isset($r['rating']) && is_numeric($r['rating'])) {
                                        $rating = (int)$r['rating'];
                                    }
                                } catch (\Throwable $e) { /* ignorar lectura */ }
                            }
                        }
                        if ($rating < 1) $rating = 1;
                        if ($rating > 5) $rating = 5;
                    ?>

                    <td class="td-actions">
                    <?php if ($id > 0): ?>
                        <a class="btn btn-sm" href="<?= $BASE ?>/post/<?= $id ?>#comentar">Comentar</a>

                        <!-- NUEVO: Ver detalle -->
                        <a class="btn btn-sm btn-outline" href="<?= $BASE ?>/post/<?= $id ?>">Ver detalle</a>

                        <a class="btn btn-sm" href="<?= $BASE ?>/post/<?= $id ?>#comentarios">Ver comentarios</a>

                        <?php if ($userId): ?>
                            <form action="<?= $BASE ?>/api/rate/simple" method="post" style="display:inline">
                                <input type="hidden" name="id" value="<?= $id ?>">
                                <button type="submit" class="btn btn-sm" title="Subir mi rating">
                                    <?= $rating ?>/5 ➕
                                </button>
                            </form>
                        <?php else: ?>
                            <span class="muted" title="Inicia sesión para votar">1/5</span>
                        <?php endif; ?>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                    </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php
} else {
    echo '<h1 class="empty-state">SIN DATOS</h1>';
}

