<?php
// Aseguramos que $datosTabla esté definido como array, aunque venga vacío
$datosTabla = $datosTabla ?? [];

if (!empty($datosTabla)) {

    // Definir columnas de la tabla
    if (isset($datosTabla[0]) && is_array($datosTabla[0])) {
        // Caso: $datosTabla es un array de arrays (varias filas)
        $columnas = array_keys($datosTabla[0]);
    } else {
        // Caso: $datosTabla es un único registro (lo envolvemos en un array)
        $columnas  = array_keys((array)$datosTabla);
        $datosTabla = [ $datosTabla ];
    }
    ?>
    <!-- Tabla HTML que renderiza los datos -->
    <table class="tabla users-table tabla-compact">
        <thead>
            <tr>
                <?php foreach ($columnas as $col): ?>
                    <!-- Nombre de columna escapado para seguridad -->
                    <th><?= htmlspecialchars($col, ENT_QUOTES, 'UTF-8') ?></th>
                <?php endforeach; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($datosTabla as $fila): ?>
                <tr>
                    <?php foreach ($columnas as $col): ?>
                        <!-- Celda con datos escapados -->
                        <td><?= htmlspecialchars((string)($fila[$col] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php
} else {
    // Si no hay datos, mostramos un mensaje
    echo "<h1 class=\"empty-state\">SIN DATOS</h1>";
}

