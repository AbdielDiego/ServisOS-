<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\User;

class UsuariosController extends Controller
{
    private User $modelo;

    // Primero el padre, luego el modelo (por si el padre inicializa cosas comunes)
    public function __construct()
    {
        parent::__construct();
        $this->modelo = new User();
    }

    /**
     * GET /usuarios
     * Muestra todos los usuarios registrados
     */
    public function index()
    {
        $datos = $this->modelo->all();

        return $this->render('usuarios/index', [
            'titulo'     => 'Usuarios Registrados',
            'datosTabla' => $datos,
        ]);
    }

    /**
     * GET /usuarios/pagina/:num
     * Muestra usuarios paginados (acepta :num o ?page=)
     */
    public function paginado(array $params = [])
    {
        $page = 1;

        if (!empty($params['num'])) {
            $page = (int)$params['num'];
        } elseif (isset($_GET['page'])) {
            $page = (int)$_GET['page'];
        }

        $page    = max(1, $page);
        $perPage = 10;

        $datos = $this->modelo->sqlPaginado($page, $perPage);
        $datos['baseUrl'] = '/usuarios/pagina';

        return $this->render('usuarios/paginar', $datos);
    }
}

