<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\Comment;

class CommentController extends Controller
{
    protected $session; // Manejo de sesiones (wrapper)
    protected $comment; // Modelo de comentarios

    public function __construct()
    {
        if (method_exists('App\Core\Controller', '__construct')) parent::__construct();
        if (session_status() !== \PHP_SESSION_ACTIVE) @session_start();

        // Inicializar dependencias
        if (!$this->session instanceof Session) {
            $this->session = new Session();
        }
        if (!$this->comment instanceof Comment) {
            $this->comment = new Comment();
        }
    }

    /**
     * POST /comments
     * Guarda un comentario enviado desde un formulario genérico
     */
    public function store()
    {
        $bp     = $this->basePath();         // Ruta base para redirecciones
        $userId = $this->getUserId();        // Usuario logueado
        if (!$userId) {
            $this->session->flash('error', 'Debes iniciar sesión para comentar');
            return $this->redirect("$bp/login");
        }

        // ID del post y texto del comentario
        $postId = (int)$this->inputValue('post_id', 0);
        $text   = trim((string)$this->inputValue('comment_text', $this->inputValue('body', '')));

        // Validaciones
        if ($postId <= 0 || mb_strlen($text) < 2) {
            $this->session->flash('error', 'Comentario inválido');
            return $this->redirect("$bp/post/{$postId}#comentar");
        }

        // Verifica que el post exista
        if (!$this->postExists($postId)) {
            $this->session->flash('error', 'El post no existe');
            return $this->redirect("$bp/");
        }

        try {
            // Inserta el comentario
            if (!$this->persist($postId, $text, $userId)) {
                throw new \RuntimeException('Insert devolvió false');
            }
            $this->session->flash('success', 'Comentario publicado');
            return $this->redirect("$bp/post/{$postId}#comentarios");
        } catch (\Throwable $e) {
            error_log('[CommentsController.store] ' . $e->getMessage());
            $this->session->flash('error', 'No se pudo guardar el comentario');
            return $this->redirect("$bp/post/{$postId}#comentar");
        }
    }

    /**
     * POST /posts/:id/comments
     * Guarda un comentario asociado a un post específico
     */
    public function storeForPost($postId)
    {
        $bp     = $this->basePath();
        $userId = $this->getUserId();
        if (!$userId) {
            $this->session->flash('error', 'Debes iniciar sesión para comentar');
            return $this->redirect("$bp/login");
        }

        $postId = (int)$postId;
        $text   = trim((string)$this->inputValue('comment_text', $this->inputValue('body', '')));

        if ($postId <= 0 || mb_strlen($text) < 2) {
            $this->session->flash('error', 'Comentario inválido');
            return $this->redirect("$bp/post/{$postId}#comentar");
        }

        if (!$this->postExists($postId)) {
            $this->session->flash('error', 'El post no existe');
            return $this->redirect("$bp/");
        }

        try {
            if (!$this->persist($postId, $text, $userId)) {
                throw new \RuntimeException('Insert devolvió false');
            }
            $this->session->flash('success', 'Comentario publicado');
            return $this->redirect("$bp/post/{$postId}#comentarios");
        } catch (\Throwable $e) {
            error_log('[CommentsController.storeForPost] ' . $e->getMessage());
            $this->session->flash('error', 'No se pudo guardar el comentario');
            return $this->redirect("$bp/post/{$postId}#comentar");
        }
    }

    /**
     * POST /comment/delete
     * Elimina un comentario (autor o Admin) y redirige a /post/delete.php
     */
    public function delete()
    {
        // 1) Validación de método
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            http_response_code(405);
            return $this->redirect($this->basePath() . '/');
        }

        $bp            = $this->basePath();
        $currentUserId = $this->getUserId();
        if ($currentUserId <= 0) {
            $this->session->flash('error', 'Debes iniciar sesión.');
            return $this->redirect("$bp/login");
        }

        // 2) Datos del form
        $commentId = (int)$this->inputValue('comment_id', 0);
        if ($commentId <= 0) {
            $this->session->flash('error', 'Comentario inválido.');
            return $this->redirect("$bp/");
        }

        // 3) Buscar dueño y post para permiso y redirección
        $row = $this->comment->getOwnerAndPost($commentId);
        if (!$row) {
            $this->session->flash('error', 'El comentario no existe.');
            return $this->redirect("$bp/");
        }

        $postId  = (int)$row['post_id'];
        $ownerId = (int)($row['user_id'] ?? 0);

        // 4) Determinar si es admin
        $rolName = (string)(
            $this->session->get('rol')
            ?? $this->session->get('user.rol_name')
            ?? ($_SESSION['rol'] ?? ($_SESSION['user']['rol_name'] ?? ''))
        );
        $rolId = (int)(
            $this->session->get('rol_id')
            ?? $this->session->get('user.rol_id')
            ?? ($_SESSION['rol_id'] ?? ($_SESSION['user']['rol_id'] ?? 0))
        );
        $isAdmin = ($rolName === 'Admin') || ($rolId === 1);

        // 5) Permisos: dueño o admin
        $isOwner = ($ownerId > 0) && ($ownerId === $currentUserId);
        if (!$isOwner && !$isAdmin) {
            $this->session->flash('error', 'No tienes permiso para borrar este comentario.');
            return $this->redirect("$bp/post/{$postId}#comentarios");
        }

        // 6) Borrar
        if ($this->comment->deleteById($commentId)) {
            $this->session->flash('success', 'Comentario eliminado.');
        } else {
            $this->session->flash('error', 'No se pudo eliminar el comentario.');
        }

        // 7) Redirigir a la página de confirmación
        return $this->redirect("$bp/post/delete.php?post_id={$postId}");
    }

    /* ===== Helpers ===== */

    // Devuelve la ruta base de la aplicación
    private function basePath(): string
    {
        return rtrim($this->basePath ?? '', '/');
    }

    // Obtiene un valor del formulario POST de manera segura
    private function inputValue(string $key, $default = null)
    {
        if (method_exists($this, 'input')) {
            $val = $this->input($key);
            return $val !== null ? $val : $default;
        }
        return $_POST[$key] ?? $default;
    }

    // Obtiene el ID del usuario actual desde sesión o Auth
    private function getUserId(): int
    {
        if (property_exists($this, 'auth') && $this->auth && method_exists($this->auth, 'user')) {
            $u = $this->auth->user();
            if (!empty($u['id'])) return (int)$u['id'];
            if (!empty($u['user_id'])) return (int)$u['user_id'];
        }
        // Compatibilidad con distintos formatos de sesión
        $sid = $this->session->get('auth_user_id')
            ?? $this->session->get('user_id')
            ?? ($this->session->get('user')['user_id'] ?? null)
            ?? ($_SESSION['user_id'] ?? ($_SESSION['user']['user_id'] ?? 0));
        return (int)$sid;
    }

    // Verifica si un post existe (usa modelo Post si está disponible)
    private function postExists(int $postId): bool
    {
        if ($postId <= 0) return false;
        if (property_exists($this, 'postModel') && $this->postModel && method_exists($this->postModel, 'exists')) {
            try {
                return (bool)$this->postModel->exists($postId);
            } catch (\Throwable $e) {
                return true; // si falla, asumimos que existe para no cortar el flujo
            }
        }
        return true;
    }

    // Persiste el comentario en la base de datos
    private function persist(int $postId, string $text, int $userId): bool
    {
        return (bool)$this->comment->create([
            'post_id'      => $postId,
            'user_id'      => $userId,
            'comment_text' => $text,
        ]);
    }
}

