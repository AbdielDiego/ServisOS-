<?php

// Verifica si la función "back" no existe para evitar redefiniciones
if (!function_exists("back")) {
    /**
     * Redirige al usuario a la página anterior usando HTTP_REFERER
     * Si no existe, vuelve a la raíz "/"
     */
    function back() {
        // Toma la URL previa del navegador, o "/" como fallback
        $url = $_SERVER["HTTP_REFERER"] ?? '/'; 
        // Redirige a esa URL
        header("Location: " . $url);
        exit(); // Termina la ejecución inmediatamente
    }
}


