<?php
namespace App\Models;

use App\Core\Model;

/**
 * Modelo Post
 * Representa la tabla "Posts" en la base de datos.
 */
class Post extends Model {
    // Nombre de la tabla y clave primaria
    protected $table = 'Posts';
    protected $primaryKey = 'post_id';

    /**
     * Retorna datos paginados de la tabla Posts
     *
     * @param int $pagina     Número de página actual
     * @param int $porPagina  Cantidad de registros por página
     * @return array          Datos paginados + info de páginas
     */
    public function sqlPaginado($pagina = 1, $porPagina = 10): array {
        // Validación y límites
        $pagina    = (int) (is_numeric($pagina) ? $pagina : 1);
        $porPagina = (int) (is_numeric($porPagina) ? $porPagina : 10);
        $pagina    = max(1, $pagina);
        $porPagina = max(1, $porPagina);

        // Calcular desplazamiento
        $offset = ($pagina - 1) * $porPagina;

        // Consulta con conteo total
        $sql = "SELECT SQL_CALC_FOUND_ROWS *
                FROM {$this->table}
                ORDER BY {$this->primaryKey} DESC
                LIMIT {$offset}, {$porPagina}";
        $stmt  = $this->db->query($sql);
        $datos = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        // Total de filas encontradas
        $totalRow = $this->db->query('SELECT FOUND_ROWS() AS total')->fetch(\PDO::FETCH_ASSOC);
        $total = isset($totalRow['total']) ? (int)$totalRow['total'] : 0;
        $totalPaginas = $porPagina > 0 ? (int)ceil($total / $porPagina) : 1;

        return [
            'pagina'       => $pagina,
            'totalPaginas' => $totalPaginas,
            'datosTabla'   => $datos
        ];
    }
}



