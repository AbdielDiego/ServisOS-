<?php
namespace App\Models;

use App\Core\Model;
use App\Core\Database;

/**
 * Modelo User
 * Representa la tabla "Users" (respeta mayúsculas si así está creada).
 */
class User extends Model
{
    // IMPORTANTES: sin tipos para respetar la firma del padre App\Core\Model
    protected $table      = 'Users';     // Cambia a 'users' si tu tabla se creó así
    protected $primaryKey = 'user_id';

    /** Devuelve un PDO: usa $this->db si el Model base lo trae, o crea uno. */
    protected function pdo(): \PDO
    {
        if (property_exists($this, 'db') && $this->db instanceof \PDO) {
            return $this->db;
        }
        $pdo = Database::getConnection();
        $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
        return $pdo;
    }

    /** Lista todos los usuarios (ajusta columnas si fuera necesario). */
    public function all(): array
    {
        $sql = "SELECT {$this->primaryKey} AS user_id, username, email, rol_id, created_at
                  FROM {$this->table}
                 ORDER BY {$this->primaryKey} DESC";
        $stmt = $this->pdo()->query($sql);
        return $stmt->fetchAll() ?: [];
    }

    /** Paginado con metadatos (page>=1). */
    public function sqlPaginado(int $page = 1, int $perPage = 10): array
    {
        $page    = max(1, (int)$page);
        $perPage = max(1, (int)$perPage);

        $pdo   = $this->pdo();
        $total = (int)$pdo->query("SELECT COUNT(*) FROM {$this->table}")->fetchColumn();

        $pages  = max(1, (int)ceil($total / $perPage));
        $page   = min($page, $pages);
        $offset = ($page - 1) * $perPage;

        $sql = "SELECT {$this->primaryKey} AS user_id, username, email, rol_id, created_at
                  FROM {$this->table}
                 ORDER BY {$this->primaryKey} DESC
                 LIMIT :limit OFFSET :offset";
        $st = $pdo->prepare($sql);
        $st->bindValue(':limit',  $perPage, \PDO::PARAM_INT);
        $st->bindValue(':offset', $offset,  \PDO::PARAM_INT);
        $st->execute();
        $items = $st->fetchAll() ?: [];

        return [
            'items'    => $items,
            'page'     => $page,
            'perPage'  => $perPage,
            'total'    => $total,
            'pages'    => $pages,
        ];
    }

    /** ---- Helpers que ya tenías, usando pdo() ---- */

    public function findByEmail(string $email): ?array
    {
        $pdo = $this->pdo();
        $sql = "SELECT user_id, username, email, password, rol_id, created_at
                  FROM {$this->table}
                 WHERE email = ?
                 LIMIT 1";
        $st = $pdo->prepare($sql);
        $st->execute([$email]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public static function findByEmailStatic(string $email): ?array
    {
        $self = new static();
        return $self->findByEmail($email);
    }

    public function findById(int $id): ?array
    {
        $pdo = $this->pdo();
        $sql = "SELECT user_id, username, email, password, rol_id, created_at
                  FROM {$this->table}
                 WHERE {$this->primaryKey} = ?
                 LIMIT 1";
        $st = $pdo->prepare($sql);
        $st->execute([$id]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * Mapea tokens (username/email) -> user_id.
     * OJO: respeta el nombre exacto de la tabla (Users/users).
     */
    public static function mapTokensToIds(array $tokens): array
    {
        if (empty($tokens)) return [];

        $pdo = Database::getConnection();

        $norm = [];
        foreach ($tokens as $t) {
            $t = trim((string)$t);
            if ($t !== '') $norm[] = $t;
        }
        if (empty($norm)) return [];

        $in    = implode(',', array_fill(0, count($norm), '?'));
        $table = (new static())->table; // usa la misma $table de esta clase

        $sql = "SELECT user_id, username, email
                  FROM {$table}
                 WHERE username IN ($in) OR email IN ($in)";
        $st = $pdo->prepare($sql);
        $st->execute(array_merge($norm, $norm));
        $rows = $st->fetchAll(\PDO::FETCH_ASSOC);

        $map = [];
        foreach ($rows as $r) {
            if (isset($r['username'])) {
                $map[strtolower((string)$r['username'])] = (int)$r['user_id'];
            }
            if (isset($r['email'])) {
                $map[strtolower((string)$r['email'])] = (int)$r['user_id'];
            }
        }
        return $map;
    }
}

