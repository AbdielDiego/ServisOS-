<?php
namespace App\Models;

use App\Core\Model;
use App\Core\Database;
use PDO;

class Comment extends Model
{
    public function __construct()
    {
        parent::__construct();
        // Evitamos redeclarar propiedades tipadas del padre
        $this->table = 'Comments';
        if (property_exists($this, 'primaryKey')) {
            $this->primaryKey = 'comment_id';
        }
    }

    /** ====== Fallback PDO ====== */
    protected function pdo(): PDO
    {
        // 1) Si $this->db ya es PDO
        if ($this->db instanceof PDO) return $this->db;

        // 2) Algunos wrappers exponen ->pdo
        if (is_object($this->db) && property_exists($this->db, 'pdo') && $this->db->pdo instanceof PDO) {
            return $this->db->pdo;
        }

        // 3) Conexión directa
        $pdo = Database::getConnection();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    }

    /** Crea un comentario y devuelve su ID (comment_id) */
    public function create(array $data): int
    {
        $postId      = (int)($data['post_id'] ?? 0);
        $userIdInput = $data['user_id'] ?? null;
        $userId      = ($userIdInput === '' || $userIdInput === null) ? null : (int)$userIdInput;
        $commentText = (string)($data['comment_text'] ?? ($data['comment'] ?? ''));

        if ($postId <= 0 || $commentText === '') {
            throw new \InvalidArgumentException('Datos de comentario incompletos');
        }

        $sql = "INSERT INTO `{$this->table}` (`post_id`,`user_id`,`comment_text`)
                VALUES (:post_id, :user_id, :comment_text)";

        // 1) Wrapper con insert(...)
        if (is_object($this->db) && method_exists($this->db, 'insert')) {
            return (int)$this->db->insert($sql, [
                'post_id'      => $postId,
                'user_id'      => $userId,
                'comment_text' => $commentText,
            ]);
        }

        // 2) Wrapper con query(...)
        if (is_object($this->db) && method_exists($this->db, 'query')) {
            try {
                $this->db->query($sql, [
                    'post_id'      => $postId,
                    'user_id'      => $userId,
                    'comment_text' => $commentText,
                ]);
            } catch (\Throwable $e) {
                $this->db->query($sql, [
                    ':post_id'      => $postId,
                    ':user_id'      => $userId,
                    ':comment_text' => $commentText,
                ]);
            }

            if (method_exists($this->db, 'lastInsertId')) {
                return (int)$this->db->lastInsertId();
            }
            if (property_exists($this->db, 'pdo') && $this->db->pdo instanceof PDO) {
                return (int)$this->db->pdo->lastInsertId();
            }
            return 1; // truthy si el controlador solo verifica éxito
        }

        // 3) PDO nativo
        $pdo  = $this->pdo();
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':post_id', $postId, PDO::PARAM_INT);
        if ($userId === null) $stmt->bindValue(':user_id', null, PDO::PARAM_NULL);
        else $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindValue(':comment_text', $commentText, PDO::PARAM_STR);
        $stmt->execute();
        return (int)$pdo->lastInsertId();
    }

    /** Devuelve los comentarios de un post (más nuevos primero) */
    public function findByPostId(int $postId): array
    {
        $sql = "SELECT
                    c.comment_id,
                    c.comment_text AS comment_text,
                    c.comment_text AS body,   -- alias para vistas viejas
                    c.created_at,
                    u.username,
                    c.user_id
                FROM `{$this->table}` c
                LEFT JOIN `Users` u ON u.user_id = c.user_id
                WHERE c.post_id = :post_id
                ORDER BY c.created_at DESC, c.comment_id DESC";

        if (is_object($this->db) && method_exists($this->db, 'query')) {
            try {
                $res = $this->db->query($sql, ['post_id' => $postId]);
            } catch (\Throwable $e) {
                $res = $this->db->query($sql, [':post_id' => $postId]);
            }
            if (is_object($res) && method_exists($res, 'fetchAll')) return $res->fetchAll();
            return (array)$res;
        }

        $pdo  = $this->pdo();
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':post_id', $postId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    /** user_id y post_id del comentario (para validar permisos y redirigir) */
    public function getOwnerAndPost(int $commentId): ?array
    {
        $sql = "SELECT comment_id, user_id, post_id
                FROM {$this->table}
                WHERE " . ($this->primaryKey ?? 'comment_id') . " = :id";

        // Wrapper
        if (is_object($this->db) && method_exists($this->db, 'query')) {
            try {
                $res = $this->db->query($sql, ['id' => $commentId]);
            } catch (\Throwable $e) {
                $res = $this->db->query($sql, [':id' => $commentId]);
            }
            if (is_object($res) && method_exists($res, 'fetch')) {
                $row = $res->fetch();
            } else {
                $row = is_array($res[0] ?? null) ? $res[0] : null;
            }
            return $row ?: null;
        }

        // PDO
        $pdo  = $this->pdo();
        $st   = $pdo->prepare($sql);
        $st->bindValue(':id', $commentId, PDO::PARAM_INT);
        $st->execute();
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /** Borra por ID (true si afectó una fila) */
    public function deleteById(int $commentId): bool
    {
        $pk  = $this->primaryKey ?? 'comment_id';
        $sql = "DELETE FROM {$this->table} WHERE {$pk} = :id";

        // Wrapper
        if (is_object($this->db) && method_exists($this->db, 'query')) {
            try {
                $res = $this->db->query($sql, ['id' => $commentId]);
            } catch (\Throwable $e) {
                $res = $this->db->query($sql, [':id' => $commentId]);
            }
            // Si el wrapper retorna filas afectadas:
            if (is_int($res)) return $res > 0;
            // Fallback: consultar existencia
            return $this->getOwnerAndPost($commentId) === null;
        }

        // PDO
        $pdo = $this->pdo();
        $st  = $pdo->prepare($sql);
        $st->bindValue(':id', $commentId, PDO::PARAM_INT);
        $st->execute();
        return $st->rowCount() > 0;
    }
}

