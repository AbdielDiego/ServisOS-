<?php


// Carga automática de clases utilizando Composer
require(__DIR__ . '/../../vendor/autoload.php');

// Inicia la sesión solo si no está activa
if (session_status() === PHP_SESSION_NONE) { 
    session_start(); 
} 

// 🛠️ DEBUG: Muestra información útil durante el desarrollo
echo $_SERVER['REQUEST_URI']; // Muestra la URI solicitada
echo "<br>SESSION ID: " . session_id();  // Muestra el ID de sesión actual
echo "<br>SESSION DATA: ";
print_r($_SESSION); // Muestra el contenido actual de la sesión

// 📌 Definición de rutas de la aplicación
$route = [
    ["GET", '/', "HomeController@index"],                      // Ruta principal
    ["GET", '/show/id/', "AuthController@show"],              // Mostrar usuario por ID
    ["GET", '/edit/id/', "AuthController@edit"],              // Editar usuario por ID
    ["GET", '/save/id/', "AuthController@save"],              // Guardar cambios
    ["POST", '/auth/login', "AuthController@login"],          // Login del usuario
    ["POST", '/auth/logout', "AuthController@logout"],        // Logout del usuario
    ["GET", "/clientes", "ClientesController@index"],         // Vista de clientes
    ["POST", "/clientes", "ClientesController@index"],        // Mismo método por POST
    ["GET", '/usuarios', "UsuariosController@index"],         // Vista de usuarios
    ["POST", '/usuarios', "UsuariosController@index"],        // Mismo por POST
    ["GET", "/registro/registro_empresario", "RegistroController@registroEmpresario"],


    ["POST", "/auth/registro_empresario/", "AuthController@registroEmpresario"],
    ["GET", "/registro/registro_empresario", "RegistroController@registroEmpresario"],
    ["GET", "/registro/showRegistro", "RegistroController@showRegistro"],


    

];

// 🧭 Busca la ruta correspondiente a la solicitud actual
$datRoute = findRoute($route, $_SERVER['REQUEST_URI']);

// 🔍 DEBUG: Muestra la ruta encontrada
print_r($datRoute);

// ✅ Si se encontró un controlador válido, lo ejecuta
if (!empty($datRoute["controlador"])) {
    echo "<br>Controlador: " . $datRoute["controlador"];

    // Arma el namespace del controlador
    $control = "App\\Controllers\\" . $datRoute["controlador"];

    // Ejecuta el método del controlador con los parámetros (vacíos en este caso)
    call_user_func(
        [new $control(), $datRoute["metodo"]],
        $datRoute["parametros"]
    );

} else {
    // ⚠️ Ruta no encontrada
    echo "No hay ruta definida para esta URL.";
}

// 🧠 Función para encontrar la ruta exacta según el método HTTP y la URL
function findRoute($routes, $bus)
{
    foreach ($routes as $val) {
        $method = $val[0];     // GET o POST
        $path = $val[1];       // Ruta esperada (ej: "/clientes")
        $action = $val[2];     // Controlador y método separados por @

        // Verifica si el método y la URI coinciden exactamente
        if ($_SERVER['REQUEST_METHOD'] === $method && $bus === $path) {
            $ejecucion = explode('@', $action);

            return [
                "controlador" => $ejecucion[0],
                "metodo" => $ejecucion[1],
                "parametros" => [] // No hay parámetros dinámicos en esta versión
            ];
        }
    }

    // Si no se encuentra coincidencia, retorna un array vacío
    return [];
}

