<?php
// Declara el namespace para el modelo Clientes
namespace App\Models;

// Importa la clase base Model que proporciona funcionalidades generales de base de datos
use App\Core\Model;

/**
 * Modelo Clientes
 * Interactúa con la tabla "clientes" en la base de datos
 */
class Clientes extends Model {

    // Define la tabla asociada al modelo
    protected $table = 'clientes';

    // Define el nombre de la clave primaria (por defecto sería "id", pero acá es "rut")
	protected $primaryKey = 'rut';

	/**
	 * Método que retorna todos los registros de la tabla clientes
	 * Utiliza el método all() heredado de Model
	 */
	public function clientesTodos() {
        return $this->all(); // SELECT * FROM clientes
	}

    /**
     * Busca un cliente por su RUT
     * @param string $rut
     * @return array|null Devuelve el cliente o null si no lo encuentra
     */
    public function findByRut($rut) {
        $query = $this->db->query(
            "SELECT * FROM {$this->table} WHERE rut = ? LIMIT 1", 
            [$rut] // Pasa el rut como parámetro seguro
        );
        return $query->fetch(); // Devuelve una fila asociativa
    }
}

