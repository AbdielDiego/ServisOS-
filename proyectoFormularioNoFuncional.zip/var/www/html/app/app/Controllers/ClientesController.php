<?php 

// Define el espacio de nombres para el controlador
namespace App\Controllers;

// Importa clases necesarias del framework y el modelo Clientes
use App\Core\Controller;
use App\Models\Clientes;

// Define el controlador de Clientes que hereda del controlador base
class ClientesController extends Controller {

    // Atributo privado para el modelo de clientes
    private $modelo;

    // Constructor del controlador
    public function __construct(){
        // Crea una instancia del modelo Clientes
        $this->modelo = new Clientes();

        // Llama al constructor del controlador base
        parent::__construct();
    }

    // Método principal para mostrar todos los clientes
    public function index(){
        // Obtiene todos los registros de clientes
        $datos = $this->modelo->clientesTodos();

        // Renderiza la vista "clientes/index" pasando los datos de los clientes
        return $this->render("clientes/index", ["clientes" => $datos]);
    }

    // Método para mostrar un cliente específico
    public function showCliente($param){
        // Obtiene el ID del cliente desde los parámetros
        $id = $param['id'];

        // Busca los datos del cliente por ID
        $datos = $this->modelo->find($id);

        // Renderiza la vista "clientes/showcliente" con los datos del cliente
        return $this->render("clientes/showcliente", ["clientes" => $datos]);
    }
}

