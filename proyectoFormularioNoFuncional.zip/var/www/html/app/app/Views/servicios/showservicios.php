<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    
    <!-- Título de la pestaña del navegador -->
    <title>Detalle del Servicio</title>
</head>
<body>

    <!-- Encabezado principal -->
    <h1>Detalle del Servicio</h1>

    <!-- Verifica si la variable $servicio tiene datos -->
    <?php if ($servicio): ?>
        
        <!-- Muestra los detalles del servicio -->
        <p><strong>ID:</strong> <?= $servicio["id"] ?></p>
        <p><strong>Nombre:</strong> <?= $servicio["nombre"] ?></p>
        <p><strong>Descripción:</strong> <?= $servicio["descripcion"] ?></p>
        <p><strong>Precio:</strong> $<?= $servicio["precio"] ?></p>

    <?php else: ?>
        <!-- Si no hay servicio cargado, muestra un mensaje de error -->
        <p>Servicio no encontrado.</p>
    <?php endif; ?>

</body>
</html>


