<?php

$atareas = ["lavar los platos", "encerar los pisos", "limpiar vidrios", "arreglar cesped", "barrer el patio", "tomar cerveza"];
$tareas = $atareas;
$link = "<a href='/ejercicio.php' >Intentar de Nuevo</a>";
$titulo = "TAREAS A REALIZAR ";

$archivoHistorial = 'orden_anterior.json';

if (isset($_GET['tarea'])) {
    $resultado = urldecode($_GET['tarea']);

    if ($resultado == "tomar cerveza") {
        $mensaje = "GANASTE AMIGO TOMATE UNA CERVEZA ";
    } else {
        $mensaje = "Te toca trabajar, jajaja: $resultado";
    }

    echo creaHtml("<h2>$mensaje</h2>", $titulo, $link);
} else {
    $ordenAnterior = [];

    if (file_exists($archivoHistorial)) {
        $ordenAnterior = json_decode(file_get_contents($archivoHistorial), true);
    }

    do {
        $tareas = $atareas; // Reiniciar
        shuffle($tareas);
    } while ($tareas === $ordenAnterior);

    // Guardar el nuevo orden
    file_put_contents($archivoHistorial, json_encode($tareas));

    $cant = count($tareas) - 1;
    $tetoca = rand(0, $cant);
    $suerte = $tareas[$tetoca];

    $lista = "<ul>";

    foreach ($tareas as $tarea) {
        if ($tarea == $suerte) {
            $lista .= "<li><a id='tsel' href='/ejercicio.php?tarea=" . urlencode($tarea) . "'>$tarea</a></li>";
        } else {
            $lista .= "<li>$tarea</li>";
        }
    }

    $lista .= "</ul>";

    echo creaHtml($lista, $titulo);
}

function creaHtml($datos, $titulo, $link = '')
{
    $script = "<script src='script.js'></script>";
    $html = "
    <html>
        <head>
        </head>
        <body>
            <h1>$titulo</h1>
            $datos
            $link
            $script
        </body>
    </html>";
    return $html;
}

