<?php


require_once('ModeloTareas.php');
require_once('VistaTareas.php');


class TareasController{

	private $modelo;
	private $vista;

	public function __construct(){
	
		$this->modelo = new ModeloTareas();
		$this->vista = new VistaTareas();	
	}
	 
	public function index( $param ){

		if ( empty($param) ){

			$this->inicioPagina();
		}else{

			$this->resultadoPagina($param);
		}

	 $this->vista->render();
	}

	private function inicioPagina(){

	$atareas = $this->modelo->getTareas();
	$tareas = $atareas;
	shuffle($tareas);
	 
	$cant = count($tareas) -1 ;
	$tetoca = rand(0,$cant);
	$suerte = $tareas[$tetoca];
	$lista = $this->vista->creaLista($tareas, $suerte);

	$this->vista->setHtml($lista); 

	}


	public function resultadoPagina( $param ){

		if ($param == "tomar cerveza"){

			$titulo = "GANASTE AMIGO TOMATE UNA BIRRA";
		
		}else{
	
			$titulo = "PERDISTE....TENES QUE TRABAJAR: $param ";

		}

		$resultado = $this->vista->creaTitulo($titulo);
		$link = $this->vista->creaLink();

		$this->vista->setHtml($resultado.$link);

	}


}

