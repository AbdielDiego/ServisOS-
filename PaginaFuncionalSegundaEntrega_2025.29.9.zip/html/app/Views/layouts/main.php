<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <!-- Título dinámico escapado para seguridad -->
  <title><?= htmlspecialchars($title ?? 'Chivita Recomienda', ENT_QUOTES, 'UTF-8') ?></title>
<?php
  // Base pública (URL base desde el script ejecutado)
  $PUBLIC_BASE = rtrim(str_replace('\\','/', dirname($_SERVER['SCRIPT_NAME'])), '/');
  if ($PUBLIC_BASE === '.' || $PUBLIC_BASE === '/') $PUBLIC_BASE = '';

  // Ruta raíz del proyecto
  $ROOT        = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 3);

  // Rutas físicas a los CSS principales
  $cssMainPath = $ROOT . '/public/css/styles.css';
  $cssUCPath   = $ROOT . '/public/css/user-corner.css';
  $cssMinPath  = $ROOT . '/public/css/minuevo.css';

  // Versionado automático según última modificación (para cache busting)
  $cssMainVer  = @filemtime($cssMainPath) ?: time();
  $cssUCVer    = @filemtime($cssUCPath)   ?: $cssMainVer;
  $cssMinVer   = @filemtime($cssMinPath)  ?: $cssMainVer;
?>
<!-- Inclusión de hojas de estilo con versionado -->
<link rel="stylesheet" href="<?= $PUBLIC_BASE ?>/css/styles.css?v=<?= $cssMainVer ?>">
<link rel="stylesheet" href="<?= $PUBLIC_BASE ?>/css/user-corner.css?v=<?= $cssUCVer ?>">
<link rel="stylesheet" href="<?= $PUBLIC_BASE ?>/css/minuevo.css?v=<?= $cssMinVer ?>">

<!-- Añade la clase .minuevo para que apliquen tus reglas -->
<body class="theme-clean minuevo">
  <header>
    <!-- Renderiza el componente de navegación -->
    <?php $this->component('navigation') ?>
  </header>

  <main class="container">
    <!-- Muestra mensajes flash (errores, notificaciones, etc.) -->
    <?php $this->component('flash-messages') ?>
    <!-- Renderizado dinámico del contenido de la vista -->
    <?= $content ?>
  </main>

  <!-- Widget de usuario en la esquina (user-corner) -->
  <?php $this->component('user-corner') ?>
</body>
</html>


