<?php
/** @var array $msg */
/** @var array $recipients */
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
?>
<div>
  <h1><?= h($msg['subject'] ?? 'Mensaje') ?></h1>
  <p><strong>De:</strong> <?= h($msg['from_name'] ?? '') ?></p>
  <p><strong>Fecha:</strong> <?= h($msg['created_at'] ?? '') ?></p>

  <hr>
  <pre><?= h($msg['body'] ?? '') ?></pre>

  <hr>
  <p><strong>Para:</strong>
    <?php if (!empty($recipients)): ?>
      <?php foreach ($recipients as $r): ?>
        <span><?= h($r['username']) ?><?= $r['is_read'] ? '' : ' (no leído)' ?></span><?php if (next($recipients)) echo ', '; ?>
      <?php endforeach; reset($recipients); ?>
    <?php else: ?>
      <em>—</em>
    <?php endif; ?>
  </p>

  <p><a href="/messages/compose?reply_to=<?= (int)($msg['id'] ?? 0) ?>">Responder</a></p>
</div>

