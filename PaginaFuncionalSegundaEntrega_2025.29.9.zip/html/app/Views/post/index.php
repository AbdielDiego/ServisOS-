<?php
require BASE_PATH . "/app/Views/components/paginar.php";
?> 

<tbody>
<?php foreach ($posts as $p): ?>
  <tr>
    <td><?= (int)$p['post_id'] ?></td>
    <td><?= (int)$p['user_id'] ?></td>
    <td><?= (int)$p['category_id'] ?></td>
    <td><?= htmlspecialchars($p['title'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
    <td><?= htmlspecialchars($p['content'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
    <td><?= htmlspecialchars($p['created_at'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
    <td><?= htmlspecialchars($p['updated_at'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>

   <td class="td-actions">
  <?php if ($id > 0): ?>
    <a class="btn btn-sm" href="<?= $BASE ?>/post/<?= $id ?>#comentar">Comentar</a>
    <a class="btn btn-sm" href="<?= $BASE ?>/post/<?= $id ?>#comentarios">Ver comentarios</a>

    <?php
      // === Rating simple usando average_rating existente ===
      // Si tu SELECT trae average_rating, lo usamos; si no, arrancamos en 1
      $ratingCols = ['average_rating','avg','promedio','rating'];
      $ratingVal  = null;
      foreach ($ratingCols as $rc) {
        if (array_key_exists($rc, $fila)) { $ratingVal = $fila[$rc]; break; }
      }
      $rating = (int)round(is_numeric($ratingVal ?? null) ? (float)$ratingVal : 1);
      if ($rating < 1) $rating = 1;
      if ($rating > 5) $rating = 5;
    ?>

    <!-- Botón de rating 1→5 al lado -->
    <span class="rating-simple" data-id="<?= $id ?>">
      <span class="rating-value"><?= $rating ?></span>/5
      <form action="<?= $BASE ?>/api/rate/simple" method="post" class="rating-form" style="display:inline">
        <input type="hidden" name="id" value="<?= $id ?>">
        <input type="hidden" name="rating" class="rating-input" value="<?= $rating ?>">
        <button type="button" class="btn btn-sm btn-increment" title="Subir rating">➕</button>
      </form>
    </span>
  <?php else: ?>
    —
  <?php endif; ?>
</td>



  </tr>
<?php endforeach; ?>
</tbody>
<script>
document.querySelectorAll('.rating-simple').forEach(box => {
  const valueEl = box.querySelector('.rating-value');
  const inputEl = box.querySelector('.rating-input');
  const btn = box.querySelector('.btn-increment');

  btn.addEventListener('click', () => {
    let val = parseInt(valueEl.textContent, 10);
    val = val >= 5 ? 1 : val + 1; // ciclo 1→5
    valueEl.textContent = val;
    inputEl.value = val;

    // Guardar en backend usando el mismo endpoint adaptado
    const form = btn.closest('form');
    const fd = new FormData(form);
    fetch(form.action, { method: 'POST', body: fd })
      .then(r => r.json())
      .then(data => {
        if (!data.ok) alert(data.msg || "Error al guardar rating");
      })
      .catch(err => console.error(err));
  });
});
</script>






