<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Minuevo;

class MinuevoController extends Controller
{
    /** @var \PDO */
    private $pdo;   // Conexión PDO a la base de datos
    /** @var Minuevo */
    private $model; // Instancia del modelo Minuevo

    public function __construct()
    {
        // Si el controlador base tiene constructor, lo llamamos
        if (method_exists('App\Core\Controller', '__construct')) {
            parent::__construct();
        }

        // Aseguramos que la sesión esté iniciada
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

        // Configuración de PDO
        $this->pdo = Database::getConnection();
        $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
        $this->pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);

        // Inicializamos el modelo con la conexión
        $this->model = new Minuevo($this->pdo);
    }

    /** GET /minuevo */
    public function index()
    {
        // Obtiene los últimos 10 posts
        $posts = $this->model->latest(10);

        // Genera slug (titulo-amigable-id) para cada post
        foreach ($posts as &$p) {
            $p['slug'] = $this->slugify($p['title']) . '-' . (int)$p['post_id'];
        }

        // Renderiza la vista index de minuevo
        return $this->view('minuevo/index', ['posts' => $posts]);
    }

    /** GET /minuevo/crear */
    public function create()
    {
        // Obtiene categorías disponibles
        $cats = $this->model->categories();

        // Renderiza formulario de creación
        return $this->view('minuevo/create', ['categories' => $cats]);
    }

    /** POST /minuevo/guardar */
    public function store()
    {
        // Verifica si el usuario está logueado
        $userId = $_SESSION['auth']['user']['user_id'] ?? $_SESSION['user']['user_id'] ?? null;
        if (!$userId) {
            $this->flash('error', 'Debes iniciar sesión.');
            return $this->redirect('/login?next=' . urlencode('/minuevo/crear'));
        }

        // Normaliza inputs del formulario
        $title   = $this->firstString($_POST['title']   ?? '');
        $content = $this->firstString($_POST['content'] ?? '');
        $cidRaw  = $this->firstString($_POST['category_id'] ?? '');

        // Validación básica
        if ($title === '' || $content === '') {
            $this->flash('error', 'Título y contenido son obligatorios.');
            return $this->redirect('/minuevo/crear');
        }

        // Convierte categoría a int si existe
        $categoryId = ($cidRaw === '' ? null : (int)$cidRaw);

        try {
            // Inserta artículo
            $id   = $this->model->create((int)$userId, $categoryId, $title, $content);
            $slug = $this->slugify($title) . '-' . $id;

            $this->flash('ok', 'Artículo creado con éxito.');
            return $this->redirect('/article/' . $slug);
        } catch (\Throwable $e) {
            $this->flash('error', 'No se pudo crear el artículo.');
            return $this->redirect('/minuevo/crear');
        }
    }

    /** GET /article/{slug|id} */
    public function show($slugOrId)
    {
        // Normaliza parámetro (si viene como array, obtiene string)
        $slugOrId = $this->firstString($slugOrId);

        // Si es numérico, busca por id
        if ($slugOrId !== '' && ctype_digit($slugOrId)) {
            $post = $this->model->findById((int)$slugOrId);
        } else {
            // Si no, extrae el id del slug o busca por título
            $id = $this->extractId($slugOrId);
            $post = $id ? $this->model->findById($id) : $this->model->findByLooseTitle($slugOrId);
        }

        // Si no encuentra, responde 404
        if (!$post) {
            http_response_code(404);
            echo "<h1>No encontrado</h1>";
            return null;
        }

        // Genera slug para el post
        $post['slug'] = $this->slugify($post['title']) . '-' . (int)$post['post_id'];

        // Obtiene promedio de rating y rating del usuario actual (si existe)
        $avg    = $this->model->avgRating((int)$post['post_id']);
        $userId = $_SESSION['auth']['user']['user_id'] ?? $_SESSION['user']['user_id'] ?? null;
        $mine   = $userId ? $this->model->userRating((int)$post['post_id'], (int)$userId) : null;

        // Renderiza vista show de minuevo
        return $this->view('minuevo/show', [
            'post'       => $post,
            'avgRating'  => $avg,
            'userRating' => $mine,
        ]);
    }

    /** POST /article/{id}/rate */
    public function rate($id)
    {
        // Verifica si usuario está logueado
        $userId = $_SESSION['auth']['user']['user_id'] ?? $_SESSION['user']['user_id'] ?? null;
        if (!$userId) {
            $this->flash('error', 'Debes iniciar sesión para puntuar.');
            return $this->redirect('/login?next=' . urlencode('/article/' . $this->firstString($id)));
        }

        // Normaliza y valida puntaje
        $rating = (int)$this->firstString($_POST['rating'] ?? '');
        if ($rating < 1 || $rating > 5) {
            $this->flash('error', 'El puntaje debe estar entre 1 y 5.');
            return $this->redirect('/minuevo');
        }

        // Busca post
        $id = (int)$this->firstString($id);
        $post = $this->model->findById($id);
        if (!$post) {
            $this->flash('error', 'El artículo no existe.');
            return $this->redirect('/minuevo');
        }

        try {
            // Inserta o actualiza rating del usuario
            $this->model->upsertRating($id, (int)$userId, $rating);
            $this->flash('ok', '¡Gracias por tu voto!');
        } catch (\Throwable $e) {
            $this->flash('error', 'No se pudo registrar tu voto.');
        }

        // Redirige al detalle del artículo con slug
        $slug = $this->slugify($post['title']) . '-' . (int)$post['post_id'];
        return $this->redirect('/article/' . $slug);
    }

    /* -------- utilidades -------- */

    // Convierte título en slug amigable para URL
    private function slugify(string $text): string
    {
        $text = trim($text);
        $text = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text) ?: $text;
        $text = strtolower($text);
        $text = preg_replace('/[^a-z0-9]+/i', '-', $text);
        $text = trim($text, '-');
        return $text ?: 'post';
    }

    // Extrae ID de un slug (ej: titulo-amigable-123 → 123)
    private function extractId(string $slug): ?int
    {
        $s = urldecode($slug);
        if (preg_match('/-(\d+)$/', $s, $m)) return (int)$m[1];
        return null;
    }

    /**
     * Devuelve el primer string válido de un valor.
     * Puede venir como string, numérico, array o cualquier tipo.
     */
    private function firstString($value): string
    {
        if (is_string($value)) return trim($value);
        if (is_numeric($value)) return (string)$value;
        if (is_array($value)) {
            foreach ($value as $v) {
                if (is_string($v) || is_numeric($v)) {
                    $s = trim((string)$v);
                    if ($s !== '') return $s;
                }
            }
            return '';
        }
        return '';
    }

    /* ===== fallbacks si el Controller base no los trae ===== */

    // Renderiza una vista
    public function view($template, $data = [])
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent, 'view')) {
            return parent::view($template, $data);
        }

        $templateName = is_string($template) ? $template : (is_array($template) ? '[array]' : strval($template));
        $base = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 2);
        $file = $base . '/app/Views/' . ltrim($templateName, '/') . '.php';

        // Si no existe la vista, error 500
        if (!is_file($file)) {
            http_response_code(500);
            echo "<h1>Vista no encontrada</h1><p>" . htmlspecialchars($templateName, ENT_QUOTES, 'UTF-8') . ".php</p>";
            return null;
        }

        // Extrae variables y carga la vista
        extract(is_array($data) ? $data : [], EXTR_SKIP);
        ob_start();
        include $file;
        $out = ob_get_clean();
        echo $out;
        return null;
    }

    // Redirige a otra ruta
    public function redirect($url)
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent, 'redirect')) {
            // Normaliza URL si es array
            if (is_array($url)) {
                $path=''; $query=[];
                if (isset($url['path'])) $path=(string)$url['path'];
                elseif (isset($url[0]))  $path=(string)$url[0];
                if (isset($url['query']) && is_array($url['query'])) $query=$url['query'];
                elseif (isset($url[1]) && is_array($url[1]))         $query=$url[1];
                $url = $path . ($query ? ('?' . http_build_query($query)) : '');
            } else {
                $url = (string)$url;
            }
            return parent::redirect($url);
        }

        // Si no existe redirect en padre, se maneja aquí
        if (is_array($url)) {
            $path=''; $query=[];
            if (isset($url['path'])) $path=(string)$url['path'];
            elseif (isset($url[0]))  $path=(string)$url[0];
            if (isset($url['query']) && is_array($url['query'])) $query=$url['query'];
            elseif (isset($url[1]) && is_array($url[1]))         $query=$url[1];
            $url = $path . ($query ? ('?' . http_build_query($query)) : '');
        } else {
            $url = (string)$url;
        }

        header('Location: ' . $url);
        exit;
    }

    // Maneja mensajes flash en sesión
    public function flash($key, $message)
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent, 'flash')) {
            return parent::flash($key, $message);
        }
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        $_SESSION['flash'][$key] = $message;
        return null;
    }
}

