<?php
if (!function_exists('h')) { function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }
$title = $title ?? 'Editar perfil';
$u     = $user ?? [];
$old   = $old  ?? [];

// Valores actuales/previos
$username = $old['username'] ?? ($u['username'] ?? '');
$email    = $old['email']    ?? ($u['email'] ?? '');
$created  = !empty($u['created_at']) ? date('Y-m-d', strtotime($u['created_at'])) : '';
$rolId    = (int)($u['rol_id'] ?? 2);

// Inicial del avatar (no hay columna de avatar en DB)
$initial  = strtoupper(mb_substr($username, 0, 1, 'UTF-8') ?: 'U');
?>

<link rel="stylesheet" href="/css/styles.css">
<link rel="stylesheet" href="/css/app-dashboard.css?v=1">

<main class="container dash-wrapper">
  <section class="profile-header">
    <div class="ph-left">
      <div class="avatar-inicial" aria-label="Avatar"><?= h($initial) ?></div>
      <div>
        <h1 class="title">Editar perfil</h1>
        <p class="subtitle">@<?= h($username) ?> • Miembro desde <?= h($created) ?></p>
      </div>
    </div>
    <div class="ph-right">
      <a href="/dashboard" class="btn btn-soft">Volver al dashboard</a>
    </div>
  </section>

  <?php if (!empty($flashes)): ?>
    <?php foreach ($flashes as $f): ?>
      <div class="alert alert-<?= h($f['type'] ?? 'success') ?>"><?= h($f['msg'] ?? '') ?></div>
    <?php endforeach; ?>
  <?php endif; ?>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-error">
      <strong>Revisá los campos:</strong>
      <ul style="margin:8px 0 0 16px;">
        <?php foreach ($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <div class="card" style="max-width:720px;">
    <form method="post" action="/profile/edit" autocomplete="off" novalidate>
      <input type="hidden" name="csrf_token" value="<?= h($csrf ?? '') ?>">

      <div class="field">
        <label>Nombre de usuario</label>
        <input type="text" name="username" required minlength="3" value="<?= h($username) ?>">
      </div>

      <div class="field">
        <label>Email</label>
        <input type="email" name="email" required value="<?= h($email) ?>">
      </div>

      <div class="grid cols-2">
        <div class="field">
          <label>Nueva contraseña <small class="muted">(opcional)</small></label>
          <input type="password" name="new_password" placeholder="••••••••">
        </div>
        <div class="field">
          <label>Repetir nueva contraseña</label>
          <input type="password" name="new_password_confirm" placeholder="••••••••">
        </div>
      </div>

      <div class="grid cols-2">
        <div class="field">
          <label>Rol</label>
          <input type="text" value="<?= $rolId === 1 ? 'Admin' : 'User' ?>" disabled>
        </div>
        <div class="field">
          <label>Creado</label>
          <input type="text" value="<?= h($created) ?>" disabled>
        </div>
      </div>

      <div class="right">
        <button type="submit" class="btn">Guardar cambios</button>
      </div>
    </form>
  </div>

  <p class="muted" style="margin-top:10px;">
    * Tu rol no puede ser modificado desde aquí. Para cambiar la contraseña, completá los dos campos.
  </p>
</main>

