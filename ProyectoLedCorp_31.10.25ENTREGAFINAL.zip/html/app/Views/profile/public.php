<?php
// ========== Helpers ==========
if (!function_exists('h')) {
  function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
}

$user        = $user        ?? [];
$stats       = $stats       ?? ['posts_total'=>0,'avg_rating'=>0,'ratings_count'=>0];
$categories  = $categories  ?? [];
$posts       = $posts       ?? [];
$recent      = $recentComms ?? [];
$page        = (int)($page ?? 1);
$limit       = (int)($limit ?? 10);
$isBanned    = !empty($isBanned);
$username    = $user['username'] ?? 'Usuario';
$memberSince = $user['created_at'] ?? null;

// Utilidad para formatear fecha
$fmt = function($ts){
  if (!$ts) return '';
  try {
    $d = new DateTime($ts);
    return $d->format('d/m/Y H:i');
  } catch (Throwable $e) {
    return (string)$ts;
  }
};
?>
<link rel="stylesheet" href="/css/publicprofile.css">

<section class="profile-public">
  <header class="page-header">
    <h1>Perfil de <?= h($username) ?></h1>
    <p class="subtitle">
      Rol: <?= h($user['role_name'] ?? 'User') ?> · Miembro desde: <?= h($fmt($memberSince)) ?>
    </p>

    <?php if ($isBanned): ?>
      <div class="flash flash-warn">
        Este usuario se encuentra actualmente <strong>baneado</strong>.
      </div>
    <?php endif; ?>
  </header>

  <!-- Stats -->
  <div class="stats-grid">
    <div class="card">
      <div class="label">Publicaciones</div>
      <div class="value"><?= (int)$stats['posts_total'] ?></div>
    </div>
    <div class="card">
      <div class="label">Promedio de Rating</div>
      <div class="value"><?= number_format((float)$stats['avg_rating'], 2) ?> / 5</div>
    </div>
    <div class="card">
      <div class="label">Calificaciones recibidas</div>
      <div class="value"><?= (int)$stats['ratings_count'] ?></div>
    </div>
  </div>

  <!-- Breakdown por categorías -->
  <section>
    <h2 style="margin:0 0 8px 0; font-size:18px;">Categorías más publicadas</h2>
    <?php if (empty($categories)): ?>
      <p class="text-dim">Sin publicaciones aún.</p>
    <?php else: ?>
      <ul class="cat-list">
        <?php foreach ($categories as $cat): ?>
          <li class="cat-item">
            <strong><?= h($cat['category']) ?></strong>
            <span class="text-dim">· <?= (int)$cat['cnt'] ?> posts</span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>

  <!-- Publicaciones -->
  <section style="margin-top:22px;">
    <h2 style="margin:0 0 8px 0; font-size:18px;">Publicaciones de <?= h($username) ?></h2>

    <?php if (empty($posts)): ?>
      <p class="text-dim">Este usuario aún no publicó servicios o artículos.</p>
    <?php else: ?>
      <div class="post-list">
        <?php foreach ($posts as $p): ?>
          <article class="post-card">
            <header style="margin-bottom:6px;">
              <h3>
                <a class="post-link" href="/post/<?= (int)$p['post_id'] ?>">
                  <?= h($p['title']) ?>
                </a>
              </h3>
              <small>
                <?= h($p['category']) ?> · <?= h($fmt($p['created_at'])) ?>
                <?php if ((int)$p['price'] > 0): ?>
                  · $ <?= number_format((int)$p['price'], 0, ',', '.') ?>
                <?php endif; ?>
              </small>
            </header>

            <p style="margin:0 0 8px 0; white-space:pre-line;"><?= nl2br(h($p['content'])) ?></p>

            <footer class="footer">
              <span class="text-dim" title="Rating promedio del post">
                ⭐ <?= number_format((float)$p['avg_post_rating'], 2) ?>/5
              </span>
              <?php if (!empty($p['tags'])): ?>
                <span class="text-dim">·</span>
                <span class="text-dim">Tags: <?= h($p['tags']) ?></span>
              <?php endif; ?>
              <span class="spacer"></span>
              <a class="btn btn-primary"
                 href="/messages/contact?to=<?= (int)($user['user_id'] ?? 0) ?>&username=<?= urlencode($username) ?>">
                Contactar
              </a>
            </footer>
          </article>
        <?php endforeach; ?>
      </div>

      <!-- Paginación simple -->
      <nav class="pager" aria-label="Paginación">
        <?php if ($page > 1): ?>
          <a href="?page=<?= $page-1 ?>" class="btn">← Anterior</a>
        <?php endif; ?>
        <?php if (count($posts) === $limit): ?>
          <a href="?page=<?= $page+1 ?>" class="btn">Siguiente →</a>
        <?php endif; ?>
      </nav>
    <?php endif; ?>
  </section>

  <!-- Últimos comentarios del usuario -->
  <section style="margin-top:26px;">
    <h2 style="margin:0 0 8px 0; font-size:18px;">Últimos comentarios</h2>
    <?php if (empty($recent)): ?>
      <p class="text-dim">Sin comentarios recientes.</p>
    <?php else: ?>
      <ul style="list-style:none; padding:0; margin:0; display:grid; gap:8px;">
        <?php foreach ($recent as $c): ?>
          <li class="cat-item">
            <div style="margin-bottom:4px; font-size:14px;">
              En <a class="post-link" href="/post/<?= (int)$c['post_id'] ?>"><?= h($c['post_title']) ?></a>
              · <?= h($fmt($c['created_at'])) ?>
            </div>
            <div style="white-space:pre-line;"><?= nl2br(h($c['comment_text'])) ?></div>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>
</section>

