<link rel="stylesheet" href="/css/minuevo.css">
<div class="minuevo">
  <h1>Crear novedad</h1>

  <?php if (!empty($_SESSION['flash']['ok'])): ?>
    <div class="alert ok"><?= htmlspecialchars($_SESSION['flash']['ok'], ENT_QUOTES, 'UTF-8') ?></div>
    <?php unset($_SESSION['flash']['ok']); ?>
  <?php endif; ?>
  <?php if (!empty($_SESSION['flash']['error'])): ?>
    <div class="alert error"><?= htmlspecialchars($_SESSION['flash']['error'], ENT_QUOTES, 'UTF-8') ?></div>
    <?php unset($_SESSION['flash']['error']); ?>
  <?php endif; ?>

  <form action="/minuevo/guardar" method="post" class="card form">
    <div class="field">
      <label for="title">Título *</label>
      <input id="title" name="title" type="text" maxlength="255" required placeholder="Ej: Novedad de mi producto">
    </div>

    <div class="field">
      <label for="category_id">Categoría (opcional)</label>
      <select id="category_id" name="category_id">
        <option value="">— Sin categoría —</option>
        <?php foreach (($categories ?? []) as $cat): ?>
          <option value="<?= (int)$cat['category_id'] ?>">
            <?= htmlspecialchars($cat['name'], ENT_QUOTES, 'UTF-8') ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="field">
      <label for="content">Contenido *</label>
      <textarea id="content" name="content" rows="8" required placeholder="Escribe la novedad…"></textarea>
    </div>

    <!-- NUEVO: Precio -->
    <div class="field">
      <label for="price">Precio (UYU)</label>
      <input
        id="price"
        name="price"
        type="number"
        min="0"
        step="1"
        inputmode="numeric"
        pattern="\d*"
        placeholder="0">
      <small class="help">Solo números enteros (se guarda en <code>Posts.price</code>).</small>
    </div>

    <button class="btn">Publicar</button>
  </form>
</div>


