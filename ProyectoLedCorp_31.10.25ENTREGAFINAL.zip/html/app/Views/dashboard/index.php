<?php
// ========== Helpers ==========
if (!function_exists('h')) {
  function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}
$h = fn($v) => h($v);

// Slugify local
$slugify = function (string $text): string {
  $text = trim($text);
  $text = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text) ?: $text;
  $text = strtolower($text);
  $text = preg_replace('/[^a-z0-9]+/i', '-', $text);
  $text = trim($text, '-');
  return $text ?: 'post';
};

// Params de búsqueda/orden
$q    = trim((string)($_GET['q'] ?? ''));
$sort = trim((string)($_GET['sort'] ?? 'fecha_desc'));

// Construir link al último post
$lastUrl = null;
if (!empty($my_posts)) {
  $p0   = $my_posts[0];
  $slug = $p0['slug'] ?? ($slugify($p0['title'] ?? 'post') . '-' . (int)($p0['post_id'] ?? 0));
  $lastUrl = '/article/' . $slug;
}

// Datos de usuario
$username    = (string)($user['username'] ?? 'usuario');
$memberSince = !empty($user['created_at']) ? date('Y-m-d', strtotime($user['created_at'])) : '';
$avatarUrl   = (string)($user['avatar_url'] ?? ''); // vacío si no hay avatar real

// ID del usuario (con fallbacks desde $auth)
$authUserId = 0;
if (isset($auth) && is_array($auth)) {
  if (isset($auth['user']) && is_array($auth['user'])) {
    $authUserId = (int)($auth['user']['user_id'] ?? $auth['user']['id'] ?? 0);
  } else {
    $authUserId = (int)($auth['user_id'] ?? 0);
  }
}
$userId    = (int)($user['user_id'] ?? $authUserId);
$publicUrl = $userId > 0 ? '/u/'.$userId : null;

// Inicial para fallback tipo user-corner
$initial = strtoupper(mb_substr($username, 0, 1, 'UTF-8') ?: 'U');

// Determinar si hay avatar “real” o usar inicial
$hasAvatar = $avatarUrl !== '' && !preg_match('~avatar-default\.png|default|placeholder~i', $avatarUrl);

// Métricas (fallbacks seguros)
$mp          = $my_posts_pagination ?? [];
$totalPosts  = (int)($mp['total'] ?? (is_array($my_posts ?? null) ? count($my_posts) : 0));
$unread      = (int)($unread_messages_count ?? 0);
$reputation  = isset($user['avg_rating']) ? number_format((float)$user['avg_rating'], 1) : (isset($user['reputation']) ? number_format((float)$user['reputation'],1) : '—');
$views       = (int)($user['profile_views'] ?? 0);

// Link activo
$currentUrl  = $currentUrl ?? ($_SERVER['REQUEST_URI'] ?? '/');

// ===== Detectar si es admin =====
// Priorizamos lo que venga en $auth, luego en $user
// Ajustá el "== 1" si usás otro ID de rol para admin
$isAdmin = false;
if (isset($auth['user']) && is_array($auth['user'])) {
    $roleFromAuth = (int)($auth['user']['rol_id'] ?? $auth['user']['role_id'] ?? 0);
    $isAdmin = $roleFromAuth === 1;
} elseif (isset($user) && is_array($user)) {
    $roleFromUser = (int)($user['rol_id'] ?? $user['role_id'] ?? 0);
    $isAdmin = $roleFromUser === 1;
}
// También: que esté logueado
$authCheck = isset($auth['check']) ? (bool)$auth['check'] : ($authUserId > 0);

?>
<link rel="stylesheet" href="/css/styles.css">
<link rel="stylesheet" href="/css/dashboard.css?v=2">

<div class="dash-wrapper">
  <!-- HERO / PERFIL -->
  <section class="profile-header">
    <div class="ph-left">
      <!-- Avatar -->
      <a href="/profile/edit" class="avatar-link" title="Editar perfil">
        <?php if ($hasAvatar): ?>
          <img class="avatar" src="<?= $h($avatarUrl) ?>" alt="Avatar de <?= $h($username) ?>">
        <?php else: ?>
          <div class="avatar avatar-inicial uc-avatar" role="img" aria-label="Avatar de <?= $h($username) ?>">
            <?= $h($initial) ?>
          </div>
        <?php endif; ?>
      </a>

      <div>
        <h1 class="title">Mi perfil</h1>
        <p class="subtitle">@<?= $h($username) ?> • Miembro desde <?= $h($memberSince) ?></p>
        <div class="quick-actions">
          <a class="btn btn-soft" href="/profile/edit">Editar perfil</a>
          <?php if ($publicUrl): ?>
            <a class="btn btn-soft" href="<?= $h($publicUrl) ?>" target="_blank">Ver perfil público</a>
          <?php endif; ?>
          <a href="/" class="btn btn-soft <?= ($currentUrl === '/' || $currentUrl === '') ? 'is-active' : '' ?>">Inicio</a>

          <?php if ($authCheck && $isAdmin): ?>
            <a href="/usuarios" class="btn btn-soft <?= ($currentUrl === '/usuarios') ? 'is-active' : '' ?>">Usuarios</a>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <div class="ph-right">
      <?php if ($lastUrl): ?>
        <a class="btn btn-primary" href="<?= $h($lastUrl) ?>">Ver mi último servicio</a>
      <?php endif; ?>
      <a class="btn btn-primary" href="/minuevo/crear">+ Nueva publicación</a>
    </div>
  </section>

  <!-- ATAJOS MENSAJERÍA -->
  <div class="msg-shortcuts">
    <span>Mensajería:</span>
    <a href="/messages/compose" class="chip-link">Enviar mensaje</a>
    <a href="/messages/sent" class="chip-link">Enviados</a>
    <a href="/messages/inbox" class="chip-link">Bandeja de entrada<?= $unread>0 ? ' ('.$unread.')' : '' ?></a>
  </div>

  <!-- MÉTRICAS -->
  <section class="stats-grid">
    <div class="stat-card">
      <span class="stat-label">Publicaciones</span>
      <span class="stat-value"><?= $totalPosts ?></span>
    </div>
    <div class="stat-card">
      <span class="stat-label">Mensajes sin leer</span>
      <span class="stat-value"><?= $unread ?></span>
    </div>
    <div class="stat-card">
      <span class="stat-label">Reputación</span>
      <span class="stat-value"><?= $h($reputation) ?> ⭐</span>
    </div>
    <div class="stat-card">
      <span class="stat-label">Visitas</span>
      <span class="stat-value"><?= number_format($views) ?></span>
    </div>
  </section>

  <!-- LISTADO DE PUBLICACIONES -->
  <section class="board">
    <header class="board-head">
      <h2>Mis publicaciones</h2>
      <div class="tools">
        <form class="search" method="get" action="/dashboard">
          <input type="search" name="q" placeholder="Buscar…" value="<?= $h($q) ?>">
          <input type="hidden" name="sort" value="<?= $h($sort) ?>">
        </form>
        <select class="select" name="sort" onchange="location.search='?q=<?= urlencode($q) ?>&sort='+this.value">
          <option value="fecha_desc"   <?= $sort==='fecha_desc'?'selected':''; ?>>Más recientes</option>
          <option value="rating_desc"  <?= $sort==='rating_desc'?'selected':''; ?>>Mejor rating</option>
          <option value="visitas_desc" <?= $sort==='visitas_desc'?'selected':''; ?>>Más vistas</option>
        </select>
      </div>
    </header>

    <?php if (empty($my_posts)): ?>
      <div class="card empty">
        <p class="meta">Todavía no publicaste nada.</p>
        <p style="margin-top:8px;">
          <a class="btn btn-primary" href="/minuevo/crear">Crear primera novedad</a>
        </p>
      </div>
    <?php else: ?>
      <?php foreach ($my_posts as $p):
        $pid     = (int)($p['post_id'] ?? 0);
        $slug    = $p['slug'] ?? ($slugify($p['title'] ?? 'post') . '-' . $pid);
        $title   = (string)($p['title'] ?? 'Sin título');
        $created = !empty($p['created_at']) ? date('Y-m-d', strtotime($p['created_at'])) : '';
        $excerpt = isset($p['content']) ? mb_strimwidth((string)$p['content'], 0, 160, '…') : '';
        $cat     = (string)($p['category'] ?? ($p['category_name'] ?? ''));
        $rating  = isset($p['avg_rating']) ? number_format((float)$p['avg_rating'], 1) : '—';
        $vistas  = (int)($p['views'] ?? 0);
      ?>
      <article class="post-card">
        <div class="post-main">
          <div class="thumb"></div>
          <div class="info">
            <h3 class="post-title">
              <a href="/article/<?= $h($slug) ?>"><?= $h($title) ?></a>
              <?php if ($cat !== ''): ?><span class="chip"><?= $h($cat) ?></span><?php endif; ?>
            </h3>
            <p class="post-desc"><?= nl2br($h($excerpt)) ?></p>
            <div class="meta">
              <span>Fecha: <?= $h($created) ?></span>
              <span>⭐ <?= $h($rating) ?></span>
              <span>👁️ <?= number_format($vistas) ?></span>
            </div>
          </div>
        </div>
        <div class="post-actions">
          <a class="btn btn-soft" href="/article/<?= $h($slug) ?>">Ver</a>
          <!-- acá podes reabrir editar/eliminar -->
        </div>
      </article>
      <?php endforeach; ?>

      <?php if (!empty($my_posts_pagination)):
        $page    = (int)($mp['page']    ?? 1);
        $perPage = (int)($mp['perPage'] ?? 6);
        $total   = (int)($mp['total']   ?? 0);
        $hasPrev = !empty($mp['hasPrev']);
        $hasNext = !empty($mp['hasNext']);
        $pages   = max(1, (int)ceil($total / max(1, $perPage)));
        $prevUrl = $hasPrev ? ('/dashboard?mp=' . ($page - 1) . '&q=' . urlencode($q) . '&sort=' . urlencode($sort)) : null;
        $nextUrl = $hasNext ? ('/dashboard?mp=' . ($page + 1) . '&q=' . urlencode($q) . '&sort=' . urlencode($sort)) : null;
      ?>
      <div class="card pager">
        <span class="meta">Página <?= $page ?> de <?= $pages ?></span>
        <div class="pager-actions">
          <?php if ($prevUrl): ?><a class="btn btn-soft" href="<?= $h($prevUrl) ?>">← Anterior</a><?php endif; ?>
          <?php if ($nextUrl): ?><a class="btn btn-soft" href="<?= $h($nextUrl) ?>">Siguiente →</a><?php endif; ?>
        </div>
      </div>
      <?php endif; ?>
    <?php endif; ?>
  </section>
</div>

