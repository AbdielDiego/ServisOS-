<?php
/** @var array       $posts */
/** @var string|null $titulo */
/** @var string|null $basePath */

declare(strict_types=1);

$BASE = htmlspecialchars(rtrim((string)($basePath ?? ''), '/'), ENT_QUOTES, 'UTF-8');
if ($BASE === '' || $BASE === '.') { $BASE = ''; }

/* Widget de estrellas sin rutas absolutas */
require_once __DIR__ . '/../components/scoring_system.php';

/* ---------------- Helpers ---------------- */
if (!function_exists('h')) {
  function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
}

$fmtExcerpt = function(string $text): string {
    if (function_exists('mb_strimwidth')) return mb_strimwidth($text, 0, 180, '…');
    return (strlen($text) > 180) ? substr($text, 0, 177) . '…' : $text;
};

$isNew = function (?string $createdAt): bool {
    if (!$createdAt) return false;
    try {
        $d = new DateTime($createdAt);
        return (new DateTime())->diff($d)->days <= 7;
    } catch (\Throwable $e) { return false; }
};
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title><?= h($titulo ?? 'Servicios') ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- CSS específico (incluye mejoras visuales y estrellas) -->
  <link rel="stylesheet" href="/css/post.css">
</head>
<body>
<section class="services">
  <h1 class="page-title"><?= h($titulo ?? 'Servicios') ?></h1>

  <?php if (empty($posts)): ?>
    <p class="empty-state">No hay servicios.</p>
  <?php else: ?>
    <ul class="service-list">
      <?php foreach ($posts as $p): ?>
        <?php
          $id       = (int)($p['post_id']      ?? 0);
          $title    = (string)($p['title']      ?? '');
          $content  = (string)($p['content']    ?? '');
          $created  = (string)($p['created_at'] ?? '');
          $category = (string)($p['category']   ?? ($p['category_name'] ?? ''));
          $price    = (int)   ($p['price']      ?? 0);
          $author   = (string)($p['username']   ?? '');

          $excerpt = $fmtExcerpt($content);
        ?>
        <li class="service-item">
          <header class="service-header">
            <div class="title-row">
              <h3><?= h($title) ?></h3>
              <div class="chips">
                <?php if ($category !== ''): ?>
                  <span class="chip chip-cat"># <?= h($category) ?></span>
                <?php endif; ?>
                <?php if ($price > 0): ?>
                  <span class="chip chip-price">$ <?= number_format($price, 0, ',', '.') ?></span>
                <?php endif; ?>
                <?php if ($isNew($created)): ?>
                  <span class="chip chip-new">Nuevo</span>
                <?php endif; ?>
              </div>
            </div>
            <small class="created"><?= h($created) ?></small>
            <?php if ($author !== ''): ?>
              <small class="author">• <?= h($author) ?></small>
            <?php endif; ?>
          </header>

          <p class="service-excerpt"><?= nl2br(h($excerpt)) ?></p>

          <div class="actions">
            <a class="btn btn-blue" href="<?= $BASE ?>/post/detail?id=<?= $id ?>">Ver detalles</a>
            <a class="btn btn-teal" href="<?= $BASE ?>/post/<?= $id ?>">Ver comentarios/comentar</a>
            <a class="btn btn-sky"  href="<?= $BASE ?>/messages/contact?post_id=<?= $id ?>">Enviar un mensaje</a>

            <div class="rating-wrap">
              <?php render_star_rating($id); ?>
            </div>
          </div>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>
</body>
</html>

