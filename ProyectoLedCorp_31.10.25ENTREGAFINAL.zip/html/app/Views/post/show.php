<?php
/** @var array            $post */
/** @var array<int,array> $comments */
/** @var array|null       $auth */
/** @var string|null      $commentAction */
/** @var bool|null        $focusForm */

if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }

if (!function_exists('h')) {
  function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
}

/* ---------- Datos del post ---------- */
$postId  = (int)($post['post_id'] ?? 0);
$title   = h($post['title']   ?? 'Post');
$content = nl2br(h($post['content'] ?? ''));

/* ---------- Acción del form ---------- */
$formAction = (isset($commentAction) && $commentAction)
  ? (string)$commentAction
  : ($postId > 0 ? "/post/{$postId}/comments" : "/comments");

/* ---------- return_to para volver al mismo post con ancla ---------- */
$returnTo = $postId > 0 ? "/post/{$postId}#comentarios" : "/post";

/* ---------- Autenticación / permisos ---------- */
$authLocal = $auth ?? ($_SESSION['auth'] ?? null);

$viewerId = (int)(
  ($authLocal['user']['user_id'] ?? null)
  ?? ($authLocal['user']['id'] ?? null)
  ?? ($_SESSION['auth']['user']['user_id'] ?? null)
  ?? ($_SESSION['user']['user_id'] ?? null)
  ?? ($_SESSION['user_id'] ?? 0)
);

$viewerRolId = (int)(
  ($authLocal['user']['rol_id'] ?? null)
  ?? ($_SESSION['auth']['user']['rol_id'] ?? null)
  ?? ($_SESSION['user']['rol_id'] ?? null)
  ?? ($_SESSION['rol_id'] ?? 0)
);

$isAdmin = ($viewerRolId === 1);
$isAuth  = $viewerId > 0;

/* ---------- Flashes ---------- */
$flashOk     = $_SESSION['flash_ok']    ?? null;
$flashError  = $_SESSION['flash_error'] ?? null;
$flashes     = $flashes ?? []; // si el layout inyecta $flashes
unset($_SESSION['flash_ok'], $_SESSION['flash_error']);
?>
<section class="post-show">
<link rel="stylesheet" href="/css/post_show.css">
  <h1 class="post-title"><?= $title ?></h1>
  <p class="post-content"><?= $content ?></p>

  <?php if (!empty($flashes)): ?>
    <?php include __DIR__ . '/../partials/flash.php'; ?>
  <?php endif; ?>

  <?php if (!empty($flashOk)): ?>
    <div class="alert alert-success">
      <?= h($flashOk) ?>
    </div>
  <?php endif; ?>
  <?php if (!empty($flashError)): ?>
    <div class="alert alert-danger">
      <?= h($flashError) ?>
    </div>
  <?php endif; ?>

  <!-- ================= Formulario: Comentar ================= -->
  <h2 id="comentar" class="section-title">Comentar</h2>

  <?php if ($isAuth): ?>
    <form action="<?= h($formAction) ?>" method="post" class="comment-form">
      <input type="hidden" name="post_id"   value="<?= $postId ?>">
      <input type="hidden" name="return_to" value="<?= h($returnTo) ?>">
      <textarea name="comment_text" rows="4" required minlength="2"
        placeholder="Escribe tu comentario..."
        class="comment-textarea"></textarea>
      <button type="submit" class="comment-button">
        Publicar
      </button>
    </form>
  <?php else: ?>
    <p><a href="/login">Inicia sesión</a> para comentar.</p>
  <?php endif; ?>

  <!-- ================= Listado de comentarios ================= -->
  <h2 id="comentarios" class="section-title">Comentarios</h2>

  <?php if (empty($comments)): ?>
    <p>No hay comentarios aún.</p>
  <?php else: ?>
    <ul class="comments-list">
      <?php foreach ($comments as $c): ?>
        <?php
          $cid     = (int)($c['comment_id'] ?? 0);
          $owner   = (int)($c['user_id'] ?? 0);
          $uname   = h($c['username'] ?? 'Anónimo');
          $texto   = nl2br(h($c['comment_text'] ?? ($c['body'] ?? '')));
          $fecha   = h($c['created_at'] ?? '');
          $editTag = h($c['edit'] ?? '');
          $canEdit = ($isAdmin || ($owner > 0 && $owner === $viewerId));
          $canDel  = $canEdit;
        ?>
        <li class="comment-item">
          <div class="comment-meta">
            <div class="comment-user-block">
              <strong class="comment-user"><?= $uname ?></strong>
              <small class="comment-date"> — <?= $fecha ?></small>
              <?php if ($editTag !== ''): ?>
                <small class="comment-edited">· Editado (<?= $editTag ?>)</small>
              <?php endif; ?>
            </div>

            <div class="comment-actions">
              <?php if ($canEdit && $cid > 0): ?>
                <a class="comment-edit-btn"
                   href="/comments/<?= $cid ?>/edit?return_to=<?= urlencode($returnTo) ?>">
                  Editar
                </a>
              <?php endif; ?>

              <?php if ($canDel && $cid > 0): ?>
                <form action="/comment/delete" method="POST"
                      onsubmit="return confirm('¿Eliminar este comentario?')"
                      class="comment-delete-form">
                  <input type="hidden" name="comment_id" value="<?= $cid ?>">
                  <input type="hidden" name="return_to"  value="<?= h($returnTo) ?>">
                  <button type="submit" class="comment-delete-btn">
                    Eliminar
                  </button>
                </form>
              <?php endif; ?>
            </div>
          </div>

          <p class="comment-text"><?= $texto ?></p>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>

<?php if (!empty($focusForm)): ?>
<script>
  const el = document.getElementById('comentar');
  if (el) el.scrollIntoView({behavior:'smooth', block:'start'});
</script>
<?php endif; ?>

