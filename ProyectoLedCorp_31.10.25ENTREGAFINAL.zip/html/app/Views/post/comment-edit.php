<?php
/** @var array $comment */
/** @var string $return_to */
/** @var array|null $auth */
/** @var string $title */

if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$cid     = (int)($comment['comment_id'] ?? 0);
$postId  = (int)($comment['post_id'] ?? 0);
$text    = (string)($comment['comment_text'] ?? '');
$uname   = h($comment['username'] ?? 'Usuario');
$backUrl = (string)($return_to ?? ('/post/' . $postId . '#comentarios'));

/* Flashes simples (compat con tu layout/partials) */
$ok    = $_SESSION['flash_ok']    ?? null;
$err   = $_SESSION['flash_error'] ?? null;
$warn  = $_SESSION['flash_warn']  ?? null;
$info  = $_SESSION['flash_info']  ?? null;
unset($_SESSION['flash_ok'], $_SESSION['flash_error'], $_SESSION['flash_warn'], $_SESSION['flash_info']);
?>

<link rel="stylesheet" href="/css/comment-edit.css?v=1">

<img class="brand-mini" src="/imagenes/comment-edit-chivita.png" alt="Chivita editando un comentario">

<section class="comment-edit">
  <h1><?= h($title ?? 'Editar comentario') ?></h1>
  <p class="subtitle">Editando comentario de <strong><?= $uname ?></strong></p>

  <?php if ($ok):   ?><div class="flash flash-success"><?= h($ok) ?></div><?php endif; ?>
  <?php if ($err):  ?><div class="flash flash-error"><?= h($err) ?></div><?php endif; ?>
  <?php if ($warn): ?><div class="flash flash-warn"><?= h($warn) ?></div><?php endif; ?>
  <?php if ($info): ?><div class="flash flash-info"><?= h($info) ?></div><?php endif; ?>

  <!-- IMPORTANTE: la ruta correcta para actualizar es POST /comments/:id -->
  <form action="/comments/<?= $cid ?>" method="post">
    <input type="hidden" name="id" value="<?= $cid ?>">
    <input type="hidden" name="return_to" value="<?= h($backUrl) ?>">

    <label for="comment_text" class="form-field-label">Texto</label>
    <textarea id="comment_text" name="comment_text" rows="6" required class="textarea" maxlength="2000"><?= h($text) ?></textarea>

    <div class="btn-row">
      <button type="submit" class="btn btn-primary">Guardar cambios</button>
      <a href="<?= h($backUrl) ?>" class="btn btn-secondary">Cancelar</a>
    </div>
  </form>
</section>

