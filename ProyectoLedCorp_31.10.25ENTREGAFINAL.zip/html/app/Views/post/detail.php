<link rel="stylesheet" href="/css/detail.css">

<?php
/** @var array $post */
/** @var array $author */

// Helper de escape seguro
if (!function_exists('h')) {
    function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
}

// ================== DATOS DEL POST / AUTOR ==================
$title     = $post['title']   ?? $post['nombre'] ?? 'Detalle del servicio';
$desc      = $post['content'] ?? $post['descripcion'] ?? $post['description'] ?? '';
$username  = $author['username'] ?? 'Desconocido';
$email     = $author['email']    ?? '';
$created   = $post['created_at'] ?? '';
$category  = $post['category'] ?? ($post['category_name'] ?? '');
$priceInt  = (int)($post['price'] ?? $post['precio'] ?? $post['monto'] ?? 0);
$priceFmt  = number_format($priceInt, 0, ',', '.');
$postId    = (int)($post['post_id'] ?? ($post['id'] ?? ($_GET['id'] ?? 0)));

// 🔎 IMPORTANTE: buscar el ID del autor en TODOS lados conocidos
$authorId = (int)(
    $author['user_id']  // 1) si el autor viene separado
    ?? $author['id']
    ?? $post['user_id'] // 2) muchos controladores lo mandan en el post
    ?? $post['author_id']
    ?? 0
);

// si encontramos ID, armamos la URL pública
$authorPublicUrl = $authorId > 0 ? '/u/' . $authorId : null;

// Querystring para “enviar mensaje”
$qs = http_build_query([
  'post_id' => $postId,
  'title'   => $title,
  'price'   => $priceInt,
]);
?>

<!-- Fallback de estilos por si no cargó tu CSS -->

<section class="detail-page">
  <header class="detail-hero">
    <h1 class="detail-title"><?= h($title) ?></h1>

    <div class="meta-inline">
      <span>
        <b>Creado por:</b> <?= h($username) ?><?= $email ? ' ('.h($email).')' : '' ?>
      </span>
      <?php if ($created): ?>
        <span class="dot">•</span>
        <span><?= h($created) ?></span>
      <?php endif; ?>

      <?php if ($authorPublicUrl): ?>

        <span class="dot">•</span>
        <a class="meta-link" href="<?= h($authorPublicUrl) ?>">
          Ver perfil público
        </a>
      <?php endif; ?>
    </div>

    <div class="chips">
      <?php if ($category): ?>
        <span class="chip chip-cat"># <?= h($category) ?></span>
      <?php endif; ?>
      <span class="chip chip-price">$ <?= h($priceFmt) ?></span>
    </div>
  </header>

  <article class="content-card detail-body">
    <div><?= nl2br(h($desc)) ?></div>
  </article>

  <div class="cta-row">
    <a class="btn-primary" href="/messages/contact?<?= $qs ?>">Enviar un mensaje</a>

    <?php if ($authorPublicUrl): ?>
    
      <a class="btn-soft" href="<?= h($authorPublicUrl) ?>">
        Ver perfil público
      </a>
    <?php endif; ?>

    <a class="back-link" href="/post">← Volver a servicios</a>
  </div>
</section>

