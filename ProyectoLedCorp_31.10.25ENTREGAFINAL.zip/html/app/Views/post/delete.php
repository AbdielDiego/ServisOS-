<link rel="stylesheet" href="/css/post_delete.css">
<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}

$postId   = (int)($_GET['post_id'] ?? 0);
$flashOk  = $_SESSION['flash_ok']   ?? $_SESSION['flash_success'] ?? null;
$flashErr = $_SESSION['flash_error'] ?? null;

// Limpiar flashes para que no reaparezcan
unset($_SESSION['flash_ok'], $_SESSION['flash_success'], $_SESSION['flash_error']);
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Comentario eliminado</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- CSS global -->
  <link rel="stylesheet" href="/css/styles.css">
  <!-- CSS específico de esta vista -->
  <link rel="stylesheet" href="/css/comment-deleted.css">
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>Comentario eliminado</h1>

      <?php if ($flashOk): ?>
        <div class="ok"><?= htmlspecialchars($flashOk, ENT_QUOTES, 'UTF-8') ?></div>
      <?php endif; ?>

      <?php if ($flashErr): ?>
        <div class="err"><?= htmlspecialchars($flashErr, ENT_QUOTES, 'UTF-8') ?></div>
      <?php endif; ?>

      <p>Tu comentario fue procesado correctamente.</p>

      <p>
        <?php if ($postId > 0): ?>
          <a class="btn" href="/post/<?= $postId ?>#comentarios">Volver al post</a>
        <?php endif; ?>
        <a class="btn secondary" href="/">Ir al inicio</a>
      </p>
    </div>
  </div>
</body>
</html>

