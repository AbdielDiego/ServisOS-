<link rel="stylesheet" href="/css/inbox.css">
<?php
/** @var array $message */
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// Datos del remitente para mostrar y para responder
$fromName  = $message['from_name']     ?? '';
$fromEmail = $message['from_email']    ?? '';
$fromUser  = $message['from_username'] ?? '';
$from      = $fromName !== '' ? $fromName : ($fromEmail !== '' ? $fromEmail : 'Desconocido');

// Asunto (y versión con "Re:" para la respuesta)
$subject       = trim((string)($message['subject'] ?? ''));
$replySubject  = preg_match('/^re:/i', $subject) ? $subject : ('Re: ' . $subject);

// Prioriza responder al username; si no hay, usa el email
$replyTo = $fromUser !== '' ? $fromUser : $fromEmail;
?>
<div class="message-show">
  <h1>Mensaje</h1>

  <p><strong>De:</strong> <?= h($from) ?></p>
  <?php if ($subject !== ''): ?>
    <p><strong>Asunto:</strong> <?= h($subject) ?></p>
  <?php endif; ?>
  <p><strong>Fecha:</strong> <?= h($message['created_at'] ?? '') ?></p>

  <hr>

  <div class="message-body"><?= nl2br(h($message['body'] ?? '')) ?></div>

  <p class="actions" style="margin-top:1rem">
    <a class="btn-responder"
       href="/messages/reply.php?to=<?= urlencode($replyTo) ?>&subject=<?= urlencode($replySubject) ?>">
      Responder
    </a>
    &nbsp; <a href="/messages/inbox">Volver al inbox</a>
  </p>
</div>

