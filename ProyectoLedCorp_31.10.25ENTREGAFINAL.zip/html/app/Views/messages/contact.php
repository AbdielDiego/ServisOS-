<link rel="stylesheet" href="/css/contact.css">
<?php
// contact.php – Vista Contactar (lógica mínima + HTML limpio)

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// Datos inyectados por el controlador (con fallbacks por GET)
$recipient = $recipient ?? [];
$username  = $recipient['username'] ?? ($_GET['username'] ?? $_GET['user'] ?? '');
$email     = $recipient['email']    ?? ($_GET['email']    ?? $_GET['gmail'] ?? '');
$userId    = $recipient['user_id']  ?? ($_GET['user_id']  ?? $_GET['uid']   ?? '');
$postTitle = $post['title']         ?? ($_GET['title']    ?? '');
$postId    = (int)($_GET['post_id'] ?? 0);

// Valor que usa el backend para resolver destinatario
$toQuery = $username !== '' ? $username : $email;

// Asunto por defecto (el backend lo puede sobreescribir si marcas “Contratar servicio”)
$autoSubject = 'Consulta sobre tu servicio' . ($postTitle ? (': ' . $postTitle) : '');

// Mensaje previo o errores
$old   = $old   ?? [];
$error = $error ?? null;

if ($toQuery === '') {
  $error = $error ?: 'No se pudo identificar al destinatario. Vuelve desde el servicio para contactar.';
}
?>

<section class="contact-page">
  <header class="contact-header">
    <h1 class="contact-title">Contactar</h1>
    <p class="contact-sub">Envía un mensaje al proveedor. Si marcas “Contratar servicio”, registraremos la contratación.</p>
  </header>

  <?php if ($error): ?>
    <div class="alert error"><?= h($error) ?></div>
  <?php endif; ?>

  <div class="recipient-card">
    <div class="meta-list">
      <div class="item"><b>Usuario:</b> <?= h($username ?: '—') ?></div>
      <div class="item"><b>Email:</b> <?= h($email ?: '—') ?></div>
      <?php if ($postTitle): ?>
      <div class="item"><b>Servicio:</b> <?= h($postTitle) ?></div>
      <?php endif; ?>
    </div>
  </div>

  <form method="post" action="/messages" class="contact-form">
    <!-- Ocultos para el backend -->
    <input type="hidden" name="to_query" value="<?= h($toQuery) ?>">
    <input type="hidden" name="subject"  value="<?= h($autoSubject) ?>">
    <?php if ($userId !== ''): ?>
      <input type="hidden" name="user_id" value="<?= h($userId) ?>">
    <?php endif; ?>
    <?php if ($postId > 0): ?>
      <input type="hidden" name="post_id" value="<?= (int)$postId ?>">
    <?php endif; ?>

    <label class="toggle">
      <input type="checkbox" name="contract_service" value="1">
      <span><strong>Contratar servicio</strong> <small>(se notificará “Servicio contratado” y se guardará en la base)</small></span>
    </label>

    <div class="field">
      <label for="body">Mensaje</label>
      <textarea id="body" name="body" required><?= h($old['body'] ?? '') ?></textarea>
    </div>

    <div class="hr-soft"></div>

    <div class="form-foot">
      <button type="submit" class="btn-primary">Enviar</button>
    </div>
  </form>
</section>

