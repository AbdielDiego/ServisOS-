<link rel="stylesheet" href="/css/styles.css">
<link rel="stylesheet" href="/css/message-form.css">

<?php
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$old   = $old   ?? [];
$error = $error ?? null;
$title = $title ?? 'Nuevo mensaje';
?>

<h1 class="msg-title"><?= h($title) ?></h1>

<?php if ($error): ?>
  <div class="alert alert-error"><?= h($error) ?></div>
<?php endif; ?>

<form method="post" action="/messages" class="msg-form">
  <label for="to_query" class="form-label">
    <strong>Para</strong> <span class="hint">(usuario o email, separados por coma)</span>
  </label>
  <input
    type="text"
    id="to_query"
    name="to_query"
    class="form-input"
    value="<?= h($old['to_query'] ?? '') ?>"
    placeholder="p.ej. diego, maria@gmail.com, juanperez"
    required
  >

  <label for="subject" class="form-label">
    <strong>Asunto</strong>
  </label>
  <input
    type="text"
    id="subject"
    name="subject"
    class="form-input"
    value="<?= h($old['subject'] ?? '') ?>"
    required
  >

  <label for="body" class="form-label">
    <strong>Mensaje</strong>
  </label>
  <textarea
    id="body"
    name="body"
    rows="8"
    class="form-textarea"
    required
  ><?= h($old['body'] ?? '') ?></textarea>

  <button type="submit" class="btn btn-primary">Enviar</button>
</form>

