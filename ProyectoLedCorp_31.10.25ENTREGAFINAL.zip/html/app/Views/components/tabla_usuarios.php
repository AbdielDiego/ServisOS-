<link rel="stylesheet" href="/css/tabla_usuarios.css">
<?php
// ---------- helpers ----------
if (!function_exists('esc')) {
    function esc(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
}
$toLower = function($s){
    return function_exists('mb_strtolower') ? mb_strtolower((string)$s, 'UTF-8') : strtolower((string)$s);
};

// ---------- mensajes flash opcionales ----------
$ok    = $ok    ?? ($_SESSION['flash_ok']    ?? null);
$error = $error ?? ($_SESSION['flash_error'] ?? null);

// ---------- datos de entrada ----------
$BASE       = $BASE ?? '';
$baseUrl    = strtok((string)($_SERVER['REQUEST_URI'] ?? ''), '?');
$emptyText  = $emptyText ?? 'No hay usuarios';
$datosTabla = $datosTabla ?? []; // puede venir vacío

// Normalizamos $datosTabla y detectamos columnas
if (!empty($datosTabla)) {
    if (isset($datosTabla[0]) && is_array($datosTabla[0])) {
        $columnas = array_keys($datosTabla[0]);
    } else {
        $columnas   = array_keys((array)$datosTabla);
        $datosTabla = [ $datosTabla ];
    }
} else {
    $columnas = []; // sin datos
}

// ---------- detectar campo ID para acciones ----------
$idKey = null;
foreach (['user_id','id','UserId','ID','userid'] as $k) {
    if (in_array($k, $columnas, true)) { $idKey = $k; break; }
}
$showActions = $idKey !== null;

// ---------- filtros por GET ----------
$qUserRaw  = trim((string)($_GET['username'] ?? ''));
$qEmailRaw = trim((string)($_GET['email']    ?? ''));
if (strlen($qUserRaw)  > 100) $qUserRaw  = substr($qUserRaw,  0, 100);
if (strlen($qEmailRaw) > 100) $qEmailRaw = substr($qEmailRaw, 0, 100);
$qUser  = $toLower($qUserRaw);
$qEmail = $toLower($qEmailRaw);

// Aplicamos filtro in-memory
$filtrados = $datosTabla;
if ($qUser !== '' || $qEmail !== '') {
    $filtrados = array_values(array_filter($datosTabla, function($fila) use ($qUser, $qEmail, $toLower) {
        $u = $toLower($fila['username'] ?? '');
        $e = $toLower($fila['email']    ?? '');
        $okU = ($qUser  === '') || (strpos($u, $qUser)  !== false);
        $okE = ($qEmail === '') || (strpos($e, $qEmail) !== false);
        return $okU && $okE;
    }));
}
?>

<!-- Asegúrate de que esta hoja se sirva desde /css/tabla_usuarios.css -->
<link rel="stylesheet" href="/css/tabla_usuarios.css">

<section class="usuarios-index container">
    <header class="header-list">
        <h1>Usuarios</h1>

        <?php if ($ok): ?>
            <div class="flash ok"><?= esc($ok) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="flash error"><?= esc($error) ?></div>
        <?php endif; ?>

        <div class="header-actions">
            <a class="btn btn-secondary" href="/usuarios/baneados">Ver usuarios baneados</a>
        </div>
    </header>

    <!-- Barra de búsqueda -->
    <form class="table-toolbar" method="get" action="">
        <div class="toolbar-row">
            <input type="search" name="username" value="<?= esc($qUserRaw) ?>" placeholder="Buscar por usuario…" autocomplete="off">
            <input type="search" name="email"    value="<?= esc($qEmailRaw) ?>" placeholder="Buscar por email…"   autocomplete="off">
            <button type="submit" class="btn btn-primary">Buscar</button>
            <a class="btn btn-muted" href="<?= esc($baseUrl) ?>">Limpiar</a>
            <span class="result-count">Resultados: <?= count($filtrados) ?></span>
        </div>
    </form>

    <?php if (!empty($columnas)): ?>
        <table class="tabla users-table tabla-compact">
            <thead>
                <tr>
                    <?php foreach ($columnas as $col): ?>
                        <th><?= esc($col) ?></th>
                    <?php endforeach; ?>
                    <?php if ($showActions): ?>
                        <th class="th-actions">acciones</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($filtrados)): ?>
                <tr><td colspan="<?= count($columnas) + ($showActions ? 1 : 0) ?>"><?= esc($emptyText) ?></td></tr>
            <?php else: ?>
                <?php foreach ($filtrados as $fila): ?>
                    <?php
                        $rowId    = $fila[$idKey] ?? null;
                        $rolValue = (int)($fila['rol_id'] ?? $fila['role_id'] ?? 2);
                        $isAdmin  = ($rolValue === 1);
                        $uname    = (string)($fila['username'] ?? ('#'.$rowId));
                    ?>
                    <tr>
                        <?php foreach ($columnas as $col): ?>
                            <td><?= esc((string)($fila[$col] ?? '')) ?></td>
                        <?php endforeach; ?>

                        <?php if ($showActions && $rowId !== null): ?>
                            <td class="acciones">
                                <?php if ($isAdmin): ?>
                                    <!-- Quitar admin -> volver user -->
                                    <a href="/usuarios/make-user/<?= (int)$rowId ?>"
                                       class="action-link action-admin"
                                       onclick="return confirm('¿Quitar permisos de admin a <?= esc($uname) ?> y volverlo usuario?');">
                                       Quitar admin
                                    </a>
                                    &nbsp;|&nbsp;
                                <?php else: ?>
                                    <!-- Volver admin -->
                                    <a href="/usuarios/make-admin/<?= (int)$rowId ?>"
                                       class="action-link action-admin"
                                       onclick="return confirm('¿Convertir a admin a <?= esc($uname) ?>?');">
                                       Volver admin
                                    </a>
                                    &nbsp;|&nbsp;
                                <?php endif; ?>

                                <a href="/usuarios/ban/<?= (int)$rowId ?>" class="action-link action-ban">Banear</a>
                                &nbsp;|&nbsp;

                                <a href="/users/delete/<?= (int)$rowId ?>"
                                   class="action-link action-del"
                                   onclick="return confirm('¿Eliminar definitivamente al usuario #<?= (int)$rowId ?>?');">
                                   Eliminar
                                </a>
                            </td>
                        <?php elseif ($showActions): ?>
                            <td class="acciones"><em>—</em></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    <?php else: ?>
        <h2 class="empty-state">SIN DATOS</h2>
    <?php endif; ?>
</section>

