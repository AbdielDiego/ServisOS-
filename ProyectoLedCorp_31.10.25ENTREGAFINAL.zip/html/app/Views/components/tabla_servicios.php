<?php
// ===================== Tabla genérica con BÚSQUEDA =====================
$datosTabla = $datosTabla ?? ($servicios ?? []);
if (!is_array($datosTabla)) { $datosTabla = []; }

$normalize = function(array $rows): array {
    if (empty($rows)) return [];
    if (isset($rows[0]) && is_array($rows[0])) return $rows;
    return [ $rows ];
};
$datosTabla = $normalize($datosTabla);

// -------- Filtro local por ?q=... --------
$q = trim((string)($_GET['q'] ?? ''));
if ($q !== '') {
    $needle = mb_strtolower($q);
    $datosTabla = array_values(array_filter($datosTabla, function($fila) use ($needle){
        foreach ($fila as $v) {
            if (is_scalar($v) && mb_strpos(mb_strtolower((string)$v), $needle) !== false) {
                return true;
            }
        }
        return false;
    }));
}

if (empty($datosTabla)) {
    $msg = $q !== '' ? 'No se encontraron resultados para “'.htmlspecialchars($q, ENT_QUOTES, 'UTF-8').'”.'
                     : 'SIN DATOS';
    echo '<h3 class="empty-state">'.$msg.'</h3>';
    return;
}

$columnas = array_keys($datosTabla[0]);
$BASE = defined('BASE_URL') ? rtrim((string)BASE_URL, '/') : '';

$detectarRecursoEId = function(array $filas, array $cols): array {
    $normCols = array_map('strtolower', $cols);
    $map = array_combine($normCols, $cols);

    $has = function($names) use ($map) {
        foreach ((array)$names as $n) {
            $n = strtolower($n);
            if (isset($map[$n])) return $map[$n];
        }
        return null;
    };

    if ($id = $has(['post_id','id_post']))     return ['entity'=>'post',     'idCol'=>$id];
    if ($id = $has(['service_id','servicio_id','id_service','id_servicio'])) return ['entity'=>'servicio', 'idCol'=>$id];
    if ($id = $has(['category_id','categoria_id','id_category','id_categoria'])) return ['entity'=>'categoria','idCol'=>$id];
    if ($id = $has(['user_id','id_user']))     return ['entity'=>'user',     'idCol'=>$id];

    $pickByHeuristic = function(string $entity, array $cols) {
        foreach ($cols as $c) {
            $lc = strtolower($c);
            if ($entity === 'post'     && str_contains($lc,'post') && str_contains($lc,'id')) return $c;
            if ($entity === 'servicio' && (str_contains($lc,'serv') || str_contains($lc,'service')) && str_contains($lc,'id')) return $c;
            if ($entity === 'categoria'&& (str_contains($lc,'cat')  || str_contains($lc,'categ'))  && str_contains($lc,'id')) return $c;
        }
        return null;
    };
    if ($id = $pickByHeuristic('post', $cols))      return ['entity'=>'post',     'idCol'=>$id];
    if ($id = $pickByHeuristic('servicio', $cols))  return ['entity'=>'servicio', 'idCol'=>$id];
    if ($id = $pickByHeuristic('categoria', $cols)) return ['entity'=>'categoria','idCol'=>$id];

    $esNumerica = fn($v) => is_numeric($v) && $v !== '';
    $candidatos = [];

    foreach ($cols as $c) {
        $lc = strtolower($c);
        if ($lc === 'id' || (function_exists('str_ends_with') ? str_ends_with($lc,'_id') : substr($lc, -3) === '_id')) {
            $vals = [];
            $todosNumericos = true;
            foreach ($filas as $f) {
                $v = $f[$c] ?? null;
                if (!$esNumerica($v)) { $todosNumericos = false; break; }
                $vals[] = (string)$v;
            }
            if (!$todosNumericos) continue;
            if (count(array_unique($vals)) >= max(2, (int)floor(count($vals)*0.5))) {
                $candidatos[] = $c;
            }
        }
    }
    if (!empty($candidatos)) {
        return ['entity'=>'post', 'idCol'=>$candidatos[0]];
    }
    return ['entity'=>null, 'idCol'=>null];
};

$det = $detectarRecursoEId($datosTabla, $columnas);
$entity = $det['entity'];
$colId  = $det['idCol'];

$rutaBase = function(?string $entity) {
    switch ($entity) {
        case 'post':      return '/post';
        case 'servicio':  return '/servicio';
        case 'categoria': return '/categoria';
        case 'user':      return '/usuario';
        default:          return null;
    }
};

$baseEntidad = $rutaBase($entity);
?>
<table class="tabla users-table tabla-compact">
    <thead>
        <tr>
            <?php foreach ($columnas as $col): ?>
                <th><?= htmlspecialchars($col, ENT_QUOTES, 'UTF-8') ?></th>
            <?php endforeach; ?>
            <?php if ($colId && $baseEntidad): ?>
              <th>Acciones</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($datosTabla as $fila): ?>
            <tr>
                <?php foreach ($columnas as $col): ?>
                    <td><?= htmlspecialchars((string)($fila[$col] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                <?php endforeach; ?>

                <?php if ($colId && $baseEntidad): ?>
                    <?php
                      $idVal = $fila[$colId] ?? null;
                      $id    = is_numeric($idVal) ? (int)$idVal : 0;

                      // Si hay category_id en la fila, los botones apuntan a /apicategorias
                      $catId = 0;
                      foreach (['category_id','categoria_id','id_category','id_categoria'] as $cname) {
                        if (array_key_exists($cname, $fila) && is_numeric($fila[$cname])) {
                          $catId = (int)$fila[$cname];
                          break;
                        }
                      }

                      if ($catId > 0) {
                          $targetBase = $BASE . '/apicategorias?category_id=' . $catId;
                      } else {
                          $targetBase = $id > 0 ? ($BASE . $baseEntidad . '/' . $id) : null;
                      }
                    ?>
                    <td class="td-actions">
                      <?php if ($targetBase): ?>
                        <a class="btn btn-sm" href="<?= htmlspecialchars($targetBase . '#comentar', ENT_QUOTES, 'UTF-8') ?>">Comentar</a>
                        <a class="btn btn-sm" href="<?= htmlspecialchars($targetBase . '#comentarios', ENT_QUOTES, 'UTF-8') ?>">Ver comentarios</a>
                      <?php else: ?>
                        —
                      <?php endif; ?>
                    </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

