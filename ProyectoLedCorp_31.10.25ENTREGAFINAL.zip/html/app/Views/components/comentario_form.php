<?php
/**
 * Espera:
 * - $context   = 'categoria' | 'servicio' | 'post'
 * - $contextId = int (id real)
 * - $actionUrl = string (ruta completa + #comentar)
 */
$ctx = $context ?? 'categoria';
$cid = (int)($contextId ?? 0);
$action = $actionUrl ?? '#'; // la vista ya arma la URL correcta
?>

<form action="<?= htmlspecialchars($action, ENT_QUOTES, 'UTF-8') ?>" method="post" class="comentario-form">
  <input type="hidden" name="context" value="<?= htmlspecialchars($ctx, ENT_QUOTES, 'UTF-8') ?>">
  <input type="hidden" name="context_id" value="<?= $cid ?>">

  <?php if ($ctx === 'categoria'): ?>
    <!-- Si comentas sobre un post dentro de la categoría, incluye el post_id -->
    <input type="number" name="post_id" placeholder="ID del post" min="1" required>
  <?php endif; ?>

  <textarea name="comment_text" rows="3" placeholder="Escribe tu comentario..." required></textarea>
  <button type="submit">Publicar un comentario</button>
</form>

