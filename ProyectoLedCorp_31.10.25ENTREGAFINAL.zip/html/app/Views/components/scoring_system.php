<?php
// components/scoring_system.php
declare(strict_types=1);

/**
 * Componente UNIFICADO de puntaje por estrellas 1..5
 *
 * Uso en la vista:
 *   require_once __DIR__ . '/../components/scoring_system.php';
 *   render_star_rating($postId);
 *
 * Hace:
 * - Detecta usuario logueado
 * - Detecta dueño del post
 * - Si es dueño → NO puede puntuar
 * - Si hay modelo/DB del framework → lo usa
 * - Si no, usa PDO plano (fallback)
 */

// ===================== HELPERS BÁSICOS =====================

if (!function_exists('ss_current_user_id_for_view')) {
    function ss_current_user_id_for_view(): int
    {
        if (session_status() !== \PHP_SESSION_ACTIVE) {
            @session_start();
        }

        // formato típico: $_SESSION['auth']['user']['user_id']
        if (!empty($_SESSION['auth']['user']) && is_array($_SESSION['auth']['user'])) {
            $u  = $_SESSION['auth']['user'];
            $id = (int)($u['user_id'] ?? $u['id'] ?? 0);
            if ($id > 0) return $id;
        }

        // otro formato: $_SESSION['user']
        if (!empty($_SESSION['user']) && is_array($_SESSION['user'])) {
            $u  = $_SESSION['user'];
            $id = (int)($u['user_id'] ?? $u['id'] ?? 0);
            if ($id > 0) return $id;
        }

        // ultra simple
        if (!empty($_SESSION['user_id'])) {
            return (int)$_SESSION['user_id'];
        }

        return 0;
    }
}

/**
 * Devuelve un PDO funcionando.
 * - Si existe App\Core\Database → lo usa.
 * - Si no existe → crea PDO con localhost/proyutu (ajusta usuario/pass).
 */
if (!function_exists('ss_pdo')) {
    function ss_pdo(): PDO
    {
        static $pdo = null;
        if ($pdo instanceof PDO) {
            return $pdo;
        }

        // 1) intentar usar tu framework, si existe
        if (class_exists('\App\Core\Database')) {
            /** @var mixed $db */
            $db  = \App\Core\Database::getConnection();
            if ($db instanceof PDO) {
                $pdo = $db;
                return $pdo;
            }
        }

        // 2) fallback plano
        $pdo = new PDO(
            'mysql:host=localhost;dbname=proyutu;charset=utf8mb4',
            'root',        
            'rootpass',
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );
        return $pdo;
    }
}

/**
 * Devuelve el user_id dueño del post.
 */
if (!function_exists('ss_post_owner_id')) {
    function ss_post_owner_id(int $postId, PDO $pdo): int
    {
        $stmt = $pdo->prepare("SELECT user_id FROM Posts WHERE post_id = ? LIMIT 1");
        $stmt->execute([$postId]);
        $row = $stmt->fetch();
        return (int)($row['user_id'] ?? 0);
    }
}

/**
 * Devuelve [avg, count] de las puntuaciones de un post.
 * Usa tu modelo si existe, si no SQL directo.
 */
if (!function_exists('ss_post_rating_stats')) {
    function ss_post_rating_stats(int $postId, PDO $pdo): array
    {
        // Si tenés modelo de tu framework, lo usamos
        if (class_exists('\App\Models\PostRating')) {
            $model = new \App\Models\PostRating($pdo);
            if (method_exists($model, 'stats')) {
                return $model->stats($postId);
            }
        }

        // Fallback SQL
        $stmt = $pdo->prepare("SELECT AVG(rating) AS avg_rating, COUNT(*) AS total FROM post_ratings WHERE post_id = ?");
        $stmt->execute([$postId]);
        $row = $stmt->fetch() ?: ['avg_rating' => null, 'total' => 0];

        return [
            'avg'   => $row['avg_rating'] !== null ? (float)$row['avg_rating'] : 0.0,
            'count' => (int)$row['total'],
        ];
    }
}

/**
 * Devuelve el rating que YA hizo este usuario para este post (o null).
 */
if (!function_exists('ss_user_rating_for_post')) {
    function ss_user_rating_for_post(int $postId, int $userId, PDO $pdo): ?int
    {
        // Si tenés modelo, lo usamos
        if (class_exists('\App\Models\PostRating')) {
            $model = new \App\Models\PostRating($pdo);
            if (method_exists($model, 'getUserRating')) {
                return $model->getUserRating($postId, $userId);
            }
        }

        // Fallback SQL
        $stmt = $pdo->prepare("SELECT rating FROM post_ratings WHERE post_id = ? AND user_id = ? LIMIT 1");
        $stmt->execute([$postId, $userId]);
        $val = $stmt->fetchColumn();
        return $val !== false ? (int)$val : null;
    }
}

// ===================== FUNCIÓN PRINCIPAL =====================

if (!function_exists('render_star_rating')) {
    /**
     * Renderiza las estrellitas para un post.
     *
     * @param int   $postId
     * @param array $opts  ['showLoginLink' => bool]
     */
    function render_star_rating(int $postId, array $opts = []): void
    {
        $pdo  = ss_pdo();
        $uid  = ss_current_user_id_for_view();
        $opts = array_merge([
            'showLoginLink' => true,
        ], $opts);

        // 1) dueño del post
        $ownerId = ss_post_owner_id($postId, $pdo);

        // 2) si el que mira es el dueño → no puede puntuar
        if ($uid > 0 && $uid === $ownerId) {
            echo '<span class="rating-disabled">No puedes puntuar tu propio servicio 🛑</span>';
            return;
        }

        // 3) traer stats y mi voto (si no está logueado, será null)
        $stats      = ss_post_rating_stats($postId, $pdo);
        $avg        = $stats['avg'];
        $count      = $stats['count'];
        $userRating = $uid > 0 ? ss_user_rating_for_post($postId, $uid, $pdo) : null;

        // 4) si no está logueado → mostrar mensaje
        if ($uid === 0) {
            // igual mostramos promedio
            echo '<div class="rating-summary">';
            echo '<span class="avg" title="Promedio">' . number_format($avg, 1, ',', '.') . '</span>';
            echo '<span class="sep">•</span>';
            echo '<span class="count" title="Cantidad de votos">' . (int)$count . ' voto' . ($count===1?'':'s') . '</span>';
            if ($opts['showLoginLink']) {
                $returnTo = $_SERVER['REQUEST_URI'] ?? '/post';
                echo '<span class="sep">•</span>';
                echo '<a class="login-hint" href="/login?next=' . urlencode($returnTo) . '">Inicia sesión para votar</a>';
            }
            echo '</div>';
            return;
        }

        // 5) usuario logueado y NO es el dueño → mostrar formulario
        $active   = $userRating ?? (int)round($avg);
        $returnTo = $_SERVER['REQUEST_URI'] ?? '/post';

        ?>
        <form class="starbox star-form" action="/rating" method="post">
            <input type="hidden" name="post_id" value="<?= (int)$postId ?>">
            <input type="hidden" name="return"  value="<?= htmlspecialchars($returnTo, ENT_QUOTES, 'UTF-8') ?>">

            <div class="stars" role="radiogroup" aria-label="Puntaje por estrellas">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                    <button
                        type="submit"
                        name="rating"
                        value="<?= $i ?>"
                        class="star<?= $i <= $active ? ' is-filled' : '' ?>"
                        aria-label="<?= $i ?> estrella<?= $i > 1 ? 's' : '' ?>"
                    >★</button>
                <?php endfor; ?>
            </div>

            <div class="rating-summary">
                <span class="avg" title="Promedio"><?= number_format($avg, 1, ',', '.') ?></span>
                <span class="sep">•</span>
                <span class="count" title="Cantidad de votos"><?= (int)$count ?> voto<?= $count===1?'':'s' ?></span>
                <?php if ($userRating !== null): ?>
                    <span class="sep">•</span>
                    <span class="yours" title="Tu voto">Tu voto: <?= (int)$userRating ?>/5</span>
                <?php endif; ?>
            </div>
        </form>
        <?php
    }
}

