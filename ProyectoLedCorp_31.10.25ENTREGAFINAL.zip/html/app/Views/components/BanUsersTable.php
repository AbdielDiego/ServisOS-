<link rel="stylesheet" href="/css/banned_users_table.css?v=<?= htmlspecialchars($cssMainVer ?? '1.0', ENT_QUOTES, 'UTF-8') ?>">
<?php
// ===============================================
// BanUsersTable.php  —  Tabla de usuarios baneados
// Espera en $datosTabla el resultado de SELECT sobre BanUsers
// Opcional: define $BASE si necesitas prefijo de rutas
// ===============================================

// ---------- helpers ----------
if (!function_exists('esc')) {
    function esc(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
}
$toLower = function($s){
    return function_exists('mb_strtolower') ? mb_strtolower((string)$s, 'UTF-8') : strtolower((string)$s);
};

// ---------- base href ----------
$BASE = $BASE ?? '';
$baseHref = rtrim((string)$BASE, '/');

// ---------- datos de entrada ----------
$datosTabla = $datosTabla ?? []; // array de filas (puede venir vacío)

// Normalizamos y detectamos columnas
if (!empty($datosTabla)) {
    if (isset($datosTabla[0]) && is_array($datosTabla[0])) {
        $columnas = array_keys($datosTabla[0]);
    } else {
        $columnas   = array_keys((array)$datosTabla);
        $datosTabla = [ $datosTabla ];
    }
} else {
    // Cabeceras por defecto
    $columnas = ['ban_id','user_id','username','email','reason','banned_by','banned_at'];
}

// ---------- detectar clave para acciones ----------
$idKey = null;
foreach (['user_id','ban_id','id','UserId','ID'] as $k) {
    if (in_array($k, $columnas, true)) { $idKey = $k; break; }
}
$showActions = $idKey !== null;

// ---------- filtros por GET ----------
$qUserRaw   = trim((string)($_GET['username'] ?? ''));
$qEmailRaw  = trim((string)($_GET['email']    ?? ''));
$qReasonRaw = trim((string)($_GET['reason']   ?? ''));

// Limitar longitudes
if (strlen($qUserRaw)   > 100) $qUserRaw   = substr($qUserRaw,   0, 100);
if (strlen($qEmailRaw)  > 100) $qEmailRaw  = substr($qEmailRaw,  0, 100);
if (strlen($qReasonRaw) > 150) $qReasonRaw = substr($qReasonRaw, 0, 150);

// Normalizados
$qUser   = $toLower($qUserRaw);
$qEmail  = $toLower($qEmailRaw);
$qReason = $toLower($qReasonRaw);

// Aplicar filtro
$filtrados = $datosTabla;
if ($qUser !== '' || $qEmail !== '' || $qReason !== '') {
    $filtrados = array_values(array_filter($datosTabla, function($fila) use ($qUser, $qEmail, $qReason, $toLower) {
        $u = $toLower((string)($fila['username'] ?? ''));
        $e = $toLower((string)($fila['email']    ?? ''));
        $r = $toLower((string)($fila['reason']   ?? ''));

        $okU = ($qUser   === '') || (strpos($u, $qUser)   !== false);
        $okE = ($qEmail  === '') || (strpos($e, $qEmail)  !== false);
        $okR = ($qReason === '') || (strpos($r, $qReason) !== false);
        return $okU && $okE && $okR;
    }));
}

// Para el botón "Limpiar"
$baseUrl = strtok((string)($_SERVER['REQUEST_URI'] ?? ''), '?');
?>

<!-- Enlazá tu CSS global -->
<link rel="stylesheet" href="/css/banned-users.css">

<!-- Toolbar de filtros -->
<form class="table-toolbar" method="get" action="">
    <div class="toolbar-row">
        <input type="search" name="username" value="<?= esc($qUserRaw)   ?>" placeholder="Buscar por usuario…" autocomplete="off">
        <input type="search" name="email"    value="<?= esc($qEmailRaw)  ?>" placeholder="Buscar por email…"   autocomplete="off">
        <input type="search" name="reason"   value="<?= esc($qReasonRaw) ?>" placeholder="Motivo…"             autocomplete="off">
        <button type="submit" class="btn btn-primary">Buscar</button>
        <a class="btn btn-muted" href="<?= esc($baseUrl) ?>">Limpiar</a>
        <span class="result-count">Resultados: <?= count($filtrados) ?></span>
    </div>
</form>

<table class="tabla banned-users-table tabla-compact">
    <thead>
        <tr>
            <?php foreach ($columnas as $col): ?>
                <th><?= esc($col) ?></th>
            <?php endforeach; ?>
            <?php if ($showActions): ?>
                <th class="th-actions">acciones</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
    <?php if (empty($filtrados)): ?>
        <tr>
            <td colspan="<?= count($columnas) + ($showActions ? 1 : 0) ?>">
                No hay usuarios baneados o no hay coincidencias…
            </td>
        </tr>
    <?php else: ?>
        <?php foreach ($filtrados as $fila): ?>
            <?php $rowId = $fila[$idKey] ?? null; ?>
            <tr>
                <?php foreach ($columnas as $col): ?>
                    <?php
                    $val = (string)($fila[$col] ?? '');
                    if ($val !== '' && preg_match('/_at$|fecha|date|time/i', $col)) {
                        $ts = strtotime($val);
                        if ($ts) $val = date('Y-m-d H:i', $ts);
                    }
                    ?>
                    <td><?= esc($val) ?></td>
                <?php endforeach; ?>

                <?php if ($showActions && $rowId !== null): ?>
                    <?php
                        $uid   = $fila['user_id'] ?? $rowId;
                        $uname = (string)($fila['username'] ?? '');
                    ?>
                    <td class="td-actions">
                        <details class="row-actions">
                            <summary title="Acciones">⋮</summary>
                            <div class="row-actions-menu">
                                <a class="action-unban"
                                   href="<?= esc(($baseHref ? $baseHref : '') . '/unban.php?user_id=' . urlencode((string)$uid)) ?>"
                                   title="Quitar ban">
                                   Desbanear
                                </a>
                                <a class="action-view"
                                   href="<?= esc(($baseHref ? $baseHref : '') . '/usuarios?username=' . urlencode($uname)) ?>">
                                   Ver usuario
                                </a>
                            </div>
                        </details>
                    </td>
                <?php elseif ($showActions): ?>
                    <td class="td-actions"><em>—</em></td>
                <?php endif; ?>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
</table>

