<?php
// Helper seguro por si no existe
if (!function_exists('h')) {
  function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
}

// Título y datos
$titulo     = $titulo    ?? 'Servicios';
$servicios  = $servicios ?? [];   // categorías
$q          = trim((string)($q ?? ($_GET['q'] ?? '')));
$mensaje    = $mensaje   ?? null;

// Filtro adicional por si llega sin procesar
$filtrados = $servicios;
if ($q !== '') {
  $qLower = mb_strtolower($q);
  $filtrados = array_filter($servicios, function($s) use ($qLower) {
    $haystack = mb_strtolower(implode(' ', [
      $s['name']        ?? '',
      $s['title']       ?? ($s['nombre'] ?? ''),
      $s['descripcion'] ?? ($s['description'] ?? ''),
      $s['categoria']   ?? ($s['category'] ?? ''),
      $s['content']     ?? ''
    ]));
    return mb_strpos($haystack, $qLower) !== false;
  });
}
$servicios = $filtrados;

// Datos de la categoría seleccionada
$categoria      = $categoria      ?? null;
$postsCat       = $postsCat       ?? [];
$comentariosCat = $comentariosCat ?? [];
?>
<link rel="stylesheet" href="/css/api.css">

<img class="brand-mini" src="/imagenes/ServiceCategories-chivita.png" alt="Chivita editando un comentario">

<main class="container servicios-page">
  <header class="servicios-header">
    <h1><?= h($titulo) ?></h1>
    <p>Aquí puedes encontrar todas las categorías disponibles. Entra a una para ver sus comentarios.</p>
    <?php if ($mensaje): ?>
      <div class="flash flash-warn"><?= h($mensaje) ?></div>
    <?php endif; ?>
  </header>

  <section class="search-card">
    <form method="get" action="">
      <div class="search-row">
        <label for="q"><strong>Buscar:</strong></label>
        <input type="text" id="q" name="q" value="<?= h($q) ?>" placeholder="Nombre de la categoría…">
        <button class="btn-primary" type="submit">Buscar</button>
      </div>
      <?php if ($q !== ''): ?>
        <p class="subtitle">Filtro aplicado: “<?= h($q) ?>”</p>
      <?php endif; ?>
    </form>
  </section>

  <!-- === RESULTADOS EN TARJETAS (categorías) === -->
  <?php $total = count($servicios); ?>
  <section class="category-results">
    <div class="cr-header">
      <?php if ($q !== ''): ?>
        <h2>Resultados de categorías (<?= (int)$total ?>) para “<?= h($q) ?>”</h2>
        <p class="cr-sub">Tip: clic en “Ver comentarios” para ir directo a la sección.</p>
      <?php else: ?>
        <h2>Todas las categorías</h2>
        <p class="cr-sub">Elegí una categoría para ver comentarios o comentar.</p>
      <?php endif; ?>
    </div>

    <?php if ($total > 0): ?>
      <div class="cr-grid">
        <?php foreach ($servicios as $s):
          $id   = (int)($s['category_id'] ?? $s['id'] ?? 0);
          $name = trim((string)($s['name'] ?? $s['title'] ?? $s['nombre'] ?? 'Categoría'));
          $desc = trim((string)($s['descripcion'] ?? $s['description'] ?? ''));
        ?>
          <article class="cr-item">
            <header class="cr-item-head">
              <h3 class="cr-title"><?= h($name) ?></h3>
            </header>

            <?php if ($desc !== ''): ?>
              <p class="cr-desc"><?= h($desc) ?></p>
            <?php endif; ?>

            <div class="cr-actions">
              <a class="btn-primary" href="/apicategorias?category_id=<?= $id ?>#comentarios">Ver comentarios</a>
              <a class="btn-soft"    href="/apicategorias?category_id=<?= $id ?>#comentar">Comentar</a>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="empty-state">
        <strong>Sin resultados</strong> para “<?= h($q) ?>”. Probá con otro término.
      </div>
    <?php endif; ?>
  </section>
  <!-- === /RESULTADOS === -->

  <?php if ($categoria): ?>
    <hr>

    <!-- ===================== Comentarios (divs bonitos) ===================== -->
    <section id="comentarios" class="categoria-panel">
      <header class="panel-head">
        <h2 class="panel-title">Comentarios de la categoría: <span class="pill pill-cat"><?= h($categoria['name']) ?></span></h2>
      </header>

      <?php if (!empty($comentariosCat)): ?>
        <div class="comments-wrap">
          <?php foreach ($comentariosCat as $c): 
            $pid   = (int)$c['post_id'];
            $ptxt  = trim((string)($c['post_title'] ?? ('#'.$pid)));
            $user  = trim((string)($c['username'] ?? 'Anónimo'));
            $fecha = trim((string)($c['created_at'] ?? ''));
            $texto = trim((string)($c['comment_text'] ?? ''));
            $edit  = trim((string)($c['edit'] ?? ''));
          ?>
          <article class="comment-card">
            <div class="comment-head">
              <a class="pill pill-post" href="/post/<?= $pid ?>#comentarios" title="Ir al post">
                <span>Post:</span> <?= h($ptxt) ?>
              </a>
              <span class="pill pill-user" title="Autor del comentario">
                <span>Usuario:</span> <?= h($user) ?>
              </span>
              <?php if ($fecha !== ''): ?>
                <time class="pill pill-time" datetime="<?= h($fecha) ?>" title="Fecha">
                  <?= h($fecha) ?>
                </time>
              <?php endif; ?>
            </div>

            <?php if ($texto !== ''): ?>
              <div class="comment-body">
                <p class="comment-text"><?= h($texto) ?></p>
              </div>
            <?php endif; ?>

            <div class="comment-foot">
              <?php if ($edit !== ''): ?>
                <small class="comment-edit-info">Edit: <?= h($edit) ?></small>
              <?php endif; ?>
              <div class="comment-actions">
                <a class="btn-soft" href="/post/<?= $pid ?>#comentar">Responder</a>
                <a class="btn-primary btn-ghost" href="/post/<?= $pid ?>">Ver post</a>
              </div>
            </div>
          </article>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="empty-state">
          <strong>Sin comentarios</strong> en los posts de esta categoría todavía.
        </div>
      <?php endif; ?>
    </section>

    <!-- ===================== Comentar (selector de post) ===================== -->
    <section id="comentar" class="categoria-panel">
      <header class="panel-head">
        <h2 class="panel-title">Comentar</h2>
        <p class="panel-sub">Elegí un post de esta categoría para dejar tu comentario.</p>
      </header>

      <?php if (!empty($postsCat)): ?>
        <div class="post-select">
          <?php foreach ($postsCat as $p): ?>
            <a class="post-chip" href="/post/<?= (int)$p['post_id'] ?>#comentar" aria-label="Comentar en <?= h($p['title']) ?>">
              <span class="dot"></span>
              <span>Comentar en:</span> <?= h($p['title']) ?>
            </a>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="empty-state">
          Aún no hay posts en esta categoría.
        </div>
      <?php endif; ?>
    </section>
  <?php endif; ?>
</main>

