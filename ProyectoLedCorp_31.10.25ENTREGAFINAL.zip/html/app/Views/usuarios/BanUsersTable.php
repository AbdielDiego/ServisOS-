<link rel="stylesheet" href="/css/banned-list.css">

<?php
// ---------- helpers ----------
if (!function_exists('esc')) {
    function esc(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
}
$toLower = function($s){
    return function_exists('mb_strtolower')
        ? mb_strtolower((string)$s, 'UTF-8')
        : strtolower((string)$s);
};

$BASE = $BASE ?? '';
$baseHref = rtrim((string)$BASE, '/');

// ---------- datos de entrada ----------
$datosTabla = $datosTabla ?? []; // puede venir vacío

// Normalizamos y detectamos columnas
if (!empty($datosTabla)) {
    if (isset($datosTabla[0]) && is_array($datosTabla[0])) {
        $columnas = array_keys($datosTabla[0]);
    } else {
        $columnas   = array_keys((array)$datosTabla);
        $datosTabla = [ $datosTabla ];
    }
} else {
    $columnas = [];
}

// ---------- detectar clave para acciones ----------
$idKey    = null; // preferimos ban_id
$altIdKey = null; // respaldo: user_id
foreach (['ban_id','id','BAN_ID'] as $k) {
    if (in_array($k, $columnas, true)) { $idKey = $k; break; }
}
foreach (['user_id','userid','USER_ID'] as $k) {
    if (in_array($k, $columnas, true)) { $altIdKey = $k; break; }
}
$showActions = ($idKey !== null) || ($altIdKey !== null);

// ---------- filtros GET ----------
$qUserRaw   = trim((string)($_GET['username'] ?? ''));
$qEmailRaw  = trim((string)($_GET['email']    ?? ''));
$qReasonRaw = trim((string)($_GET['reason']   ?? ''));

// limitar longitudes
if (strlen($qUserRaw)  > 100) $qUserRaw  = substr($qUserRaw,  0, 100);
if (strlen($qEmailRaw) > 100) $qEmailRaw = substr($qEmailRaw, 0, 100);
if (strlen($qReasonRaw)> 200) $qReasonRaw= substr($qReasonRaw,0, 200);

$qUser   = $toLower($qUserRaw);
$qEmail  = $toLower($qEmailRaw);
$qReason = $toLower($qReasonRaw);

// Aplicar filtros a nivel de vista
$filtrados = $datosTabla;
if ($qUser !== '' || $qEmail !== '' || $qReason !== '') {
    $filtrados = array_values(array_filter(
        $datosTabla,
        function($fila) use ($qUser, $qEmail, $qReason, $toLower) {
            $u = $toLower($fila['username'] ?? '');
            $e = $toLower($fila['email']    ?? '');
            $r = $toLower($fila['reason']   ?? '');
            $okU = ($qUser   === '') || (strpos($u, $qUser)   !== false);
            $okE = ($qEmail  === '') || (strpos($e, $qEmail)  !== false);
            $okR = ($qReason === '') || (strpos($r, $qReason) !== false);
            return $okU && $okE && $okR;
        }
    ));
}

// Para el botón "Limpiar"
$baseUrl = strtok((string)($_SERVER['REQUEST_URI'] ?? ''), '?');

// Reordenamos columnas para mostrar campos útiles primero
$preferidas = ['ban_id','user_id','username','email','reason','banned_by','banned_by_name','banned_at'];
$orden      = array_values(array_unique(array_merge($preferidas, $columnas)));
?>

<!-- Toolbar de búsqueda -->
<form class="table-toolbar" method="get" action="">
    <input type="search" name="username" value="<?= esc($qUserRaw)   ?>" placeholder="Filtrar por usuario…" autocomplete="off">
    <input type="search" name="email"    value="<?= esc($qEmailRaw)  ?>" placeholder="Filtrar por email…"   autocomplete="off">
    <input type="search" name="reason"   value="<?= esc($qReasonRaw) ?>" placeholder="Filtrar por motivo…"  autocomplete="off">
    <button type="submit" class="btn btn-primary">Buscar</button>
    <a class="btn btn-muted" href="<?= esc($baseUrl) ?>">Limpiar</a>
    <span class="result-count">Resultados: <?= count($filtrados) ?></span>
</form>

<?php if (!empty($columnas)): ?>
    <table class="tabla users-table tabla-compact">
        <thead>
            <tr>
                <?php foreach ($orden as $col): ?>
                    <?php if (!in_array($col, $columnas, true)) continue; ?>
                    <th><?= esc($col) ?></th>
                <?php endforeach; ?>
                <?php if ($showActions): ?>
                    <th class="th-actions">acciones</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($filtrados)): ?>
                <tr>
                    <td colspan="<?= count($orden) + ($showActions ? 1 : 0) ?>">
                        Sin coincidencias…
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($filtrados as $fila): ?>
                    <?php
                    $rowBanId  = $idKey    ? ($fila[$idKey]    ?? null) : null;
                    $rowUserId = $altIdKey ? ($fila[$altIdKey] ?? null) : null;
                    ?>
                    <tr>
                        <?php foreach ($orden as $col): ?>
                            <?php if (!in_array($col, $columnas, true)) continue; ?>
                            <td>
                                <?php
                                $val = (string)($fila[$col] ?? '');
                                if ($col === 'banned_at' && $val !== '') {
                                    try {
                                        $dt  = new DateTime($val);
                                        $val = $dt->format('Y-m-d H:i');
                                    } catch (Throwable $e) {
                                        // dejar valor original
                                    }
                                }
                                echo esc($val);
                                ?>
                            </td>
                        <?php endforeach; ?>

                        <?php if ($showActions && ($rowBanId !== null || $rowUserId !== null)): ?>
                            <td class="td-actions">
                                <a class="action-unban"
                                   href="<?= esc(($baseHref ? $baseHref : '') . '/unban?' . ($rowBanId !== null ? ('ban_id=' . urlencode((string)$rowBanId)) : ('user_id=' . urlencode((string)$rowUserId)))) ?>">
                                   Desbanear
                                </a>
                                <?php if ($rowUserId !== null): ?>
                                    <a class="action-view" href="<?= esc('/post?user=' . urlencode((string)$rowUserId)) ?>">
                                        Ver posts
                                    </a>
                                <?php endif; ?>
                            </td>
                        <?php elseif ($showActions): ?>
                            <td class="td-actions"><em>—</em></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
<?php else: ?>
    <p class="no-data">No hay baneados aún.</p>
<?php endif; ?>

