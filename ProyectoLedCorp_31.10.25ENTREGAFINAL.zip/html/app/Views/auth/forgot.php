<?php
// ---------- Setup ----------
$title = isset($title) ? (string)$title : 'Olvidé mi contraseña';
if (!function_exists('h')) { function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); } }
if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

// Tomar email para pre-rellenar (último usado o ?email=)
$prefillEmail = '';
if (!empty($_GET['email'])) {
  $prefillEmail = trim((string)$_GET['email']);
} elseif (!empty($_SESSION['last_email'])) {
  $prefillEmail = trim((string)$_SESSION['last_email']);
}

// Detectar si es admin (por si querés mostrar atajos)
$isAdmin = false;
if (!empty($_SESSION['auth']['user'])) {
  $u = $_SESSION['auth']['user'];
  $isAdmin = (int)($u['rol_id'] ?? $u['role_id'] ?? 0) === 1;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title><?= h($title) ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="/css/login.css">
</head>
<body>
  <main style="width:100%;max-width:640px;margin:0 auto;padding:20px 16px;">
    <h2>Recuperar acceso</h2>

    <?php if (!empty($_SESSION['flash'])): ?>
      <?php foreach ($_SESSION['flash'] as $type => $msg):
        $class = ($type === 'success') ? 'alert-success' : (($type === 'error') ? 'alert-error' : 'alert-warning'); ?>
        <div class="alert <?= $class ?>"><?= h($msg) ?></div>
      <?php endforeach; unset($_SESSION['flash']); ?>
    <?php endif; ?>

    <?php if (!empty($_GET['sent'])): ?>
      <div class="alert alert-success">Si el email existe, te enviamos un enlace para restablecer la contraseña.</div>
    <?php endif; ?>

    <!-- ===== Form principal: envío de enlace ===== -->
    <form method="POST" action="/forgot" novalidate>
      <div>
        <label>Email:</label>
        <input id="forgot-email" type="email" name="email" required placeholder="tucorreo@ejemplo.com"
               autocomplete="email" value="<?= h($prefillEmail) ?>">
        <small>Te enviaremos un enlace para crear una nueva contraseña.</small>
      </div>

      <div class="auth-extras" style="margin-top:-4px; display:flex; gap:12px;">
        <a href="/login">Volver a iniciar sesión</a>
        <a href="/register">Crear cuenta</a>
        <?php if ($isAdmin): ?>
          <a href="/admin/support" class="btn-link">Ver pedidos de soporte</a>
        <?php endif; ?>
      </div>

      <button type="submit"><span class="label">Enviar enlace</span></button>
      <span class="shine" aria-hidden="true"></span>
    </form>

    <details class="support-box" style="margin-top:16px;">
      <summary>¿No te llega el correo? Contactar al admin</summary>
      <form method="POST" action="/forgot/support" class="support-form" novalidate>
        <label>Email de tu cuenta:</label>
        <input type="email" name="email" required placeholder="tucorreo@ejemplo.com"
               value="<?= h($prefillEmail) ?>">
        <label>Mensaje para el admin (opcional):</label>
        <textarea name="note" rows="3" maxlength="600"
                  placeholder="Contanos si cambiaste de correo, si no recordás usuario, etc."></textarea>
        <button type="submit" class="btn-secondary">Pedir reset al admin</button>
      </form>
    </details>
  </main>
</body>
</html>

