<?php
if (!function_exists('h')) { function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); } }
if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

$titulo  = $titulo  ?? 'Pedidos de soporte';
$pedidos = is_array($pedidos ?? null) ? $pedidos : [];
$cssVer  = '1.0.2';
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title><?= h($titulo) ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="/css/support.css?v=<?= h($cssVer) ?>">
</head>
<body class="as-body">
  <header class="as-header">
    <div class="as-container">
      <h1 class="as-title">Pedidos de soporte</h1>
      <nav class="as-breadcrumbs">
        <a class="as-link" href="/users">Volver a usuarios</a>
      </nav>
    </div>
  </header>

  <main class="as-container">
    <?php if (!empty($_SESSION['flash'])): ?>
      <div class="as-flashes">
        <?php foreach ($_SESSION['flash'] as $type => $msg): ?>
          <div class="as-flash as-<?= $type === 'success' ? 'ok' : ($type === 'error' ? 'err' : 'warn') ?>">
            <?= h($msg) ?>
          </div>
        <?php endforeach; unset($_SESSION['flash']); ?>
      </div>
    <?php endif; ?>

    <?php if (empty($pedidos)): ?>
      <section class="as-empty">
        <div class="as-empty-card">
          <svg class="as-empty-ico" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M4 4h16v14H7l-3 3V4z" fill="currentColor" opacity=".18"/>
            <path d="M7 8h10M7 12h7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
          </svg>
          <h2>Sin pedidos de soporte</h2>
          <p>Cuando un usuario pida ayuda desde “Olvidé mi contraseña”, aparecerá aquí.</p>
        </div>
      </section>
    <?php else: ?>
      <section class="as-card">
        <div class="as-table-wrap">
          <table class="as-table">
            <thead>
              <tr>
                <th class="as-col-id">#</th>
                <th class="as-col-date">Fecha</th>
                <th>Remitente</th>
                <th>Email</th>
                <th>Asunto</th>
                <th class="as-col-status">Leído</th>
                <th class="as-col-actions">Acciones</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($pedidos as $p):
                $id     = (int)($p['id'] ?? 0);
                $fecha  = (string)($p['created_at'] ?? '');
                $uid    = (int)($p['resolved_user_id'] ?? ($p['sender_id'] ?? 0));
                $nombre = trim((string)($p['display_username'] ?? $p['sender_username'] ?? ''));
                $email  = trim((string)($p['display_email']   ?? $p['sender_email']   ?? ''));
                $asunto = (string)($p['subject'] ?? '');
                $isRead = (int)($p['is_read'] ?? 0) === 1;
              ?>
                <tr>
                  <td data-label="#" class="as-col-id"><?= $id ?></td>
                  <td data-label="Fecha" class="as-nowrap"><?= h($fecha) ?></td>

                  <td data-label="Remitente">
                    <?php if ($nombre !== ''): ?>
                      <?= h($nombre) ?>
                      <?php if ($uid > 0): ?>
                        <small class="muted"> (ID <?= $uid ?>)</small>
                      <?php endif; ?>
                    <?php else: ?>
                      —
                    <?php endif; ?>
                  </td>

                  <td data-label="Email">
                    <?php if ($email !== ''): ?>
                      <a class="as-link" href="mailto:<?= h($email) ?>"><?= h($email) ?></a>
                    <?php else: ?>
                      —
                    <?php endif; ?>
                  </td>

                  <td data-label="Asunto"><?= h($asunto) ?></td>

                  <td data-label="Leído" class="as-col-status">
                    <span class="as-pill <?= $isRead ? 'is-read' : 'is-unread' ?>">
                      <?= $isRead ? 'Sí' : 'No' ?>
                    </span>
                  </td>

                  <td data-label="Acciones" class="as-col-actions">
                    <form method="POST" action="/admin/support/reset"
                          onsubmit="return confirm('¿Resetear la contraseña del usuario asociado al mensaje #<?= $id ?> a \"1111\"?');">
                      <input type="hidden" name="message_id" value="<?= $id ?>">
                      <button type="submit" class="as-btn as-btn-danger">Resetear contraseña</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </section>
    <?php endif; ?>
  </main>
</body>
</html>

