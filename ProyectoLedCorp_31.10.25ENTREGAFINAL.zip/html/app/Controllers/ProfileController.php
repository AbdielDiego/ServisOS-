<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Models\User;

class ProfileController extends Controller
{
    /* ============ Helpers de sesión ============ */
    private function user(): ?array {
        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }
        return $_SESSION['auth']['user'] ?? $_SESSION['user'] ?? null;
    }

    private function currentUserId(): int {
        $u = $this->user();
        if (is_array($u)) {
            $id = (int)($u['user_id'] ?? $u['id'] ?? 0);
        } elseif (isset($_SESSION['user_id'])) {
            $id = (int)$_SESSION['user_id'];
        } else {
            $id = 0;
        }
        return $id > 0 ? $id : 0;
    }

    /* ============ CSRF ============ */
    private function ensureCsrf(): string {
        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    private function checkCsrf(?string $token): bool {
        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }
        return isset($_SESSION['csrf_token']) && is_string($token) && hash_equals($_SESSION['csrf_token'], $token);
    }

    /* ============ GET /profile/edit ============ */
    public function edit(): void {
        $uid = $this->currentUserId();
        if ($uid <= 0) { header('Location: /login'); return; }

        $user = User::findById($uid);
        if (!$user) { header('Location: /'); return; }

        $csrf   = $this->ensureCsrf();
        $title  = 'Editar perfil';
        $errors = $_SESSION['errors'] ?? [];
        $old    = $_SESSION['old'] ?? [];
        $flashes= $_SESSION['flashes'] ?? [];

        // limpiar one-shot
        unset($_SESSION['errors'], $_SESSION['old'], $_SESSION['flashes']);

        // Vista
        include __DIR__ . '/../Views/profile/edit.php';
    }

    /* ============ POST /profile/edit ============ */
    public function update(): void {
        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }

        $uid = $this->currentUserId();
        if ($uid <= 0) { header('Location: /login'); return; }

        // CSRF
        if (!$this->checkCsrf($_POST['csrf_token'] ?? null)) {
            $_SESSION['errors'] = ['csrf' => 'Token inválido. Intente nuevamente.'];
            header('Location: /profile/edit', true, 303);
            return;
        }

        // Inputs
        $username   = trim((string)($_POST['username'] ?? ''));
        $email      = trim((string)($_POST['email'] ?? ''));
        $newPass    = (string)($_POST['new_password'] ?? '');
        $newPass2   = (string)($_POST['new_password_confirm'] ?? '');

        $errors = [];

        // Validaciones básicas
        if ($username === '' || mb_strlen($username) < 3) {
            $errors['username'] = 'El nombre de usuario debe tener al menos 3 caracteres.';
        }
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Email inválido.';
        }

        // Unicidad
        if (!$errors) {
            if (User::usernameExists($username, $uid)) {
                $errors['username'] = 'Ese nombre de usuario ya está en uso.';
            }
            if (User::emailExists($email, $uid)) {
                $errors['email'] = 'Ese email ya está registrado.';
            }
        }

        // Cambio de contraseña (opcional)
        $changePassword = false;
        if ($newPass !== '' || $newPass2 !== '') {
            if (mb_strlen($newPass) < 8) {
                $errors['new_password'] = 'La contraseña debe tener al menos 8 caracteres.';
            } elseif ($newPass !== $newPass2) {
                $errors['new_password_confirm'] = 'Las contraseñas no coinciden.';
            } else {
                $changePassword = true;
            }
        }

        if ($errors) {
            $_SESSION['errors'] = $errors;
            $_SESSION['old'] = ['username' => $username, 'email' => $email];
            header('Location: /profile/edit', true, 303);
            return;
        }

        // Persistir cambios
        User::updateProfile($uid, $username, $email);
        if ($changePassword) {
            $hash = password_hash($newPass, PASSWORD_BCRYPT);
            User::updatePassword($uid, $hash);
        }

        // Actualizar datos vivos en la sesión si existen
        if (isset($_SESSION['auth']['user'])) {
            $_SESSION['auth']['user']['username'] = $username;
            $_SESSION['auth']['user']['email']    = $email;
        } else {
            $_SESSION['username'] = $username;
            $_SESSION['email']    = $email;
        }

        $_SESSION['flashes'][] = ['type' => 'success', 'msg' => 'Perfil actualizado correctamente.'];
        header('Location: /profile/edit', true, 303);
    }
}

