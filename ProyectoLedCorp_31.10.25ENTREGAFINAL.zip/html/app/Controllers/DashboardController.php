<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\UserMetrics;
use PDO;


class DashboardController extends Controller
{
    private PDO $pdo;

    public function __construct()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }

        $this->pdo = Database::getConnection();
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $this->pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES,   false);

       
    }

    /** GET /dashboard */
    public function index(): void
    {
        $user = $this->currentUser();
        if (!$user) { $this->redirect('/login'); return; }

        $uid = (int)$user['user_id'];

        // ===== Métricas para tarjetas =====
        $sum = UserMetrics::summary($uid);
        $user['avg_rating']    = $sum['avg_rating'];     // Reputación
        $user['profile_views'] = $sum['profile_views'];  // Visitas (proxy o real si lo tienes)
        $posts_total           = $sum['posts_total'];
        $unread                = $sum['unread_messages'];

        // ===== Publicaciones (paginado simple) =====
        $page    = max(1, (int)($_GET['mp'] ?? 1));
        $perPage = 6;
        $offset  = ($page - 1) * $perPage;

        // Usa Minuevo si existe; si no, UserMetrics::getMyPosts
        $my_posts = [];
        $total    = $posts_total;

        if (class_exists('\App\Models\Minuevo')) {
            /** @var \App\Models\Minuevo $minuevo */
            $minuevo = new \App\Models\Minuevo($this->pdo);
            $my_posts = $minuevo->byUser($uid, $perPage, $offset);
            $total    = (int)$minuevo->countByUser($uid);
        } else {
            $my_posts = UserMetrics::getMyPosts($uid, $perPage, $offset);
            $total    = $posts_total;
        }

        foreach ($my_posts as &$p) {
            if (empty($p['slug'])) {
                $pid       = (int)($p['post_id'] ?? 0);
                $title     = (string)($p['title'] ?? 'post');
                $p['slug'] = $this->slugify($title) . '-' . $pid;
            }
        } unset($p);

        $hasPrev = $page > 1;
        $hasNext = ($offset + count($my_posts)) < $total;

        // ===== Render =====
        $this->view('dashboard/index', [
            'title'                 => 'Mi perfil',
            'user'                  => $user,
            'my_posts'              => $my_posts,
            'my_posts_pagination'   => [
                'page'    => $page,
                'perPage' => $perPage,
                'total'   => $total,
                'hasPrev' => $hasPrev,
                'hasNext' => $hasNext,
            ],
            'unread_messages_count' => $unread,
            'auth'                  => ['check' => true, 'user' => $user],
        ]);
    }

    /* ====================== Helpers ====================== */

    /** Obtiene el usuario actual desde sesión y normaliza datos mínimos */
    private function currentUser(): ?array
    {
        $cand = null;

        if (!empty($_SESSION['auth']['check']) && !empty($_SESSION['auth']['user'])) {
            $cand = $_SESSION['auth']['user'];
        } elseif (!empty($_SESSION['user'])) {
            $cand = $_SESSION['user'];
        }

        if (is_object($cand)) $cand = (array)$cand;
        if (!is_array($cand)) $cand = [];

        $id = $cand['user_id'] ?? $cand['id'] ?? null;

        // Si no hay id, resolver por email o username
        if (!$id && (!empty($cand['email']) || !empty($cand['username']))) {
            $st = $this->pdo->prepare("
                SELECT user_id, username, email, created_at, rol_id
                FROM Users
                WHERE email = :email OR username = :username
                LIMIT 1
            ");
            $st->execute([
                ':email'    => (string)($cand['email']    ?? ''),
                ':username' => (string)($cand['username'] ?? ''),
            ]);
            $row = $st->fetch();
            if ($row) {
                $id   = (int)$row['user_id'];
                $cand = array_merge($row, $cand);
            }
        }

        if (!$id) return null;

        $st = $this->pdo->prepare("
            SELECT u.user_id, u.username, u.email, u.created_at, u.rol_id, r.rol_name AS role_name
            FROM Users u
            LEFT JOIN RolUsers r ON r.rol_id = u.rol_id
            WHERE u.user_id = :id
            LIMIT 1
        ");
        $st->execute([':id' => $id]);
        $row = $st->fetch();
        if (!$row) return null;

        return [
            'user_id'    => (int)$row['user_id'],
            'username'   => (string)$row['username'],
            'email'      => (string)$row['email'],
            'created_at' => (string)$row['created_at'],
            'rol_id'     => (int)$row['rol_id'],
            'role_name'  => (string)($row['role_name'] ?? 'User'),
        ];
    }

    /** Slugify simple */
    private function slugify(string $text): string
    {
        $text = trim($text);
        $text = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text) ?: $text;
        $text = strtolower($text);
        $text = preg_replace('/[^a-z0-9]+/i', '-', $text);
        $text = trim($text, '-');
        return $text !== '' ? $text : 'post';
    }

  

    /** @inheritDoc */
    public function view($template, $data = [])
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent, 'view')) {
            return parent::view($template, $data);
        }
        $base = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 2);
        $file = $base . '/app/Views/' . ltrim((string)$template, '/') . '.php';
        if (!is_file($file)) {
            http_response_code(500);
            echo "<h1>Vista no encontrada</h1><p>" . htmlspecialchars((string)$template, ENT_QUOTES, 'UTF-8') . ".php</p>";
            return null;
        }
        extract(is_array($data) ? $data : [], EXTR_SKIP);
        ob_start(); include $file; $out = ob_get_clean(); echo $out;
        return null;
    }

    /** @inheritDoc */
    public function redirect($url)
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent, 'redirect')) {
            return parent::redirect($url);
        }
        $url = (string)$url;
        header('Location: '.$url);
        exit;
    }
}

