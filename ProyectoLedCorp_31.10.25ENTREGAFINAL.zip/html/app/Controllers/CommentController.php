<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Comment;
use PDO;

class CommentController extends Controller
{
    private Comment $comment;

    public function __construct()
    {
        if (is_callable([Controller::class, '__construct'])) {
            parent::__construct();
        }
        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }
        $this->comment = new Comment();
    }

    /* =================== Vistas / flashes / redirect =================== */

    protected function view(string $view, array $data = []): void
    {
        $relative = ltrim(str_replace(['\\', '..'], ['/', ''], $view), '/');
        $base     = dirname(__DIR__) . '/Views/';

        $file = $base . $relative . '.php';
        if (!is_file($file) && substr($relative, 0, 6) === 'posts/') {
            $relative = 'post/' . substr($relative, 6);
            $file = $base . $relative . '.php';
        }

        if (is_file($file)) { extract($data, EXTR_SKIP); include $file; return; }

        header('Content-Type: text/html; charset=utf-8');
        echo "<h1>Vista no encontrada</h1><p>Buscada: <code>{$file}</code></p>";
        exit;
    }

    protected function flash(string $type, string $message): void
    {
        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }
        switch ($type) {
            case 'success':
            case 'ok':      $_SESSION['flash_ok']   = $message; break;
            case 'error':
            case 'danger':  $_SESSION['flash_error']= $message; break;
            case 'warning':
            case 'warn':    $_SESSION['flash_warn'] = $message; break;
            default:        $_SESSION['flash_info'] = $message; break;
        }
    }

    public function redirect($url): void
    {
        if (method_exists('App\Core\Controller', 'redirect')) {
            try { parent::redirect($url); return; } catch (\Throwable $e) {}
        }
        $to = (string)$url;
        if (!headers_sent()) header('Location: ' . $to, true, 302);
        else echo "<script>location.href=" . json_encode($to) . ";</script>";
        exit;
    }

    /* ============================== Helpers ============================== */

    private function user(): ?array { return $_SESSION['auth']['user'] ?? $_SESSION['user'] ?? null; }

    private function currentUserId(): int
    {
        $u = $this->user();
        if (is_array($u)) {
            $id = (int)($u['user_id'] ?? $u['id'] ?? 0);
        } elseif (isset($_SESSION['user_id'])) {
            $id = (int)$_SESSION['user_id'];
        } else { $id = 0; }
        return $id > 0 ? $id : 0;
    }

    private function isAdmin(): bool
    {
        $u = $this->user();
        return isset($u['rol_id']) && (int)$u['rol_id'] === 1;
    }

    private function ensureLogged(): void
    {
        if ($this->currentUserId() === 0) {
            $this->flash('error', 'Debes iniciar sesión para continuar.');
            $this->redirect('/login');
        }
    }

    private function readText(): string
    {
        return trim((string)($_POST['comment_text'] ?? $_POST['comment'] ?? $_POST['body'] ?? ''));
    }

    private function backWith(string $key, string $msg): void
    {
        $_SESSION[$key] = $msg;
        $this->redirect($_SERVER['HTTP_REFERER'] ?? '/post');
    }

   
    public function storeUnified(array $params = []): void
    {
        $this->ensureLogged();

        $postId = 0;
        if (isset($params['id'])) {
            $postId = (int)$params['id'];
        }
        if ($postId <= 0) {
            $postId = (int)($_POST['post_id'] ?? 0);
        }
        if ($postId <= 0 && isset($_SERVER['REQUEST_URI'])) {
            if (preg_match('#/post/(\d+)/comments#', (string)$_SERVER['REQUEST_URI'], $m)) {
                $postId = (int)$m[1];
            }
        }

        $this->createComment($postId);
    }

    // Compatibilidad con rutas viejas/alias (el Router SIEMPRE pasa $params)
    public function store(array $params = []): void        { $this->storeUnified($params); }
    public function storeForPost(array $params = []): void { $this->storeUnified($params); }

    private function createComment(int $postId): void
    {
        if ($postId <= 0) { $this->backWith('flash_error','Publicación inválida.'); return; }

        $text = $this->readText();
        if (mb_strlen($text) < 2) { $this->backWith('flash_error','Escribe un comentario.'); return; }

        // Verificar existencia del post (evita FK y desvíos)
        $pdo = Database::getConnection();
        $chk = $pdo->prepare('SELECT post_id FROM Posts WHERE post_id = :pid LIMIT 1');
        $chk->execute([':pid' => $postId]);
        if (!$chk->fetch(PDO::FETCH_ASSOC)) {
            $this->backWith('flash_error','El servicio/post no existe.');
            return;
        }

        // Usar el Model para insertar (user_id NULL si anónimo)
        $this->comment->createForPost($postId, $this->currentUserId(), $text);

        $this->flash('success', 'Comentario publicado.');
        $this->redirect('/post/' . $postId . '#comentarios');
    }

    /* ============================== EDITAR ============================== */

    public function editForm(array $params = []): void
    {
        $this->ensureLogged();

        $commentId = (int)($params['id'] ?? $_GET['id'] ?? 0);
        if ($commentId <= 0) { $this->flash('error', 'Comentario inválido.'); $this->redirect('/'); }

        $comment = \App\Models\Comment::findById($commentId);
        if (!$comment) { $this->flash('error', 'Comentario no encontrado.'); $this->redirect('/'); }

        $uid   = $this->currentUserId();
        $admin = $this->isAdmin();
        $owner = (int)($comment['user_id'] ?? 0);

        if (!$admin && ($owner === 0 || $owner !== $uid)) {
            $this->flash('error', 'No tienes permiso para editar este comentario.');
            $this->redirect('/post/' . (int)$comment['post_id'] . '#comentarios');
        }

        $returnTo = (string)($_GET['return_to'] ?? ('/post/' . (int)$comment['post_id'] . '#comentarios'));

        $this->view('post/comment-edit', [
            'title'     => 'Editar comentario',
            'comment'   => $comment,
            'return_to' => $returnTo,
            'auth'      => ['user' => $this->user()],
        ]);
    }

    public function update(array $params = []): void
    {
        $this->ensureLogged();

        $commentId = (int)($params['id'] ?? $_POST['id'] ?? 0);
        if ($commentId <= 0) { $this->flash('error', 'Comentario inválido.'); $this->redirect('/'); }

        $comment = \App\Models\Comment::findById($commentId);
        if (!$comment) { $this->flash('error', 'Comentario no encontrado.'); $this->redirect('/'); }

        $uid   = $this->currentUserId();
        $admin = $this->isAdmin();
        $owner = (int)($comment['user_id'] ?? 0);

        if (!$admin && ($owner === 0 || $owner !== $uid)) {
            $this->flash('error', 'No tienes permiso para editar este comentario.');
            $this->redirect('/post/' . (int)$comment['post_id'] . '#comentarios');
        }

        $text     = $this->readText();
        $returnTo = (string)($_POST['return_to'] ?? ('/post/' . (int)$comment['post_id'] . '#comentarios'));

        if ($text === '') {
            $this->flash('error', 'El comentario no puede estar vacío.');
            $this->redirect('/comments/' . $commentId . '/edit?return_to=' . urlencode($returnTo));
        }
        if (mb_strlen($text) > 2000) {
            $this->flash('error', 'Máximo 2000 caracteres.');
            $this->redirect('/comments/' . $commentId . '/edit?return_to=' . urlencode($returnTo));
        }

        $ok = \App\Models\Comment::updateText($commentId, $uid, $text, $admin);

        if ($ok) $this->flash('success', 'Comentario actualizado.');
        else     $this->flash('warning', 'No hubo cambios o no fue posible actualizar.');

        $this->redirect($returnTo);
    }

    /* ============================== BORRAR ============================== */

    // POST /comment/delete  (form)  — mantiene compatibilidad
    public function delete(): void
    {
        $this->ensureLogged();
        $commentId = (int)($_POST['comment_id'] ?? 0);
        $this->deleteCommon($commentId);
    }

    // DELETE /comments/:id  o  POST /comments/:id/delete
    public function destroy($idOrParams = []): void
    {
        $this->ensureLogged();
        $commentId = is_array($idOrParams) ? (int)($idOrParams['id'] ?? 0) : (int)$idOrParams;
        if ($commentId <= 0) { $commentId = (int)($_POST['comment_id'] ?? 0); }
        $this->deleteCommon($commentId);
    }

    /**
     * Nuevo: wrapper para rutas unificadas de borrado
     * - POST /comments/:id/delete
     * - POST /comment/delete (hidden comment_id)
     */
    public function destroyUnified(array $params = []): void
    {
        // Reutiliza la lógica existente de destroy()
        $this->destroy($params);
    }

    private function deleteCommon(int $commentId): void
    {
        if ($commentId <= 0) { $this->flash('error','Comentario inválido.'); $this->redirect('/'); }

        $row = $this->comment->getOwnerAndPost($commentId);
        if (!$row) { $this->flash('error','El comentario no existe.'); $this->redirect('/'); }

        $postId  = (int)$row['post_id'];
        $ownerId = (int)($row['user_id'] ?? 0);

        $current = $this->currentUserId();
        $isOwner = ($current > 0 && $current === $ownerId);
        $isAdmin = $this->isAdmin();

        if (!$isOwner && !$isAdmin) {
            $this->flash('error', 'No tienes permiso para borrar este comentario.');
            $this->redirect('/post/' . $postId . '#comentarios');
        }

        if ($this->comment->deleteById($commentId)) $this->flash('success', 'Comentario eliminado.');
        else                                         $this->flash('error',   'No se pudo eliminar el comentario.');

        $this->redirect('/post/' . $postId . '#comentarios');
    }
}

