<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Post;

class MinuevoController extends Controller
{
    /** @var \PDO */
    private \PDO $pdo;

    /** @var object|null Instancia de App\Models\Minuevo si existe */
    private $minuevoModel = null;

    /** @var Post */
    private Post $postModel;

    public function __construct()
    {
        if (is_callable([parent::class, '__construct'])) {
            parent::__construct();
        }

        $this->pdo = Database::getConnection();
        $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);

        $this->postModel = new Post();

        // Crear modelo Minuevo si está disponible
        if (class_exists('\App\Models\Minuevo')) {
            $cls = '\App\Models\Minuevo';
            $this->minuevoModel = new $cls($this->pdo);
        }

        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }
    }

    /* ============================ LISTADO ============================ */

    /** GET /minuevo */
    public function index(): void
    {
        if ($this->minuevoModel && method_exists($this->minuevoModel, 'latest')) {
            $posts = $this->minuevoModel->latest(12);
        } else {
            $st = $this->pdo->query(
                'SELECT post_id, user_id, category_id, title, content, price, created_at, updated_at
                   FROM Posts
               ORDER BY post_id DESC
                  LIMIT 12'
            );
            $posts = $st->fetchAll();
        }

        echo $this->render('minuevo/index', ['posts' => $posts]);
    }

    /* ============================ CREAR ============================ */

    /** GET /minuevo/create */
    public function create(): void
    {
        if ($this->minuevoModel && method_exists($this->minuevoModel, 'categories')) {
            $cats = $this->minuevoModel->categories();
        } else {
            $st   = $this->pdo->query('SELECT category_id, name FROM Categories ORDER BY name');
            $cats = $st->fetchAll();
        }

        echo $this->render('minuevo/create', [
            'categories' => $cats,
        ]);
    }

    /** POST /minuevo/guardar */
    public function store(): void
    {
        $u = $_SESSION['user'] ?? ($_SESSION['auth']['user'] ?? null);
        $userId = (int)($u['user_id'] ?? $u['id'] ?? 0);
        if ($userId <= 0) {
            $this->flashBoth('error', 'Debes iniciar sesión.');
            $this->redirect('/login');
            return;
        }

        $title       = trim((string)($_POST['title'] ?? ''));
        $content     = trim((string)($_POST['content'] ?? ''));
        $categoryRaw = $_POST['category_id'] ?? '';
        $categoryId  = ($categoryRaw === '' ? null : (int)$categoryRaw);

        // PRICE: entero no negativo
        $priceRaw = $_POST['price'] ?? '';
        $price    = is_numeric($priceRaw) ? (int)$priceRaw : 0;
        if ($price < 0) $price = 0;

        if ($title === '' || $content === '') {
            $this->flashBoth('error', 'Título y contenido son obligatorios.');
            $this->redirect('/minuevo/create');
            return;
        }

        // Crear usando el modelo Post (que ya soporta price)
        $newId = $this->postModel->create([
            'user_id'     => $userId,
            'category_id' => $categoryId,
            'title'       => $title,
            'content'     => $content,
            'price'       => $price,
        ]);

        $this->flashBoth('ok', 'Publicado correctamente.');
        $this->redirect('/post/' . (int)$newId);
    }

    /* ============================ DETALLE ============================ */

    /** GET /article/{slug-o-id} (compatibilidad) */
    public function show($slugOrId): void
    {
        $slugOrId = $this->firstString($slugOrId);
        $post = null;

        if ($this->minuevoModel) {
            if ($slugOrId !== '' && ctype_digit($slugOrId)) {
                $post = $this->minuevoModel->findById((int)$slugOrId);
            } else {
                $id = $this->extractId($slugOrId);
                $post = $id
                    ? $this->minuevoModel->findById($id)
                    : (method_exists($this->minuevoModel, 'findByLooseTitle')
                        ? $this->minuevoModel->findByLooseTitle($slugOrId)
                        : null);
            }
        } else {
            if ($slugOrId !== '' && ctype_digit($slugOrId)) {
                $st = $this->pdo->prepare(
                    'SELECT post_id, user_id, category_id, title, content, price, created_at, updated_at
                       FROM Posts WHERE post_id = ? LIMIT 1'
                );
                $st->execute([(int)$slugOrId]);
                $post = $st->fetch() ?: null;
            }
        }

        if (!$post) { $this->redirect('/minuevo'); return; }

        $userId = (int)($_SESSION['auth']['user']['user_id'] ?? $_SESSION['user']['user_id'] ?? 0);
        $avg  = ($this->minuevoModel && method_exists($this->minuevoModel, 'avgRating'))
              ? $this->minuevoModel->avgRating((int)$post['post_id'])
              : null;
        $mine = ($userId && $this->minuevoModel && method_exists($this->minuevoModel, 'userRating'))
              ? $this->minuevoModel->userRating((int)$post['post_id'], $userId)
              : null;

        echo $this->render('minuevo/show', [
            'post'       => $post,
            'avgRating'  => $avg,
            'userRating' => $mine,
        ]);
    }

    /* ============================ RATING ============================ */

    /** POST /article/{id}/rate */
    public function rate($id): void
    {
        if (!$this->minuevoModel || !method_exists($this->minuevoModel, 'upsertRating')) {
            $this->flashBoth('error', 'La puntuación no está disponible.');
            $this->redirect('/minuevo');
            return;
        }

        $userId = $_SESSION['auth']['user']['user_id'] ?? $_SESSION['user']['user_id'] ?? null;
        if (!$userId) {
            $this->flashBoth('error', 'Debes iniciar sesión para puntuar.');
            $this->redirect('/login?next=' . urlencode('/article/' . $this->firstString($id)));
            return;
        }

        $slugOrId = $this->firstString($id);
        if ($slugOrId !== '' && ctype_digit($slugOrId)) {
            $post = $this->minuevoModel->findById((int)$slugOrId);
        } else {
            $postIdFromSlug = $this->extractId($slugOrId);
            $post = $postIdFromSlug ? $this->minuevoModel->findById($postIdFromSlug)
                                    : (method_exists($this->minuevoModel, 'findByLooseTitle')
                                        ? $this->minuevoModel->findByLooseTitle($slugOrId)
                                        : null);
        }
        if (!$post) { $this->flashBoth('error', 'Artículo no encontrado.'); $this->redirect('/minuevo'); return; }

        if ((int)($post['author_id'] ?? 0) === (int)$userId) {
            $this->flashBoth('error', 'No podés puntuar tu propio artículo.');
            $slug = $this->slugify((string)($post['title'] ?? 'articulo')) . '-' . (int)$post['post_id'];
            $this->redirect('/article/' . $slug);
            return;
        }

        $rating = (int)$this->firstString($_POST['rating'] ?? '');
        if ($rating < 1 || $rating > 5) {
            $this->flashBoth('error', 'El puntaje debe estar entre 1 y 5.');
            $slug = $this->slugify((string)($post['title'] ?? 'articulo')) . '-' . (int)$post['post_id'];
            $this->redirect('/article/' . $slug);
            return;
        }

        try {
            $this->minuevoModel->upsertRating((int)$post['post_id'], (int)$userId, (int)$rating);
            $this->flashBoth('ok', 'Tu puntaje fue registrado.');
        } catch (\Throwable $e) {
            $this->flashBoth('error', 'No se pudo registrar tu voto.');
        }

        $slug = $this->slugify((string)($post['title'] ?? 'articulo')) . '-' . (int)$post['post_id'];
        $this->redirect('/article/' . $slug);
    }

    /* ============================ Utils ============================ */

    private function slugify(string $text): string
    {
        $text = trim($text);
        $text = @iconv('UTF-8','ASCII//TRANSLIT',$text) ?: $text;
        $text = strtolower((string)preg_replace('/[^a-z0-9]+/i','-',$text));
        return trim($text, '-');
    }

    private function extractId(string $slug): ?int
    {
        return (preg_match('~-(\d+)$~', $slug, $m)) ? (int)$m[1] : null;
    }

    private function firstString($v): string
    {
        if (is_array($v)) $v = reset($v);
        return is_string($v) ? trim($v) : '';
    }

    /** Guarda flash en ambos formatos: $_SESSION['flash'][key] y $_SESSION['flash_key'] */
    private function flashBoth(string $key, string $msg): void
    {
        $_SESSION['flash'][$key] = $msg;
        $_SESSION['flash_' . $key] = $msg;
    }
}

