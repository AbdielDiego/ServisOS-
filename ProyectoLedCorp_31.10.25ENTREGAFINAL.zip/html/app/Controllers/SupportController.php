<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use PDO;

class SupportController extends Controller
{
    /** POST /forgot/support */
    public function requestReset(): void
    {
        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }

        $email = trim((string)($_POST['email'] ?? ''));
        $note  = trim((string)($_POST['note']  ?? ''));

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['flash']['error'] = 'Ingresá un email válido.';
            $this->redirect('/forgot');
            return;
        }

        $pdo = $this->resolvePdo();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Todos los admins (rol_id = 1)
        $stmt = $pdo->query("SELECT user_id FROM Users WHERE rol_id = 1");
        $adminIds = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));

        // Fallback si no hay por rol
        if (empty($adminIds)) {
            $stmt = $pdo->prepare("SELECT user_id FROM Users WHERE username='Administrador' LIMIT 1");
            $stmt->execute();
            $aux = (int)$stmt->fetchColumn();
            if ($aux > 0) { $adminIds = [$aux]; }
        }

        if (empty($adminIds)) {
            $_SESSION['flash']['error'] = 'No hay un administrador configurado para recibir tu pedido.';
            $this->redirect('/forgot');
            return;
        }

        $senderId = (int)($_SESSION['auth']['user']['user_id'] ?? 0);

        // Info del usuario (si existe ese email en Users)
        $existsStmt = $pdo->prepare("SELECT user_id, username FROM Users WHERE email = ? LIMIT 1");
        $existsStmt->execute([$email]);
        $usr = $existsStmt->fetch(PDO::FETCH_ASSOC);
        $usrLine = $usr
            ? ("Usuario en sistema: {$usr['username']} (ID {$usr['user_id']})")
            : "Usuario en sistema: (email no registrado)";

        $subject = 'Solicitud de reset de contraseña';
        $body    = "Pedido de reset manual de contraseña\n"
                 . "-----------------------------------\n"
                 . "Email del solicitante: {$email}\n"
                 . "{$usrLine}\n"
                 . "Mensaje del usuario: " . ($note !== '' ? $note : '(sin nota)') . "\n"
                 . "IP: " . ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0') . "\n"
                 . "Agente: " . ($_SERVER['HTTP_USER_AGENT'] ?? '') . "\n"
                 . "Fecha: " . date('Y-m-d H:i:s');

        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("INSERT INTO messages (sender_id, subject, body) VALUES (?, ?, ?)");
            $stmt->execute([$senderId, $subject, $body]);
            $messageId = (int)$pdo->lastInsertId();

            $insRec = $pdo->prepare("INSERT INTO message_recipients (message_id, recipient_id) VALUES (?, ?)");
            foreach ($adminIds as $rid) {
                $insRec->execute([$messageId, (int)$rid]);
            }

            $pdo->commit();
            $_SESSION['flash']['success'] = 'Tu pedido fue enviado al/los administrador(es).';
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            $_SESSION['flash']['error'] = 'No se pudo enviar el pedido al admin: '.$e->getMessage();
        }

        $_SESSION['last_email'] = $email;
        $this->redirect('/forgot');
    }

    /** GET /admin/support */
    public function adminIndex(): void
    {
        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }

        $user = $_SESSION['auth']['user'] ?? null;
        $isAdmin = is_array($user) && (int)($user['rol_id'] ?? $user['role_id'] ?? 0) === 1;
        if (!$isAdmin) {
            $_SESSION['flash']['error'] = 'Acceso restringido a administradores.';
            $this->redirect('/login');
            return;
        }
        $adminId = (int)$user['user_id'];

        $pdo = $this->resolvePdo();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Solo pedidos de reset dirigidos a este admin
        $sql = "
            SELECT 
                m.id,
                m.sender_id,
                u.username AS sender_username,
                u.email    AS sender_email,
                m.subject,
                m.body,
                m.created_at,
                COALESCE(mr.is_read, 0) AS is_read
            FROM messages m
            INNER JOIN message_recipients mr
                    ON mr.message_id = m.id
                   AND mr.recipient_id = :admin_id
            LEFT JOIN Users u
                   ON u.user_id = m.sender_id
            WHERE m.subject LIKE 'Solicitud de reset de contraseña%'
               OR m.body    LIKE 'Pedido de reset manual de contraseña%'
            ORDER BY m.created_at DESC
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':admin_id' => $adminId]);
        $pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Resolver datos aunque sender_id sea 0 (email en el cuerpo)
        foreach ($pedidos as &$p) {
            $p['resolved_user_id'] = (int)($p['sender_id'] ?? 0);
            $p['display_username'] = trim((string)($p['sender_username'] ?? ''));
            $p['display_email']    = trim((string)($p['sender_email'] ?? ''));

            if ($p['display_email'] === '' || $p['display_username'] === '' || $p['resolved_user_id'] <= 0) {
                $emailInBody = $this->extractEmailFromBody((string)($p['body'] ?? ''));
                if ($emailInBody !== '') {
                    if ($p['display_email'] === '') {
                        $p['display_email'] = $emailInBody;
                    }
                    $q = $pdo->prepare("SELECT user_id, username, email FROM Users WHERE email = ? LIMIT 1");
                    $q->execute([$emailInBody]);
                    if ($u = $q->fetch(PDO::FETCH_ASSOC)) {
                        if ($p['resolved_user_id'] <= 0) $p['resolved_user_id'] = (int)$u['user_id'];
                        if ($p['display_username'] === '') $p['display_username'] = (string)$u['username'];
                        if ($p['display_email'] === '')    $p['display_email']    = (string)$u['email'];
                    }
                }
            }
        }
        unset($p);

        $titulo = 'Pedidos de soporte';
        $view = defined('BASE_PATH')
            ? BASE_PATH . '/app/Views/support/index.php'
            : __DIR__ . '/../Views/support/index.php';

        require $view;
    }

    /** POST /admin/support/reset */
    public function resetPassword(): void
    {
        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }

        $user = $_SESSION['auth']['user'] ?? null;
        $isAdmin = is_array($user) && (int)($user['rol_id'] ?? $user['role_id'] ?? 0) === 1;
        if (!$isAdmin) {
            $_SESSION['flash']['error'] = 'Acceso restringido a administradores.';
            $this->redirect('/login');
            return;
        }
        $adminId = (int)$user['user_id'];

        $messageId = (int)($_POST['message_id'] ?? 0);
        if ($messageId <= 0) {
            $_SESSION['flash']['error'] = 'ID de mensaje inválido.';
            $this->redirect('/admin/support');
            return;
        }

        $pdo = $this->resolvePdo();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Traer el mensaje
        $stmt = $pdo->prepare("SELECT id, sender_id, body FROM messages WHERE id = ? LIMIT 1");
        $stmt->execute([$messageId]);
        $msg = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$msg) {
            $_SESSION['flash']['error'] = 'Mensaje no encontrado.';
            $this->redirect('/admin/support');
            return;
        }

        // Resolver user_id destino
        $targetUserId = (int)($msg['sender_id'] ?? 0);
        if ($targetUserId <= 0) {
            $email = $this->extractEmailFromBody((string)$msg['body']);
            if ($email !== '') {
                $q = $pdo->prepare("SELECT user_id FROM Users WHERE email = ? LIMIT 1");
                $q->execute([$email]);
                $targetUserId = (int)$q->fetchColumn();
            }
        }
        if ($targetUserId <= 0) {
            $_SESSION['flash']['error'] = 'No se pudo identificar al usuario del pedido.';
            $this->redirect('/admin/support');
            return;
        }

        // SIEMPRE BCRYPT
        $plain = '1111';
        $hash  = password_hash($plain, PASSWORD_BCRYPT);

        try {
            $pdo->beginTransaction();

            $up = $pdo->prepare("UPDATE Users SET password = ? WHERE user_id = ? LIMIT 1");
            $up->execute([$hash, $targetUserId]);

            $mr = $pdo->prepare("UPDATE message_recipients 
                                 SET is_read = 1, read_at = NOW() 
                                 WHERE message_id = ? AND recipient_id = ?");
            $mr->execute([$messageId, $adminId]);

            $pdo->commit();
            $_SESSION['flash']['success'] = "Contraseña reseteada a '1111' para el usuario #{$targetUserId}.";
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $_SESSION['flash']['error'] = 'No se pudo resetear la contraseña: ' . $e->getMessage();
        }

        $this->redirect('/admin/support');
    }

    /** Extrae un email del cuerpo del mensaje. */
    private function extractEmailFromBody(string $body): string
    {
        if (preg_match('/Email del solicitante:\s*([^\s<>\r\n]+)/i', $body, $m)) {
            return filter_var(trim($m[1]), FILTER_VALIDATE_EMAIL) ? trim($m[1]) : '';
        }
        if (preg_match('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', $body, $m2)) {
            $email = trim($m2[0]);
            return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : '';
        }
        return '';
    }

    /** Resuelve un PDO desde tu wrapper Database. */
    private function resolvePdo(): PDO
    {
        if (isset($this->db)) {
            if (method_exists($this->db, 'pdo'))     { $pdo = $this->db->pdo();     if ($pdo instanceof PDO) return $pdo; }
            if (method_exists($this->db, 'getPdo'))  { $pdo = $this->db->getPdo();  if ($pdo instanceof PDO) return $pdo; }
            if ($this->db instanceof PDO)            { return $this->db; }
        }

        $dbClass = Database::class;

        if (method_exists($dbClass, 'getInstance')) {
            $db = $dbClass::getInstance();
            if (method_exists($db, 'pdo'))    { $pdo = $db->pdo();    if ($pdo instanceof PDO) return $pdo; }
            if (method_exists($db, 'getPdo')) { $pdo = $db->getPdo(); if ($pdo instanceof PDO) return $pdo; }
        }
        if (method_exists($dbClass, 'instance')) {
            $db = $dbClass::instance();
            if (method_exists($db, 'pdo'))    { $pdo = $db->pdo();    if ($pdo instanceof PDO) return $pdo; }
            if (method_exists($db, 'getPdo')) { $pdo = $db->getPdo(); if ($pdo instanceof PDO) return $pdo; }
        }
        if (method_exists($dbClass, 'get')) {
            $db = $dbClass::get();
            if (method_exists($db, 'pdo'))    { $pdo = $db->pdo();    if ($pdo instanceof PDO) return $pdo; }
            if (method_exists($db, 'getPdo')) { $pdo = $db->getPdo(); if ($pdo instanceof PDO) return $pdo; }
        }
        if (method_exists($dbClass, 'connection')) {
            $pdo = $dbClass::connection();
            if ($pdo instanceof PDO) return $pdo;
        }

        throw new \RuntimeException('No se pudo resolver la conexión PDO desde Database.');
    }
}

