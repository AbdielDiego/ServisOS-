<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Api;

class ApiController extends Controller
{
    private $modelo;

    public function __construct(){
        $this->modelo = new Api();
        parent::__construct();
    }

    public function index()
    {
        $mensaje = null;

        // =======================
        // POST: buscar categoría por id o nombre y renderizar HTML
        // =======================
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['miDato'])) {
            $miDato = trim((string)$_POST['miDato']);
            $cat = null;

            if ($miDato !== '' && ctype_digit($miDato)) {
                $cat = $this->modelo->findById((int)$miDato);
            } else {
                if ($miDato !== '') {
                    $cat = $this->modelo->findByName($miDato);
                }
            }

            if (!$cat) {
                $mensaje = 'La categoría no existe.';
            }

            // armamos mismo flujo que GET con category_id seleccionado (si existe)
            $q  = '';
            $categorias = $this->modelo->all($q);

            $categoriaSel   = $cat ?: null;
            $postsDeCat     = [];
            $comentariosCat = [];
            if ($categoriaSel) {
                $cid            = (int)$categoriaSel['category_id'];
                $postsDeCat     = $this->modelo->getPostsByCategory($cid);
                $comentariosCat = $this->modelo->getCommentsByCategory($cid);
            }

            $this->render("api/index", [
                "titulo"         => "Categorias: Mostrar Articulos",
                "servicios"      => $categorias,
                "q"              => $q,
                "categoria"      => $categoriaSel,
                "postsCat"       => $postsDeCat,
                "comentariosCat" => $comentariosCat,
                "mensaje"        => $mensaje
            ]);
            return;
        }

        // =======================
        // GET: lista + detalle opcional por category_id
        // =======================
        $q  = trim((string)($_GET['q'] ?? ''));
        $id = isset($_GET['category_id']) && ctype_digit((string)$_GET['category_id'])
            ? (int)$_GET['category_id']
            : 0;

        $categorias = $this->modelo->all($q);

        $categoriaSel   = null;
        $postsDeCat     = [];
        $comentariosCat = [];

        if ($id > 0) {
            $categoriaSel = $this->modelo->findById($id);
            if ($categoriaSel) {
                $postsDeCat     = $this->modelo->getPostsByCategory($id);
                $comentariosCat = $this->modelo->getCommentsByCategory($id);
            } else {
                $mensaje = 'La categoría indicada no existe.';
            }
        }

        $this->render("api/index", [
            "titulo"         => "Categorias: Mostrar Articulos",
            "servicios"      => $categorias,
            "q"              => $q,
            "categoria"      => $categoriaSel,
            "postsCat"       => $postsDeCat,
            "comentariosCat" => $comentariosCat,
            "mensaje"        => $mensaje
        ]);
    }
}

