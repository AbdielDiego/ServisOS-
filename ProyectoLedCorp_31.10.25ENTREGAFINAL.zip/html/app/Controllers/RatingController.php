<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\PostRating;
use PDO;

class RatingController extends Controller
{
    /* ============================
     * Helpers de sesión / auth
     * ============================ */
    private function user(): ?array {
        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }
        if (!empty($_SESSION['auth']['user']) && is_array($_SESSION['auth']['user'])) return $_SESSION['auth']['user'];
        if (!empty($_SESSION['user'])        && is_array($_SESSION['user']))        return $_SESSION['user'];
        return null;
    }
    private function currentUserId(): int {
        $u = $this->user();
        if (is_array($u)) {
            $id = (int)($u['user_id'] ?? $u['id'] ?? 0);
        } elseif (!empty($_SESSION['user_id'])) {
            $id = (int)$_SESSION['user_id'];
        } else { $id = 0; }
        return $id > 0 ? $id : 0;
    }

    public function rate(): void
    {
        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            http_response_code(405); echo 'Method Not Allowed'; return;
        }

        $return = (string)($_POST['return'] ?? ($_SERVER['HTTP_REFERER'] ?? '/post'));
        if (!str_starts_with($return, '/')) { $return = '/post'; }

        $uid    = $this->currentUserId();
        $postId = (int)($_POST['post_id'] ?? 0);
        $rating = (int)($_POST['rating']  ?? 0);

        if ($uid <= 0) { header('Location: /login?next=' . urlencode($return)); return; }
        if ($postId <= 0 || $rating < 1 || $rating > 5) { header('Location: ' . $return); return; }

        try {
            $pdo = Database::getConnection();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

            // Valida que exista el post
            $chk = $pdo->prepare('SELECT 1 FROM Posts WHERE post_id=?');
            $chk->execute([$postId]);
            if (!$chk->fetch()) { header('Location: ' . $return); return; }

            $model = new PostRating($pdo);
            $model->save($postId, $uid, $rating);
        } catch (\Throwable $e) {
            // Silencioso: no rompemos el flujo
        }

        header('Location: ' . $return);
    }
}

