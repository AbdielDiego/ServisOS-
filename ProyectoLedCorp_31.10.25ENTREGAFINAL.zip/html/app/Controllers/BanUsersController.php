<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Models\BanUser;
use PDO;
use Throwable;

class BanUsersController extends Controller
{
    private PDO $pdo;
    private BanUser $banModel;

    public function __construct()
    {
        parent::__construct();

        // Usa tu conexión central
        $this->pdo = \App\Core\Database::getConnection();
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $this->banModel = new BanUser();
    }

    /**
     * GET /usuarios/baneados
     */
    public function index(): void
    {
        $sql = "
            SELECT
                b.ban_id,
                b.user_id,
                b.username,
                b.email,
                b.reason,
                b.banned_by,
                admin.username AS banned_by_name,
                b.banned_at
            FROM BanUsers b
            LEFT JOIN Users admin ON admin.user_id = b.banned_by
            ORDER BY b.banned_at DESC, b.ban_id DESC
        ";
        $rows = $this->pdo->query($sql)->fetchAll();

        $this->render('usuarios/BanUsersIndex', [
            'titulo'     => 'Usuarios baneados',
            'datosTabla' => $rows,
        ]);
    }

    /**
     * GET /usuarios/ban/:id
     * POST /usuarios/ban   (recibe id|username|email)
     */
    public function ban(array $params = []): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        // 1) comprobar que sea admin
        $authUser = $_SESSION['auth']['user'] ?? null;
        $isAdmin  = is_array($authUser) && (int)($authUser['rol_id'] ?? $authUser['role_id'] ?? 0) === 1;
        if (!$isAdmin) {
            http_response_code(403);
            echo 'Solo los administradores pueden banear.';
            return;
        }
        $adminId = (int)$authUser['user_id'];

        // 2) intentar sacar el user a banear de TODOS los lugares posibles
        $userId  = null;
        $username = '';
        $email    = '';

        // a) desde la ruta /usuarios/ban/37
        if (isset($params['id']) && ctype_digit((string)$params['id'])) {
            $userId = (int)$params['id'];
        } elseif (isset($params[0]) && ctype_digit((string)$params[0])) {
            // por si tu router manda el 0 en vez de ['id'=>...]
            $userId = (int)$params[0];
        }

        // b) desde GET/POST
        if ($userId === null && isset($_REQUEST['id']) && ctype_digit((string)$_REQUEST['id'])) {
            $userId = (int)$_REQUEST['id'];
        }
        if ($userId === null && isset($_REQUEST['user_id']) && ctype_digit((string)$_REQUEST['user_id'])) {
            $userId = (int)$_REQUEST['user_id'];
        }

        // c) por username
        if ($userId === null) {
            $username = trim((string)($_REQUEST['username'] ?? ''));
        }

        // d) por email / gmail
        if ($userId === null && $username === '') {
            $email = trim((string)($_REQUEST['email'] ?? ($_REQUEST['gmail'] ?? '')));
        }

        // 3) si no tengo todavía user_id, lo busco en la tabla Users
        if ($userId === null) {
            if ($username !== '') {
                $st = $this->pdo->prepare('SELECT user_id FROM Users WHERE username = ?');
                $st->execute([$username]);
                $row = $st->fetch();
                if ($row) {
                    $userId = (int)$row['user_id'];
                }
            } elseif ($email !== '') {
                $st = $this->pdo->prepare('SELECT user_id FROM Users WHERE email = ?');
                $st->execute([$email]);
                $row = $st->fetch();
                if ($row) {
                    $userId = (int)$row['user_id'];
                }
            }
        }

        if ($userId === null) {
            http_response_code(400);
            echo 'Faltan parámetros: envía id, username o email.';
            return;
        }

        $reason = trim((string)($_REQUEST['reason'] ?? ''));

        try {
            // usa el modelo que ya tenías con UPSERT
            $this->banModel->banUser($userId, $reason, $adminId, null);
        } catch (Throwable $e) {
            http_response_code(500);
            echo 'No se pudo banear: ' . $e->getMessage();
            return;
        }

        $redir = $_REQUEST['redirect'] ?? '/usuarios/baneados';
        header('Location: ' . $redir);
        exit;
    }

    /**
     * GET/POST /usuarios/unban/:id
     */
    public function unban(array $params = []): void
    {
        $banId  = null;
        $userId = null;

        if (isset($params['id']) && ctype_digit((string)$params['id'])) {
            $banId = (int)$params['id'];
        } elseif (isset($params[0]) && ctype_digit((string)$params[0])) {
            $banId = (int)$params[0];
        }

        if (isset($_REQUEST['ban_id']) && ctype_digit((string)$_REQUEST['ban_id'])) {
            $banId = (int)$_REQUEST['ban_id'];
        }
        if (isset($_REQUEST['user_id']) && ctype_digit((string)$_REQUEST['user_id'])) {
            $userId = (int)$_REQUEST['user_id'];
        }

        if ($banId === null && $userId === null) {
            http_response_code(400);
            echo 'Faltan parámetros: envía ban_id o user_id.';
            return;
        }

        try {
            if ($banId !== null) {
                $st = $this->pdo->prepare('DELETE FROM BanUsers WHERE ban_id = ?');
                $st->execute([$banId]);
            } else {
                $st = $this->pdo->prepare('DELETE FROM BanUsers WHERE user_id = ?');
                $st->execute([$userId]);
            }
        } catch (Throwable $e) {
            http_response_code(500);
            echo 'No se pudo desbanear: ' . $e->getMessage();
            return;
        }

        $redir = $_REQUEST['redirect'] ?? '/usuarios/baneados';
        header('Location: ' . $redir . '?unbanned=1');
        exit;
    }
}

