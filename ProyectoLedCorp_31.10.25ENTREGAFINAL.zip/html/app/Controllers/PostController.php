<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Post;
use App\Models\Comment;
use PDO;

final class PostController extends Controller
{
    private Post $modelo;
    private Comment $comment;

    public function __construct()
    {
        if (is_callable([parent::class, '__construct'])) {
            parent::__construct();
        }
        $this->modelo  = new Post();
        $this->comment = class_exists(Comment::class) ? new Comment() : new class {
            public function findByPostId(int $id): array { return []; }
        };

        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }
    }

    /* ======================== GET /post ======================== */
    public function index(array $params = []): void
    {
        $pagina = (int)($params['pagina'] ?? ($_GET['pagina'] ?? 1));
        $pagina = max(1, $pagina);

        if (method_exists($this->modelo, 'sqlPaginado')) {
            $data  = $this->modelo->sqlPaginado($pagina);
            $posts = $data['posts']
                  ?? $data['items']
                  ?? $data['rows']
                  ?? $data['data']
                  ?? $data['registros']
                  ?? [];
        } else {
            $posts = method_exists($this->modelo, 'listAll') ? $this->modelo->listAll() : [];
        }

        $this->renderCompat('post/index', [
            'titulo' => 'Servicios',
            'posts'  => $posts,
        ]);
    }

    /* ============== GET /post/:id (detalle + comentarios) ============== */
    public function show($idOrParams = []): void
    {
        $postId = is_array($idOrParams)
            ? (int)($idOrParams['id'] ?? ($_GET['id'] ?? 0))
            : (int)$idOrParams;

        if ($postId <= 0) { $this->redirect('/post'); return; }

        $post = $this->getPostById($postId);
        if (!$post) { $this->redirect('/post'); return; }

        $comments = $this->comment->findByPostId($postId);

        $this->renderCompat('post/show', [
            'title'         => $post['title'] ?? 'Servicio',
            'post'          => $post,           // incluye price/autor (por join)
            'comments'      => $comments,
            'focusForm'     => false,
            
            'commentAction' => "/post/{$postId}/comments",
        ]);
    }

    /* ======= GET /post/:id/comentar (mismo show con foco en el form) ======= */
    public function comentar($id): void
    {
        $postId = (int)$id;
        if ($postId <= 0) { $this->redirect('/post'); return; }

        $post = $this->getPostById($postId);
        if (!$post) { $this->redirect('/post'); return; }

        $comments = $this->comment->findByPostId($postId);

        $this->renderCompat('post/show', [
            'title'         => 'Comentar: ' . ($post['title'] ?? 'Servicio'),
            'post'          => $post,
            'comments'      => $comments,
            'focusForm'     => true,
           
            'commentAction' => "/post/{$postId}/comments",
        ]);
    }

    /* ========== GET /post/detail?id=...  (detalle sin form) ========== */
    public function detail(): void
    {
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) { $this->redirect('/post'); return; }

        $post = $this->getPostById($id);
        if (!$post) {
            $_SESSION['flash_error'] = 'Servicio no encontrado.';
            $this->redirect('/post');
            return;
        }

        // Autor (fallback si el join no trajo datos)
        $author = [
            'username' => (string)($post['username'] ?? 'Desconocido'),
            'email'    => (string)($post['email']    ?? ''),
        ];
        if ($author['username'] === 'Desconocido' && !empty($post['user_id'])) {
            try {
                $pdo = Database::getConnection();
                $st  = $pdo->prepare('SELECT username, email FROM Users WHERE user_id = :id LIMIT 1');
                $st->execute([':id' => (int)$post['user_id']]);
                if ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                    $author['username'] = (string)($row['username'] ?? 'Desconocido');
                    $author['email']    = (string)($row['email'] ?? '');
                }
            } catch (\Throwable $e) { /* silencio */ }
        }

        $this->renderCompat('post/detail', [
            'title'  => 'Detalle del servicio',
            'post'   => $post,
            'author' => $author,
        ]);
    }

    /* ============================ Helpers ============================ */

    private function getPostById(int $id): ?array
    {
        if (method_exists($this->modelo, 'getById')) {
            $row = $this->modelo->getById($id);
            if ($row) return $row;
        }
        if (method_exists($this->modelo, 'findById')) {
            $row = $this->modelo->findById($id);
            if ($row) return $row;
        }
        if (method_exists($this->modelo, 'find')) {
            $row = $this->modelo->find(['post_id' => $id]);
            if ($row) return $row;
        }
        return null;
    }

    private function renderCompat(string $view, array $vars = []): void
    {
        if (method_exists($this, 'render')) {
            echo $this->render($view, $vars);
            return;
        }
        extract($vars, EXTR_SKIP);
        $path = __DIR__ . '/../../Views/' . str_replace('.', '/', $view) . '.php';
        require $path;
    }
}

