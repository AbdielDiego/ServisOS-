<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\PublicProfile;
use App\Models\UserMetrics;
use App\Core\Database;
use PDO;

class PublicProfileController
{
    /** Perfil público por ID: /u/:id o /profile/:id */
    public function show(): void
    {
        $id = 0;

        // 1) Router -> $this->routeParams['id']
        if (property_exists($this, 'routeParams') && is_array($this->routeParams ?? null)) {
            $id = (int)($this->routeParams['id'] ?? 0);
        }

        // 2) Querystring -> ?id=24
        if ($id <= 0) {
            $id = (int)($_GET['id'] ?? 0);
        }

        // 3) Fallback: parsear la URL por si el router no inyecta params
        if ($id <= 0 && isset($_SERVER['REQUEST_URI'])) {
            if (preg_match('#/(?:u|profile)/(\d+)(?:\D.*)?$#', $_SERVER['REQUEST_URI'], $m)) {
                $id = (int)$m[1];
            }
        }

        if ($id <= 0) {
            http_response_code(404);
            $this->render('errors/404', ['message' => 'Perfil no encontrado']);
            return;
        }

        // ===== Datos del usuario =====
        $user = PublicProfile::getUserPublic($id);
        if (!$user) {
            http_response_code(404);
            $this->render('errors/404', ['message' => 'Perfil no existe']);
            return;
        }

        $page   = max(1, (int)($_GET['page'] ?? 1));
        $limit  = 10;
        $offset = ($page - 1) * $limit;

        $stats       = PublicProfile::getUserStats($id);
        $categories  = PublicProfile::getCategoryBreakdown($id);
        $posts       = PublicProfile::getUserPosts($id, $limit, $offset);
        $recentComms = PublicProfile::getRecentCommentsByUser($id, 10);

        // ===== Visitas del perfil (reputación ya viene en $stats['avg_rating']) =====
        // Intentamos usar UserMetrics::getVisits(); si no existe, calculamos un proxy (ratings + comments sobre sus posts)
        $visits = 0;
        if (class_exists(UserMetrics::class) && method_exists(UserMetrics::class, 'getVisits')) {
            $visits = (int)UserMetrics::getVisits($id);
        } else {
            // Fallback: visitas aproximadas = cantidad de ratings + cantidad de comentarios sobre posts del usuario
            $pdo = Database::getConnection();
            $pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

            // Comentarios sobre sus posts
            $q1 = $pdo->prepare("
                SELECT COUNT(*) 
                FROM Comments c 
                JOIN Posts p ON p.post_id = c.post_id 
                WHERE p.user_id = :id
            ");
            $q1->execute([':id' => $id]);
            $commentsOnHisPosts = (int)$q1->fetchColumn();

            // Ratings sobre sus posts
            $q2 = $pdo->prepare("
                SELECT COUNT(*)
                FROM post_ratings r
                JOIN Posts p ON p.post_id = r.post_id
                WHERE p.user_id = :id
            ");
            $q2->execute([':id' => $id]);
            $ratingsOnHisPosts = (int)$q2->fetchColumn();

            $visits = $commentsOnHisPosts + $ratingsOnHisPosts;
        }

        // ===== Render =====
        $this->render('profile/public', [
            'title'       => 'Perfil de ' . ($user['username'] ?? 'Usuario'),
            'user'        => $user,
            'stats'       => $stats,       // incluye avg_rating y ratings_count
            'categories'  => $categories,
            'posts'       => $posts,
            'recentComms' => $recentComms,
            'page'        => $page,
            'limit'       => $limit,
            'isBanned'    => (bool)($user['is_banned'] ?? false),
            'visits'      => $visits,     // <-- agregado: valor para el div de "Visitas"
        ]);
    }

    /* ================= Helpers de render ================= */

    protected function render(string $view, array $data = []): void
    {
        $file = $this->resolveViewPath($view);

        // Intentar .phtml si no existe .php
        if (!is_file($file)) {
            $alt = preg_replace('/\.php$/', '.phtml', $file);
            if ($alt && is_file($alt)) { $file = $alt; }
        }

        if (!is_file($file)) {
            http_response_code(in_array($view, ['errors/404','error/404','404']) ? 404 : 500);
            echo "<h1>Vista no encontrada</h1><p>No existe la vista: <code>" . htmlspecialchars($view) . "</code></p>";
            return;
        }

        extract($data, EXTR_SKIP);

        $viewsBase = dirname(__DIR__) . '/Views/';
        $header = $viewsBase . 'partials/header.php';
        $footer = $viewsBase . 'partials/footer.php';

        if (is_file($header)) { include $header; }
        include $file;
        if (is_file($footer)) { include $footer; }
    }

    protected function resolveViewPath(string $view): string
    {
        $view = ltrim($view, '/');
        $base = dirname(__DIR__) . '/Views/';
        return $base . $view . (str_ends_with($view, '.php') ? '' : '.php');
    }
}

