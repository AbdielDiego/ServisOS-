<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;

final class Comment
{
    /* ======================= PDO helper ======================= */
    private static function pdo(): PDO
    {
        $pdo = Database::getConnection();
        // Robustez por si el conector no setea estos atributos
        $pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    }

    /* ========================== READ ========================== */

    /**
     * Lista comentarios por post, con alias 'body' y marca 'edit'.
     * Ordenados del más viejo al más nuevo (ASC) para mantener coherencia
     * con tu UI que muestra histórico primero.
     */
    public function findByPostId(int $postId): array
    {
        $pdo = self::pdo();
        $sql = "
            SELECT
                c.comment_id,
                c.post_id,
                c.user_id,
                c.comment_text,
                c.comment_text AS body,
                c.created_at,
                c.edit,
                u.username
            FROM Comments c
            LEFT JOIN Users u ON u.user_id = c.user_id
            WHERE c.post_id = :pid
            ORDER BY c.created_at ASC, c.comment_id ASC
        ";
        $st = $pdo->prepare($sql);
        $st->execute([':pid' => $postId]);
        return $st->fetchAll() ?: [];
    }

    /** Detalle por id (estático para compatibilidad con el controlador). */
    public static function findById(int $commentId): ?array
    {
        $pdo = self::pdo();
        $st = $pdo->prepare("
            SELECT c.*, u.username
            FROM Comments c
            LEFT JOIN Users u ON u.user_id = c.user_id
            WHERE c.comment_id = :id
            LIMIT 1
        ");
        $st->execute([':id' => $commentId]);
        $row = $st->fetch();
        return $row ?: null;
    }

    /**
     * Devuelve owner y post (para permisos y redirect luego de borrar).
     */
    public function getOwnerAndPost(int $commentId): ?array
    {
        $pdo = self::pdo();
        $st = $pdo->prepare("
            SELECT comment_id, post_id, user_id
            FROM Comments
            WHERE comment_id = :id
            LIMIT 1
        ");
        $st->execute([':id' => $commentId]);
        $row = $st->fetch();
        return $row ?: null;
    }

    /* ========================= CREATE ========================= */

    /**
     * Crea comentario para un post.
     * Devuelve true si insertó (el controlador no usa el id).
     * Acepta userId null (comentario anónimo permitido por tu FK).
     * Valida que el post exista para evitar el bug típico de FK/ID inválido.
     */
    public function createForPost(int $postId, ?int $userId, string $text): bool
    {
        $pdo = self::pdo();

        // Validar que exista el post
        $chk = $pdo->prepare("SELECT 1 FROM Posts WHERE post_id = :id LIMIT 1");
        $chk->execute([':id' => $postId]);
        if (!$chk->fetchColumn()) {
            return false;
        }

        $sql = "
            INSERT INTO Comments (post_id, user_id, comment_text, created_at)
            VALUES (:pid, :uid, :txt, CURRENT_TIMESTAMP)
        ";
        $st = $pdo->prepare($sql);
        return $st->execute([
            ':pid' => $postId,
            ':uid' => ($userId !== null && $userId > 0) ? $userId : null,
            ':txt' => $text,
        ]);
    }

    /* ========================= UPDATE ========================= */

    /**
     * Actualiza el texto del comentario y setea la marca 'edit' con timestamp y actor.
     * Si no es admin, solo puede editar su propio comentario.
     */
    public static function updateText(int $commentId, int $actorUserId, string $text, bool $isAdmin): bool
    {
        $pdo = self::pdo();

        if (!$isAdmin) {
            $owner = $pdo->prepare("SELECT user_id FROM Comments WHERE comment_id = :id LIMIT 1");
            $owner->execute([':id' => $commentId]);
            $uid = (int)($owner->fetchColumn() ?: 0);
            if ($uid === 0 || $uid !== $actorUserId) {
                return false;
            }
        }

        $mark = date('Y-m-d H:i:s') . ' by ' . $actorUserId;
        $st = $pdo->prepare("
            UPDATE Comments
               SET comment_text = :txt,
                   edit         = :edit
             WHERE comment_id   = :id
             LIMIT 1
        ");
        $st->execute([
            ':txt'  => $text,
            ':edit' => $mark,
            ':id'   => $commentId,
        ]);
        return $st->rowCount() > 0;
    }

    /* ========================= DELETE ========================= */

    public function deleteById(int $commentId): bool
    {
        $pdo = self::pdo();
        $st  = $pdo->prepare("DELETE FROM Comments WHERE comment_id = :id LIMIT 1");
        $st->execute([':id' => $commentId]);
        return $st->rowCount() > 0;
    }
}

