<?php
namespace App\Models;

use App\Core\Database;
use PDO;

class BanUser
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Database::getConnection();
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }

    /**
     * Inserta o actualiza un ban en BanUsers
     */
    public function banUser(int $userId, ?string $reason, ?int $adminId): void
    {
        $sql = "
            INSERT INTO BanUsers (user_id, username, email, reason, banned_by, banned_at)
            SELECT u.user_id, u.username, u.email, :reason, :admin, NOW()
            FROM Users u
            WHERE u.user_id = :uid
            ON DUPLICATE KEY UPDATE
                reason    = VALUES(reason),
                banned_by = VALUES(banned_by),
                banned_at = VALUES(banned_at),
                username  = VALUES(username),
                email     = VALUES(email)
        ";
        $st = $this->pdo->prepare($sql);
        $st->execute([
            ':reason' => ($reason === '' ? null : $reason),
            ':admin'  => ($adminId ?: null),
            ':uid'    => $userId,
        ]);
    }

    public function unbanByUserId(int $userId): void
    {
        $st = $this->pdo->prepare("DELETE FROM BanUsers WHERE user_id = :id");
        $st->execute([':id' => $userId]);
    }

    public function unbanByBanId(int $banId): void
    {
        $st = $this->pdo->prepare("DELETE FROM BanUsers WHERE ban_id = :id");
        $st->execute([':id' => $banId]);
    }
}

