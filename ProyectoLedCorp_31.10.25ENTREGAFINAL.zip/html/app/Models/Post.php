<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;

final class Post
{
    private PDO $pdo;
    private string $table = 'Posts';
    private string $pk    = 'post_id';

    public function __construct()
    {
        $this->pdo = Database::getConnection();
        // Robusto por si el conector no lo establece
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }

    /* ===================== SELECT helpers ===================== */

    /** SELECT base con joins + agregados de rating (si existen) */
    private function selectBase(): string
    {
        // Nota: LEFT JOIN al subquery de ratings para no romper si no hay votos
        return "
            SELECT
                p.{$this->pk}      AS post_id,
                p.user_id,
                p.category_id,
                p.title,
                p.content,
                p.price,
                p.created_at,
                p.updated_at,
                c.name             AS category,
                u.username,
                u.email,
                r.avg_post_rating,
                r.ratings_count
            FROM {$this->table} p
            LEFT JOIN Categories c ON c.category_id = p.category_id
            LEFT JOIN Users      u ON u.user_id     = p.user_id
            LEFT JOIN (
                SELECT
                    post_id,
                    ROUND(AVG(rating), 1) AS avg_post_rating,
                    COUNT(*)              AS ratings_count
                FROM post_ratings
                GROUP BY post_id
            ) r ON r.post_id = p.{$this->pk}
        ";
    }

    /* ========================= SELECTS ========================= */

    /** Lista todos los posts (para /post) con categoría, autor y price. */
    public function listAll(): array
    {
        $sql = $this->selectBase() . " 
               ORDER BY p.created_at DESC, p.{$this->pk} DESC";
        return $this->pdo->query($sql)->fetchAll() ?: [];
    }

    /** Paginado simple (devuelve siempre 'posts' como clave) */
    public function sqlPaginado(int $pagina = 1, int $porPagina = 10): array
    {
        $pagina    = max(1, $pagina);
        $porPagina = max(1, $porPagina);
        $offset    = ($pagina - 1) * $porPagina;

        $total = (int)$this->pdo->query("SELECT COUNT(*) FROM {$this->table}")->fetchColumn();

        $sql = $this->selectBase() . "
               ORDER BY p.created_at DESC, p.{$this->pk} DESC
               LIMIT :lim OFFSET :off";
        $st = $this->pdo->prepare($sql);
        $st->bindValue(':lim', $porPagina, PDO::PARAM_INT);
        $st->bindValue(':off', $offset,   PDO::PARAM_INT);
        $st->execute();

        return [
            'posts'       => $st->fetchAll() ?: [],
            'total'       => $total,
            'porPagina'   => $porPagina,
            'pagina'      => $pagina,
        ];
    }

    /** Detalle por id (incluye autor, email, categoría y price) */
    public function getById(int $id): ?array
    {
        $sql = $this->selectBase() . " 
               WHERE p.{$this->pk} = :id
               LIMIT 1";
        $st = $this->pdo->prepare($sql);
        $st->execute([':id' => $id]);
        $row = $st->fetch();
        return $row ?: null;
    }

    /** Alias por compatibilidad con su controlador */
    public function findById(int $id): ?array
    {
        return $this->getById($id);
    }

    /**
     * Búsqueda flexible. Si recibe sólo post_id, usa getById().
     * Acepta keys: post_id, user_id, category_id, title (match exacto), etc.
     */
    public function find(array $where): ?array
    {
        if (empty($where)) return null;

        if (isset($where[$this->pk]) && count($where) === 1) {
            return $this->getById((int)$where[$this->pk]);
        }

        // Whitelist simple para evitar inyecciones en keys
        $allowed = ['post_id','user_id','category_id','title'];
        $clauses = [];
        $params  = [];

        foreach ($where as $k => $v) {
            if (!in_array($k, $allowed, true)) continue;
            $param = ':' . $k;
            $clauses[]   = "p.$k = $param";
            $params[$param] = $v;
        }

        if (empty($clauses)) return null;

        $sql = $this->selectBase() . "
               WHERE " . implode(' AND ', $clauses) . "
               LIMIT 1";
        $st = $this->pdo->prepare($sql);
        $st->execute($params);
        $row = $st->fetch();
        return $row ?: null;
    }

    /* ===================== INSERT / UPDATE ===================== */

    /**
     * Crea un post. Keys esperadas:
     *  - user_id (int, requerido)
     *  - category_id (int|null)
     *  - title (string), content (string)
     *  - price (int >= 0, opcional; default 0)
     */
    public function create(array $data): int
    {
        $sql = "INSERT INTO {$this->table}
                   (user_id, category_id, title, content, price)
                VALUES
                   (:user_id, :category_id, :title, :content, :price)";

        $st = $this->pdo->prepare($sql);

        $st->bindValue(':user_id', (int)($data['user_id'] ?? 0), PDO::PARAM_INT);

        if (array_key_exists('category_id', $data) && $data['category_id'] !== null && $data['category_id'] !== '') {
            $st->bindValue(':category_id', (int)$data['category_id'], PDO::PARAM_INT);
        } else {
            $st->bindValue(':category_id', null, PDO::PARAM_NULL);
        }

        $st->bindValue(':title',   (string)($data['title']   ?? ''), PDO::PARAM_STR);
        $st->bindValue(':content', (string)($data['content'] ?? ''), PDO::PARAM_STR);

        $price = isset($data['price']) && is_numeric($data['price']) ? (int)$data['price'] : 0;
        if ($price < 0) $price = 0;
        $st->bindValue(':price', $price, PDO::PARAM_INT);

        $st->execute();
        return (int)$this->pdo->lastInsertId();
    }

    /** Actualiza sólo el precio (según su uso previo) */
    public function updatePrice(int $postId, int $price): void
    {
        if ($price < 0) $price = 0;
        $this->pdo->prepare("
            UPDATE {$this->table}
               SET price = :price
             WHERE {$this->pk} = :id
        ")->execute([':price' => $price, ':id' => $postId]);
    }
}

