<?php
namespace App\Models;

use App\Core\Model;

class Api extends Model
{
    public function __construct(){
        $this->table = "Categories";
        $this->primaryKey = "category_id";
        parent::__construct();
    }

    public function all(string $q = ''): array {
        if ($q !== '') {
            $sql = "SELECT category_id, name
                    FROM {$this->table}
                    WHERE name LIKE :q
                    ORDER BY name ASC";
            $stmt = $this->db->query($sql, [':q' => "%{$q}%"]);
        } else {
            $sql = "SELECT category_id, name
                    FROM {$this->table}
                    ORDER BY name ASC";
            $stmt = $this->db->query($sql);
        }
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function findById(int $id): ?array {
        $sql = "SELECT category_id, name
                FROM {$this->table}
                WHERE {$this->primaryKey} = :id
                LIMIT 1";
        $stmt = $this->db->query($sql, [':id' => $id]);
        $row  = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public function findByName(string $name): ?array {
        $sql = "SELECT category_id, name
                FROM {$this->table}
                WHERE name = :name
                LIMIT 1";
        $stmt = $this->db->query($sql, [':name' => $name]);
        $row  = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public function getPostsByCategory(int $categoryId): array {
        $sql = "SELECT p.post_id, p.title, p.content, p.price, p.user_id,
                       u.username,
                       p.created_at, p.updated_at
                FROM Posts p
                LEFT JOIN Users u ON u.user_id = p.user_id
                WHERE p.category_id = :cid
                ORDER BY p.created_at DESC, p.post_id DESC";
        $stmt = $this->db->query($sql, [':cid' => $categoryId]);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function getCommentsByCategory(int $categoryId): array {
        $sql = "SELECT c.comment_id, c.post_id, c.user_id, c.comment_text,
                       c.created_at, c.edit,
                       p.title AS post_title,
                       u.username
                FROM Comments c
                INNER JOIN Posts p ON p.post_id = c.post_id
                LEFT JOIN Users u  ON u.user_id = c.user_id
                WHERE p.category_id = :cid
                ORDER BY c.created_at DESC, c.comment_id DESC";
        $stmt = $this->db->query($sql, [':cid' => $categoryId]);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    // Compatibilidad
    public function executeRawQuery(string $sql, array $params = []): array {
        $stmt = $this->db->query($sql, $params);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
}

