<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;

class UserMetrics
{
    protected static function pdo(): PDO
    {
        $pdo = Database::getConnection();
        $pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    }

    /** Datos básicos del usuario (para dashboard) */
    public static function getUserBasic(int $userId): ?array
    {
        $sql = "SELECT u.user_id, u.username, u.created_at, u.rol_id, r.rol_name AS role_name
                FROM Users u
                LEFT JOIN RolUsers r ON r.rol_id = u.rol_id
                WHERE u.user_id = :id
                LIMIT 1";
        $st  = self::pdo()->prepare($sql);
        $st->execute([':id' => $userId]);
        $row = $st->fetch();
        return $row ?: null;
    }

    /** Publicaciones totales del usuario */
    public static function getPostsTotal(int $userId): int
    {
        $st = self::pdo()->prepare("SELECT COUNT(*) FROM Posts WHERE user_id = :id");
        $st->execute([':id' => $userId]);
        return (int)$st->fetchColumn();
    }

    /** Mensajes sin leer (bandeja de entrada) */
    public static function getUnreadMessages(int $userId): int
    {
        $sql = "SELECT COUNT(*) 
                FROM message_recipients mr
                WHERE mr.recipient_id = :id AND mr.is_read = 0";
        $st = self::pdo()->prepare($sql);
        $st->execute([':id' => $userId]);
        return (int)$st->fetchColumn();
    }

    /**
     * Reputación del usuario:
     * - avg_rating: promedio de ratings de TODOS sus posts
     * - ratings_count: cantidad total de calificaciones recibidas
     */
    public static function getReputation(int $userId): array
    {
        $sql = "SELECT IFNULL(AVG(pr.rating), 0) AS avg_rating,
                       COUNT(pr.id)            AS ratings_count
                FROM Posts p
                LEFT JOIN post_ratings pr ON pr.post_id = p.post_id
                WHERE p.user_id = :id";
        $st  = self::pdo()->prepare($sql);
        $st->execute([':id' => $userId]);
        $row = $st->fetch() ?: ['avg_rating' => 0, 'ratings_count' => 0];

        return [
            'avg_rating'    => round((float)$row['avg_rating'], 2),
            'ratings_count' => (int)$row['ratings_count'],
        ];
    }

    /**
     * Visitas (proxy sin tabla de vistas):
     * - comments_on_posts: comentarios que recibió en sus posts
     * - ratings_count: ya calculado arriba
     * visitas = comments_on_posts + ratings_count
     */
    public static function getVisits(int $userId): int
    {
        $sql = "SELECT COUNT(*) AS comments_on_posts
                FROM Comments c
                JOIN Posts p ON p.post_id = c.post_id
                WHERE p.user_id = :id";
        $st  = self::pdo()->prepare($sql);
        $st->execute([':id' => $userId]);
        $commentsOnPosts = (int)$st->fetchColumn();

        $ratings = self::getReputation($userId)['ratings_count'];
        return $commentsOnPosts + $ratings;
    }

    /** Paquete completo para pintar tarjetas del Dashboard */
    public static function summary(int $userId): array
    {
        $postsTotal = self::getPostsTotal($userId);
        $repu       = self::getReputation($userId);
        $visits     = self::getVisits($userId);
        $unread     = self::getUnreadMessages($userId);

        return [
            'posts_total'      => $postsTotal,
            'avg_rating'       => $repu['avg_rating'],
            'ratings_count'    => $repu['ratings_count'],
            'profile_views'    => $visits,          // nombre usado por tu vista
            'unread_messages'  => $unread,
        ];
    }

    /** Lista simple de posts (para el dashboard) */
    public static function getMyPosts(int $userId, int $limit = 6, int $offset = 0): array
    {
        $sql = "SELECT p.post_id, p.title, p.content, p.price, p.created_at,
                       COALESCE(c.name,'Sin categoría') AS category,
                       (SELECT IFNULL(AVG(r.rating),0)
                        FROM post_ratings r WHERE r.post_id = p.post_id) AS avg_rating
                FROM Posts p
                LEFT JOIN Categories c ON c.category_id = p.category_id
                WHERE p.user_id = :id
                ORDER BY p.created_at DESC, p.post_id DESC
                LIMIT :limit OFFSET :offset";
        $pdo = self::pdo();
        $st  = $pdo->prepare($sql);
        $st->bindValue(':id',     $userId, PDO::PARAM_INT);
        $st->bindValue(':limit',  max(1, $limit), PDO::PARAM_INT);
        $st->bindValue(':offset', max(0, $offset), PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll() ?: [];
    }
}

