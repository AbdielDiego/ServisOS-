<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;

class PublicProfile
{
    protected static function pdo(): PDO
    {
        $pdo = Database::getConnection();
        $pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    }

    /** Datos públicos por ID (ocultamos email) + rol textual + flag baneado */
    public static function getUserPublic(int $userId): ?array
    {
        $sql = "SELECT u.user_id, u.username, u.rol_id, u.created_at,
                       r.rol_name AS role_name,
                       EXISTS(SELECT 1 FROM BanUsers b WHERE b.user_id = u.user_id) AS is_banned
                FROM Users u
                LEFT JOIN RolUsers r ON r.rol_id = u.rol_id
                WHERE u.user_id = :id
                LIMIT 1";
        $st  = self::pdo()->prepare($sql);
        $st->execute([':id' => $userId]);
        $row = $st->fetch();
        return $row ?: null;
    }

    /** Stats: total posts, promedio de ratings de sus posts y cantidad de calificaciones */
    public static function getUserStats(int $userId): array
    {
        $pdo = self::pdo();

        $st = $pdo->prepare("SELECT COUNT(*) FROM Posts WHERE user_id = :id");
        $st->execute([':id' => $userId]);
        $posts_total = (int)$st->fetchColumn();

        $st = $pdo->prepare("
            SELECT IFNULL(AVG(r.rating),0) AS avg_rating, COUNT(r.id) AS ratings_count
            FROM Posts p
            LEFT JOIN post_ratings r ON r.post_id = p.post_id
            WHERE p.user_id = :id
        ");
        $st->execute([':id' => $userId]);
        $ratings = $st->fetch() ?: ['avg_rating' => 0, 'ratings_count' => 0];

        return [
            'posts_total'   => $posts_total,
            'avg_rating'    => round((float)$ratings['avg_rating'], 2),
            'ratings_count' => (int)$ratings['ratings_count'],
        ];
        }

    /** Desglose por categorías (nombre + cantidad de posts) */
    public static function getCategoryBreakdown(int $userId): array
    {
        $sql = "SELECT COALESCE(c.name, 'Sin categoría') AS category, COUNT(*) AS cnt
                FROM Posts p
                LEFT JOIN Categories c ON c.category_id = p.category_id
                WHERE p.user_id = :id
                GROUP BY c.category_id
                ORDER BY cnt DESC, category ASC";
        $st  = self::pdo()->prepare($sql);
        $st->execute([':id' => $userId]);
        return $st->fetchAll() ?: [];
    }

    /** Posts del usuario (paginados) con categoría, tags y promedio del post */
    public static function getUserPosts(int $userId, int $limit = 10, int $offset = 0): array
    {
        $sql = "SELECT 
                    p.post_id, p.title, p.content, p.price, p.created_at, p.updated_at,
                    COALESCE(c.name, 'Sin categoría') AS category,
                    (
                        SELECT GROUP_CONCAT(t.name ORDER BY t.name SEPARATOR ', ')
                        FROM PostTags pt
                        JOIN Tags t ON t.tag_id = pt.tag_id
                        WHERE pt.post_id = p.post_id
                    ) AS tags,
                    (SELECT IFNULL(AVG(r.rating),0) FROM post_ratings r WHERE r.post_id = p.post_id) AS avg_post_rating
                FROM Posts p
                LEFT JOIN Categories c ON c.category_id = p.category_id
                WHERE p.user_id = :id
                ORDER BY p.created_at DESC, p.post_id DESC
                LIMIT :limit OFFSET :offset";
        $pdo = self::pdo();
        $st  = $pdo->prepare($sql);
        $st->bindValue(':id',     $userId,           PDO::PARAM_INT);
        $st->bindValue(':limit',  max(1, $limit),    PDO::PARAM_INT);
        $st->bindValue(':offset', max(0, $offset),   PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll() ?: [];
    }

    /** Últimos comentarios hechos por el usuario */
    public static function getRecentCommentsByUser(int $userId, int $limit = 10): array
    {
        $sql = "SELECT c.comment_id, c.comment_text, c.created_at,
                       p.post_id, p.title AS post_title
                FROM Comments c
                JOIN Posts p ON p.post_id = c.post_id
                WHERE c.user_id = :id
                ORDER BY c.created_at DESC, c.comment_id DESC
                LIMIT :limit";
        $pdo = self::pdo();
        $st  = $pdo->prepare($sql);
        $st->bindValue(':id',    $userId,         PDO::PARAM_INT);
        $st->bindValue(':limit', max(1, $limit),   PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll() ?: [];
    }
}

