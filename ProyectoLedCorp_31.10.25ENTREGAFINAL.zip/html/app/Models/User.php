<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;
use PDO;

/**
 * Modelo unificado de Usuarios
 * - Compatible con App\Core\Model (propiedades NO tipadas)
 * - Métodos estáticos para find/update + utilidades
 * - Métodos de instancia para listados con filtros
 */
class User extends Model
{
    /* =========================
     * Config de tabla/PK
     * ========================= */
    public const TABLE = 'Users';
    public const PK    = 'user_id';

    /** Propiedades NO tipadas (compat con App\Core\Model) */
    protected $table      = self::TABLE;
    protected $primaryKey = self::PK;

    /* =========================
     * Conexión PDO (común)
     * ========================= */
    protected static function pdo(): PDO
    {
        $pdo = Database::getConnection();
        $pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    }

    /** Añade alias 'role_id' sin romper 'rol_id' (compatibilidad) */
    protected static function withRoleAlias(?array $row): ?array
    {
        if (!$row) return null;
        if (!array_key_exists('role_id', $row) && array_key_exists('rol_id', $row)) {
            $row['role_id'] = $row['rol_id'];
        }
        return $row;
    }

    /* =========================
     * Métodos ESTÁTICOS (compat)
     * ========================= */

    /** Buscar por ID (campos básicos) */
    public static function findById(int $id): ?array
    {
        $sql = "SELECT user_id, username, email, rol_id, created_at
                FROM " . self::TABLE . "
                WHERE " . self::PK . " = ?";
        $st  = self::pdo()->prepare($sql);
        $st->execute([$id]);
        return self::withRoleAlias($st->fetch() ?: null);
    }

    /** ¿Existe username (excluyendo un ID)? */
    public static function usernameExists(string $username, int $exceptId = 0): bool
    {
        $sql = "SELECT COUNT(*)
                FROM " . self::TABLE . "
                WHERE username = ? AND " . self::PK . " <> ?";
        $st  = self::pdo()->prepare($sql);
        $st->execute([$username, $exceptId]);
        return (int)$st->fetchColumn() > 0;
    }

    /** ¿Existe email (excluyendo un ID)? */
    public static function emailExists(string $email, int $exceptId = 0): bool
    {
        $sql = "SELECT COUNT(*)
                FROM " . self::TABLE . "
                WHERE email = ? AND " . self::PK . " <> ?";
        $st  = self::pdo()->prepare($sql);
        $st->execute([$email, $exceptId]);
        return (int)$st->fetchColumn() > 0;
    }

    /** Actualizar username + email */
    public static function updateProfile(int $id, string $username, string $email): bool
    {
        $sql = "UPDATE " . self::TABLE . " SET username = ?, email = ? WHERE " . self::PK . " = ?";
        $st  = self::pdo()->prepare($sql);
        return $st->execute([$username, $email, $id]);
    }

    /** Actualizar contraseña (hash ya calculado) */
    public static function updatePassword(int $id, string $passwordHash): bool
    {
        $sql = "UPDATE " . self::TABLE . " SET password = ? WHERE " . self::PK . " = ?";
        $st  = self::pdo()->prepare($sql);
        return $st->execute([$passwordHash, $id]);
    }

    /** Buscar por email (incluye password hash) */
    public static function findByEmail(string $email): ?array
    {
        $sql = "SELECT user_id, username, email, password, rol_id, created_at
                FROM " . self::TABLE . " WHERE email = ? LIMIT 1";
        $st  = self::pdo()->prepare($sql);
        $st->execute([$email]);
        return self::withRoleAlias($st->fetch() ?: null);
    }

    /** ¿Usuario baneado? (tabla BanUsers) */
    public static function isBanned(int $userId): bool
    {
        $st = self::pdo()->prepare("SELECT 1 FROM BanUsers WHERE user_id = ? LIMIT 1");
        $st->execute([$userId]);
        return (bool)$st->fetchColumn();
    }

    /* ====================================
     * Métodos DE INSTANCIA (listas/filters)
     * ==================================== */

    /**
     * Lista usuarios activos (no baneados).
     * Filtros: ['user' => string, 'email' => string]
     */
    public function listActive(array $filters = []): array
    {
        $sql = "SELECT
                    u." . $this->primaryKey . " AS user_id,
                    u.username,
                    u.email,
                    u.rol_id AS rol_id,
                    u.created_at
                FROM " . $this->table . " u
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM BanUsers b
                    WHERE b.user_id = u." . $this->primaryKey . "
                )";

        $params = [];
        if (!empty($filters['user'])) {
            $sql .= " AND u.username LIKE :user";
            $params[':user'] = '%'.$filters['user'].'%';
        }
        if (!empty($filters['email'])) {
            $sql .= " AND u.email LIKE :email";
            $params[':email'] = '%'.$filters['email'].'%';
        }

        $sql .= " ORDER BY u." . $this->primaryKey . " DESC";

        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        $rows = $st->fetchAll() ?: [];
        foreach ($rows as &$r) { $r['role_id'] = $r['rol_id']; }
        return $rows;
    }

    /** Obtener por ID (instancia, con alias role_id) */
    public function getById(int $id): ?array
    {
        $sql = "SELECT user_id, username, email, rol_id, created_at
                FROM " . $this->table . "
                WHERE " . $this->primaryKey . " = :id
                LIMIT 1";
        $st  = self::pdo()->prepare($sql);
        $st->execute([':id' => $id]);
        return self::withRoleAlias($st->fetch() ?: null);
    }
}

