<?php
use App\Middleware\AuthMiddleware;
use App\Middleware\AdminMiddleware;

$mwAuth  = [AuthMiddleware::class];
$mwAdmin = [AdminMiddleware::class];

$addMany = function (string $method, array $paths, string $handler, ?array $mw = null) use ($router) {
    foreach ($paths as $p) {
        $router->addRoute($method, $p, $handler, $mw ?? []);
    }
};

/* ======================= Rutas públicas ======================= */
$addMany('GET',  ['/'],              'HomeController@index');
$addMany('GET',  ['/apicategorias'], 'ApiController@index');
$addMany('POST', ['/apicategorias'], 'ApiController@index');
$router->addRoute('POST', '/forgot/support', 'SupportController@requestReset');
$router->addRoute('GET',  '/admin/support',  'SupportController@adminIndex');
$router->addRoute('POST', '/admin/support/reset', 'SupportController@resetPassword');

/* Auth */
$addMany('GET',  ['/login'],    'AuthController@showLogin');
$addMany('POST', ['/login'],    'AuthController@login');
$addMany('GET',  ['/logout'],   'AuthController@logout');
$addMany('GET',  ['/register'], 'AuthController@showRegister');
$addMany('POST', ['/register'], 'AuthController@register');

/* =================== Recuperar contraseña ==================== */
$addMany('GET',  ['/forgot'], 'AuthController@forgot');
$addMany('POST', ['/forgot'], 'AuthController@forgotPost');
$addMany('GET',  ['/reset'],  'AuthController@reset');
$addMany('POST', ['/reset'],  'AuthController@resetPost');

/* ========================== MiNuevo ========================== */
$router->addRoute('GET',  '/minuevo',          'MinuevoController@index');
$router->addRoute('GET',  '/minuevo/crear',    'MinuevoController@create', [AuthMiddleware::class]);
$router->addRoute('POST', '/minuevo/guardar',  'MinuevoController@store',  [AuthMiddleware::class]);
$router->addRoute('GET',  '/article/:slug',    'MinuevoController@show');
$router->addRoute('POST', '/article/:id/rate', 'MinuevoController@rate',   [AuthMiddleware::class]);

/* =================== Dashboard / Mi Perfil =================== */
$addMany('GET',  ['/dashboard','/dashboard.php','/mi-perfil','/perfil','/profile'], 'DashboardController@index', $mwAuth);

/* Perfil (editar) */
$addMany('GET',  ['/profile/edit'], 'ProfileController@edit',   $mwAuth);
$addMany('POST', ['/profile/edit'], 'ProfileController@update', $mwAuth);

/* Perfil público por ID */
$addMany('GET', ['/u/:id','/profile/:id'], 'PublicProfileController@show');

/* ============================ Categorías ========================== */
$addMany('GET',  ['/categorias','/categoria'], 'PostController@index');
$addMany('GET',  ['/categoria/:id','/category/:id','/categories/:id'], 'PostController@index');

/* ============================ Posts ========================== */
$addMany('GET',  ['/post'],                 'PostController@index');
$addMany('GET',  ['/post/paginar/:pagina'], 'PostController@index');
$addMany('GET',  ['/post/detail'],          'PostController@detail');
$addMany('GET',  ['/post/:id'],             'PostController@show');
$addMany('GET',  ['/post/:id/comentar'],    'PostController@comentar');

/* ========================= Comentarios ======================= */
$router->addRoute('POST', '/post/:id/comments',  'CommentController@storeUnified', $mwAuth);
$router->addRoute('POST', '/posts/:id/comments', 'CommentController@storeUnified', $mwAuth);
$router->addRoute('POST', '/comments',           'CommentController@storeUnified', $mwAuth);

$addMany('GET',  ['/comments/:id/edit'], 'CommentController@editForm', $mwAuth);
$addMany('POST', ['/comments/:id'],      'CommentController@update',   $mwAuth);

$addMany('POST', ['/comments/:id/delete','/comment/delete'], 'CommentController@destroyUnified', $mwAuth);

/* =========================== Rating ========================== */
$addMany('POST', ['/rating'],          'RatingController@rate',       $mwAuth);
$addMany('POST', ['/api/rate/simple'], 'RatingController@rateSimple', $mwAuth);

/* ============================ Mensajes ======================= */
$addMany('GET',  ['/messages/inbox'],                       'MessageController@inbox',    $mwAuth);
$addMany('GET',  ['/messages/sent'],                        'MessageController@sent',     $mwAuth);
$addMany('GET',  ['/messages/compose'],                     'MessageController@compose',  $mwAuth);
$addMany('GET',  ['/messages/reply','/messages/reply.php'], 'MessageController@reply',    $mwAuth);
$addMany('GET',  ['/messages/contact','/messages/contact.php'],'MessageController@contact',$mwAuth);
$addMany('POST', ['/messages'],                             'MessageController@store',    $mwAuth);
$addMany('GET',  ['/messages/:id'],                         'MessageController@show',     $mwAuth);
$addMany('POST', ['/messages/read/:id'],                    'MessageController@markRead', $mwAuth);
$addMany('POST', ['/messages/:id/reply'],                   'MessageController@replyPost',$mwAuth);
$addMany('POST', ['/messages/delete/:id'],                  'MessageController@delete',   $mwAuth);
$addMany('GET',  ['/messages/delete/:id'],                  'MessageController@delete',   $mwAuth);

/* ====================== Admin: Usuarios (listar / roles) ====================== */
$addMany('GET',  ['/usuarios','/users'], 'UsuariosController@index', $mwAdmin);
$addMany('GET',  ['/usuarios/make-admin/:id'], 'UsuariosController@makeAdmin', $mwAdmin);
$addMany('POST', ['/usuarios/make-admin/:id'], 'UsuariosController@makeAdmin', $mwAdmin);
$addMany('GET',  ['/usuarios/make-user/:id'],  'UsuariosController@makeUser',  $mwAdmin);
$addMany('POST', ['/usuarios/make-user/:id'],  'UsuariosController@makeUser',  $mwAdmin);

/* ====================== Admin: Baneos (UNIFICADO) ====================== */
/* 1) Listado de baneados */
$addMany('GET', [
    '/usuarios/baneados',
    '/banusers.php',
    '/ban',               // alias viejo
], 'BanUsersController@index', $mwAdmin);

/* 2) Banear (GET desde botón o POST desde form) */
$addMany('GET', [
    '/usuarios/ban',
    '/usuarios/ban/:id',
    '/ban/:id',           // alias por si ya lo usabas
], 'BanUsersController@ban', $mwAdmin);

$addMany('POST', [
    '/usuarios/ban',
    '/ban',
], 'BanUsersController@ban', $mwAdmin);

/* 3) Desbanear */
$addMany('GET', [
    '/usuarios/unban/:id',
    '/unban/:id',
    '/unban',             // para /unban?user_id=...
    '/unban.php',
], 'BanUsersController@unban', $mwAdmin);

$addMany('POST', [
    '/usuarios/unban',
    '/unban',
], 'BanUsersController@unban', $mwAdmin);

/* ====== (IMPORTANTE) Eliminar rutas viejas que chocaban ====== */
/* Antes tenías:
   $addMany('GET',  ['/usuarios/ban','/usuarios/ban/:id'], 'UsuariosController@ban',     $mwAdmin);
   $addMany('POST', ['/usuarios/ban','/usuarios/ban/:id'], 'UsuariosController@banPost', $mwAdmin);
   Eso lo quitamos porque ahora lo hace BanUsersController.
*/

/* ====================== Admin: Delete user ====================== */
$addMany('GET',  ['/users/delete/:id'], 'UsuariosController@delete',  $mwAdmin);
$addMany('POST', ['/users/delete/:id'], 'UsuariosController@destroy', $mwAdmin);
$addMany('GET',  ['/deleteuser','/deleteuser.php'],  'UsuariosController@destroy', $mwAdmin);
$addMany('POST', ['/deleteuser','/deleteuser.php'],  'UsuariosController@destroy', $mwAdmin);

