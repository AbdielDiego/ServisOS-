<link rel="stylesheet" href="/css/styles.css">
<!-- Título de la página -->
<h2>Iniciar sesión</h2>

<!-- Formulario de login (método POST) -->
<form method="POST" style="max-width: 300px;">

    <!-- Campo Email -->
    <div>
        <label>Email:</label>
        <input type="email" name="email" required value="">
        <small>Ingrese su email</small>
    </div>
    
    <!-- Campo Contraseña -->
    <div>
        <label>Contraseña:</label>
        <input type="password" name="password" required value="">
        <small>Ingrese su contraseña</small>
    </div>
    
    <!-- Botón de envío -->
    <button type="submit">Ingresar</button>
</form>

