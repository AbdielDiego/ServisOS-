<!-- Barra de navegación principal -->
<nav>
    <!-- Link a inicio -->
    <a href="/" class="<?= ($currentUrl === '/' || $currentUrl === '') ? 'active' : '' ?>">Inicio</a>

    <?php if ($auth['check']): ?>
        <!-- Links visibles solo para usuarios autenticados -->
        <a href="/dashboard" class="<?= (strpos($currentUrl, '/dashboard') === 0) ? 'active' : '' ?>">Dashboard</a>
        <a href="/logout">Cerrar sesión</a>
    <?php else: ?>
        <!-- Link visible si NO está logueado -->
        <a href="/login" class="<?= ($currentUrl === '/login') ? 'active' : '' ?>">Login</a>
    <?php endif; ?>

    <?php
    // Detección de rol de usuario
    $user    = $auth['user'] ?? null;
    $rolName = $user['rol_name'] ?? ($user['rol'] ?? ($_SESSION['rol'] ?? ''));
    $rolId   = isset($user['rol_id']) ? (int)$user['rol_id'] : 0;

    // Considerar admin si rol_name = "admin" o rol_id = 1
    $isAdmin = (strtolower((string)$rolName) === 'admin') || ($rolId === 1);

    // Mostrar enlace Usuarios solo a admins autenticados
    if ($auth['check'] && $isAdmin): ?>
        <a href="/usuarios" class="<?= ($currentUrl === '/usuarios') ? 'active' : '' ?>">Usuarios</a>
    <?php endif; ?>

    <!-- Links visibles para todos -->
    <a href="/post" class="<?= ($currentUrl === '/post') ? 'active' : '' ?>">Servicios</a>
    <a href="/apicategorias" class="<?= ($currentUrl === '/apicategorias') ? 'active' : '' ?>">Categorias de Servicios</a>
    <a href="/register" class="<?= ($currentUrl === '/register') ? 'active' : '' ?>">Registrarse</a>
</nav>


