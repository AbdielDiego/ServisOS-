<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\Comment;

class CommentController extends Controller
{
    protected $session;
    protected $comment;

    public function __construct()
    {
        parent::__construct();
        // Inicializar dependencias
        if (!$this->session instanceof Session) {
            $this->session = new Session();
        }
        if (!$this->comment instanceof Comment) {
            $this->comment = new Comment();
        }
    }

    // POST /comments
    public function store()
    {
        $bp     = $this->basePath();
        $userId = $this->getUserId();
        if (!$userId) {
            $this->session->flash('error', 'Debes iniciar sesión para comentar');
            return $this->redirect("$bp/login");
        }

        $postId = (int)$this->inputValue('post_id', 0);
        $text   = trim((string)$this->inputValue('comment_text', $this->inputValue('body', '')));

        if ($postId <= 0 || mb_strlen($text) < 2) {
            $this->session->flash('error', 'Comentario inválido');
            return $this->redirect("$bp/post/{$postId}#comentar");
        }

        if (!$this->postExists($postId)) {
            $this->session->flash('error', 'El post no existe');
            return $this->redirect("$bp/");
        }

        try {
            if (!$this->persist($postId, $text, $userId)) {
                throw new \RuntimeException('Insert devolvió false');
            }
            $this->session->flash('success', 'Comentario publicado');
            return $this->redirect("$bp/post/{$postId}#comentarios");
        } catch (\Throwable $e) {
            error_log('[CommentsController.store] ' . $e->getMessage());
            $this->session->flash('error', 'No se pudo guardar el comentario');
            return $this->redirect("$bp/post/{$postId}#comentar");
        }
    }

    // POST /posts/:id/comments
    public function storeForPost($postId)
    {
        $bp     = $this->basePath();
        $userId = $this->getUserId();
        if (!$userId) {
            $this->session->flash('error', 'Debes iniciar sesión para comentar');
            return $this->redirect("$bp/login");
        }

        $postId = (int)$postId;
        $text   = trim((string)$this->inputValue('comment_text', $this->inputValue('body', '')));

        if ($postId <= 0 || mb_strlen($text) < 2) {
            $this->session->flash('error', 'Comentario inválido');
            return $this->redirect("$bp/post/{$postId}#comentar");
        }

        if (!$this->postExists($postId)) {
            $this->session->flash('error', 'El post no existe');
            return $this->redirect("$bp/");
        }

        try {
            if (!$this->persist($postId, $text, $userId)) {
                throw new \RuntimeException('Insert devolvió false');
            }
            $this->session->flash('success', 'Comentario publicado');
            return $this->redirect("$bp/post/{$postId}#comentarios");
        } catch (\Throwable $e) {
            error_log('[CommentsController.storeForPost] ' . $e->getMessage());
            $this->session->flash('error', 'No se pudo guardar el comentario');
            return $this->redirect("$bp/post/{$postId}#comentar");
        }
    }

    /* ===== Helpers ===== */

    private function basePath(): string
    {
        return rtrim($this->basePath ?? '', '/');
    }

    private function inputValue(string $key, $default = null)
    {
        if (method_exists($this, 'input')) {
            $val = $this->input($key);
            return $val !== null ? $val : $default;
        }
        return $_POST[$key] ?? $default;
    }

    private function getUserId(): int
    {
        if (property_exists($this, 'auth') && $this->auth && method_exists($this->auth, 'user')) {
            $u = $this->auth->user();
            if (!empty($u['id'])) return (int)$u['id'];
        }
        return (int)($this->session->get('auth_user_id') ?? 0);
    }

    private function postExists(int $postId): bool
    {
        if ($postId <= 0) return false;
        if (property_exists($this, 'postModel') && $this->postModel && method_exists($this->postModel, 'exists')) {
            try {
                return (bool)$this->postModel->exists($postId);
            } catch (\Throwable $e) {
                return true;
            }
        }
        return true;
    }

    private function persist(int $postId, string $text, int $userId): bool
    {
        return (bool)$this->comment->create([
            'post_id'      => $postId,
            'user_id'      => $userId,
            'comment_text' => $text,
        ]);
    }
}

