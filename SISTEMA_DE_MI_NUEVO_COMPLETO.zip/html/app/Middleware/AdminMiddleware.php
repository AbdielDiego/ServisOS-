<?php
namespace App\Middleware;

class AdminMiddleware
{
    public function handle()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

        $user = $_SESSION['auth']['user'] ?? $_SESSION['user'] ?? null;
        $isAdmin = false;

        if (is_array($user)) {
            // Ajusta si tu app guarda el rol distinto
            $isAdmin = (isset($user['rol_id']) && (int)$user['rol_id'] === 1);
        }

        // Si no es admin, 403
        if (!$isAdmin) {
            http_response_code(403);
            echo "<h1>Acceso denegado</h1><p>No tienes permisos para ver esta página.</p>";
            exit;
        }

        return true;
    }
}

