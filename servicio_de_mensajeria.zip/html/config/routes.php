<?php
use App\Middleware\AuthMiddleware;
use App\Middleware\AdminMiddleware;

/* =======================
 * Rutas públicas
 * ======================= */
$router->addRoute('GET',  '/',               'HomeController@index');
$router->addRoute('GET',  '/apicategorias',  'ApiController@index');
$router->addRoute('POST', '/apicategorias',  'ApiController@index');

$router->addRoute('GET',  '/login',          'AuthController@showLogin');
$router->addRoute('POST', '/login',          'AuthController@login');
$router->addRoute('GET',  '/logout',         'AuthController@logout');
$router->addRoute('GET',  '/register',       'AuthController@showRegister');
$router->addRoute('POST', '/register',       'AuthController@register');

/* =======================
 * Posts
 * ======================= */
$router->addRoute('GET', '/post',                 'PostController@index', [AuthMiddleware::class]);
$router->addRoute('GET', '/post/paginar/:pagina', 'PostController@index', [AuthMiddleware::class]);
$router->addRoute('GET', '/post/:id',             'PostController@show',  [AuthMiddleware::class]);

/* =======================
 * Categorías
 * ======================= */
$router->addRoute('GET',  '/categoria/:id',             'CategoriaController@show');
$router->addRoute('POST', '/categoria/:id/comentarios', 'CategoriaController@storeComment', [AuthMiddleware::class]);

/* =======================
 * Comentarios
 * ======================= */
$router->addRoute('POST', '/comments',           'CommentController@store',        [AuthMiddleware::class]);
$router->addRoute('POST', '/posts/:id/comments', 'CommentController@storeForPost', [AuthMiddleware::class]);

/* =======================
 * Rating
 * ======================= */
$router->addRoute('POST', '/api/rate/simple', 'RatingController@rateSimple');

/* =======================
 * MiNuevo (módulo)
 * ======================= */
$router->addRoute('GET',  '/minuevo',          'MinuevoController@index');
$router->addRoute('GET',  '/minuevo/crear',    'MinuevoController@create', [AuthMiddleware::class]);
$router->addRoute('POST', '/minuevo/guardar',  'MinuevoController@store',  [AuthMiddleware::class]);
$router->addRoute('GET',  '/article/:slug',    'MinuevoController@show');
$router->addRoute('POST', '/article/:id/rate', 'MinuevoController@rate',   [AuthMiddleware::class]);

/* Mensajes */
$router->addRoute('GET',  '/messages/inbox',      'MessageController@inbox',   [AuthMiddleware::class]);
$router->addRoute('GET',  '/messages/sent',       'MessageController@sent',    [AuthMiddleware::class]);
$router->addRoute('GET',  '/messages/new',        'MessageController@compose', [AuthMiddleware::class]);
$router->addRoute('POST', '/messages',            'MessageController@store',   [AuthMiddleware::class]);

// SOLO rutas con ID para ver detalle:
$router->addRoute('GET',  '/messages/:id',        'MessageController@compose',  [AuthMiddleware::class]);
$router->addRoute('GET',  '/messages/compose/:id', 'MessageController@compose',  [AuthMiddleware::class]);

// Acciones sobre un mensaje
$router->addRoute('POST', '/messages/read/:id',   'MessageController@markRead',[AuthMiddleware::class]);
$router->addRoute('POST', '/messages/:id/reply',  'MessageController@reply',   [AuthMiddleware::class]);



/* =======================
 * Otros
 * ======================= */
$router->addRoute('GET',  '/dashboard',     'DashboardController@index',  [AuthMiddleware::class]);
$router->addRoute('GET',  '/dashboard/:id', 'DashboardController@show',   [AuthMiddleware::class]);
$router->addRoute('GET',  '/profile',       'ProfileController@index',    [AuthMiddleware::class]);
$router->addRoute('POST', '/profile',       'ProfileController@update',   [AuthMiddleware::class]);
$router->addRoute('GET',  '/usuarios',      'UsuariosController@index',   [AdminMiddleware::class]);

