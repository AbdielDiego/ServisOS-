<link rel="stylesheet" href="/css/styles.css">
<?php
/** @var array  $items */
/** @var int    $newCount */
/** @var string $title */
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/** Devuelve el primer dato no vacío entre posibles claves */
function firstNonEmpty(array $row, array $keys, $default = 'Desconocido'){
    foreach ($keys as $k){
        if (!empty($row[$k])) return $row[$k];
    }
    return $default;
}
?>
<div>
  <h1><?= h($title ?? 'Inbox') ?></h1>

  <?php if (!empty($_SESSION['flash_ok'])): ?>
    <div class="alert ok"><?= h($_SESSION['flash_ok']); unset($_SESSION['flash_ok']); ?></div>
  <?php endif; ?>
  <?php if (!empty($_SESSION['flash_error'])): ?>
    <div class="alert error"><?= h($_SESSION['flash_error']); unset($_SESSION['flash_error']); ?></div>
  <?php endif; ?>

  <?php if (($newCount ?? 0) > 0): ?>
    <div class="alert info">Tienes <?= (int)$newCount ?> mensaje<?= $newCount==1?'':'s' ?> nuevo<?= $newCount==1?'':'s' ?>.</div>
  <?php endif; ?>

  <?php if (empty($items)): ?>
    <p>No hay mensajes.</p>
  <?php else: ?>
    <ul>
      <?php foreach ($items as $row): ?>
        <?php
          // Preferimos username; si tu modelo también trae email, lo tomamos como fallback.
          $from = firstNonEmpty($row, ['from_name','from_username','from_email','email','username'], 'Desconocido');
        ?>
        <li>
          <a href="/messages/<?= (int)$row['message_id'] ?>">
            <?= h($row['subject']) ?>
            <?php if (empty($row['is_read'])): ?> (nuevo)<?php endif; ?>
          </a>
          · De: <?= h($from) ?> · <?= h($row['created_at']) ?>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</div>

