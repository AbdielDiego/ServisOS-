<?php
// Asegurar variables para evitar errores
$post  = $post ?? [];
$pid   = (int)($post['post_id'] ?? 0);
$title = $post['title']   ?? 'Post';
$body  = $post['content'] ?? '';
?>


<!-- Título del post -->
<h1><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></h1>

<!-- Contenido del post -->
<article>
  <p><?= nl2br(htmlspecialchars($body, ENT_QUOTES, 'UTF-8')) ?></p>
</article>

<?php
// Incluir componente de mensajes flash (si existe)
$flashPath = BASE_PATH . "/app/Views/components/flash-messages.php";
if (file_exists($flashPath)) { require $flashPath; }
?>

<!-- Sección para comentarios -->
<section id="comentar">
  <h2>Deja tu comentario</h2>

  <?php if (isset($this->session) && $this->session->has('auth_user_id')): ?>
    <!-- Formulario de comentarios (solo para usuarios logueados) -->
    <form method="POST" action="/posts/<?= $pid ?>/comments" novalidate>
      <div>
        <label for="body">Comentario</label>
        <textarea id="body" name="body" rows="5" required></textarea>
      </div>

      <!-- Botón de enviar y enlace de retorno -->
      <button type="submit">Publicar</button>
      <a href="/post/<?= $pid ?>">Volver al post</a>
    </form>
  <?php else: ?>
    <!-- Aviso para usuarios no autenticados -->
    <p><a href="/login">Inicia sesión</a> para comentar.</p>
  <?php endif; ?>
</section>


