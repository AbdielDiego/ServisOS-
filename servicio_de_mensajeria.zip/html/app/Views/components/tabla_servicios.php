<?php
// ========= Tabla genérica con detección de ID y recurso =========

$datosTabla = $datosTabla ?? [];

if (!empty($datosTabla)) {

    // Columnas
    if (isset($datosTabla[0]) && is_array($datosTabla[0])) {
        $columnas = array_keys($datosTabla[0]);
    } else {
        $columnas  = array_keys((array)$datosTabla);
        $datosTabla = [ $datosTabla ];
    }

    // BASE pública
    $BASE = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

    /**
     * Detecta el recurso (post|servicio|categoria|user|generic) y la mejor columna ID.
     * Reglas:
     *  - Busca columnas típicas por entidad (post_id, service_id, category_id, etc.)
     *  - Si no encuentra, aplica heurísticas por nombre (contiene 'post'+'id', 'serv'+'id', 'cat'+'id')
     *  - Si todo falla, intenta 'id' o cualquier '*_id' que varíe y sea numérico
     */
    $detectarRecursoEId = function(array $filas, array $cols): array {
        $normCols = array_map('strtolower', $cols);
        $map = array_combine($normCols, $cols); // lower->original

        $has = function($names) use ($map) {
            foreach ((array)$names as $n) {
                $n = strtolower($n);
                if (isset($map[$n])) return $map[$n];
            }
            return null;
        };

        // 1) Reglas directas por nombres comunes
        if ($id = $has(['post_id','id_post']))     return ['entity'=>'post',     'idCol'=>$id];
        if ($id = $has(['service_id','servicio_id','id_service','id_servicio'])) return ['entity'=>'servicio', 'idCol'=>$id];
        if ($id = $has(['category_id','categoria_id','id_category','id_categoria'])) return ['entity'=>'categoria','idCol'=>$id];
        if ($id = $has(['user_id','id_user']))     return ['entity'=>'user',     'idCol'=>$id];

        // 2) Heurística por combinación de palabras
        $pickByHeuristic = function(string $entity, array $cols) {
            foreach ($cols as $c) {
                $lc = strtolower($c);
                if ($entity === 'post'     && str_contains($lc,'post') && str_contains($lc,'id')) return $c;
                if ($entity === 'servicio' && (str_contains($lc,'serv') || str_contains($lc,'service')) && str_contains($lc,'id')) return $c;
                if ($entity === 'categoria'&& (str_contains($lc,'cat')  || str_contains($lc,'categ'))  && str_contains($lc,'id')) return $c;
            }
            return null;
        };
        if ($id = $pickByHeuristic('post', $cols))      return ['entity'=>'post',     'idCol'=>$id];
        if ($id = $pickByHeuristic('servicio', $cols))  return ['entity'=>'servicio', 'idCol'=>$id];
        if ($id = $pickByHeuristic('categoria', $cols)) return ['entity'=>'categoria','idCol'=>$id];

        // 3) Fallback genérico: 'id' o cualquier '*_id' que sea numérico y varíe
        $esNumerica = fn($v) => is_numeric($v) && $v !== '';
        $candidatos = [];

        foreach ($cols as $c) {
            $lc = strtolower($c);
            if ($lc === 'id' || str_ends_with($lc,'_id')) {
                // ¿numérico y con variación?
                $vals = [];
                $todosNumericos = true;
                foreach ($filas as $f) {
                    $v = $f[$c] ?? null;
                    if (!$esNumerica($v)) { $todosNumericos = false; break; }
                    $vals[] = (string)$v;
                }
                if (!$todosNumericos) continue;
                if (count(array_unique($vals)) >= max(2, (int)floor(count($vals)*0.5))) {
                    $candidatos[] = $c;
                }
            }
        }

        if (!empty($candidatos)) {
            // por defecto, si no sabemos el recurso exacto, tratamos como 'post'
            return ['entity'=>'post', 'idCol'=>$candidatos[0]];
        }

        // Sin id utilizable
        return ['entity'=>null, 'idCol'=>null];
    };

    $det = $detectarRecursoEId($datosTabla, $columnas);
    $entity = $det['entity'];
    $colId  = $det['idCol'];

    // Mapea entidad a ruta base
    $rutaBase = function(?string $entity) {
        switch ($entity) {
            case 'post':      return '/post';
            case 'servicio':  return '/servicio';
            case 'categoria': return '/categoria';
            case 'user':      return '/usuario';   // si querés abrir detalle de usuario
            default:          return null;         // sin acciones
        }
    };

    $baseEntidad = $rutaBase($entity);
    ?>
    <table class="tabla users-table tabla-compact">
        <thead>
            <tr>
                <?php foreach ($columnas as $col): ?>
                    <th><?= htmlspecialchars($col, ENT_QUOTES, 'UTF-8') ?></th>
                <?php endforeach; ?>
                <?php if ($colId && $baseEntidad): ?>
                  <th>Acciones</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($datosTabla as $fila): ?>
                <tr>
                    <?php foreach ($columnas as $col): ?>
                        <td><?= htmlspecialchars((string)($fila[$col] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                    <?php endforeach; ?>

                    <?php if ($colId && $baseEntidad): ?>
                        <?php
                          $idVal = $fila[$colId] ?? null;
                          $id    = is_numeric($idVal) ? (int)$idVal : 0;
                        ?>
                        <td class="td-actions">
                          <?php if ($id > 0): ?>
                            <a class="btn btn-sm" href="<?= $BASE . $baseEntidad ?>/<?= $id ?>#comentar">Comentar</a>
                            <a class="btn btn-sm" href="<?= $BASE . $baseEntidad ?>/<?= $id ?>#comentarios">Ver comentarios</a>
                          <?php else: ?>
                            —
                          <?php endif; ?>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php
} else {
    echo "<h1 class=\"empty-state\">SIN DATOS</h1>";
}

