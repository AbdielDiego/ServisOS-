<?php
// Aseguramos que $auth siempre sea un array
if (!isset($auth) || !is_array($auth)) {
    $auth = [];
}

// Verificar si hay sesión activa (auth o sesión nativa)
$isLogged = !empty($auth['check']) || !empty($_SESSION['username']);

if ($isLogged):
    // Extraer datos del usuario desde $auth o $_SESSION
    $user     = $auth['user'] ?? [];
    $username = $user['username'] ?? ($_SESSION['username'] ?? 'Usuario');
    $rolName  = $user['rol_name'] ?? ($user['rol'] ?? ($_SESSION['rol'] ?? ''));
    $email    = $user['email'] ?? ($_SESSION['email'] ?? 'Sin email');
?>
    <!-- Widget de esquina para mostrar info de usuario logueado -->
    <div class="user-corner" onclick="this.classList.toggle('open')">
        
        <!-- Encabezado -->
        <div class="uc-header"> Sesión activa</div>
        
        <!-- Detalles del usuario -->
        <div class="uc-details">
            <!-- Nombre de usuario -->
            <div class="uc-name"> <?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?></div>
            <a href="/logout">Cerrar sesión</a>
            <!-- Rol si existe -->
            <?php if ($rolName !== ''): ?>
                <div class="uc-rol"> Rol: <?= htmlspecialchars($rolName, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            
            <!-- Email -->
            <div class="uc-extra"> Email: <?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?></div>
        </div>
    </div>
<?php endif; ?>

