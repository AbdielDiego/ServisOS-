<?php
// Vars necesarias:
// $entityType: 'post' | 'servicio' | 'categoria'
// $entityId:   int
// $avg:        float (average_rating)
// $count:      int   (rating_count)
// $readOnly:   bool  (opcional)
$avg   = isset($avg) ? (float)$avg : 0.0;
$count = isset($count) ? (int)$count : 0;
$readOnly = $readOnly ?? false;
$target = [
  'post'      => '/api/rate/post',
  'servicio'  => '/api/rate/servicio',
  'categoria' => '/api/rate/categoria'
][$entityType] ?? '#';

$rounded = number_format($avg, 2, ',', '.');
$uid = 'rate_'. $entityType .'_'. $entityId . '_' . random_int(1000,9999);
?>
<div class="rating-box" id="<?= $uid ?>" data-endpoint="<?= htmlspecialchars($target) ?>" data-id="<?= (int)$entityId ?>">
  <div class="stars <?= $readOnly ? 'ro':'' ?>">
    <?php for ($i=1; $i<=5; $i++): 
      $filled = ($avg >= $i - 0.5); // medio punto para “media estrella” visual simple
    ?>
      <span class="star <?= $filled ? 'filled':'' ?>" data-value="<?= $i ?>">★</span>
    <?php endfor; ?>
  </div>
  <div class="meta">
    <small><strong><?= $rounded ?></strong> / 5 · <?= $count ?> voto<?= $count===1?'':'s' ?></small>
  </div>
</div>

<style>
.rating-box { display:inline-block; }
.rating-box .stars { font-size: 1.3rem; cursor: pointer; user-select:none; }
.rating-box .stars.ro { cursor: default; }
.rating-box .star { padding: 0 .1rem; transition: transform .1s; }
.rating-box .star:hover { transform: scale(1.15); }
.rating-box .star.filled { color: #ffc107; text-shadow: 0 0 6px rgba(255,193,7,.6); }
.rating-box .meta { margin-top: .2rem; color: #bbb; }
</style>

<?php if (!$readOnly): ?>
<script>
(() => {
  const box = document.getElementById('<?= $uid ?>');
  if (!box) return;
  const endpoint = box.dataset.endpoint;
  const id = box.dataset.id;
  const stars = box.querySelectorAll('.star');

  stars.forEach(s => {
    s.addEventListener('click', async (e) => {
      const value = e.currentTarget.dataset.value;
      try {
        const form = new FormData();
        form.set('id', id);
        form.set('rating', value);

        const resp = await fetch(endpoint, {
          method: 'POST',
          body: form,
          headers: { 'X-Requested-With': 'fetch' } // por si usas filtros
        });
        const data = await resp.json();

        if (!data.ok) {
          alert(data.msg || 'No se pudo registrar tu voto');
          return;
        }

        // Actualiza UI (estrellas, meta)
        const avg = parseFloat(data.average_rating || 0);
        const count = parseInt(data.rating_count || 0, 10);

        // marcar filled
        stars.forEach((st, idx) => {
          const i = idx + 1;
          if (avg >= i - 0.5) st.classList.add('filled');
          else st.classList.remove('filled');
        });

        const meta = box.querySelector('.meta');
        if (meta) meta.innerHTML = `<small><strong>${avg.toFixed(2).replace('.', ',')}</strong> / 5 · ${count} voto${count===1?'':'s'}</small>`;
      } catch (err) {
        alert('Error de red');
      }
    });
  });
})();
</script>
<?php endif; ?>

