<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\MessageRecipient;

class MessageController extends Controller
{
    /* =========================
     *   Helpers de autenticación
     * ========================= */
    private function currentUserId(): ?int
    {
        if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
        // Soporta distintas claves usadas en tu app
        if (isset($_SESSION['auth']['user'])) {
            $u = $_SESSION['auth']['user'];
            return (int)($u['user_id'] ?? $u['id'] ?? 0);
        }
        if (isset($_SESSION['user'])) {
            $u = $_SESSION['user'];
            return (int)($u['user_id'] ?? $u['id'] ?? 0);
        }
        if (isset($_SESSION['user_id'])) return (int)$_SESSION['user_id'];
        return null;
    }

    /** Exige sesión y devuelve el user_id */
    private function requireAuth(): int
    {
        $uid = $this->currentUserId();
        if (!$uid) {
            header('Location: /login');
            exit;
        }
        return $uid;
    }

    /* =========================
     *          INBOX
     * ========================= */
    /** GET /messages/inbox */
    public function inbox()
    {
        $uid      = $this->requireAuth();
        $items    = MessageRecipient::inboxFor($uid, 200);
        $newCount = MessageRecipient::countNewFor($uid);

        return $this->render('messages/inbox', [
            'title'    => 'Inbox',
            'items'    => $items,
            'newCount' => $newCount,
        ]);
    }

    /* =========================
     *         ENVIADOS
     * ========================= */
    /** GET /messages/sent */
    public function sent()
    {
        $uid = $this->requireAuth();
        $pdo = Database::getConnection();

        // Concatena nombres (o email si no hay username) de los destinatarios
        $sql = "
            SELECT
                m.id AS message_id,
                m.subject,
                m.created_at,
                COALESCE(
                    GROUP_CONCAT(
                        DISTINCT COALESCE(NULLIF(u.username, ''), u.email)
                        ORDER BY u.username SEPARATOR ', '
                    ),
                    ''
                ) AS to_names
            FROM messages m
            LEFT JOIN message_recipients mr ON mr.message_id = m.id
            LEFT JOIN Users u              ON u.user_id      = mr.recipient_id
            WHERE m.sender_id = :uid
            GROUP BY m.id, m.subject, m.created_at
            ORDER BY m.created_at DESC
        ";
        $st = $pdo->prepare($sql);
        $st->execute([':uid' => $uid]);
        $items = $st->fetchAll(\PDO::FETCH_ASSOC);

        return $this->render('messages/sent', [
            'title' => 'Mensajes',
            'items' => $items,
        ]);
    }

    /* =========================
     *     COMPOSE (barra clásica)
     * ========================= */
    /** GET /messages/compose */
    public function compose()
    {
        $this->requireAuth();
        return $this->render('messages/compose', [
            'title' => 'Nuevo mensaje',
            'old'   => [
                'to_query' => $_POST['to_query'] ?? '',
                'subject'  => $_POST['subject']  ?? '',
                'body'     => $_POST['body']     ?? '',
            ],
        ]);
    }

    /**
     * Convierte el texto libre (usernames/emails separados por coma o espacio)
     * a IDs de usuario, sin JS.
     * @return array [array $ids, array $noEncontrados]
     */
    private function resolveRecipientIdsFromQuery(string $raw, int $currentUserId): array
    {
        $tokens = preg_split('/[,\s]+/', $raw, -1, PREG_SPLIT_NO_EMPTY);
        if (empty($tokens)) return [[], []];

        // Normalizamos a minúsculas y únicos
        $needles = [];
        foreach ($tokens as $t) {
            $t = strtolower(trim($t));
            if ($t !== '') $needles[$t] = true;
        }
        if (empty($needles)) return [[], []];

        $pdo = Database::getConnection();

        // Traemos candidatos cuyos username o email estén en la lista
        // (comparación case-insensitive)
        // armamos placeholders
        $placeholders = implode(',', array_fill(0, count($needles), '?'));
        $params = array_keys($needles);
        $params = array_merge($params, $params); // para username y email

        $sql = "
            SELECT user_id, LOWER(username) AS uname, LOWER(email) AS uemail
            FROM Users
            WHERE LOWER(username) IN ($placeholders)
               OR LOWER(email)    IN ($placeholders)
        ";
        $st = $pdo->prepare($sql);
        $st->execute($params);
        $rows = $st->fetchAll(\PDO::FETCH_ASSOC);

        // Mapa token -> id
        $map = [];
        foreach ($rows as $r) {
            if (!empty($r['uname']))  $map[$r['uname']]  = (int)$r['user_id'];
            if (!empty($r['uemail'])) $map[$r['uemail']] = (int)$r['user_id'];
        }

        $ids = [];
        $unknown = [];
        foreach (array_keys($needles) as $tok) {
            if (isset($map[$tok])) {
                $id = (int)$map[$tok];
                if ($id > 0 && $id !== $currentUserId) {
                    $ids[$id] = true; // set
                }
            } else {
                $unknown[] = $tok;
            }
        }

        return [array_keys($ids), $unknown];
    }

    /** POST /messages */
    public function store()
    {
        $uid     = $this->requireAuth();
        $pdo     = Database::getConnection();
        $toQuery = trim($_POST['to_query'] ?? '');
        $subject = trim($_POST['subject']  ?? '');
        $body    = trim($_POST['body']     ?? '');

        if ($subject === '' || $body === '' || $toQuery === '') {
            return $this->render('messages/compose', [
                'title' => 'Nuevo mensaje',
                'error' => 'Completa destinatarios, asunto y mensaje.',
                'old'   => ['to_query'=>$toQuery, 'subject'=>$subject, 'body'=>$body],
            ]);
        }

        [$recips, $unknown] = $this->resolveRecipientIdsFromQuery($toQuery, $uid);

        if (!empty($unknown)) {
            return $this->render('messages/compose', [
                'title' => 'Nuevo mensaje',
                'error' => 'No se encontraron: ' . implode(', ', $unknown),
                'old'   => ['to_query'=>$toQuery, 'subject'=>$subject, 'body'=>$body],
            ]);
        }
        if (empty($recips)) {
            return $this->render('messages/compose', [
                'title' => 'Nuevo mensaje',
                'error' => 'No hay destinatarios válidos (no puedes enviarte a ti mismo).',
                'old'   => ['to_query'=>$toQuery, 'subject'=>$subject, 'body'=>$body],
            ]);
        }

        // Crear mensaje
        $st = $pdo->prepare("INSERT INTO messages (sender_id, subject, body) VALUES (:sid, :sub, :bod)");
        $st->execute([':sid'=>$uid, ':sub'=>$subject, ':bod'=>$body]);
        $mid = (int)$pdo->lastInsertId();

        // Vincular destinatarios
        MessageRecipient::addRecipients($mid, $recips);

        return $this->redirect('/messages/sent');
    }

    /* =========================
     *           SHOW
     * ========================= */
    /** GET /messages/:id  (detalle) */
    public function show($id)
    {
        $uid = $this->requireAuth();
        $mid = (int)$id;
        if ($mid <= 0) return $this->redirect('/messages/inbox');

        if (!MessageRecipient::userCanSee($mid, $uid)) {
            http_response_code(403);
            return $this->render('errors/403', ['message' => 'No autorizado']);
        }

        $pdo = Database::getConnection();

        // Mensaje
        $st = $pdo->prepare("
            SELECT m.id, m.subject, m.body, m.created_at,
                   m.sender_id, su.username AS from_name
            FROM messages m
            INNER JOIN Users su ON su.user_id = m.sender_id
            WHERE m.id = :mid
            LIMIT 1
        ");
        $st->execute([':mid' => $mid]);
        $message = $st->fetch(\PDO::FETCH_ASSOC);
        if (!$message) return $this->redirect('/messages/inbox');

        // Destinatarios
        $st = $pdo->prepare("
            SELECT mr.recipient_id, mr.is_read, mr.read_at, u.username
            FROM message_recipients mr
            INNER JOIN Users u ON u.user_id = mr.recipient_id
            WHERE mr.message_id = :mid
            ORDER BY u.username
        ");
        $st->execute([':mid' => $mid]);
        $recipients = $st->fetchAll(\PDO::FETCH_ASSOC);

        // Si soy destinatario, marcar leído
        $st = $pdo->prepare("
            SELECT 1 FROM message_recipients
            WHERE message_id = :mid AND recipient_id = :uid LIMIT 1
        ");
        $st->execute([':mid' => $mid, ':uid' => $uid]);
        if ($st->fetchColumn()) {
            MessageRecipient::markRead($mid, $uid);
        }

        return $this->render('messages/show', [
            'title'      => 'Mensaje',
            'message'    => $message,
            'recipients' => $recipients,
        ]);
    }
}

