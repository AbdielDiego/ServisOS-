<?php
namespace App\Models;

use App\Core\Database;

class User
{
    /**
     * Recibe una lista de tokens (username o email).
     * Devuelve [ token_normalizado => user_id ] solo para los que existan.
     */
    public static function mapTokensToIds(array $tokens): array
    {
        if (empty($tokens)) return [];
        $pdo = Database::getConnection();

        // normalizar tokens y limpiar
        $norm = [];
        foreach ($tokens as $t) {
            $t = trim((string)$t);
            if ($t !== '') $norm[] = $t;
        }
        if (empty($norm)) return [];

        // placeholders dinámicos
        $inUser = implode(',', array_fill(0, count($norm), '?'));

        // buscamos por username O email
        $sql = "SELECT user_id, username, email
                  FROM Users
                 WHERE username IN ($inUser) OR email IN ($inUser)";
        $st  = $pdo->prepare($sql);
        // bind dos veces el mismo arreglo (username y email)
        $st->execute(array_merge($norm, $norm));
        $rows = $st->fetchAll(\PDO::FETCH_ASSOC);

        $map = [];
        foreach ($rows as $r) {
            // mapear tanto username como email al mismo id
            $map[strtolower($r['username'])] = (int)$r['user_id'];
            $map[strtolower($r['email'])]    = (int)$r['user_id'];
        }
        return $map;
    }
}

