<?php
namespace App\Models;

use App\Core\Database;

class MessageRecipient
{
    public static function inboxFor(int $userId, int $limit=100): array {
        $pdo = Database::getConnection();
        $sql = "
            SELECT mr.message_id, m.subject, m.created_at,
                   mr.is_read, u.username AS from_name
            FROM message_recipients mr
            INNER JOIN messages m ON m.id = mr.message_id
            INNER JOIN Users u ON u.user_id = m.sender_id
            WHERE mr.recipient_id = :uid
            ORDER BY m.created_at DESC
            LIMIT {$limit}
        ";
        $st = $pdo->prepare($sql);
        $st->execute([':uid'=>$userId]);
        return $st->fetchAll(\PDO::FETCH_ASSOC);
    }

    public static function countNewFor(int $userId): int {
        $pdo = Database::getConnection();
        $st = $pdo->prepare("
            SELECT COUNT(*) FROM message_recipients
            WHERE recipient_id = :uid AND is_read = 0
        ");
        $st->execute([':uid'=>$userId]);
        return (int)$st->fetchColumn();
    }

    public static function markRead(int $messageId, int $userId): void {
        $pdo = Database::getConnection();
        $st = $pdo->prepare("
            UPDATE message_recipients
               SET is_read=1, read_at=NOW()
             WHERE message_id=:mid AND recipient_id=:uid
        ");
        $st->execute([':mid'=>$messageId, ':uid'=>$userId]);
    }

    public static function userCanSee(int $mid, int $uid): bool {
        $pdo = Database::getConnection();
        $st = $pdo->prepare("SELECT 1 FROM message_recipients WHERE message_id=:mid AND recipient_id=:uid");
        $st->execute([':mid'=>$mid, ':uid'=>$uid]);
        if ($st->fetchColumn()) return true;

        $st = $pdo->prepare("SELECT 1 FROM messages WHERE id=:mid AND sender_id=:uid");
        $st->execute([':mid'=>$mid, ':uid'=>$uid]);
        return (bool)$st->fetchColumn();
    }

    public static function addRecipients(int $messageId, array $recipientIds): void {
        $pdo = Database::getConnection();
        $st = $pdo->prepare("INSERT INTO message_recipients (message_id,recipient_id,is_read) VALUES (:mid,:rid,0)");
        foreach ($recipientIds as $rid) {
            $st->execute([':mid'=>$messageId, ':rid'=>$rid]);
        }
    }
}

