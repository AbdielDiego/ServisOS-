<?php

if (!function_exists("back")) {
    function back() {
        $url = $_SERVER["HTTP_REFERER"] ?? '/'; // fallback por si no existe
        header("Location: " . $url);
        exit();
    }
}

