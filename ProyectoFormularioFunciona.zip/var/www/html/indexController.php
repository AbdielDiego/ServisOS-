<?php

require_once(__DIR__ . '/../Controller/controller.php');

// Definición de ruta
$route = ["GET", '/', "controller@index"];


if ($route[1] == '/') {
    // Separar controlador y método
    [$controlador, $metodo] = explode('@', $route[2]);

    // Instanciar el controlador y llamar al método (sin parámetros en este caso)
    $controllerInstance = new $controlador();
    $datos = $controllerInstance->$metodo();  // ← Se espera que el método retorne datos

    // Puedes suponer que devuelve algo como:
    // ['titulo' => 'Título de ejemplo', 'datos' => [...]]
    $titulo = $datos['titulo'] ?? 'Sin título';
    $filas = $datos['datos'] ?? [];
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($titulo) ?></title>
</head>
<body>

<h1><?= htmlspecialchars($titulo) ?></h1>

<?php foreach($filas as $i => $row): ?>
    <pre><?php print_r($row); ?></pre>
<?php endforeach; ?>

</body>
</html>

