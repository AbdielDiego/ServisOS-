<?php

$link = linkRandom();
    
if (count($_GET) == 0 ){
    
    echo crearHtml("Sigue el link ", "Conversor Decimal Binario (100-1000)");

}else{

    if ( isset($_GET['var1']) && is_numeric($_GET['var1'])){
      
        $numdec = $_GET['var1'];
        $datos = [];
  
        while ($numdec > 0 ){

                $mod = $numdec % 2;
                $numdec = intdiv( $numdec , 2);
           
                echo "MODULO: $mod - NUMDECIMAL: $numdec <br>";
        
               array_unshift($datos, $mod);
        }

    $binario = implode('',$datos);
    echo crearHtml($binario);

   }else{

    $link = linkRandom();
    echo crearHtml("Debe tener un link válido verifique", "Error en el numero recibido");

    }
}


function crearHTML( $dato, $titulo="Número Binario" ){

global $link;

$html = "
<html>
        <head></head>
        <body>
              <h1>$titulo</h1>
              <h2>$dato<h2>
              <h3> $link </h3>
		</body>
</html>" ;

return $html;

}


function linkRandom(){
$numran = rand(100,1000);

return  "<a href='/?var1=".$numran."'>Convertir Numero Decimal </a>";

}

