<?php
phpinfo();
echo $_GET["var"] -> valor;
