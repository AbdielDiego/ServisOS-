<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\User;
use App\Services\AuthService;
use App\Core\Session;

class AuthController extends Controller {

    private $auth;
    private $session;

    public function __construct() {
        parent::__construct();
        $this->auth = new AuthService();
        $this->session = new Session();
    }

    public function showLogin() {
        if ($this->auth && $this->auth->check()) {
            $this->redirect('/dashboard');
        }

        return $this->render('auth/login', [
            'title' => 'Iniciar Sesión'
        ]);
    }

    public function login() {
        $email = $this->input('email');
        $password = $this->input('password');

        $errors = $this->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        if (!empty($errors)) {
            return $this->render('auth/login', [
                'title' => 'Iniciar Sesión',
                'errors' => $errors,
                'input' => ['email' => $email]
            ]);
        }

        if ($this->auth && $this->auth->attempt($email, $password)) {
            $this->session->flash('success', 'Has iniciado sesión correctamente');
            $this->redirect('/dashboard');
        }

        $this->session->flash('error', 'Credenciales incorrectas');
        return $this->render('auth/login', [
            'title' => 'Iniciar Sesión',
            'input' => ['email' => $email]
        ]);
    }

    public function showRegister() {
        if ($this->auth && $this->auth->check()) {
            $this->redirect('/dashboard');
        }

        return $this->render('auth/register', [
            'title' => 'Registro de Usuario'
        ]);
    }

    public function register() {
        $name = $this->input('name');
        $email = $this->input('email');
        $password = $this->input('password');
        $passwordConfirm = $this->input('password_confirm');

        $errors = $this->validate([
            'name' => 'required|min:3',
            'email' => 'required|email',
            'password' => 'required|min:4'
        ]);

        if ($password !== $passwordConfirm) {
            $errors['password_confirm'] = 'Las contraseñas no coinciden';
        }

        $user = (new User())->findByEmail($email);
        if ($user) {
            $errors['email'] = 'Este email ya está registrado';
        }

        if (!empty($errors)) {
            return $this->render('auth/register', [
                'title' => 'Registro de Usuario',
                'errors' => $errors,
                'input' => [
                    'name' => $name,
                    'email' => $email
                ]
            ]);
        }

        $userId = $this->auth->register([
            'name' => $name,
            'email' => $email,
            'password' => $password,
            'role' => 'user'
        ]);

        if ($userId) {
            $this->auth->attempt($email, $password);
            $this->session->flash('success', 'Te has registrado correctamente');
            $this->redirect('/dashboard');
        }

        $this->session->flash('error', 'Error al registrar el usuario');
        return $this->render('auth/register', [
            'title' => 'Registro de Usuario',
            'input' => [
                'name' => $name,
                'email' => $email
            ]
        ]);
    }

    public function logout() {
        if ($this->auth) {
            $this->auth->logout();
        }
        $this->session->flash('success', 'Has cerrado sesión correctamente');
        $this->redirect('/');
    }

    // ✅ Método para mostrar el formulario de Registro Empresario
    public function registroEmpresario() {
        return $this->render('registro/registro_empresario', [
            'title' => 'Registro para Empresarios'
        ]);
    }
}

