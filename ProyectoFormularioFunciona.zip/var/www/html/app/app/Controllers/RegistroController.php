


<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Empresario;

class RegistroController extends Controller {

    public function registroEmpresario() {
        return $this->render("registro/registro_empresario", ["title" => "Registro Empresarial"]);
    }

    public function guardarEmpresario() {
        $data = [
            'representante' => $_POST['nombre_representante'],
            'empresa' => $_POST['nombre_empresa'],
            'ruc' => $_POST['ruc_cif'],
            'telefono' => $_POST['telefono'],
            'direccion' => $_POST['direccion'],
            'sector' => $_POST['sector'],
            'sitio_web' => $_POST['sitio_web'],
            'logo' => '', // implementación futura
            'email' => $_POST['email'],
            'password' => password_hash($_POST['password'], PASSWORD_DEFAULT)
        ];

        $modelo = new Empresario();
        $modelo->guardar($data);

        $this->redirect('/');
    }
}


public function showRegistro() {
    $modelo = new \App\Models\Empresario();
    $empresarios = $modelo->all(); // Usa el método del modelo base

    return $this->render('registro/showRegistro', [
        'title' => 'Empresarios Registrados',
        'empresarios' => $empresarios
    ]);
}

