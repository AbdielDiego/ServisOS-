<?php
namespace App\Models;

use App\Core\Model;

class Empresario extends Model {
    protected $table = "empresarios";

    public function guardar($data) {
        return $this->create($data);
    }
}

