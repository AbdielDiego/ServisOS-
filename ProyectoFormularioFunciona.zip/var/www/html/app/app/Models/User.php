<?php
namespace App\Models;

// Importa la clase base Model y PDO para manipulación directa
use App\Core\Model;
use PDO;

class User extends Model {
    // Define el nombre de la tabla asociada a este modelo
    protected $table = 'users';

    /**
     * Busca un usuario por su email (consulta preparada con marcador ?)
     * @param string $email - Correo del usuario a buscar
     * @return mixed - Array asociativo con los datos del usuario o false si no existe
     */
    public function findByEmail($email) {
        $query = $this->db->query(
            "SELECT * FROM {$this->table} WHERE email = ? LIMIT 1", 
            [$email] // Parámetro enviado como array
        );
        return $query->fetch(); // Devuelve el primer resultado encontrado
    }

    /**
     * Verifica si el email y la contraseña coinciden con algún usuario
     * @param string $email - Email ingresado por el usuario
     * @param string $password - Contraseña ingresada (sin hashear)
     * @return mixed - Array de usuario si es válido, false si no coincide
     */
    public function checkUser($email, $password) {
        $pdo = $this->db->getPDO(); // 👈 Accedemos al objeto PDO real de la conexión

        // Prepara la consulta para buscar el email
        $stmt = $pdo->prepare("SELECT * FROM {$this->table} WHERE email = :email LIMIT 1");
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        // Recupera los datos del usuario
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verifica la contraseña hasheada contra la ingresada
        if ($user && password_verify($password, $user['password'])) {
            return $user; // Devuelve el usuario si las credenciales son correctas
        }

        return false; // Si no hay coincidencia
    }
}

