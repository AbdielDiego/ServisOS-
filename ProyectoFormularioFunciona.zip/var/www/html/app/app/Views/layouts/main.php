<!DOCTYPE html>
<html>
<head>
    <!-- Codificación de caracteres -->
    <meta charset="UTF-8">

    <!-- Vista adaptable para móviles -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Título del documento, usa $title si está definido -->
    <title><?= $title ?? 'ServisOs' ?></title>

    <!-- Estilos CSS internos -->
    <style>
        /* Estilo general del cuerpo */
        body { 
            font-family: Arial, sans-serif; 
            margin: 0; 
            padding: 0;
            line-height: 1.6;
        }

        /* Encabezado con fondo oscuro y texto blanco */
        header { 
            background: #333; 
            color: white; 
            padding: 1rem;
        }

        /* Contenedor principal con ancho definido y centrado */
        .container { 
            width: 80%; 
            margin: 0 auto;
            padding: 20px;
        }

        /* Estilo para los enlaces de navegación */
        nav a {
            color: white;
            text-decoration: none;
            margin-right: 15px;
        }

        /* Subrayado al pasar el mouse */
        nav a:hover {
            text-decoration: underline;
        }

        /* Clase para destacar enlaces activos */
        .active { 
            font-weight: bold; 
        }

        /* Estilo para mostrar errores */
        .error {
            color: red;
            margin-bottom: 1rem;
        }

        /* Margen inferior entre campos del formulario */
        form div {
            margin-bottom: 1rem;
        }

        /* Etiquetas de los formularios */
        label {
            display: block;
            margin-bottom: 5px;
        }

        /* Inputs ocupan todo el ancho y padding interno */
        input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }

        /* Botón de formularios */
        button {
            padding: 8px 16px;
            background: #333;
            color: white;
            border: none;
            cursor: pointer;
        }

        /* Cambio de color al pasar el mouse por el botón */
        button:hover {
            background: #555;
        }

        /* Estilo base para alertas */
        .alert {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        /* Alerta de error (roja) */
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
        }

        /* Alerta de éxito (verde) */
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }

        /* Estilo de tabla */
        .tabla, td, th {
            background-color: #d4edda;
            color: #155724;
            border-collapse: collapse;
            border: 1px dotted navy;
        }
    </style>
</head>

<body>
    <!-- Sección del encabezado donde se incluye el menú -->
    <header>
        <?php require( __DIR__.'/menu.php'); ?> <!-- Inserta el archivo de navegación -->
    </header>

    <!-- Contenido principal -->
    <main class="container">
        <?php echo $content ?> <!-- Aquí se renderiza el contenido dinámico de cada vista -->
    </main>
</body>
</html>

