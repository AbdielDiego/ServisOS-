<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Empresarios Registrados</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&family=Roboto&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #111;
            color: #00ffe1;
            font-family: 'Roboto', sans-serif;
            text-align: center;
        }

        table {
            width: 90%;
            margin: 30px auto;
            border-collapse: collapse;
            background: rgba(255,255,255,0.05);
            backdrop-filter: blur(4px);
            color: white;
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 12px 15px;
            border: 1px solid #444;
        }

        th {
            background-color: #00ffe1;
            color: #111;
            font-family: 'Orbitron', sans-serif;
        }

        tr:hover {
            background-color: rgba(0, 255, 225, 0.1);
        }

        h1 {
            margin-top: 30px;
            font-family: 'Orbitron', sans-serif;
            color: #00ffe1;
        }
    </style>
</head>
<body>
    <h1>Empresarios Registrados</h1>

    <?php if (count($empresarios) === 0): ?>
        <p>No hay empresarios registrados aún.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Representante</th>
                <th>Empresa</th>
                <th>RUC</th>
                <th>Teléfono</th>
                <th>Dirección</th>
                <th>Sector</th>
                <th>Sitio Web</th>
                <th>Email</th>
            </tr>
            <?php foreach ($empresarios as $emp): ?>
                <tr>
                    <td><?= $emp['id'] ?></td>
                    <td><?= $emp['representante'] ?></td>
                    <td><?= $emp['empresa'] ?></td>
                    <td><?= $emp['ruc'] ?></td>
                    <td><?= $emp['telefono'] ?></td>
                    <td><?= $emp['direccion'] ?></td>
                    <td><?= $emp['sector'] ?></td>
                    <td><?= $emp['sitio_web'] ?></td>
                    <td><?= $emp['email'] ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</body>
</html>

