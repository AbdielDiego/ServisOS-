<?php
// Define el espacio de nombres del core
namespace App\Core;

/**
 * Clase Database que maneja la conexión a la base de datos
 * Utiliza el patrón Singleton para mantener una única conexión
 */
class Database {

    // Instancia única de la clase
    private static $instance;

    // Conexión PDO
    private $connection;

    /**
     * Constructor privado: se ejecuta solo desde dentro de la clase
     * Configura y crea la conexión PDO a la base de datos
     */
    private function __construct() {
        // Carga la configuración desde el archivo database.php
        $config = require __DIR__ . "/../../config/database.php";

        // Crea el DSN (cadena de conexión) con los datos de configuración
        $dsn = "{$config["driver"]}:host={$config["host"]};dbname={$config["database"]};charset={$config["charset"]}";
        
        try {
            // Intenta establecer una nueva conexión PDO con los datos proporcionados
            $this->connection = new \PDO(
                $dsn,
                $config["username"],
                $config["password"],
                $config["options"] ?? [] // Opciones opcionales
            );
        } catch (\PDOException $e) {
            // Si hay error al conectar, lanza una excepción con mensaje personalizado
            throw new \Exception("Error de conexión a la base de datos: " . $e->getMessage());
        }
    }

    /**
     * Método estático para obtener la instancia única de Database
     * Aplica el patrón Singleton para evitar múltiples conexiones
     */
    public static function getInstance() {
        if (!self::$instance) {
            self::$instance = new self(); // Crea una nueva instancia si no existe
        }
        return self::$instance;
    }

    /**
     * Ejecuta una consulta preparada
     * @param string $sql Consulta SQL con placeholders
     * @param array $params Parámetros asociados a la consulta
     * @return PDOStatement Resultado de la ejecución
     */
    public function query($sql, $params = []) {
        $stmt = $this->connection->prepare($sql); // Prepara la consulta
        $stmt->execute($params);                  // Ejecuta con parámetros
        return $stmt;                             // Devuelve el resultado (PDOStatement)
    }

    /**
     * Devuelve la conexión PDO directamente (si se necesita acceso avanzado)
     */
    public function getPDO() {
        return $this->connection;
    }

    /**
     * Devuelve el ID del último registro insertado
     */
    public function lastInsertId() {
        return $this->connection->lastInsertId();
    }
}

