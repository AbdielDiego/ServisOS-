<?php
// Namespace del core del framework
namespace App\Core;

/**
 * Clase View
 * Maneja la visualización/renderizado de vistas con soporte para layouts
 */
class View {
 
    // Datos compartidos entre vistas
    protected $data = [];
	
    /**
     * Comparte datos con todas las vistas (útil para títulos, usuario actual, etc.)
     * Puede pasar un array completo o clave/valor individuales
     */
    public function share($key, $value = null) {
        // Si el primer parámetro es un array, los fusiona con los datos existentes
        if (is_array($key)) {
            $this->data = array_merge($this->data, $key);
        } else {
            // Si no, agrega el valor como clave única
            $this->data[$key] = $value;
        }
        return $this; // Permite encadenar métodos (opcional)
    }

    /**
     * Renderiza una vista dentro de un layout
     * @param string $viewPath Ruta relativa de la vista (sin .php)
     * @param array $data Datos que se pasarán a la vista
     */
    public function render($viewPath, $data = []) {
        // Extrae las variables del array para que se puedan usar en la vista como $variable
        extract($data);
        
        // Inicia el buffer de salida (captura lo que se imprime)
        ob_start();

        // Construye la ruta del archivo de vista
        $viewFile = __DIR__ . "/../Views/{$viewPath}.php";
        
        // Incluye el archivo de vista (queda guardado en el buffer)
        require $viewFile;

        // Guarda el contenido generado por la vista en una variable
        $content = ob_get_clean();
        
        // Ruta del layout principal (puede usar la variable $content)
        $layoutFile = __DIR__ . "/../Views/layouts/main.php";
        
        // Renderiza el layout con el contenido dentro
        require $layoutFile;
    }
}

