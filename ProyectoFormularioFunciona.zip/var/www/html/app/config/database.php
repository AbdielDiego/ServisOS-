<?php
/**
 * Configuración de la base de datos
 * Cambiar estos valores según tu entorno
 */
return [

    // 🔌 Tipo de base de datos (MySQL, PostgreSQL, etc.)
    "driver" => "mysql",

    // 🌐 Dirección del servidor de base de datos
    "host" => "localhost",

    // 🗄️ Nombre de la base de datos a la que se va a conectar
    "database" => "proyutu",

    // 👤 Usuario con permisos para acceder a la base
    "username" => "proyutu",

    // 🔒 Contraseña del usuario
    "password" => "12345678",

    // 🔤 Codificación de caracteres utilizada
    "charset" => "utf8mb4",

    // ⚙️ Opciones adicionales de PDO (manejo de errores, etc.)
    "options" => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,         // Lanza excepciones si hay errores SQL
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,    // Devuelve resultados como arrays asociativos
        PDO::ATTR_EMULATE_PREPARES => false                  // Usa sentencias preparadas nativas de MySQL
    ]
];

