<?php

// Carga automática de clases y dependencias usando Composer
require(__DIR__.'/../vendor/autoload.php');

// Inicia la sesión para mantener datos entre solicitudes
session_start();


// Las siguientes líneas son comentarios para depuración
// echo $_SERVER['REQUEST_URI']; // Muestra la URL solicitada
// echo " <br> " .session_id(); // Muestra el ID de la sesión actual
// echo "<BR>SESSION ";
// print_r($_SESSION) ."  <br>"; // Muestra el contenido de la sesión


// Definición de rutas disponibles en la aplicación
$route = [
    ["GET", '/', "HomeController@index"], // Ruta principal - método index del HomeController
    ["GET",'/usuarios', "AuthController@index"], // Listar usuarios - método index del AuthController
    ["GET",'/show/id', "AuthController@show"], // Mostrar usuario por id - método show del AuthController
    ["GET",'/save/id/', "AuthController@save"], // Guardar usuario por id - método save del AuthController
    ["POST",'/auth/login', "AuthController@login"], // Login - método login del AuthController
    ["POST",'/auth/logout', "AuthController@logout"], // Logout - método logout del AuthController
    ["POST",'/cliente', "ClientesController@index"], // Ruta clientes - método index del ClientesController
    ["GET", "/servicios", "ServiciosController@index"], // Listar servicios - método index del ServiciosController
    ["GET", "/showservicio/id", "ServiciosController@showServicio"], // Mostrar servicio por id - método showServicio del ServiciosController

   ["POST", "/registro/guardar", "RegistroController@guardarEmpresario"],
   ["GET", "/registro/showRegistro", "RegistroController@showRegistro"],


];
// Busca la ruta correspondiente a la URL solicitada
$datRoute = findRoute( $route, $_SERVER['REQUEST_URI'] );


// Si se encontró un controlador y método para la ruta
if ( !empty ( $datRoute["controlador"] ) ){

    // Crea el nombre completo del controlador incluyendo el namespace
    $control = "App\\Controllers\\". $datRoute["controlador"];

    // Llama al método del controlador pasando los parámetros que se hayan detectado
    call_user_func([new $control(), 
                    $datRoute["metodo"] ], 
                    $datRoute["parametros"]
        );

} else {
    // Si no hay ruta definida para la URL, muestra mensaje de error
    echo "no hay ruta";
}



// Función que busca en el array de rutas la que coincida con la URL solicitada
function findRoute( $routes, $bus ){

    $controlador = "" ;
    $metodo = "" ;
    $parametro = [];

    // Recorre todas las rutas definidas
    foreach($routes as $i => $val){

        // Comprueba si la URL solicitada contiene la ruta definida
        if ( strpos (  $bus , $val[1] ) !== false ){

            // Separa el controlador y método que se deben ejecutar (formato Controlador@metodo)
            $ejecucion = explode('@',$val[2]);

            $controlador = $ejecucion[0]; // Nombre del controlador
            $metodo = $ejecucion[1]; // Nombre del método
            $parametro = []; // Inicializa el array de parámetros vacío

            // Si la ruta no es la principal ('/')
            if ( $bus !== '/' ){

                // Divide la URL solicitada en partes separadas por '/'
                $parmts = explode('/', $bus);

                // Si la URL tiene exactamente 4 partes, se asume que la 3ª es clave y la 4ª valor
                if ( count( $parmts) == 4 ){
                    // Asigna el parámetro para el controlador con la clave y valor extraídos
                    $parametro[$parmts[2]]= $parmts[3];
                }               
            }
        }
    }

    // Retorna el controlador, método y parámetros encontrados
    return ["controlador" => $controlador, "metodo" => $metodo, "parametros" => $parametro];

}


