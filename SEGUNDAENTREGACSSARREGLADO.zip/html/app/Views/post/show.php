<?php
// Normalizar autenticación: revisa tanto $auth como $session
$isAuth = !empty($auth['check'])
  || (isset($session) && is_object($session) && method_exists($session, 'has') && $session->has('auth_user_id'));

// BasePath seguro para URLs
$bp = htmlspecialchars($basePath ?? '', ENT_QUOTES, 'UTF-8');
?>
<!-- Contenido del post -->
<article>
  <h1><?= htmlspecialchars($post['title'] ?? 'Post', ENT_QUOTES, 'UTF-8') ?></h1>
  <p><?= nl2br(htmlspecialchars($post['content'] ?? '', ENT_QUOTES, 'UTF-8')) ?></p>
</article>

<!-- Formulario de comentar -->
<h2 id="comentar">Comentar</h2>
<?php if ($isAuth): ?>
  <!-- Solo visible si el usuario está autenticado -->
  <form action="<?= $bp ?>/comments" method="post">
    <!-- ID del post oculto -->
    <input type="hidden" name="post_id" value="<?= isset($post['post_id']) ? (int)$post['post_id'] : 0 ?>">

    <!-- Texto del comentario -->
    <textarea name="comment_text" rows="3" required minlength="2"></textarea><br>

    <button type="submit">Publicar</button>
  </form>
<?php else: ?>
  <!-- Si no está logueado -->
  <p><a href="<?= $bp ?>/login">Inicia sesión</a> para comentar.</p>
<?php endif; ?>

<!-- Listado de comentarios -->
<h2 id="comentarios">Comentarios</h2>
<?php if (!empty($comments)): ?>
  <ul>
    <?php foreach ($comments as $c): ?>
      <li>
        <!-- Nombre del usuario -->
        <strong><?= htmlspecialchars($c['username'] ?? 'Usuario', ENT_QUOTES, 'UTF-8') ?></strong>
        <!-- Fecha de creación -->
        <small><?= htmlspecialchars($c['created_at'] ?? '', ENT_QUOTES, 'UTF-8') ?></small>
        <!-- Texto del comentario -->
        <p><?= nl2br(htmlspecialchars($c['comment_text'] ?? '', ENT_QUOTES, 'UTF-8')) ?></p>

        <?php if ($isAuth): ?>
          <!-- Aquí se pueden agregar botones extra (ej: editar, eliminar comentario) -->
        <?php endif; ?>
      </li>
    <?php endforeach; ?>
  </ul>
<?php else: ?>
  <!-- Si no existen comentarios -->
  <p>Aún no hay comentarios.</p>
<?php endif; ?>

