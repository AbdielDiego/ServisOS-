<?php
// ========= Tabla genérica con detección de ID de post =========

$datosTabla = $datosTabla ?? [];

if (!empty($datosTabla)) {

    // Columnas
    if (isset($datosTabla[0]) && is_array($datosTabla[0])) {
        $columnas = array_keys($datosTabla[0]);
    } else {
        $columnas  = array_keys((array)$datosTabla);
        $datosTabla = [ $datosTabla ];
    }

    // Base pública (para armar URLs correctas)
    $BASE = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';

    /**
     * Encuentra la mejor columna para usar como ID de post.
     * Reglas:
     *  - Prioriza 'post_id', 'id_post', etc. (post + id)
     *  - Luego 'id' / '*_id'
     *  - Debe ser numérica y variar entre filas (evita valor constante)
     */
    $encontrarColumnaId = function(array $filas, array $cols): ?string {
        if (empty($filas)) return null;

        // Helpers
        $esNumerica = function($v) { return is_numeric($v) && $v !== ''; };

        // Candidatos con score
        $scores = [];
        foreach ($cols as $c) {
            $lc = strtolower($c);
            $score = 0;

            // Scoring por nombre
            if ($lc === 'post_id' || $lc === 'id_post') { $score += 100; }
            if (str_contains($lc, 'post') && str_contains($lc, 'id')) { $score += 80; }
            if ($lc === 'id') { $score += 60; }
            if (str_ends_with($lc, '_id')) { $score += 40; }

            // Validación de valores (numéricos y variados)
            $vals = [];
            $todosNumericos = true;
            foreach ($filas as $f) {
                $v = $f[$c] ?? null;
                if (!$esNumerica($v)) { $todosNumericos = false; break; }
                $vals[] = (string)$v;
            }
            if (!$todosNumericos) continue;

            $distinct = count(array_unique($vals));
            if ($distinct < max(2, (int)floor(count($vals) * 0.5))) {
                // Si casi no varía, descartamos (probablemente constante)
                continue;
            }

            $scores[$c] = $score;
        }

        if (empty($scores)) return null;

        // Elegir el de mayor score
        arsort($scores, SORT_NUMERIC);
        $mejor = array_key_first($scores);
        return $mejor ?: null;
    };

    $colId = $encontrarColumnaId($datosTabla, $columnas);

    // Render
    ?>
    <table class="tabla users-table tabla-compact">
        <thead>
            <tr>
                <?php foreach ($columnas as $col): ?>
                    <th><?= htmlspecialchars($col, ENT_QUOTES, 'UTF-8') ?></th>
                <?php endforeach; ?>
                <?php if ($colId): ?>
                  <th>Acciones</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($datosTabla as $fila): ?>
                <tr>
                    <?php foreach ($columnas as $col): ?>
                        <td><?= htmlspecialchars((string)($fila[$col] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                    <?php endforeach; ?>

                    <?php if ($colId): ?>
                        <?php
                          $idVal = $fila[$colId] ?? null;
                          $id    = is_numeric($idVal) ? (int)$idVal : 0;
                        ?>
                        <td class="td-actions">
                          <?php if ($id > 0): ?>
                            <a class="btn btn-sm" href="<?= $BASE ?>/post/<?= $id ?>#comentar">Comentar</a>
                            <a class="btn btn-sm" href="<?= $BASE ?>/post/<?= $id ?>#comentarios">Ver comentarios</a>
                          <?php else: ?>
                            —
                          <?php endif; ?>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php
} else {
    echo "<h1 class=\"empty-state\">SIN DATOS</h1>";
}

