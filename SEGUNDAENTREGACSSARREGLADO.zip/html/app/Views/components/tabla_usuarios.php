<?php
$datosTabla = $datosTabla ?? [];

if (!empty($datosTabla)) {

    // Columnas
    if (isset($datosTabla[0]) && is_array($datosTabla[0])) {
        $columnas = array_keys($datosTabla[0]);
    } else {
        $columnas  = array_keys((array)$datosTabla);
        $datosTabla = [ $datosTabla ];
    }
    ?>
    <table class="tabla users-table tabla-compact">
        <thead>
            <tr>
                <?php foreach ($columnas as $col): ?>
                    <th><?= htmlspecialchars($col, ENT_QUOTES, 'UTF-8') ?></th>
                <?php endforeach; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($datosTabla as $fila): ?>
                <tr>
                    <?php foreach ($columnas as $col): ?>
                        <td><?= htmlspecialchars((string)($fila[$col] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php
} else {
    echo "<h1 class=\"empty-state\">SIN DATOS</h1>";
}

