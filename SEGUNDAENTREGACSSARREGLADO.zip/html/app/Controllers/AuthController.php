<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Services\AuthService;

class AuthController extends Controller
{
    protected $session;
    protected $auth; // servicio de autenticación

    public function __construct()
    {
        parent::__construct();
        $this->session = new Session();
        $this->auth    = new AuthService($this->session);
    }

    // Mostrar login
    public function showLogin()
    {
        if ($this->auth->check()) {
            return $this->redirect('/dashboard');
        }

        return $this->render('auth/login', [
            'title' => 'Iniciar Sesión'
        ]);
    }

    // Procesar login
    public function login()
    {
        $email    = $this->input('email');
        $password = $this->input('password');

        $errors = $this->validate([
            'email'    => 'required|email',
            'password' => 'required'
        ]);

        if (!empty($errors)) {
            return $this->render('auth/login', [
                'title'  => 'Iniciar Sesión',
                'errors' => $errors,
                'input'  => ['email' => $email]
            ]);
        }

        $user = $this->auth->attempt($email, $password);

        if ($user) {
            $this->session->flash('success', 'Has iniciado sesión correctamente');
            return $this->redirect('/dashboard');
        }

        $this->session->flash('error', 'Credenciales incorrectas');
        return $this->render('auth/login', [
            'title' => 'Iniciar Sesión',
            'input' => ['email' => $email]
        ]);
    }

    // Mostrar registro
    public function showRegister()
    {
        if ($this->auth->check()) {
            return $this->redirect('/dashboard');
        }

        return $this->render('auth/register', [
            'title' => 'Registro de Usuario'
        ]);
    }

    // Procesar registro
    public function register()
    {
        $name             = $this->input('name');
        $email            = $this->input('email');
        $password         = $this->input('password');
        $password_confirm = $this->input('password_confirm');

        // Validación
        $errors = $this->validate([
            'name'             => 'required|min:3',
            'email'            => 'required|email',
            'password'         => 'required|min:4',
            'password_confirm' => 'required|same:password'
        ]);

        // Chequeo duplicados
        if (empty($errors)) {
            $dupeUsername = $this->auth->userExistsByUsername($name);
            $dupeEmail    = $this->auth->userExistsByEmail($email);

            if ($dupeUsername || $dupeEmail) {
                $this->session->flash('error', 'El usuario ya está registrado');
                if ($dupeUsername) { $errors['name']  = 'Este nombre de usuario ya está en uso'; }
                if ($dupeEmail)    { $errors['email'] = 'Este email ya está en uso'; }
            }
        } else {
            if (isset($errors['password_confirm']) && $errors['password_confirm'] === 'Las contraseñas no coinciden') {
                $this->session->flash('error', 'Las contraseñas no coinciden');
            }
        }

        // Si hay errores
        if (!empty($errors)) {
            return $this->render('auth/register', [
                'title'  => 'Registro de Usuario',
                'errors' => $errors,
                'input'  => [
                    'name'  => $name,
                    'email' => $email
                ]
            ]);
        }

        // Crear usuario
        try {
            $userId = $this->auth->register([
                'username' => $name,
                'email'    => $email,
                'password' => $password
            ]);
        } catch (\PDOException $e) {
            // Error UNIQUE
            if ($e->getCode() === '23000') {
                $this->session->flash('error', 'El usuario ya está registrado');

                $errors = [];
                $msg = $e->getMessage();
                if (stripos($msg, "for key 'username'") !== false || stripos($msg, "for key 'uniq_users_username'") !== false) {
                    $errors['name'] = 'Este nombre de usuario ya está en uso';
                }
                if (stripos($msg, "for key 'email'") !== false || stripos($msg, "for key 'uniq_users_email'") !== false) {
                    $errors['email'] = 'Este email ya está en uso';
                }
                if (empty($errors)) {
                    $errors['name']  = 'Este nombre de usuario ya está en uso';
                    $errors['email'] = 'Este email ya está en uso';
                }

                return $this->render('auth/register', [
                    'title'  => 'Registro de Usuario',
                    'errors' => $errors,
                    'input'  => [
                        'name'  => $name,
                        'email' => $email
                    ]
                ]);
            }

            throw $e;
        }

        if ($userId) {
            // Auto-login
            $this->session->set('auth_user_id', $userId);
            $this->session->set('username', $name);

            $this->session->flash('success', 'Te has registrado correctamente');
            return $this->redirect('/dashboard');
        }

        // Fallback
        $this->session->flash('error', 'Error al registrar el usuario');
        return $this->render('auth/register', [
            'title' => 'Registro de Usuario',
            'input' => [
                'name'  => $name,
                'email' => $email
            ]
        ]);
    }

    // Cerrar sesión
    public function logout()
    {
        $this->auth->logout();
        $this->session->flash('success', 'Has cerrado sesión correctamente');
        return $this->redirect('/');
    }
}

