<?php
namespace App\Controllers;

use App\Core\Controller;

class CategoriaController extends Controller
{
    private $pdo; // conexión PDO

    public function __construct()
    {
        parent::__construct();

        // Contenedor con PDO
        if (isset($this->container['db']) && $this->container['db'] instanceof \PDO) {
            $this->pdo = $this->container['db'];
            return;
        }

        // Wrapper Database
        if (class_exists('\App\Core\Database')) {
            $Db = '\App\Core\Database';

            if (method_exists($Db, 'getInstance')) {
                $inst = $Db::getInstance();
                if ($inst instanceof $Db) {
                    if (method_exists($inst, 'getConnection') && $inst->getConnection() instanceof \PDO) {
                        $this->pdo = $inst->getConnection();
                        return;
                    }
                    if (property_exists($inst, 'pdo') && $inst->pdo instanceof \PDO) {
                        $this->pdo = $inst->pdo;
                        return;
                    }
                }
            }

            if (method_exists($Db, 'getConnection') && $Db::getConnection() instanceof \PDO) {
                $this->pdo = $Db::getConnection();
                return;
            }

            if (property_exists($Db, 'pdo') && $Db::$pdo instanceof \PDO) {
                $this->pdo = $Db::$pdo;
                return;
            }
        }

        // Config fallback
        $cfgPath = defined('BASE_PATH')
            ? BASE_PATH . '/config/database.php'
            : __DIR__ . '/../../config/database.php';

        $cfg = require $cfgPath;

        $driver  = $cfg['driver']   ?? 'mysql';
        $host    = $cfg['host']     ?? 'localhost';
        $db      = $cfg['database'] ?? '';
        $user    = $cfg['username'] ?? '';
        $pass    = $cfg['password'] ?? '';
        $charset = $cfg['charset']  ?? 'utf8mb4';
        $options = $cfg['options']  ?? [
            \PDO::ATTR_ERRMODE            => \PDO::ERRMODE_EXCEPTION,
            \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
            \PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        $dsn = sprintf('%s:host=%s;dbname=%s;charset=%s', $driver, $host, $db, $charset);
        $this->pdo = new \PDO($dsn, $user, $pass, $options);
    }

    // GET /categoria/:id
    public function show($id): void
    {
        $catId = (int)$id;
        if ($catId <= 0) {
            $this->render('errors/404', ['title' => 'No encontrado']);
            return;
        }

        // Categoría
        $q = $this->pdo->prepare('SELECT * FROM Categories WHERE category_id = ? LIMIT 1');
        $q->execute([$catId]);
        $categoria = $q->fetch();
        if (!$categoria) {
            $this->render('errors/404', ['title' => 'Categoría no encontrada']);
            return;
        }

        // Posts con conteo de comentarios
        $p = $this->pdo->prepare('
            SELECT p.*,
                   (SELECT COUNT(*) FROM Comments c WHERE c.post_id = p.post_id) AS comments_count
            FROM Posts p
            WHERE p.category_id = ?
            ORDER BY p.created_at DESC
        ');
        $p->execute([$catId]);
        $posts = $p->fetchAll();

        // basePath
        $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
        $basePath   = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
        if ($basePath === '.' || $basePath === '/') { $basePath = ''; }

        $this->render('categoria/show', [
            'title'     => 'Categoría: ' . ($categoria['name'] ?? 'Sin nombre'),
            'categoria' => $categoria,
            'posts'     => $posts,
            'basePath'  => $basePath,
        ]);
    }

    // POST /categoria/:id/comentarios
    public function storeComment($id): void
    {
        $catId  = (int)$id;
        $postId = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;
        $text   = trim($_POST['comment_text'] ?? '');
        $userId = $_SESSION['user']['user_id'] ?? null;

        if ($catId <= 0 || $postId <= 0 || $text === '') {
            $_SESSION['flash_error'][] = 'Datos incompletos.';
            $this->redirect("/categoria/{$catId}#comentar");
            return;
        }

        // Validar pertenencia del post
        $chk = $this->pdo->prepare('SELECT 1 FROM Posts WHERE post_id=? AND category_id=?');
        $chk->execute([$postId, $catId]);
        if (!$chk->fetchColumn()) {
            $_SESSION['flash_error'][] = 'El post no pertenece a esta categoría.';
            $this->redirect("/categoria/{$catId}");
            return;
        }

        $ins = $this->pdo->prepare('INSERT INTO Comments (post_id, user_id, comment_text) VALUES (?,?,?)');
        $ins->execute([$postId, $userId, $text]);

        $_SESSION['flash_success'][] = 'Comentario publicado.';
        $this->redirect("/categoria/{$catId}#comentarios");
    }
}



