<?php
namespace App\Core;

/**
 * Clase Database
 * Implementa un patrón Singleton para manejar la conexión PDO.
 */
class Database {
    private static $instance;   // instancia única
    private $connection;        // conexión PDO

    /**
     * Constructor privado: inicializa la conexión
     */
    private function __construct() {
        // Cargar configuración desde config/database.php
        $config = require BASE_PATH . "/config/database.php";

        // Construir DSN
        $dsn = "{$config["driver"]}:host={$config["host"]};dbname={$config["database"]};charset={$config["charset"]}";
        
        try {
            // Crear conexión PDO
            $this->connection = new \PDO(
                $dsn,
                $config["username"],
                $config["password"],
                $config["options"] ?? []
            );
        } catch (\PDOException $e) {
            throw new \Exception("Error de conexión a la base de datos: " . $e->getMessage());
        }
    }

    /**
     * Retorna la única instancia (Singleton)
     */
    public static function getInstance() {
        if (!self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Ejecuta una consulta preparada
     */
    public function query($sql, $params = []) {
        $stmt = $this->connection->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
    
    /**
     * Devuelve el último ID insertado
     */
    public function lastInsertId() {
        return $this->connection->lastInsertId();
    }
}

