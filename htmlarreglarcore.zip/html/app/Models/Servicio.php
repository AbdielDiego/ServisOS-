<?php
namespace App\Models;

use App\Core\Model;

class Servicio extends Model {
    protected $table = 'servicios';
    protected $primaryKey = 'id_servicio';

    public function getAll() {
        $sql = "SELECT * FROM {$this->table} ORDER BY id_servicio DESC";
        return $this->query($sql)->fetchAll();
    }

    public function getById($id) {
        $sql = "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = :id";
        return $this->query($sql, ['id' => $id])->fetch();
    }

    public function createServicio($data) {
        $sql = "INSERT INTO {$this->table} (nombre_servicio, descripcion_servicio, precio_servicio, fecha_creacion) 
                VALUES (:nombre, :descripcion, :precio, NOW())";
        return $this->query($sql, [
            'nombre'      => $data['nombre_servicio'],
            'descripcion' => $data['descripcion_servicio'],
            'precio'      => $data['precio_servicio']
        ]);
    }

    public function updateServicio($id, $data) {
        $sql = "UPDATE {$this->table} SET 
                    nombre_servicio = :nombre, 
                    descripcion_servicio = :descripcion, 
                    precio_servicio = :precio
                WHERE {$this->primaryKey} = :id";
        return $this->query($sql, [
            'nombre'      => $data['nombre_servicio'],
            'descripcion' => $data['descripcion_servicio'],
            'precio'      => $data['precio_servicio'],
            'id'          => $id
        ]);
    }

    public function deleteServicio($id) {
        $sql = "DELETE FROM {$this->table} WHERE {$this->primaryKey} = :id";
        return $this->query($sql, ['id' => $id]);
    }
}

