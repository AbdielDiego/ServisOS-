 <link rel="stylesheet" href="css/homepage.css">


<?php


echo '
       <div class="container">
        <h1>Servicios</h1>
        <p>Aca puedes encontrar todos los servicios </p>

        <h2></h2>
        <label for="portinput">Dato a enviar por POST:</label>
        <input type="text" id="postInput" value= >
        <button id="fetchPostData" class="post">Enviar Datos (POST)</button>
        <div id="postResult" class="result-box">Esperando datos POST... ' ;

echo "<h2>$titulo</h2>";    

require BASE_PATH ."/app/Views/components/tabla.php"; 

echo '</div>
	</div>

    <script src="js/api.js"></script>';

