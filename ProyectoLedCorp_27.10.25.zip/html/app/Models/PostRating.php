<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;

class PostRating
{
    private PDO $pdo;

    public function __construct(?PDO $pdo = null)
    {
        $this->pdo = $pdo ?: Database::getConnection();
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }

    public function getUserRating(int $postId, int $userId): ?int
    {
        $st = $this->pdo->prepare('SELECT rating FROM post_ratings WHERE post_id=? AND user_id=?');
        $st->execute([$postId, $userId]);
        $row = $st->fetch();
        return $row ? (int)$row['rating'] : null;
    }

    public function stats(int $postId): array
    {
        $st = $this->pdo->prepare('SELECT ROUND(AVG(rating),2) AS avg, COUNT(*) AS cnt FROM post_ratings WHERE post_id=?');
        $st->execute([$postId]);
        $row = $st->fetch() ?: ['avg'=>null, 'cnt'=>0];
        return [
            'avg'   => $row['avg'] !== null ? (float)$row['avg'] : 0.0,
            'count' => (int)$row['cnt'],
        ];
    }

    public function save(int $postId, int $userId, int $rating): void
    {
        $rating = max(1, min(5, $rating));
        $sql = 'INSERT INTO post_ratings (post_id, user_id, rating)
                VALUES (:p,:u,:r)
                ON DUPLICATE KEY UPDATE rating=VALUES(rating), updated_at=CURRENT_TIMESTAMP()';
        $st = $this->pdo->prepare($sql);
        $st->execute([':p'=>$postId, ':u'=>$userId, ':r'=>$rating]);
    }
}

