<?php
/** @var array $flashes */
if (!empty($flashes)):
    foreach ($flashes as $f):
        $type = htmlspecialchars($f['type'] ?? 'info', ENT_QUOTES, 'UTF-8');
        $msg  = htmlspecialchars($f['message'] ?? '', ENT_QUOTES, 'UTF-8');
?>
    <div class="alert alert-<?= $type ?>" role="alert" style="margin: 12px 0;">
        <?= $msg ?>
    </div>
<?php
    endforeach;
endif;

