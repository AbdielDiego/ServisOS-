<?php
// ---------- helpers ----------
if (!function_exists('esc')) {
    function esc(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
}
$toLower = function($s){ return function_exists('mb_strtolower') ? mb_strtolower((string)$s, 'UTF-8') : strtolower((string)$s); };


$BASE = $BASE ?? ''; 
$baseHref = rtrim((string)$BASE, '/');

// ---------- datos de entrada ----------
$datosTabla = $datosTabla ?? []; // puede venir vacío

// Normalizamos $datosTabla y detectamos columnas
if (!empty($datosTabla)) {
    if (isset($datosTabla[0]) && is_array($datosTabla[0])) {
        $columnas = array_keys($datosTabla[0]);
    } else {
        $columnas   = array_keys((array)$datosTabla);
        $datosTabla = [ $datosTabla ];
    }
} else {
    $columnas = []; // sin datos
}

// ---------- detectar campo ID para acciones ----------
$idKey = null;
foreach (['user_id','id','UserId','ID','userid'] as $k) {
    if (in_array($k, $columnas, true)) { $idKey = $k; break; }
}
$showActions = $idKey !== null;

// ---------- filtros por GET (solo PHP) ----------
$qUserRaw  = trim((string)($_GET['username'] ?? ''));
$qEmailRaw = trim((string)($_GET['email']    ?? ''));

// Limite de longitud por prolijidad (opcional)
if (strlen($qUserRaw)  > 100) $qUserRaw  = substr($qUserRaw,  0, 100);
if (strlen($qEmailRaw) > 100) $qEmailRaw = substr($qEmailRaw, 0, 100);

// Claves en minúsculas para comparar
$qUser  = $toLower($qUserRaw);
$qEmail = $toLower($qEmailRaw);

// Aplicamos filtro server-side
$filtrados = $datosTabla;
if ($qUser !== '' || $qEmail !== '') {
    $filtrados = array_values(array_filter($datosTabla, function($fila) use ($qUser, $qEmail, $toLower) {
        $u = $toLower($fila['username'] ?? '');
        $e = $toLower($fila['email']    ?? '');
        $okU = ($qUser  === '') || (strpos($u, $qUser)  !== false);
        $okE = ($qEmail === '') || (strpos($e, $qEmail) !== false);
        return $okU && $okE;
    }));
}

// Para el botón "Limpiar" sacamos la query de la URL actual
$baseUrl = strtok((string)($_SERVER['REQUEST_URI'] ?? ''), '?');
?>

<!-- Barra de búsqueda (solo PHP) -->
<form class="table-toolbar" method="get" action="">
    <div class="toolbar-row">
        <input type="search" name="username" value="<?= esc($qUserRaw) ?>" placeholder="Buscar por usuario…" autocomplete="off">
        <input type="search" name="email"    value="<?= esc($qEmailRaw) ?>" placeholder="Buscar por email…"   autocomplete="off">
        <button type="submit" class="btn btn-primary">Buscar</button>
        <a class="btn btn-muted" href="<?= esc($baseUrl) ?>">Limpiar</a>
        <span class="result-count">Resultados: <?= count($filtrados) ?></span>
    </div>
</form>

<?php if (!empty($columnas)): ?>
    <table class="tabla users-table tabla-compact">
        <thead>
            <tr>
                <?php foreach ($columnas as $col): ?>
                    <th><?= esc($col) ?></th>
                <?php endforeach; ?>
                <?php if ($showActions): ?>
                    <th class="th-actions">acciones</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($filtrados)): ?>
                <tr><td colspan="<?= count($columnas) + ($showActions ? 1 : 0) ?>">Sin coincidencias…</td></tr>
            <?php else: ?>
                <?php foreach ($filtrados as $fila): ?>
                    <?php $rowId = $fila[$idKey] ?? null; ?>
                    <tr>
                        <?php foreach ($columnas as $col): ?>
                            <td><?= esc((string)($fila[$col] ?? '')) ?></td>
                        <?php endforeach; ?>

                        <?php if ($showActions && $rowId !== null): ?>
                            <td class="td-actions">
                                <!-- Mini menú sin JS: <details>/<summary> -->
                                <details class="row-actions">
                                    <summary title="Acciones">⋮</summary>
                                    <div class="row-actions-menu">
                                        <a class="action-ban"
                                           href="<?= esc(($baseHref ? $baseHref : '') . '/ban.php?id=' . urlencode((string)$rowId)) ?>">
                                           Banear
                                        </a>
                                        <a class="action-del"
                                           href="<?= esc(($baseHref ? $baseHref : '') . '/deleteuser.php?id=' . urlencode((string)$rowId)) ?>">
                                           Eliminar
                                        </a>
                                    </div>
                                </details>
                            </td>
                        <?php elseif ($showActions): ?>
                            <td class="td-actions"><em>—</em></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
<?php else: ?>
    <h1 class="empty-state">SIN DATOS</h1>
<?php endif; ?>

