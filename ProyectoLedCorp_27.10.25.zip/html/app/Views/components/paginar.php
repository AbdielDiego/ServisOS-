<?php


// 1) Incluir la tabla (si existe)
$__tabla = __DIR__ . '/tabla.php';
if (is_file($__tabla)) {
    require $__tabla;
}

// 2) Normalizar variables esperadas por la paginación
//    Acepta $paginaActual o $pagina como alias.
$paginaActual = isset($paginaActual)
    ? (int)$paginaActual
    : (isset($pagina) ? (int)$pagina : 1);

$totalPaginas = isset($totalPaginas) ? (int)$totalPaginas : 1;
$baseUrl      = isset($baseUrl) ? (string)$baseUrl : '';

// Limites defensivos
if ($totalPaginas < 1) $totalPaginas = 1;
if ($paginaActual < 1) $paginaActual = 1;
if ($paginaActual > $totalPaginas) $paginaActual = $totalPaginas;
?>

<?php if ($totalPaginas > 1): ?>
<nav class="paginacion">
    <ul style="display:flex;gap:.5rem;list-style:none;padding:0;margin:1rem 0;">
        <?php if ($paginaActual > 1): ?>
            <li><a href="<?= htmlspecialchars($baseUrl, ENT_QUOTES) ?>/<?= $paginaActual - 1 ?>">« Anterior</a></li>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
            <?php if ($i === $paginaActual): ?>
                <li><strong><?= $i ?></strong></li>
            <?php else: ?>
                <li><a href="<?= htmlspecialchars($baseUrl, ENT_QUOTES) ?>/<?= $i ?>"><?= $i ?></a></li>
            <?php endif; ?>
        <?php endfor; ?>

        <?php if ($paginaActual < $totalPaginas): ?>
            <li><a href="<?= htmlspecialchars($baseUrl, ENT_QUOTES) ?>/<?= $paginaActual + 1 ?>">Siguiente »</a></li>
        <?php endif; ?>
    </ul>
</nav>
<?php endif; ?>




