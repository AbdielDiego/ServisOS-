<?php
declare(strict_types=1);

/**
 * Componente de puntaje por estrellas 1..5 (PHP puro, sin JS)
 * Uso:  require_once __DIR__ . '/../components/scoring_system.php';
 *       render_star_rating($postId);
 */

use App\Core\Database;
use App\Models\PostRating;

if (!function_exists('ss_current_user_id_for_view')) {
    function ss_current_user_id_for_view(): int {
        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }
        if (!empty($_SESSION['auth']['user']) && is_array($_SESSION['auth']['user'])) {
            $u = $_SESSION['auth']['user']; $id = (int)($u['user_id'] ?? $u['id'] ?? 0); return $id>0?$id:0;
        }
        if (!empty($_SESSION['user']) && is_array($_SESSION['user'])) {
            $u = $_SESSION['user']; $id = (int)($u['user_id'] ?? $u['id'] ?? 0); return $id>0?$id:0;
        }
        if (!empty($_SESSION['user_id'])) return (int)$_SESSION['user_id'];
        return 0;
    }
}

if (!function_exists('render_star_rating')) {
    function render_star_rating(int $postId, array $opts = []): void
    {
        $pdo   = Database::getConnection();
        $model = new PostRating($pdo);

        $uid        = ss_current_user_id_for_view();
        $userRating = $uid > 0 ? $model->getUserRating($postId, $uid) : null;
        $stat       = $model->stats($postId);
        $avg        = $stat['avg'];
        $count      = $stat['count'];
        $active     = $userRating ?? (int)round($avg);
        $disabled   = ($uid <= 0);
        $returnTo   = $_SERVER['REQUEST_URI'] ?? '/post';

        ?>
        <form class="starbox star-form" action="/rating" method="post">
            <input type="hidden" name="post_id" value="<?= (int)$postId ?>">
            <input type="hidden" name="return"  value="<?= htmlspecialchars($returnTo, ENT_QUOTES, 'UTF-8') ?>">

            <div class="stars" role="radiogroup" aria-label="Puntaje por estrellas">
                <?php for ($i=1; $i<=5; $i++): ?>
                    <button
                        type="submit"
                        name="rating"
                        value="<?= $i ?>"
                        class="star<?= $i <= $active ? ' is-filled' : '' ?><?= $disabled ? ' is-disabled' : '' ?>"
                        aria-label="<?= $i ?> estrella<?= $i>1?'s':'' ?>"
                        <?= $disabled ? 'disabled' : '' ?>>★</button>
                <?php endfor; ?>
            </div>

            <div class="rating-summary">
                <span class="avg" title="Promedio"><?= number_format($avg, 1, ',', '.') ?></span>
                <span class="sep">•</span>
                <span class="count" title="Cantidad de votos"><?= (int)$count ?> voto<?= $count===1?'':'s' ?></span>
                <?php if ($userRating !== null): ?>
                    <span class="sep">•</span>
                    <span class="yours" title="Tu voto">Tu voto: <?= (int)$userRating ?>/5</span>
                <?php elseif ($disabled): ?>
                    <span class="sep">•</span>
                    <a class="login-hint" href="/login?next=<?= urlencode($returnTo) ?>">Inicia sesión para votar</a>
                <?php endif; ?>
            </div>
        </form>
        <?php
    }
}

