<?php
// Título en el layout (si lo usas)

$titulo = $titulo ?? 'Usuarios baneados';
?>
 <a href="/" class="<?= ($currentUrl === '/' || $currentUrl === '') ? 'active' : '' ?>">Inicio</a>
 <a href="/usuarios" class="<?= ($currentUrl === '/' || $currentUrl === '') ? 'active' : '' ?>">Ir atras</a>
<h1 style="margin: 20px 0; font-weight: 800;">Usuarios baneados</h1>

<?php
// Variables que llegan del render:
$BASE       = $BASE       ?? '';
$datosTabla = $datosTabla ?? [];

// Incluye la tabla (misma carpeta)
require __DIR__ . '/BanUsersTable.php';

