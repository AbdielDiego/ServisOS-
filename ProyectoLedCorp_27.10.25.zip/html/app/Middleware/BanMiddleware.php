<?php
namespace App\Middleware;

use App\Support\Flash;

class BanMiddleware
{
    public function handle(callable $next)
    {
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();

        $user = $_SESSION['user'] ?? null;
        $isBanned = false;

        if (is_array($user)) {
            // Abarcamos nombres de campo comunes: is_banned | banned | ban | status
            $isBanned = (int)($user['is_banned'] ?? $user['banned'] ?? $user['ban'] ?? 0) === 1
                        || (isset($user['status']) && strtolower((string)$user['status']) === 'banned');
        }

        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

        if ($isBanned && $uri !== '/login') {
            // Cerrar sesión y avisar SOLO en /login
            unset($_SESSION['user']);
            Flash::set('danger', 'Usted está baneado, comuníquese con el equipo técnico de ChivitaRecomienda');
            header('Location: /login', true, 302);
            exit;
        }

        return $next();
    }
}

