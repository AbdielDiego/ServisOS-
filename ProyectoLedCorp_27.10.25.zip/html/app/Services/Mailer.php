<?php
namespace App\Services;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;
use PHPMailer\PHPMailer\SMTP;

class Mailer
{
    /**
     * Envío de correo HTML.
     * - Usa .env con fallbacks seguros
     * - Charset UTF-8, AltBody plano
     * - Valida email destino
     * - Soporta TLS/SSL según SMTP_SECURE o puerto
     */
    public static function send(string $to, string $subject, string $html): bool
    {
        // 0) Verificación de librería instalada
        if (!class_exists(PHPMailer::class)) {
            error_log('[Mailer] PHPMailer no está instalado. Ejecuta: composer require phpmailer/phpmailer');
            return false;
        }

        // 1) Validar email de destino
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            error_log('[Mailer] Email inválido: ' . $to);
            return false;
        }

        // 2) Cargar variables de entorno con fallback a getenv()
        $env = static fn($k, $def = null) => $_ENV[$k] ?? getenv($k) ?? $def;

        $host      = $env('SMTP_HOST', 'localhost');
        $port      = (int)$env('SMTP_PORT', 587);
        $user      = (string)$env('SMTP_USER', '');
        $pass      = (string)$env('SMTP_PASS', '');
        $fromEmail = (string)$env('MAIL_FROM', 'no-reply@example.com');
        $fromName  = (string)$env('MAIL_NAME', 'Chivita Recomienda');
        $secure    = (string)$env('SMTP_SECURE', 'tls'); // 'tls' | 'ssl' | ''
        $debug     = (int)$env('SMTP_DEBUG', 0);         // 0=off, 2=client/server msgs
        $timeout   = (int)$env('SMTP_TIMEOUT', 10);      // segundos
        $replyTo   = (string)$env('MAIL_REPLY_TO', '');  // opcional

        // Si no se configuró SMTP_SECURE, inferir por puerto
        if ($secure === '' || $secure === null) {
            if ($port === 465) $secure = PHPMailer::ENCRYPTION_SMTPS; // ssl implícito
            else               $secure = PHPMailer::ENCRYPTION_STARTTLS;
        } else {
            // Normalizar valores comunes
            if (in_array(strtolower($secure), ['ssl','smtps'], true)) {
                $secure = PHPMailer::ENCRYPTION_SMTPS;
            } else {
                $secure = PHPMailer::ENCRYPTION_STARTTLS;
            }
        }

        $mail = new PHPMailer(true);

        try {
            // 3) Config SMTP
            $mail->SMTPDebug  = $debug;           // cuidado en producción
            $mail->Timeout    = $timeout;
            $mail->CharSet    = 'UTF-8';
            $mail->isSMTP();
            $mail->Host       = $host;
            $mail->SMTPAuth   = ($user !== '' || $pass !== '');
            $mail->Username   = $user;
            $mail->Password   = $pass;
            $mail->SMTPSecure = $secure;
            $mail->Port       = $port;

            // 4) Remitente y destinatarios
            // Validar remitente; si es inválido, usar fallback
            if (!filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
                $fromEmail = 'no-reply@example.com';
            }
            $mail->setFrom($fromEmail, $fromName);
            $mail->addAddress($to);

            if ($replyTo && filter_var($replyTo, FILTER_VALIDATE_EMAIL)) {
                $mail->addReplyTo($replyTo, $fromName);
            }

            // 5) Contenido
            $mail->isHTML(true);
            $mail->Subject = $subject;
            // Sanitizar mínimamente AltBody (texto plano)
            $plain = trim(html_entity_decode(strip_tags($html), ENT_QUOTES, 'UTF-8'));
            $mail->AltBody = $plain !== '' ? $plain : ' ';

            // Si te llega texto sin <p> ni <br>, respetar saltos con nl2br (ya venías haciéndolo)
            // Si ya viene con HTML armado, no tocar:
            $mail->Body = (strpos($html, '<') === false) ? nl2br($html) : $html;

            // 6) Enviar
            return $mail->send();
        } catch (PHPMailerException $e) {
            // Log detallado incluyendo ErrorInfo
            error_log('[Mailer PHPMailerException] ' . $e->getMessage());
            error_log('[Mailer ErrorInfo] ' . $mail->ErrorInfo);
            return false;
        } catch (\Throwable $e) {
            error_log('[Mailer Throwable] ' . $e->getMessage());
            return false;
        }
    }
}

