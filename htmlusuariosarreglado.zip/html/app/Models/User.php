<?php
namespace App\Models;

use App\Core\Model;

class User extends Model {
    protected $table = 'Users';
    protected $primaryKey = "user_id";

    public function findByEmail($email) {
        $query = $this->db->query(
            "SELECT * FROM {$this->table} WHERE email = ? LIMIT 1", 
            [$email]
        );
        return $query->fetch(\PDO::FETCH_ASSOC);
    }

    /**
     * Devuelve todos los usuarios de la tabla Users.
     */
    public function all(): array {
        $sql = "SELECT * FROM {$this->table}";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * Ejecuta una consulta SQL cruda y devuelve todas las filas.
     * Útil para listados con filtros o joins.
     */
    public function executeRawQuery(string $sql, array $params = []): array {
        $stmt = $this->db->query($sql, $params);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
}

