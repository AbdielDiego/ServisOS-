<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Services\AuthService;

class AuthController extends Controller
{
    protected $session;
    protected $auth; // AuthService (no confundir con App\Core\Auth)

    public function __construct()
    {
        parent::__construct();
        $this->session = new Session();
        $this->auth    = new AuthService($this->session);
    }

    public function showLogin()
    {
        if ($this->auth->check()) {
            return $this->redirect('/dashboard');
        }

        return $this->render('auth/login', [
            'title' => 'Iniciar Sesión'
        ]);
    }

    public function login()
    {
        $email    = $this->input('email');
        $password = $this->input('password');

        $errors = $this->validate([
            'email'    => 'required|email',
            'password' => 'required'
        ]);

        if (!empty($errors)) {
            return $this->render('auth/login', [
                'title'  => 'Iniciar Sesión',
                'errors' => $errors,
                'input'  => ['email' => $email]
            ]);
        }

        // ⬇️ Ahora attempt() devuelve el usuario y setea la sesión canónica
        $user = $this->auth->attempt($email, $password);

        if ($user) {
            $this->session->flash('success', 'Has iniciado sesión correctamente');
            return $this->redirect('/dashboard');
        }

        $this->session->flash('error', 'Credenciales incorrectas');
        return $this->render('auth/login', [
            'title' => 'Iniciar Sesión',
            'input' => ['email' => $email]
        ]);
    }

    public function showRegister()
    {
        if ($this->auth->check()) {
            return $this->redirect('/dashboard');
        }

        return $this->render('auth/register', [
            'title' => 'Registro de Usuario'
        ]);
    }

    public function register()
    {
        $name              = $this->input('name');
        $email             = $this->input('email');
        $password          = $this->input('password');
        $password_confirm  = $this->input('password_confirm');

        $errors = $this->validate([
            'name'             => 'required|min:3',
            'email'            => 'required|email',
            'password'         => 'required|min:4',
            'password_confirm' => 'required|same:password'
        ]);

        if (!empty($errors)) {
            return $this->render('auth/register', [
                'title'  => 'Registro de Usuario',
                'errors' => $errors,
                'input'  => [
                    'name'  => $name,
                    'email' => $email
                ]
            ]);
        }

        // Crear usuario
        $userId = $this->auth->register([
            'username' => $name,   // normalizado en el servicio
            'email'    => $email,
            'password' => $password
        ]);

        if ($userId) {
            // 🔒 Auto-login inmediato y consistente con toda la app:
            // usamos la misma clave canónica que check() y el middleware.
            $this->session->set('auth_user_id', $userId);

            // (Opcional) guardar para UI
            $this->session->set('username', $name);

            $this->session->flash('success', 'Te has registrado correctamente');
            return $this->redirect('/dashboard');
        }

        $this->session->flash('error', 'Error al registrar el usuario');
        return $this->render('auth/register', [
            'title' => 'Registro de Usuario',
            'input' => [
                'name'  => $name,
                'email' => $email
            ]
        ]);
    }

    public function logout()
    {
        $this->auth->logout();
        $this->session->flash('success', 'Has cerrado sesión correctamente');
        return $this->redirect('/');
    }
}

