function creaHtml($datos, $titulo, $link = '' ){
	$script = "<script src='script.js'></script>";
	$html = "
		<html>
			<head>
			</head>

			<body>
				<h1>$titulo</h1>
				$datos
				$link

			$script
			</body>

		</html>";

return  $html;
}

     



require_once('Model.php');
require_once('View.php');







































































































                    
                                                  
                   
            
          
                      
   


