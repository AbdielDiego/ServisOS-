<!-- nombre_tabla.php -->
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Tabla de Nombres con PHP</title>
  <style>
    table, th, td {
      border: 1px solid black;
      border-collapse: collapse;
      padding: 8px;
    }
  </style>
</head>
<body>

  <h2>Ingrese un nombre</h2>
  <form method="POST">
    <input type="text" name="nombre" required>
    <button type="submit">Agregar</button>
  </form>

  <?php
  // Arreglo para guardar nombres temporalmente
  $nombres = [];

  // Si se ha enviado un nombre por POST
  if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["nombre"])) {
    $nombres[] = htmlspecialchars($_POST["nombre"]);
  }

  if (!empty($nombres)) {
    echo "<h2>Tabla de Nombres</h2>";
    echo "<table>";
    echo "<tr><th>Nombre</th></tr>";

    foreach ($nombres as $nombre) {
      echo "<tr><td>$nombre</td></tr>";
    }

    echo "</table>";
  }
  ?>

</body>
</html>

