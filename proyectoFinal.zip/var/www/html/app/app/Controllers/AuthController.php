<?php
namespace App\Controllers;

// Importa clases necesarias del core y modelos
use App\Core\Controller;
use App\Models\User;
use App\Services\AuthService;
use App\Core\Session;

class AuthController extends Controller {

    // Constructor que inicializa servicios de autenticación y sesión
    public function __construct() {
        parent::__construct();
        $this->auth = new AuthService();
        $this->session = new Session();
    }

    // Muestra la vista de login si no está logueado, si lo está redirige al dashboard
    public function showLogin() {
        if ($this->auth && $this->auth->check()) {
            $this->redirect('/dashboard');
        }

        return $this->render('auth/login', [
            'title' => 'Iniciar Sesión'
        ]);
    }

    // Procesa el intento de login
    public function login() {
        $email = $this->input('email');             // Obtiene email del formulario
        $password = $this->input('password');       // Obtiene password del formulario

        // Valida campos requeridos
        $errors = $this->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        // Si hay errores de validación, los muestra
        if (!empty($errors)) {
            return $this->render('auth/login', [
                'title' => 'Iniciar Sesión',
                'errors' => $errors,
                'input' => ['email' => $email]
            ]);
        }

        // Si las credenciales son válidas, inicia sesión y redirige al dashboard
        if ($this->auth && $this->auth->attempt($email, $password)) {
            $this->session->flash('success', 'Has iniciado sesión correctamente');
            $this->redirect('/dashboard');
        }

        // Si fallan las credenciales, muestra mensaje de error
        $this->session->flash('error', 'Credenciales incorrectas');
        return $this->render('auth/login', [
            'title' => 'Iniciar Sesión',
            'input' => ['email' => $email]
        ]);
    }

    // Muestra el formulario de registro
    public function showRegister() {
        if ($this->auth && $this->auth->check()) {
            $this->redirect('/dashboard');
        }

        return $this->render('auth/register', [
            'title' => 'Registro de Usuario'
        ]);
    }

    // Procesa el registro de un nuevo usuario
    public function register() {
        $name = $this->input('name');                       // Captura nombre
        $email = $this->input('email');                     // Captura email
        $password = $this->input('password');               // Captura contraseña
        $passwordConfirm = $this->input('password_confirm');// Captura confirmación

        // Valida campos
        $errors = $this->validate([
            'name' => 'required|min:3',
            'email' => 'required|email',
            'password' => 'required|min:4'
        ]);

        // Verifica que las contraseñas coincidan
        if ($password !== $passwordConfirm) {
            $errors['password_confirm'] = 'Las contraseñas no coinciden';
        }

        // Verifica que el email no esté ya registrado
        $user = (new User())->findByEmail($email);
        if ($user) {
            $errors['email'] = 'Este email ya está registrado';
        }

        // Si hay errores, vuelve a la vista con los errores
        if (!empty($errors)) {
            return $this->render('auth/register', [
                'title' => 'Registro de Usuario',
                'errors' => $errors,
                'input' => [
                    'name' => $name,
                    'email' => $email
                ]
            ]);
        }

        // Registra al usuario y lo intenta loguear automáticamente
        $userId = $this->auth->register([
            'name' => $name,
            'email' => $email,
            'password' => $password,
            'role' => 'user'
        ]);

        // Si el registro fue exitoso, inicia sesión y redirige
        if ($userId) {
            $this->auth->attempt($email, $password);
            $this->session->flash('success', 'Te has registrado correctamente');
            $this->redirect('/dashboard');
        }

        // Si algo falla, muestra mensaje de error
        $this->session->flash('error', 'Error al registrar el usuario');
        return $this->render('auth/register', [
            'title' => 'Registro de Usuario',
            'input' => [
                'name' => $name,
                'email' => $email
            ]
        ]);
    }

    // Cierra sesión del usuario
    public function logout() {
        if ($this->auth) {
            $this->auth->logout();
        }
        $this->session->flash('success', 'Has cerrado sesión correctamente');
        $this->redirect('/');
    }
}

