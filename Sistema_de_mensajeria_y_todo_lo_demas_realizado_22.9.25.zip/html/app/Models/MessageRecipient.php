<?php
namespace App\Models;

use App\Core\Database;
use PDO;

class MessageRecipient
{
    private const T_MR = 'message_recipients'; // destinatarios
    private const T_M  = 'messages';           // mensajes
    private const T_U  = 'Users';              // usuarios

    /**
     * Bandeja para usuario (trae el cuerpo como 'body' y la fecha como 'created_at').
     */
    public static function findInboxForUser(int $userId, int $limit = 200): array
    {
        $pdo = Database::getConnection();
        $sql = "
            SELECT
                mr.message_id,
                mr.is_read,
                m.created_at AS created_at,         
                m.subject,
                m.body       AS body,               
                u.username   AS from_username,
                u.email      AS from_email
            FROM ".self::T_MR." mr
            INNER JOIN ".self::T_M." m
                ON m.id = mr.message_id
            INNER JOIN ".self::T_U." u
                ON u.user_id = m.sender_id
            WHERE mr.recipient_id = :uid
            ORDER BY m.created_at DESC
            LIMIT :lim
        ";
        $st = $pdo->prepare($sql);
        $st->bindValue(':uid', $userId, PDO::PARAM_INT);
        $st->bindValue(':lim', $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Bandeja para admin (ve todo).
     */
    public static function findInboxForAdmin(int $limit = 200): array
    {
        $pdo = Database::getConnection();
        $sql = "
            SELECT
                mr.message_id,
                mr.is_read,
                m.created_at AS created_at,
                m.subject,
                m.body       AS body,
                u.username   AS from_username,
                u.email      AS from_email
            FROM ".self::T_MR." mr
            INNER JOIN ".self::T_M." m
                ON m.id = mr.message_id
            INNER JOIN ".self::T_U." u
                ON u.user_id = m.sender_id
            ORDER BY m.created_at DESC
            LIMIT :lim
        ";
        $st = $pdo->prepare($sql);
        $st->bindValue(':lim', $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Alias compatible con otro código tuyo */
    public static function inboxFor(int $userId, int $limit = 200): array
    {
        return self::findInboxForUser($userId, $limit);
    }

    /** Contador de no leídos (nuevos) */
    public static function countUnreadForUser(int $userId): int
    {
        $pdo = Database::getConnection();
        $st = $pdo->prepare("
            SELECT COUNT(*)
            FROM ".self::T_MR."
            WHERE recipient_id = :uid AND is_read = 0
        ");
        $st->execute([':uid' => $userId]);
        return (int)$st->fetchColumn();
    }

    /** Alias compatible */
    public static function countNewFor(int $userId): int
    {
        return self::countUnreadForUser($userId);
    }

    /**
     * Marca como leído para un destinatario.
     */
    public static function markRead(int $messageId, int $userId): void
    {
        $pdo = Database::getConnection();
        $st = $pdo->prepare("
            UPDATE ".self::T_MR."
               SET is_read = 1, read_at = NOW()
             WHERE message_id = :mid AND recipient_id = :uid
        ");
        $st->execute([':mid' => $messageId, ':uid' => $userId]);
    }

    /**
     * Verifica si el usuario puede ver el mensaje:
     * - es destinatario (recipient_id)
     * - o es remitente (sender_id)
     */
    public static function userCanSee(int $mid, int $uid): bool
    {
        $pdo = Database::getConnection();

        // ¿Es destinatario?
        $st = $pdo->prepare("
            SELECT 1 FROM ".self::T_MR."
            WHERE message_id = :mid AND recipient_id = :uid
            LIMIT 1
        ");
        $st->execute([':mid' => $mid, ':uid' => $uid]);
        if ($st->fetchColumn()) return true;

        // ¿Es remitente?
        $st = $pdo->prepare("
            SELECT 1 FROM ".self::T_M."
            WHERE id = :mid AND sender_id = :uid
            LIMIT 1
        ");
        $st->execute([':mid' => $mid, ':uid' => $uid]);
        return (bool)$st->fetchColumn();
    }

    /**
     * Inserta destinatarios.
     */
    public static function addRecipients(int $messageId, array $recipientIds): void
    {
        if (empty($recipientIds)) return;

        $pdo = Database::getConnection();
        $sql = "INSERT INTO ".self::T_MR." (message_id, recipient_id, is_read) VALUES (:mid, :rid, 0)";
        $st  = $pdo->prepare($sql);

        foreach ($recipientIds as $rid) {
            $st->execute([':mid' => $messageId, ':rid' => $rid]);
        }
    }
}

