<?php
namespace App\Models;

use App\Core\Model;

class PasswordReset extends Model
{
    protected $table = 'password_resets';
    protected $primaryKey = 'id';

    public static function createForEmail(string $email, string $tokenPlain, int $ttlMinutes = 30): bool
    {
        $instance = new static();
        $hash = hash('sha256', $tokenPlain);
        $expires = (new \DateTime("+{$ttlMinutes} minutes"))->format('Y-m-d H:i:s');
        $sql = "INSERT INTO password_resets (email, token_hash, expires_at) VALUES (?, ?, ?)";
        return (bool) $instance->db->query($sql, [$email, $hash, $expires]);
    }

    public static function findValid(string $email, string $tokenPlain): ?array
    {
        $instance = new static();
        $hash = hash('sha256', $tokenPlain);
        $sql = "SELECT * FROM password_resets WHERE email = ? AND token_hash = ? AND expires_at > NOW() ORDER BY id DESC LIMIT 1";
        $row = $instance->db->query($sql, [$email, $hash])->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public static function deleteForEmail(string $email): void
    {
        $instance = new static();
        $instance->db->query("DELETE FROM password_resets WHERE email = ?", [$email]);
    }
}

