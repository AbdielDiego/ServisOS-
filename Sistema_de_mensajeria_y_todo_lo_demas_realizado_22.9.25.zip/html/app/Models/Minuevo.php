<?php
namespace App\Models;

class Minuevo
{
    private \PDO $pdo; // Conexión a la base de datos

    // Constructor: recibe una instancia de PDO
    public function __construct(\PDO $pdo) { $this->pdo = $pdo; }

    /**
     * Devuelve los últimos posts creados.
     * Incluye título, contenido, autor y categoría.
     */
    public function latest(int $limit = 10): array
    {
        $sql = "SELECT p.post_id, p.title, p.content, p.created_at,
                       u.username AS author, c.name AS category
                FROM Posts p
                JOIN Users u ON u.user_id = p.user_id
                LEFT JOIN Categories c ON c.category_id = p.category_id
                ORDER BY p.created_at DESC
                LIMIT :lim";
        $st = $this->pdo->prepare($sql);
        $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }

    /**
     * Devuelve todas las categorías disponibles.
     */
    public function categories(): array
    {
        $st = $this->pdo->query("SELECT category_id, name FROM Categories ORDER BY name ASC");
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }

    /**
     * Crea un nuevo post en la base de datos.
     * Retorna el ID insertado.
     */
    public function create(int $userId, ?int $categoryId, string $title, string $content): int
    {
        $sql = "INSERT INTO Posts (user_id, category_id, title, content, created_at, updated_at)
                VALUES (:uid, :cid, :title, :content, NOW(), NOW())";
        $st = $this->pdo->prepare($sql);
        $st->bindValue(':uid', $userId, \PDO::PARAM_INT);
        $st->bindValue(':title', $title, \PDO::PARAM_STR);
        $st->bindValue(':content', $content, \PDO::PARAM_STR);
        if ($categoryId) $st->bindValue(':cid', $categoryId, \PDO::PARAM_INT);
        else             $st->bindValue(':cid', null, \PDO::PARAM_NULL);
        $st->execute();
        return (int)$this->pdo->lastInsertId();
    }

    /**
     * Busca un post por su ID.
     */
    public function findById(int $id): ?array
    {
        $sql = "SELECT p.post_id, p.title, p.content, p.created_at, p.updated_at,
                       u.username AS author, u.user_id AS author_id,
                       c.name AS category, c.category_id
                FROM Posts p
                JOIN Users u ON u.user_id = p.user_id
                LEFT JOIN Categories c ON c.category_id = p.category_id
                WHERE p.post_id = :id";
        $st = $this->pdo->prepare($sql);
        $st->bindValue(':id', $id, \PDO::PARAM_INT);
        $st->execute();
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * Busca un post por título, con variantes:
     * - exacto
     * - normalizado (con guiones)
     * - LIKE
     */
    public function findByLooseTitle(string $input): ?array
    {
        $t1 = trim(urldecode($input));
        if ($t1 === '') return null;

        // 1) Exacto
        $sqlExact = "SELECT p.post_id, p.title, p.content, p.created_at, p.updated_at,
                            u.username AS author, u.user_id AS author_id,
                            c.name AS category, c.category_id
                     FROM Posts p
                     JOIN Users u ON u.user_id = p.user_id
                     LEFT JOIN Categories c ON c.category_id = p.category_id
                     WHERE p.title = :t
                     ORDER BY p.created_at DESC
                     LIMIT 1";
        $st = $this->pdo->prepare($sqlExact);
        $st->execute([':t' => $t1]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        if ($row) return $row;

        // 2) Variantes
        $t2 = preg_replace('/-+/', ' ', $t1);                  // "mi-post" -> "mi post"
        $t3 = preg_replace('/\s+/', '-', strtolower($t1));     // "Mi Post Nuevo" -> "mi-post-nuevo"
        $like1 = "%{$t1}%";
        $like2 = "%{$t2}%";

        $sqlLike = "SELECT p.post_id, p.title, p.content, p.created_at, p.updated_at,
                           u.username AS author, u.user_id AS author_id,
                           c.name AS category, c.category_id
                    FROM Posts p
                    JOIN Users u ON u.user_id = p.user_id
                    LEFT JOIN Categories c ON c.category_id = p.category_id
                    WHERE p.title LIKE :t1
                       OR p.title LIKE :t2
                       OR REPLACE(LOWER(p.title), ' ', '-') = :t3
                    ORDER BY p.created_at DESC
                    LIMIT 1";
        $st = $this->pdo->prepare($sqlLike);
        $st->execute([
            ':t1' => $like1,
            ':t2' => $like2,
            ':t3' => $t3,
        ]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * Calcula el promedio de rating de un post.
     * Devuelve null si no hay votos.
     */
    public function avgRating(int $postId): ?float
    {
        $st = $this->pdo->prepare("SELECT AVG(rating) AS avg_rating, COUNT(*) AS cnt
                                   FROM post_ratings WHERE post_id = :pid");
        $st->execute([':pid' => $postId]);
        $row = $st->fetch();
        if (!$row || (int)$row['cnt'] === 0) return null;
        return (float)$row['avg_rating'];
    }

    /**
     * Devuelve el rating de un usuario en un post.
     */
    public function userRating(int $postId, int $userId): ?int
    {
        $st = $this->pdo->prepare("SELECT rating FROM post_ratings WHERE post_id = :pid AND user_id = :uid");
        $st->execute([':pid' => $postId, ':uid' => $userId]);
        $row = $st->fetch();
        return $row ? (int)$row['rating'] : null;
    }

    /**
     * Inserta o actualiza un rating de usuario en un post.
     */
    public function upsertRating(int $postId, int $userId, int $rating): void
    {
        $sql = "INSERT INTO post_ratings (post_id, user_id, rating, created_at, updated_at)
                VALUES (:pid, :uid, :r, NOW(), NOW())
                ON DUPLICATE KEY UPDATE rating = VALUES(rating), updated_at = NOW()";
        $st = $this->pdo->prepare($sql);
        $st->execute([':pid' => $postId, ':uid' => $userId, ':r' => $rating]);
    }

    /* ------ Métodos para el dashboard (mis posts) ------ */

    /**
     * Devuelve los posts creados por un usuario, con límite y offset.
     */
    public function byUser(int $userId, int $limit = 6, int $offset = 0): array
    {
        $sql = "SELECT p.post_id, p.title, p.content, p.created_at,
                       c.name AS category
                FROM Posts p
                LEFT JOIN Categories c ON c.category_id = p.category_id
                WHERE p.user_id = :uid
                ORDER BY p.created_at DESC
                LIMIT :off, :lim";
        $st = $this->pdo->prepare($sql);
        $st->bindValue(':uid', $userId, \PDO::PARAM_INT);
        $st->bindValue(':off', $offset, \PDO::PARAM_INT);
        $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }

    /**
     * Cuenta cuántos posts tiene un usuario.
     */
    public function countByUser(int $userId): int
    {
        $st = $this->pdo->prepare("SELECT COUNT(*) AS n FROM Posts WHERE user_id = :uid");
        $st->execute([':uid' => $userId]);
        $row = $st->fetch(\PDO::FETCH_ASSOC);
        return $row ? (int)$row['n'] : 0;
    }
}

