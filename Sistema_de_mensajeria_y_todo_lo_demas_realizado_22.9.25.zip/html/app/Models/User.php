<?php
namespace App\Models;

use App\Core\Model;
use App\Core\Database;

/**
 * Modelo User
 * Representa la tabla "Users" y provee métodos de consulta.
 */
class User extends Model
{
    protected $table = 'Users';
    protected $primaryKey = 'user_id';

    /**
     * Retorna una fila de usuario por su email (o null si no existe).
     * Compatible tanto si tu Model base expone $this->db como si no.
     */
    public function findByEmail(string $email): ?array
    {
        $pdo = (property_exists($this, 'db') && $this->db) ? $this->db : Database::getConnection();
        $sql = "SELECT user_id, username, email, password, rol_id, created_at
                  FROM {$this->table}
                 WHERE email = ?
                 LIMIT 1";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$email]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * Versión estática por comodidad.
     */
    public static function findByEmailStatic(string $email): ?array
    {
        $self = new static();
        return $self->findByEmail($email);
    }

    /**
     * Buscar por ID.
     */
    public function findById(int $id): ?array
    {
        $pdo = (property_exists($this, 'db') && $this->db) ? $this->db : Database::getConnection();
        $sql = "SELECT user_id, username, email, password, rol_id, created_at
                  FROM {$this->table}
                 WHERE {$this->primaryKey} = ?
                 LIMIT 1";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * Recibe una lista de tokens (username o email).
     * Devuelve [ token_normalizado => user_id ] solo para los que existan.
     * Útil para “resolver destinatarios” en mensajería interna.
     */
    public static function mapTokensToIds(array $tokens): array
    {
        if (empty($tokens)) return [];
        $pdo = Database::getConnection();

        // normalizar tokens y limpiar
        $norm = [];
        foreach ($tokens as $t) {
            $t = trim((string)$t);
            if ($t !== '') $norm[] = $t;
        }
        if (empty($norm)) return [];

        // placeholders dinámicos
        $in = implode(',', array_fill(0, count($norm), '?'));

        // buscamos por username O email
        $sql = "SELECT user_id, username, email
                  FROM Users
                 WHERE username IN ($in) OR email IN ($in)";

        $st = $pdo->prepare($sql);
        // bind dos veces el mismo arreglo (username y email)
        $st->execute(array_merge($norm, $norm));
        $rows = $st->fetchAll(\PDO::FETCH_ASSOC);

        $map = [];
        foreach ($rows as $r) {
            if (isset($r['username'])) {
                $map[strtolower((string)$r['username'])] = (int)$r['user_id'];
            }
            if (isset($r['email'])) {
                $map[strtolower((string)$r['email'])] = (int)$r['user_id'];
            }
        }
        return $map;
    }
}

