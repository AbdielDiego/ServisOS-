<?php
namespace App\Models;

use App\Core\Model;
use App\Core\Database;

/**
 * Modelo User
 * Representa la tabla "Users" y provee métodos de consulta.
 */
class User extends Model
{
    protected $table = 'Users';         // Nombre de la tabla en la base de datos
    protected $primaryKey = 'user_id';  // Clave primaria de la tabla

    /**
     * Busca un usuario por su email.
     * Retorna un array con los datos o null si no existe.
     * Compatible tanto si el Model base tiene $this->db como si no.
     */
    public function findByEmail(string $email): ?array
    {
        // Usa la conexión disponible ($this->db) o crea una nueva
        $pdo = (property_exists($this, 'db') && $this->db) ? $this->db : Database::getConnection();

        // Consulta SQL
        $sql = "SELECT user_id, username, email, password, rol_id, created_at
                  FROM {$this->table}
                 WHERE email = ?
                 LIMIT 1";

        // Ejecuta consulta preparada
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$email]);

        // Devuelve el resultado o null
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * Versión estática para buscar por email.
     * Permite hacer: User::findByEmailStatic($email);
     */
    public static function findByEmailStatic(string $email): ?array
    {
        $self = new static();
        return $self->findByEmail($email);
    }

    /**
     * Busca un usuario por ID.
     * Devuelve un array con los datos o null.
     */
    public function findById(int $id): ?array
    {
        $pdo = (property_exists($this, 'db') && $this->db) ? $this->db : Database::getConnection();

        $sql = "SELECT user_id, username, email, password, rol_id, created_at
                  FROM {$this->table}
                 WHERE {$this->primaryKey} = ?
                 LIMIT 1";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);

        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * Recibe una lista de tokens (username o email).
     * Devuelve un array con el formato:
     *   [ token_normalizado => user_id ]
     * Solo incluye los que existan en la base.
     * Se usa para resolver destinatarios en mensajería interna.
     */
    public static function mapTokensToIds(array $tokens): array
    {
        if (empty($tokens)) return [];

        $pdo = Database::getConnection();

        // Normalizar tokens: limpiar y convertir a string
        $norm = [];
        foreach ($tokens as $t) {
            $t = trim((string)$t);
            if ($t !== '') $norm[] = $t;
        }
        if (empty($norm)) return [];

        // Crear placeholders dinámicos según cantidad de tokens
        $in = implode(',', array_fill(0, count($norm), '?'));

        // Buscar coincidencias por username O email
        $sql = "SELECT user_id, username, email
                  FROM Users
                 WHERE username IN ($in) OR email IN ($in)";

        $st = $pdo->prepare($sql);
        // Se pasan dos veces los mismos parámetros: para username y para email
        $st->execute(array_merge($norm, $norm));
        $rows = $st->fetchAll(\PDO::FETCH_ASSOC);

        // Construir mapa resultado
        $map = [];
        foreach ($rows as $r) {
            if (isset($r['username'])) {
                $map[strtolower((string)$r['username'])] = (int)$r['user_id'];
            }
            if (isset($r['email'])) {
                $map[strtolower((string)$r['email'])] = (int)$r['user_id'];
            }
        }
        return $map;
    }
}

