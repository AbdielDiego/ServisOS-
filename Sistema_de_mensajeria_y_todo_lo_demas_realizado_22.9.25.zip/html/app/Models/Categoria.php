<?php 
namespace App\Models;
use App\Core\Model;

/**
 * Modelo Categoria
 * Representa la tabla "Categories" en la base de datos.
 */
class Categoria extends Model {

    public function __construct() {
        // Nombre de la tabla
        $this->table = "Categories";
        // Clave primaria
        $this->primaryKey = "category_id";

        // Inicializa la lógica del Model base
        parent::__construct();	
    }
}

