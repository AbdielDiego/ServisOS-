<?php
namespace App\Models;

use App\Core\Model;

class Rating extends Model
{
    // Nombre de la tabla asociada (se define dinámicamente en tiempo de ejecución)
    protected string $table = ''; 

    // Campos permitidos para inserción/actualización masiva
    protected array $fillable = ['user_id','rating'];

    /**
     * Define la tabla sobre la cual operará este modelo
     */
    public function setTable(string $table): void { 
        $this->table = $table; 
    }

    /**
     * Inserta o actualiza un registro de rating según si ya existe.
     * - Si el registro existe (cumple la condición $where), lo actualiza.
     * - Si no existe, lo inserta.
     *
     * @param array $where Condiciones de búsqueda (ej: ['user_id'=>5, 'post_id'=>10])
     * @param array $data  Datos a actualizar o insertar (ej: ['rating'=>4])
     * @return bool        True en caso de éxito, False si falla
     */
    public function upsertByUser(array $where, array $data): bool
    {
        // Verifica si ya existe el registro que cumpla las condiciones
        $exists = $this->firstWhere($where);

        if ($exists) {
            // Si existe → actualizar
            return $this->updateWhere($where, $data);
        }

        // Si no existe → insertar
        return $this->insert(array_merge($where, $data));
    }
}


