<?php
// Variables disponibles: $title (opcional)
$title = isset($title) ? (string)$title : 'Olvidé mi contraseña';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="/css/login.css">
</head>
<body>

  <main style="width:100%;max-width:640px;margin:0 auto;padding:20px 16px;">
    <h2>Recuperar acceso</h2>

    <?php
    // Flash messages (si las hubiera)
    if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
    if (!empty($_SESSION['flash'])):
      foreach ($_SESSION['flash'] as $type => $msg):
        $class = ($type === 'success') ? 'alert-success' : (($type === 'error') ? 'alert-error' : 'alert-warning');
    ?>
      <div class="alert <?= $class ?>"><?= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') ?></div>
    <?php
      endforeach;
      unset($_SESSION['flash']);
    endif;
    ?>

    <?php if (!empty($_GET['sent'])): ?>
      <div class="alert alert-success">
        Si el email existe, te enviamos un enlace para restablecer la contraseña.
      </div>
    <?php endif; ?>

    <form method="POST" action="/forgot" novalidate>
      <div>
        <label>Email:</label>
        <input type="email" name="email" required placeholder="tucorreo@ejemplo.com" autocomplete="email">
        <small>Te enviaremos un enlace para crear una nueva contraseña.</small>
      </div>

      <div class="auth-extras" style="margin-top:-4px">
        <a href="/login">Volver a iniciar sesión</a>
        <a href="/register">Crear cuenta</a>
      </div>

      <button type="submit"><span class="label">Enviar enlace</span></button>
      <span class="shine" aria-hidden="true"></span>
    </form>
  </main>

  <script>
    // Loader del botón
    const btnF = document.querySelector('button[type="submit"]');
    const formF = document.querySelector('form');
    if (formF && btnF){
      formF.addEventListener('submit', ()=>{
        btnF.classList.add('is-loading');
        if (!btnF.querySelector('.spinner')){
          const s = document.createElement('i'); s.className = 'spinner'; btnF.appendChild(s);
        }
      }, {passive:true});
    }
    // Brillo que sigue al mouse
    if (btnF){
      btnF.addEventListener('pointermove', e=>{
        const r = btnF.getBoundingClientRect();
        btnF.style.setProperty('--x', ((e.clientX - r.left)/r.width*100)+'%');
        btnF.style.setProperty('--y', ((e.clientY - r.top )/r.height*100)+'%');
      });
    }
  </script>
</body>
</html>


