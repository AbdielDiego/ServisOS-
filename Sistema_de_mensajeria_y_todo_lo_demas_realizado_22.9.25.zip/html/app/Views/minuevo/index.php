<link rel="stylesheet" href="/css/minuevo.css">
<main class="minuevo">
  <h1>Últimas Novedades</h1>
  <p>Publicaciones recientes de la comunidad.</p>

  <?php if (!empty($_SESSION['flash']['ok'])): ?>
    <div class="alert ok"><?= htmlspecialchars($_SESSION['flash']['ok'], ENT_QUOTES, 'UTF-8') ?></div>
    <?php unset($_SESSION['flash']['ok']); ?>
  <?php endif; ?>
  <?php if (!empty($_SESSION['flash']['error'])): ?>
    <div class="alert error"><?= htmlspecialchars($_SESSION['flash']['error'], ENT_QUOTES, 'UTF-8') ?></div>
    <?php unset($_SESSION['flash']['error']); ?>
  <?php endif; ?>

  <?php if (!empty($_SESSION['user'])): ?>
    <p><a class="btn" href="/minuevo/crear">➕ Crear novedad</a></p>
  <?php endif; ?>

  <?php if (empty($posts)): ?>
    <p>No hay publicaciones todavía.</p>
  <?php else: ?>
    <div class="list">
      <?php foreach ($posts as $p): ?>
        <article class="card">
          <h3>
            <a href="/article/<?= htmlspecialchars($p['slug'], ENT_QUOTES, 'UTF-8') ?>">
              <?= htmlspecialchars($p['title'], ENT_QUOTES, 'UTF-8') ?>
            </a>
          </h3>
          <p class="meta">
            <strong>Autor:</strong> <?= htmlspecialchars($p['author'], ENT_QUOTES, 'UTF-8') ?>
            <?php if (!empty($p['category'])): ?>
              &nbsp;|&nbsp; <strong>Categoría:</strong> <?= htmlspecialchars($p['category'], ENT_QUOTES, 'UTF-8') ?>
            <?php endif; ?>
            &nbsp;|&nbsp; <strong>Fecha:</strong> <?= htmlspecialchars(date('Y-m-d', strtotime($p['created_at'])), ENT_QUOTES, 'UTF-8') ?>
          </p>
          <p><?= nl2br(htmlspecialchars(mb_strimwidth($p['content'], 0, 240, '…'), ENT_QUOTES, 'UTF-8')) ?></p>
          <p style="margin-top:8px;"><a class="btn" href="/article/<?= htmlspecialchars($p['slug'], ENT_QUOTES, 'UTF-8') ?>">Leer más</a></p>
        </article>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</main>

