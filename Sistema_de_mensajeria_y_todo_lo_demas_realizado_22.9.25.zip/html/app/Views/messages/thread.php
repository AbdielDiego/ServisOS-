<link rel="stylesheet" href="/css/styles.css">
<?php
// Asegura sesión para los flashes
if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }

/** @var array $message */
/** @var array $recipients */
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// Tomamos el ID correctamente (según cómo venga desde el controlador)
$messageId = (int)($message['id'] ?? $message['message_id'] ?? 0);

// ¿El usuario logueado es el emisor?
$loggedId   = (int)($_SESSION['user']['user_id'] ?? $_SESSION['user']['id'] ?? $_SESSION['user_id'] ?? 0);
$isSender   = $loggedId && $loggedId === (int)($message['sender_id'] ?? 0);
?>
<h1><?= h($message['subject'] ?? 'Mensaje') ?></h1>

<p>
  <strong>De:</strong> <?= h($message['from_name'] ?? '') ?>
  &nbsp;·&nbsp;
  <strong>Fecha:</strong> <?= h($message['created_at'] ?? '') ?>
</p>

<hr>

<div style="white-space:pre-wrap; line-height:1.5">
  <?= h($message['body'] ?? '') ?>
</div>

<hr>

<h3>Destinatarios</h3>
<ul>
  <?php if (!empty($recipients)): ?>
    <?php foreach ($recipients as $r): ?>
      <li>
        <?= h($r['username'] ?? '') ?>
        <?= !empty($r['is_read']) ? '(leído)' : '(no leído)' ?>
        <?php if (!empty($r['is_read']) && !empty($r['read_at'])): ?>
          — <small><?= h($r['read_at']) ?></small>
        <?php endif; ?>
      </li>
    <?php endforeach; ?>
  <?php else: ?>
    <li><em>Sin destinatarios</em></li>
  <?php endif; ?>
</ul>

<hr>

<h3>Responder</h3>

<?php if (!empty($_SESSION['flash_error'])): ?>
  <div class="alert error"><?= h($_SESSION['flash_error']); unset($_SESSION['flash_error']); ?></div>
<?php endif; ?>
<?php if (!empty($_SESSION['flash_ok'])): ?>
  <div class="alert ok"><?= h($_SESSION['flash_ok']); unset($_SESSION['flash_ok']); ?></div>
<?php endif; ?>

<form method="post" action="/messages/<?= $messageId ?>/reply">
  <textarea name="body" rows="4" required style="width:100%;"></textarea>
  <br>
  <button type="submit">Enviar respuesta</button>
</form>

<p style="margin-top:1rem;">
  <a href="/messages/inbox">← Volver a Inbox</a>
  <?php if ($isSender): ?>
    &nbsp;|&nbsp; <a href="/messages/sent">Ver enviados</a>
  <?php endif; ?>
</p>

