<?php
/** @var array $categoria */
/** @var int   $categoriaId */
/** @var string $basePath */
/** @var array $posts */

$catIdReal = (int)($categoria['category_id'] ?? $categoriaId ?? 0);
$catNombre = htmlspecialchars($categoria['name'] ?? 'Sin nombre', ENT_QUOTES, 'UTF-8');
$bp        = rtrim($basePath ?? '', '/');
?>

<section class="categoria-page">
  <h1>Categoría: <?= $catNombre ?></h1>

  <p>
    ID: <strong><?= $catIdReal ?></strong>
    · Nombre: <strong><?= $catNombre ?></strong>
  </p>

  <?php if (empty($posts)): ?>
    <p>No hay posts en esta categoría.</p>
  <?php else: ?>
    <ul class="posts">
      <?php foreach ($posts as $p): ?>
        <li>
          <a href="<?= $bp ?>/post/<?= (int)$p['post_id'] ?>">
            <?= htmlspecialchars($p['title'] ?? 'Sin título', ENT_QUOTES, 'UTF-8') ?>
          </a>
          <small>(<?= (int)($p['comments_count'] ?? 0) ?> comentarios)</small>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>

  <!-- Anclas -->
  <a id="comentarios"></a>
  <a id="comentar"></a>

  <!-- Botón que SIEMPRE respeta el id real -->
  <p>
    <a class="btn" href="<?= $bp ?>/categoria/<?= $catIdReal ?>#comentar">Comentar</a>
  </p>

  <?php
    // Formulario de comentario dentro de categoría
    $component = BASE_PATH . "/app/Views/components/comentario_form.php";
    $context   = 'categoria';
    $contextId = $catIdReal;
    $actionUrl = "{$bp}/categoria/{$catIdReal}/comentarios#comentar"; // coincide con tu POST
    require $component;
  ?>
</section>

