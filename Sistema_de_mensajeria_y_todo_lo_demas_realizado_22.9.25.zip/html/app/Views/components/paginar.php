<?php 
// Incluir tabla de datos
require 'tabla.php';
?>

<!-- Sección de paginación -->
<div class="paginacion">
    <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
        <!-- Enlace a cada página -->
        <a href="<?= $baseUrl . '/' . $i ?>" 
           <?= $i == $pagina ? 'style="font-weight: bold;"' : '' ?>>
            <?= $i ?>
        </a>
    <?php endfor; ?>
</div>



