<?php
namespace App\Core;

class View {
    protected $sharedData = [];

    /**
     * Escapa con soporte para arrays/objetos.
     * - Arrays: une los elementos en un string (no escalares -> JSON legible).
     * - Objetos sin __toString(): los convierte a JSON.
     * - Null: cadena vacía.
     */
    public function e($value): string
    {
        if ($value === null) return '';

        if (is_array($value)) {
            $value = implode(' ', array_map(function ($v) {
                if (is_scalar($v) || $v === null) return (string)$v;
                if (is_object($v) && method_exists($v, '__toString')) return (string)$v;
                return json_encode($v, JSON_UNESCAPED_UNICODE);
            }, $value));
        } elseif (is_object($value) && !method_exists($value, '__toString')) {
            $value = json_encode($value, JSON_UNESCAPED_UNICODE);
        }

        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }

    public function share($key, $value = null): void
    {
        if (is_array($key)) {
            $this->sharedData = array_merge($this->sharedData, $key);
        } else {
            $this->sharedData[$key] = $value;
        }
    }

    public function component($name, $data = []): void
    {
        // Combina datos compartidos con los específicos del componente
        $data = array_merge($this->sharedData, $data);
        extract($data, EXTR_OVERWRITE);

        // Resuelve ruta del componente
        if (strpos($name, '/') === false) {
            $componentFile = BASE_PATH . "/app/Views/components/{$name}.php";
        } else {
            // Permite subdirectorios: 'minuevo/lista_articulos'
            $componentFile = BASE_PATH . "/app/Views/{$name}.php";
        }

        if (!file_exists($componentFile)) {
            error_log("Componente no encontrado: {$name}. Ruta esperada: {$componentFile}");
            echo "<div style='color:red;'>Error: Componente '{$this->e($name)}' no encontrado.</div>";
            return;
        }

        require $componentFile; // imprime directamente en el buffer de render()
    }

    public function render($viewPath, $data = []): void
    {
        // Combina datos compartidos con los de la vista
        $data = array_merge($this->sharedData, $data);
        extract($data, EXTR_OVERWRITE);

        // Captura salida de la vista
        ob_start();
        $viewFile = BASE_PATH . "/app/Views/{$viewPath}.php";

        if (!file_exists($viewFile)) {
            ob_end_clean();
            throw new \Exception("Vista no encontrada: {$viewPath}. Archivo esperado: {$viewFile}");
        }

        require $viewFile;
        $content = ob_get_clean();

        // Layout principal
        $layoutFile = BASE_PATH . "/app/Views/layouts/main.php";

        if (file_exists($layoutFile)) {
            // $_layoutContent disponible para el layout
            $_layoutContent = $content;
            ob_start();
            require $layoutFile;
            echo ob_get_clean();
        } else {
            echo $content;
        }
    }
}

