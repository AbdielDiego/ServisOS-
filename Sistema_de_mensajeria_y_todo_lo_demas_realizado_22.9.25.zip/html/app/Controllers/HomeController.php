<?php
namespace App\Controllers;

use App\Core\Controller;

class HomeController extends Controller {

    /**
     * Acción principal del sitio (ruta "/")
     * Renderiza la vista "home" y pasa como dato el título "Chivita Recomienda".
     */
    public function index() {
        // Llama al método render para mostrar la vista "home"
        // y envía un array con la variable 'title'
        return $this->render('home', [
            'title' => 'Chivita Recomienda'
        ]);
    }
}

