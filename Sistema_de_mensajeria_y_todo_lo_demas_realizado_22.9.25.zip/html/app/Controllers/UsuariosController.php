<?php 

namespace App\Controllers;
use App\Core\Controller;
use App\Models\User;

class UsuariosController extends Controller {

    private $modelo; // instancia del modelo User

    // Constructor: inicializa el modelo User y llama al constructor del padre
    public function __construct() {
        $this->modelo = new User();
        parent::__construct();
    }

    /**
     * GET /usuarios
     * Muestra todos los usuarios registrados
     */
    public function index() {
        // Obtiene todos los registros de la tabla Users mediante el modelo
        $datos = $this->modelo->all();

        // Renderiza la vista "usuarios/index" y pasa los datos como variables
        return $this->render("usuarios/index", [
            "titulo"     => "Usuarios Registrados", // título para la vista
            "datosTabla" => $datos                 // datos de la tabla (usuarios)
        ]);
    }

    /**
     * GET /usuarios/pagina/:num
     * Muestra usuarios paginados
     */
    public function paginado() {
        // Llama a método sqlPaginado() del modelo User para traer registros por páginas
        $datos = $this->modelo->sqlPaginado();

        // Define la URL base que usará el paginador para construir los enlaces
        $datos["baseUrl"] = "/usuarios/pagina";

        // Renderiza la vista "usuarios/paginar" con los datos paginados
        return $this->render("usuarios/paginar", $datos);
    }
}

