<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Post;
use App\Models\Comment;

class PostController extends Controller
{
    /** @var Post */
    private $modelo;   // Instancia del modelo Post
    /** @var Comment */
    private $comment;  // Instancia del modelo Comment

    public function __construct()
    {
        parent::__construct();
        // Inicializamos los modelos Post y Comment si aún no existen
        $this->modelo  = $this->modelo  ?? new Post();
        $this->comment = $this->comment ?? new Comment();
    }

    /**
     * GET /post
     * GET /post/paginar/:pagina
     * Lista todos los posts con paginación
     */
    public function index(array $params = []): void
    {
        // Página segura (convierte a int y se asegura que sea >= 1)
        $pagina = (int)($params['pagina'] ?? ($_GET['pagina'] ?? 1));
        $pagina = max(1, $pagina);

        // Llama al método sqlPaginado del modelo Post
        $datos = $this->modelo->sqlPaginado($pagina);

        // Normaliza la clave de los posts para la vista
        $datos['posts'] = $datos['posts']
            ?? ($datos['items']     ?? null)
            ?? ($datos['rows']      ?? null)
            ?? ($datos['data']      ?? null)
            ?? ($datos['registros'] ?? null)
            ?? [];

        // Datos adicionales para la vista
        $datos['baseUrl'] = '/post/paginar';
        $datos['titulo']  = 'Todos los Post ingresados';

        // Renderiza la vista index de post
        $this->render('post/index', $datos);
    }

    /**
     * GET /post/:id/comentar
     * Muestra formulario o vista para comentar un post específico
     */
    public function comentar($id)
    {
        $id = (int)$id; // Normaliza el id

        // Busca el post usando el método findById o un fallback a find()
        if (method_exists($this->modelo, 'findById')) {
            $post = $this->modelo->findById($id);
        } else {
            $post = $this->modelo->find(['post_id' => $id]);
        }

        // Si no encuentra el post, redirige al listado
        if (!$post) {
            return $this->redirect('/post');
        }

        // Calcula basePath por si la vista necesita rutas relativas
        $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
        $basePath   = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
        if ($basePath === '.' || $basePath === '/') { $basePath = ''; }

        // Renderiza la vista comentar
        return $this->render('post/comentar', [
            'title'    => 'Comentar: ' . ($post['title'] ?? 'Post'),
            'post'     => $post,
            'basePath' => $basePath,
        ]);
    }

    /**
     * GET /post/:id
     * Muestra el detalle de un post junto con sus comentarios
     */
    public function show($id)
    {
        // Normaliza el parámetro id
        $id = is_array($id) ? (int)($id['id'] ?? 0) : (int)$id;
        if ($id <= 0) {
            return $this->redirect('/post');
        }

        // 1) Busca el post por id
        if (method_exists($this->modelo, 'findById')) {
            $post = $this->modelo->findById($id);
        } else {
            $post = $this->modelo->find(['post_id' => $id]);
            // Fallback prudente si find() acepta int directamente
            if (!$post && method_exists($this->modelo, 'find')) {
                $tmp = $this->modelo->find($id);
                if (is_array($tmp)) { $post = $tmp; }
            }
        }

        // Si no encuentra el post, redirige al listado
        if (!$post) {
            return $this->redirect('/post');
        }

        // 2) Busca los comentarios del post
        if (method_exists($this->comment, 'findByPostId')) {
            $comments = $this->comment->findByPostId($id);
        } else {
            // Si no existe ese método en Comment, devuelve vacío
            $comments = [];
        }

        // Calcula basePath por si la vista necesita rutas relativas
        $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
        $basePath   = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
        if ($basePath === '.' || $basePath === '/') { $basePath = ''; }

        // 3) Renderiza la vista show con post y comentarios
        return $this->render('post/show', [
            'title'    => $post['title'] ?? 'Post',
            'post'     => $post,
            'comments' => $comments,
            'basePath' => $basePath,
        ]);
    }
}


