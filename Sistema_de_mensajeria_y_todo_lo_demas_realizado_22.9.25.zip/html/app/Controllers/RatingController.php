<?php
namespace App\Controllers;

use App\Core\Controller;

class RatingController extends Controller
{
    private function pdo(): \PDO
    {
        if (isset($this->container['db']) && $this->container['db'] instanceof \PDO) {
            return $this->container['db'];
        }
        $Db = '\App\Core\Database';
        if (class_exists($Db)) {
            if (method_exists($Db, 'getInstance')) {
                $inst = $Db::getInstance();
                if (is_object($inst)) {
                    if (method_exists($inst, 'getConnection')) {
                        $pdo = $inst->getConnection();
                        if ($pdo instanceof \PDO) return $pdo;
                    }
                    if (property_exists($inst, 'pdo') && $inst->pdo instanceof \PDO) {
                        return $inst->pdo;
                    }
                }
            }
            if (property_exists($Db, 'pdo') && isset($Db::$pdo) && $Db::$pdo instanceof \PDO) {
                return $Db::$pdo;
            }
        }
        $Model = '\App\Core\Model';
        if (class_exists($Model)) {
            if (method_exists($Model, 'pdo')) {
                $pdo = $Model::pdo();
                if ($pdo instanceof \PDO) return $pdo;
            }
            if (method_exists($Model, 'getPDO')) {
                $pdo = $Model::getPDO();
                if ($pdo instanceof \PDO) return $pdo;
            }
            if (property_exists($Model, 'pdo') && isset($Model::$pdo) && $Model::$pdo instanceof \PDO) {
                return $Model::$pdo;
            }
        }
        if (function_exists('db')) {
            $pdo = db();
            if ($pdo instanceof \PDO) return $pdo;
        }
        if (defined('DB_HOST') && defined('DB_NAME') && defined('DB_USER')) {
            $dsn  = defined('DB_DSN') ? DB_DSN : ('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4');
            $pass = defined('DB_PASS') ? DB_PASS : '';
            return new \PDO($dsn, DB_USER, $pass, [
                \PDO::ATTR_ERRMODE            => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
            ]);
        }
        throw new \RuntimeException('No pude obtener una conexión PDO.');
    }

    private function currentUserId(): ?int
    {
        if (class_exists('\App\Core\Auth')) {
            try {
                $auth = new \App\Core\Auth();
                if (method_exists($auth, 'user')) {
                    $u = $auth->user();
                    if (is_array($u)) {
                        if (isset($u['user_id']) && is_numeric($u['user_id'])) return (int)$u['user_id'];
                        if (isset($u['id'])      && is_numeric($u['id']))      return (int)$u['id'];
                    } elseif (is_object($u)) {
                        if (isset($u->user_id) && is_numeric($u->user_id)) return (int)$u->user_id;
                        if (isset($u->id)      && is_numeric($u->id))      return (int)$u->id;
                    }
                }
            } catch (\Throwable $e) {}
        }
        if (!empty($_SESSION['user']['user_id'])) return (int)$_SESSION['user']['user_id'];
        if (!empty($_SESSION['user']['id']))      return (int)$_SESSION['user']['id'];
        return null;
    }

    /** POST /api/rate/simple -> incrementa tu rating en post_ratings: 1→5→1 */
    public function rateSimple(): void
    {
        $postId = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        if ($postId <= 0) { $this->redirectBack(); }

        $userId = $this->currentUserId();
        if (!$userId) { $this->redirectBack(); }

        try {
            $pdo = $this->pdo();

            // traer mi rating actual
            $sel = $pdo->prepare("SELECT rating FROM post_ratings WHERE post_id = ? AND user_id = ? LIMIT 1");
            $sel->execute([$postId, $userId]);
            $row = $sel->fetch();

            $curr = isset($row['rating']) ? (int)$row['rating'] : 0;
            if ($curr < 1 || $curr > 5) $curr = 0;
            $next = ($curr >= 5) ? 1 : ($curr + 1);

            if ($row) {
                $upd = $pdo->prepare("UPDATE post_ratings SET rating = ?, updated_at = CURRENT_TIMESTAMP WHERE post_id = ? AND user_id = ?");
                $upd->execute([$next, $postId, $userId]);
            } else {
                $ins = $pdo->prepare("INSERT INTO post_ratings (post_id, user_id, rating) VALUES (?, ?, ?)");
                $ins->execute([$postId, $userId, $next]);
            }
        } catch (\Throwable $e) {
            error_log('rateSimple error: '.$e->getMessage());
        }

        $this->redirectBack();
    }

    private function redirectBack(): void
    {
        $back = $_SERVER['HTTP_REFERER'] ?? '/post';
        header('Location: '.$back);
        exit;
    }
}


