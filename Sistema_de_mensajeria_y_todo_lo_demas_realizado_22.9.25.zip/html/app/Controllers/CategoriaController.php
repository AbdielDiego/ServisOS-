<?php
namespace App\Controllers;

use App\Core\Controller;

class CategoriaController extends Controller
{
    /** @var \PDO */
    private $pdo; // conexión PDO

    public function __construct()
    {
        parent::__construct();

        // 1) Intento: contenedor con PDO
        if (isset($this->container['db']) && $this->container['db'] instanceof \PDO) {
            $this->pdo = $this->container['db'];
        } else {
            // 2) Intento: Wrapper Database
            if (class_exists('\App\Core\Database')) {
                $Db = '\App\Core\Database';

                if (method_exists($Db, 'getInstance')) {
                    $inst = $Db::getInstance();
                    if ($inst instanceof $Db) {
                        if (method_exists($inst, 'getConnection') && $inst->getConnection() instanceof \PDO) {
                            $this->pdo = $inst->getConnection();
                        } elseif (property_exists($inst, 'pdo') && $inst->pdo instanceof \PDO) {
                            $this->pdo = $inst->pdo;
                        }
                    }
                }

                if (!$this->pdo && method_exists($Db, 'getConnection') && $Db::getConnection() instanceof \PDO) {
                    $this->pdo = $Db::getConnection();
                }

                if (!$this->pdo && property_exists($Db, 'pdo') && $Db::$pdo instanceof \PDO) {
                    $this->pdo = $Db::$pdo;
                }
            }
        }

        // 3) Fallback final: config/database.php
        if (!$this->pdo) {
            $cfgPath = defined('BASE_PATH')
                ? BASE_PATH . '/config/database.php'
                : __DIR__ . '/../../config/database.php';

            $cfg = require $cfgPath;

            $driver  = $cfg['driver']   ?? 'mysql';
            $host    = $cfg['host']     ?? 'localhost';
            $db      = $cfg['database'] ?? '';
            $user    = $cfg['username'] ?? '';
            $pass    = $cfg['password'] ?? '';
            $charset = $cfg['charset']  ?? 'utf8mb4';
            $options = $cfg['options']  ?? [
                \PDO::ATTR_ERRMODE            => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
                \PDO::ATTR_EMULATE_PREPARES   => false,
            ];

            $dsn = sprintf('%s:host=%s;dbname=%s;charset=%s', $driver, $host, $db, $charset);
            $this->pdo = new \PDO($dsn, $user, $pass, $options);
        }
    }

    // ====================== Helpers internos ======================

    /** Devuelve el id del usuario logueado, buscando recursivamente en $_SESSION */
    private function currentUserId(): ?int
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            @session_start();
        }

        // claves habituales
        $keys = ['user_id','id','id_user','usuario_id','idUsuario','cliente_id','id_cliente'];

        $finder = function ($arr) use (&$finder, $keys): int {
            if (!is_array($arr)) return 0;

            foreach ($keys as $k) {
                if (isset($arr[$k]) && is_numeric($arr[$k])) {
                    $val = (int)$arr[$k];
                    if ($val > 0) return $val;
                }
            }
            foreach ($arr as $v) {
                if (is_array($v)) {
                    $found = $finder($v);
                    if ($found > 0) return $found;
                }
            }
            return 0;
        };

        if (!empty($_SESSION['auth'])) {
            $found = $finder($_SESSION['auth']);
            if ($found > 0) return $found;
        }

        $found = $finder($_SESSION ?? []);
        return $found > 0 ? $found : null;
    }

    /** Acepta int|string|array y devuelve el ID como entero seguro */
    private function normalizeId($id): int
    {
        if (is_array($id)) {
            if (isset($id['id'])) return (int)$id['id'];
            $vals = array_values($id);
            return isset($vals[0]) ? (int)$vals[0] : 0;
        }
        return (int)$id;
    }

    /** Devuelve el basePath calculado por SCRIPT_NAME (por si usas subcarpeta) */
    private function getBasePath(): string
    {
        $sn = $_SERVER['SCRIPT_NAME'] ?? '';
        $bp = rtrim(str_replace('\\', '/', dirname($sn)), '/');
        return ($bp === '.' || $bp === '/') ? '' : $bp;
    }

    /** Redirige a /categoria/{id} con un fragmento opcional (#comentar / #comentarios) */
    private function redirectCategoria(int $catId, string $fragment = ''): void
    {
        $this->redirect("/categoria/{$catId}{$fragment}");
    }

    // ========================== Acciones ==========================

    // GET /categoria/:id
    public function show($id): void
    {
        $catId = $this->normalizeId($id);
        if ($catId <= 0) {
            $this->render('errors/404', ['title' => 'No encontrado']);
            return;
        }

        // Categoría
        $q = $this->pdo->prepare('SELECT * FROM Categories WHERE category_id = ? LIMIT 1');
        $q->execute([$catId]);
        $categoria = $q->fetch();
        if (!$categoria) {
            $this->render('errors/404', ['title' => 'Categoría no encontrada']);
            return;
        }

        // Posts con conteo de comentarios
        $p = $this->pdo->prepare('
            SELECT p.*,
                   (SELECT COUNT(*) FROM Comments c WHERE c.post_id = p.post_id) AS comments_count
            FROM Posts p
            WHERE p.category_id = ?
            ORDER BY p.created_at DESC
        ');
        $p->execute([$catId]);
        $posts = $p->fetchAll();

        $this->render('categoria/show', [
            'title'              => 'Categoría: ' . ($categoria['name'] ?? 'Sin nombre'),
            'categoria'          => $categoria,
            'categoriaId'        => $catId,                 // clave para la vista
            'posts'              => $posts,
            'basePath'           => $this->getBasePath(),
            'anchorComentar'     => '#comentar',
            'anchorComentarios'  => '#comentarios',
        ]);
    }

    // POST /categoria/:id/comentarios
    public function storeComment($id): void
    {
        $catId  = $this->normalizeId($id);
        $postId = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;
        $text   = trim($_POST['comment_text'] ?? '');
        $userId = $this->currentUserId(); // usa la función unificada

        // Reglas básicas
        if (!$userId) {
            $_SESSION['flash_error'][] = 'Debes iniciar sesión para comentar.';
            $this->redirectCategoria($catId, '#comentar');
            return;
        }

        if ($catId <= 0 || $postId <= 0 || $text === '') {
            $_SESSION['flash_error'][] = 'Datos incompletos.';
            $this->redirectCategoria($catId, '#comentar');
            return;
        }

        // Validar que el post pertenece a la categoría
        $chk = $this->pdo->prepare('SELECT 1 FROM Posts WHERE post_id=? AND category_id=?');
        $chk->execute([$postId, $catId]);
        if (!$chk->fetchColumn()) {
            $_SESSION['flash_error'][] = 'El post no pertenece a esta categoría.';
            $this->redirectCategoria($catId, '#comentar');
            return;
        }

        // Insertar comentario
        $ins = $this->pdo->prepare('INSERT INTO Comments (post_id, user_id, comment_text) VALUES (?,?,?)');
        $ins->execute([$postId, $userId, $text]);

        $_SESSION['flash_success'][] = 'Comentario publicado.';
        $this->redirectCategoria($catId, '#comentarios'); // o '#comentar'
    }
}

