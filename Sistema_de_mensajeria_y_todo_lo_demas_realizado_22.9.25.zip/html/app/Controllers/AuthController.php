<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\User;
use App\Models\PasswordReset;
use App\Services\Mailer;          // opcional: si no existe, se loguea el link
use App\Core\Session;             // opcional
use App\Services\AuthService;     // opcional
use App\Models\MessageRecipient;  // opcional (contador de no leídos)

class AuthController extends Controller
{
    private \PDO $pdo;
    protected $session = null;
    protected $authSvc = null;

    public function __construct()
    {
        if (method_exists('App\Core\Controller', '__construct')) parent::__construct();
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

        // PDO base
        $this->pdo = Database::getConnection();
        $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
        $this->pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);

        // Opcionales
        if (class_exists(Session::class))       $this->session = new Session();
        if (class_exists(AuthService::class))   $this->authSvc = new AuthService($this->session ?? null);
    }

    /* ===========================
       LOGIN / LOGOUT / REGISTER
       =========================== */
    public function showLogin()
    {
        if ($this->isAuthenticated()) {
            $next = $this->safeNext($_GET['next'] ?? '');
            return $this->redirect($next ?: '/dashboard');
        }
        $next = $this->safeNext($_GET['next'] ?? '');
        return $this->view('auth/login', ['title' => 'Iniciar Sesión', 'next' => $next]);
    }

    public function login()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

        $email    = trim($_POST['email'] ?? '');
        $password = (string)($_POST['password'] ?? '');
        $next     = $this->safeNext($_POST['next'] ?? '');

        // 1) Si existe AuthService
        if ($this->authSvc && method_exists($this->authSvc, 'attempt')) {
            $user = $this->authSvc->attempt($email, $password);
            if (!$user) {
                $this->flash('error', 'Credenciales incorrectas');
                return $this->view('auth/login', ['title'=>'Iniciar Sesión', 'next'=>$next, 'input'=>['email'=>$email]]);
            }
            $_SESSION['auth'] = ['check'=>true, 'user'=>$this->normalizeUser($user)];
            $_SESSION['user'] = $_SESSION['auth']['user'];

            $this->setUnreadFlashes();
            return $this->redirect($next ?: '/dashboard');
        }

        // 2) Fallback directo a DB (tabla Users)
        $st = $this->pdo->prepare("
            SELECT user_id, username, email, password, rol_id, created_at
              FROM Users
             WHERE email = :e
             LIMIT 1
        ");
        $st->execute([':e'=>$email]);
        $row = $st->fetch();

        $ok = false;
        if ($row) {
            $hash = (string)$row['password'];
            if (preg_match('/^\$2[ayb]\$/', $hash)) $ok = password_verify($password, $hash); // bcrypt
            else $ok = hash_equals($hash, $password); // legacy texto plano
        }

        if (!$ok) {
            $this->flash('error', 'Credenciales inválidas');
            return $this->view('auth/login', ['title'=>'Iniciar Sesión', 'next'=>$next, 'input'=>['email'=>$email]]);
        }

        $_SESSION['auth'] = [
            'check' => true,
            'user'  => [
                'user_id'    => (int)$row['user_id'],
                'username'   => (string)$row['username'],
                'email'      => (string)$row['email'],
                'rol_id'     => (int)$row['rol_id'],
                'created_at' => (string)$row['created_at'],
            ],
        ];
        $_SESSION['user'] = $_SESSION['auth']['user'];

        $this->setUnreadFlashes();

        if (!$next || $this->isLoginPath($next)) $next = '/dashboard';
        return $this->redirect($next);
    }

    private function setUnreadFlashes(): void
    {
        $uid = (int)($_SESSION['auth']['user']['user_id'] ?? 0);
        if ($uid <= 0) return;

        $unread = 0;
        if (class_exists(MessageRecipient::class)) {
            if (method_exists(MessageRecipient::class, 'unreadCountForUser')) {
                $unread = MessageRecipient::unreadCountForUser($uid);
            } elseif (method_exists(MessageRecipient::class, 'unreadCount')) {
                $unread = MessageRecipient::unreadCount($uid);
            }
        }
        $_SESSION['inbox_unread'] = $unread;

        if ($unread > 0) {
            $msg = ($unread === 1) ? "Tienes 1 mensaje nuevo." : "Tienes {$unread} mensajes nuevos.";
            $this->flash('info', $msg);
        }
    }

    public function showRegister()
    {
        if ($this->isAuthenticated()) return $this->redirect('/dashboard');
        return $this->view('auth/register', ['title'=>'Registro de Usuario']);
    }

    public function register()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

        $name             = trim($_POST['name'] ?? '');
        $email            = trim($_POST['email'] ?? '');
        $password         = (string)($_POST['password'] ?? '');
        $password_confirm = (string)($_POST['password_confirm'] ?? '');

        $errors = [];
        if ($name === '' || mb_strlen($name) < 3)            $errors['name'] = 'Mínimo 3 caracteres';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL))      $errors['email'] = 'Email inválido';
        if (mb_strlen($password) < 4)                        $errors['password'] = 'Mínimo 4 caracteres';
        if ($password_confirm !== $password)                 $errors['password_confirm'] = 'Las contraseñas no coinciden';

        if (!$errors) {
            $existsU = $this->exists('username', $name);
            $existsE = $this->exists('email', $email);
            if ($existsU) $errors['name']  = 'Este nombre de usuario ya está en uso';
            if ($existsE) $errors['email'] = 'Este email ya está en uso';
        }

        if ($errors) {
            $this->flash('error', 'Revisa los errores del formulario');
            return $this->view('auth/register', [
                'title'=>'Registro de Usuario', 'errors'=>$errors, 'input'=>['name'=>$name,'email'=>$email]
            ]);
        }

        try {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $st = $this->pdo->prepare("INSERT INTO Users (username, email, password, rol_id, created_at) VALUES (:u,:e,:p,2,NOW())");
            $st->execute([':u'=>$name, ':e'=>$email, ':p'=>$hash]);
            $userId = (int)$this->pdo->lastInsertId();
        } catch (\PDOException $e) {
            if ($e->getCode() === '23000') {
                $msg = $e->getMessage();
                $errors = [];
                if (stripos($msg, "for key 'username'") !== false) $errors['name']  = 'Nombre en uso';
                if (stripos($msg, "for key 'email'")    !== false) $errors['email'] = 'Email en uso';
                if (!$errors) { $errors['name']='Usuario duplicado'; $errors['email']='Email duplicado'; }
                $this->flash('error', 'El usuario ya está registrado');
                return $this->view('auth/register', [
                    'title'=>'Registro de Usuario','errors'=>$errors,'input'=>['name'=>$name,'email'=>$email]
                ]);
            }
            throw $e;
        }

        $_SESSION['auth'] = [
            'check' => true,
            'user'  => ['user_id'=>$userId,'username'=>$name,'email'=>$email,'rol_id'=>2,'created_at'=>date('Y-m-d H:i:s')],
        ];
        $_SESSION['user'] = $_SESSION['auth']['user'];

        $this->flash('success','Registro correcto. ¡Bienvenid@!');
        return $this->redirect('/dashboard');
    }

    public function logout()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        $_SESSION = []; session_destroy();
        return $this->redirect('/login');
    }

    private function exists(string $field, string $value): bool
    {
        $allowed = ['username','email'];
        if (!in_array($field, $allowed, true)) return false;
        $st = $this->pdo->prepare("SELECT 1 FROM Users WHERE {$field} = :v LIMIT 1");
        $st->execute([':v'=>$value]);
        return (bool)$st->fetchColumn();
    }

    private function normalizeUser($u): array
    {
        if (is_object($u)) $u = (array)$u;
        return [
            'user_id'    => (int)($u['user_id'] ?? $u['id'] ?? 0),
            'username'   => (string)($u['username'] ?? $u['name'] ?? ''),
            'email'      => (string)($u['email'] ?? ''),
            'rol_id'     => (int)($u['rol_id'] ?? $u['role_id'] ?? 0),
            'created_at' => (string)($u['created_at'] ?? date('Y-m-d H:i:s')),
        ];
    }

    private function isAuthenticated(): bool
    {
        return (!empty($_SESSION['auth']['check']) && !empty($_SESSION['auth']['user'])) || (!empty($_SESSION['user']));
    }
    private function isLoginPath(string $path): bool
    {
        $p = parse_url($path, PHP_URL_PATH) ?: $path;
        return (bool)preg_match('#^/login/?$#', $p);
    }
    private function safeNext(string $next): string
    {
        $next = trim($next);
        if ($next === '' || $this->isLoginPath($next)) return '';
        $parts = parse_url($next);
        if (!$parts) return '';
        if (!empty($parts['scheme']) || !empty($parts['host'])) return '';
        $path  = $parts['path']  ?? '/dashboard';
        $query = isset($parts['query']) ? ('?'.$parts['query']) : '';
        return $path.$query;
    }

    /* ===========================
       FORGOT / RESET PASSWORD
       =========================== */
    public function forgot()
    {
        // Vista con el form de email
        return $this->view('auth/forgot', ['title' => 'Olvidé mi contraseña']);
    }

    public function forgotPost()
    {
        $email = trim($_POST['email'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $this->backWith('error', 'Ingresa un email válido.');
        }

        $user = (new User())->findByEmail($email);
        // Para no filtrar si existe o no, damos misma respuesta
        $token = bin2hex(random_bytes(32)); // token en claro para URL
        if ($user) {
            // elimina previos y crea nuevo
            PasswordReset::deleteForEmail($email);
            PasswordReset::createForEmail($email, $token, 30);

            // link reset
            $host = ($_SERVER['HTTP_HOST'] ?? 'localhost');
            $link = "http://{$host}/reset?email=".urlencode($email)."&token={$token}";

            // envía email (si en localhost no sale, al menos mostramos log)
            $subject = "Resetea tu contraseña";
            $body = "Hola, para restablecer tu contraseña haz clic aquí:\n{$link}\n\nEste enlace vence en 30 minutos.";
            try {
                if (class_exists(Mailer::class)) {
                    (new Mailer())->send($email, $subject, nl2br($body));
                } else {
                    error_log("[FORGOT] Reset link: ".$link);
                }
            } catch (\Throwable $e) {
                error_log("[FORGOT ERROR] ".$e->getMessage());
            }
        }

        return $this->redirect('/forgot?sent=1'); // respuesta genérica
    }

    public function reset()
    {
        $email = $_GET['email'] ?? '';
        $token = $_GET['token'] ?? '';
        // Mostramos form; la validación real ocurre al enviar
        return $this->view('auth/reset', [
            'title' => 'Restablecer contraseña',
            'email' => $email,
            'token' => $token
        ]);
    }

    public function resetPost()
    {
        $email = $_POST['email'] ?? '';
        $token = $_POST['token'] ?? '';
        $pass  = $_POST['password'] ?? '';
        $pass2 = $_POST['password_confirm'] ?? '';

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($token) < 20) {
            return $this->backWith('error', 'Enlace inválido.');
        }
        if ($pass !== $pass2 || strlen($pass) < 6) {
            return $this->backWith('error', 'La contraseña no coincide o es muy corta (mín. 6).');
        }

        $valid = PasswordReset::findValid($email, $token);
        if (!$valid) {
            return $this->backWith('error', 'El enlace es inválido o ha expirado.');
        }

        // Actualiza password
        $hash = password_hash($pass, PASSWORD_BCRYPT);
        $this->pdo->prepare("UPDATE Users SET password = ? WHERE email = ?")->execute([$hash, $email]);

        // borra tokens de ese email
        PasswordReset::deleteForEmail($email);

        return $this->redirect('/login?reset=1');
    }

    /* ===========================
       Helpers locales (fallbacks)
       =========================== */
    private function backWith(string $type, string $msg)
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        $_SESSION['flash'][$type] = $msg;
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '/'));
        exit;
    }

    public function view($template, $data = [])
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent,'view')) return parent::view($template,$data);
        $templateName = is_string($template) ? $template : (is_array($template) ? '[array]' : strval($template));
        $base = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 2);
        $file = $base.'/app/Views/'.ltrim($templateName,'/').'.php';
        if (!is_file($file)) { http_response_code(500); echo "<h1>Vista no encontrada</h1><p>".htmlspecialchars($templateName,ENT_QUOTES,'UTF-8').".php</p>"; return null; }
        extract(is_array($data)?$data:[], EXTR_SKIP);
        ob_start(); include $file; $out = ob_get_clean(); echo $out;
        return null;
    }

    public function redirect($url)
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent,'redirect')) return parent::redirect($url);

        if (is_array($url)) {
            $path=''; $query=[];
            if (isset($url['path'])) $path=(string)$url['path'];
            elseif (isset($url[0]))  $path=(string)$url[0];
            if (isset($url['query']) && is_array($url['query'])) $query=$url['query'];
            elseif (isset($url[1]) && is_array($url[1]))         $query=$url[1];
            $url = $path.($query?('?'.http_build_query($query)):'');
        } else $url = (string)$url;

        $current = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $target  = parse_url($url, PHP_URL_PATH) ?: $url;
        if ($current === $target) {
            http_response_code(409);
            echo "<h1>No se puede redirigir</h1><p>Ya estás en <code>".htmlspecialchars($current,ENT_QUOTES,'UTF-8')."</code>.</p>";
            return null;
        }
        header('Location: '.$url); exit;
    }

    public function flash($key,$message)
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent,'flash')) return parent::flash($key,$message);
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        $_SESSION['flash'][$key] = $message; return null;
    }

    public function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

