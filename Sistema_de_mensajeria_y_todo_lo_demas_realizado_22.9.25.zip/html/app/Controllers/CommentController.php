<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Models\Comment;

class CommentController extends Controller
{
    protected $session; // Manejo de sesiones
    protected $comment; // Modelo de comentarios

    public function __construct()
    {
        parent::__construct();
        // Inicializar dependencias
        if (!$this->session instanceof Session) {
            $this->session = new Session();
        }
        if (!$this->comment instanceof Comment) {
            $this->comment = new Comment();
        }
    }

    /**
     * POST /comments
     * Guarda un comentario enviado desde un formulario genérico
     */
    public function store()
    {
        $bp     = $this->basePath(); // Ruta base para redirecciones
        $userId = $this->getUserId(); // Usuario logueado
        if (!$userId) {
            $this->session->flash('error', 'Debes iniciar sesión para comentar');
            return $this->redirect("$bp/login");
        }

        // ID del post y texto del comentario
        $postId = (int)$this->inputValue('post_id', 0);
        $text   = trim((string)$this->inputValue('comment_text', $this->inputValue('body', '')));

        // Validaciones
        if ($postId <= 0 || mb_strlen($text) < 2) {
            $this->session->flash('error', 'Comentario inválido');
            return $this->redirect("$bp/post/{$postId}#comentar");
        }

        // Verifica que el post exista
        if (!$this->postExists($postId)) {
            $this->session->flash('error', 'El post no existe');
            return $this->redirect("$bp/");
        }

        try {
            // Inserta el comentario
            if (!$this->persist($postId, $text, $userId)) {
                throw new \RuntimeException('Insert devolvió false');
            }
            $this->session->flash('success', 'Comentario publicado');
            return $this->redirect("$bp/post/{$postId}#comentarios");
        } catch (\Throwable $e) {
            // Registra error y devuelve al formulario
            error_log('[CommentsController.store] ' . $e->getMessage());
            $this->session->flash('error', 'No se pudo guardar el comentario');
            return $this->redirect("$bp/post/{$postId}#comentar");
        }
    }

    /**
     * POST /posts/:id/comments
     * Guarda un comentario asociado a un post específico
     */
    public function storeForPost($postId)
    {
        $bp     = $this->basePath();
        $userId = $this->getUserId();
        if (!$userId) {
            $this->session->flash('error', 'Debes iniciar sesión para comentar');
            return $this->redirect("$bp/login");
        }

        $postId = (int)$postId;
        $text   = trim((string)$this->inputValue('comment_text', $this->inputValue('body', '')));

        if ($postId <= 0 || mb_strlen($text) < 2) {
            $this->session->flash('error', 'Comentario inválido');
            return $this->redirect("$bp/post/{$postId}#comentar");
        }

        if (!$this->postExists($postId)) {
            $this->session->flash('error', 'El post no existe');
            return $this->redirect("$bp/");
        }

        try {
            if (!$this->persist($postId, $text, $userId)) {
                throw new \RuntimeException('Insert devolvió false');
            }
            $this->session->flash('success', 'Comentario publicado');
            return $this->redirect("$bp/post/{$postId}#comentarios");
        } catch (\Throwable $e) {
            error_log('[CommentsController.storeForPost] ' . $e->getMessage());
            $this->session->flash('error', 'No se pudo guardar el comentario');
            return $this->redirect("$bp/post/{$postId}#comentar");
        }
    }

    /* ===== Helpers ===== */

    // Devuelve la ruta base de la aplicación
    private function basePath(): string
    {
        return rtrim($this->basePath ?? '', '/');
    }

    // Obtiene un valor del formulario POST de manera segura
    private function inputValue(string $key, $default = null)
    {
        if (method_exists($this, 'input')) {
            $val = $this->input($key);
            return $val !== null ? $val : $default;
        }
        return $_POST[$key] ?? $default;
    }

    // Obtiene el ID del usuario actual desde sesión o Auth
    private function getUserId(): int
    {
        if (property_exists($this, 'auth') && $this->auth && method_exists($this->auth, 'user')) {
            $u = $this->auth->user();
            if (!empty($u['id'])) return (int)$u['id'];
        }
        return (int)($this->session->get('auth_user_id') ?? 0);
    }

    // Verifica si un post existe (usa modelo Post si está disponible)
    private function postExists(int $postId): bool
    {
        if ($postId <= 0) return false;
        if (property_exists($this, 'postModel') && $this->postModel && method_exists($this->postModel, 'exists')) {
            try {
                return (bool)$this->postModel->exists($postId);
            } catch (\Throwable $e) {
                return true; // Si falla, asumimos que existe
            }
        }
        return true;
    }

    // Persiste el comentario en la base de datos
    private function persist(int $postId, string $text, int $userId): bool
    {
        return (bool)$this->comment->create([
            'post_id'      => $postId,
            'user_id'      => $userId,
            'comment_text' => $text,
        ]);
    }
}

