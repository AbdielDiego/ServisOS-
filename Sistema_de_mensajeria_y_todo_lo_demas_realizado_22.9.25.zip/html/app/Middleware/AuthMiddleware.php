<?php
namespace App\Middleware;

class AuthMiddleware
{
    /**
     * Tu Router llama a handle() SIN argumentos.
     * Este middleware valida sesión y, si no existe,
     * redirige a /login con ?next=<ruta-actual>, evitando bucles.
     */
    public function handle()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

        $isAuth = (!empty($_SESSION['auth']['check']) && !empty($_SESSION['auth']['user']))
               || (!empty($_SESSION['user']));

        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

        // Rutas públicas que jamás deben redirigir (evita loops)
        $public = [
            '/login',
            '/register',
            '/logout',
        ];

        // Permitir assets estáticos
        if (preg_match('#^/(css|js|img|images|assets)/#', $path)) {
            return true;
        }

        // Si es pública, continuar
        if (in_array($path, $public, true)) {
            return true;
        }

        // Si NO hay sesión, redirigir a /login con next
        if (!$isAuth) {
            $nextUrl = $_SERVER['REQUEST_URI'] ?? '/dashboard';
            // Anti-loop: si ya apunta a /login, no sigas redirigiendo
            if ($path !== '/login') {
                header('Location: /login?next=' . urlencode($nextUrl));
                exit;
            }
        }

        return true;
    }
}


