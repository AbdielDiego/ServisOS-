<?php
namespace App\Middleware;

class AdminMiddleware
{
    /** ID de rol administrador (según tu tabla Users: rol_id=1) */
    public const ADMIN_ROLE_ID = 1;

    /** Middleware estático (el router lo invoca como [AdminMiddleware::class]) */
    public static function handle(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        // Estado de sesión compatible con tu AuthController
        $user = $_SESSION['auth']['user'] ?? $_SESSION['user'] ?? null;

        // No logueado -> ir a login con next
        if (!$user) {
            header('Location: /login?next=' . urlencode($_SERVER['REQUEST_URI'] ?? '/'));
            exit;
        }

        // Verificar rol admin
        $role = (int)($user['rol_id'] ?? $user['role_id'] ?? $user['role'] ?? 0);
        if ($role !== self::ADMIN_ROLE_ID) {
            $_SESSION['flash']['error'] = 'Acceso denegado. No tienes permisos para ver esta página.';
            http_response_code(403);
            header('Location: /'); // o la ruta que prefieras
            exit;
        }
        // Si llega aquí, es admin -> el router continúa con el controlador
    }

    /** Compatibilidad: si tu router instancia y ejecuta como invocable */
    public function __invoke(): void
    {
        self::handle();
    }
}

