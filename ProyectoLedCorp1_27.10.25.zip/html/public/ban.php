<?php
declare(strict_types=1);

/**
 * Banear usuario: mueve sus datos a BanUsers sin borrar de Users.
 * Query params: ?id= | ?username= | ?email= (alias ?gmail=), opcional ?reason= y ?redirect=
 */

if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

/* =======================
 * Bootstrap del proyecto
 * ======================= */
$ROOT = dirname(__DIR__);

// 1) Autoload de Composer (si existe)
$autoload = $ROOT . '/vendor/autoload.php';
if (is_file($autoload)) {
    require_once $autoload;
}

// 2) Cargar Database si no vino por autoload
if (!class_exists('\App\Core\Database')) {
    $dbClass = $ROOT . '/app/Core/Database.php';
    if (is_file($dbClass)) require_once $dbClass;

    // Configs posibles (si las usas)
    $cfg1 = $ROOT . '/config/database.php';
    $cfg2 = $ROOT . '/app/config/database.php';
    if (is_file($cfg1)) require_once $cfg1;
    if (is_file($cfg2)) require_once $cfg2;
}

/* =======================
 * Conexión PDO
 * ======================= */
function pdo(): PDO {
    // Preferir la conexión centralizada de tu app
    if (class_exists('\App\Core\Database') && method_exists('\App\Core\Database', 'getConnection')) {
        $pdo = \App\Core\Database::getConnection();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        return $pdo;
    }

    // Fallback: NUNCA root; usar el usuario de app que ya creaste
    $DB_HOST = getenv('DB_HOST') ?: '127.0.0.1';
    $DB_NAME = getenv('DB_NAME') ?: 'proyutu';
    $DB_USER = getenv('DB_USER') ?: 'appuser';
    $DB_PASS = getenv('DB_PASS') ?: 'apppass';

    $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4";
    return new PDO($dsn, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
}

/* =======================
 * Crear tabla BanUsers si no existe
 * ======================= */
function ensureBanTable(PDO $pdo): void {
    $sql = <<<SQL
CREATE TABLE IF NOT EXISTS `BanUsers` (
  `user_id`   INT(11)      NOT NULL,
  `username`  VARCHAR(50)  NOT NULL,
  `email`     VARCHAR(100) NOT NULL,
  `reason`    VARCHAR(255) DEFAULT NULL,
  `banned_by` INT(11)      DEFAULT NULL,
  `banned_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  KEY `email` (`email`),
  KEY `banned_by` (`banned_by`),
  CONSTRAINT `BanUsers_user_fk`
      FOREIGN KEY (`user_id`) REFERENCES `Users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `BanUsers_admin_fk`
      FOREIGN KEY (`banned_by`) REFERENCES `Users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;
    $pdo->exec($sql);
}

/* =======================
 * Leer parámetros
 * ======================= */
$rawId    = isset($_REQUEST['id']) ? trim((string)$_REQUEST['id']) : '';
$username = isset($_REQUEST['username']) ? trim((string)$_REQUEST['username']) : '';
$email    = isset($_REQUEST['email']) ? trim((string)$_REQUEST['email']) : '';
if ($email === '' && isset($_REQUEST['gmail'])) { // alias admitido
    $email = trim((string)$_REQUEST['gmail']);
}
$reason   = isset($_REQUEST['reason']) ? trim((string)$_REQUEST['reason']) : '';

if ($rawId === '' && $username === '' && $email === '') {
    http_response_code(400);
    exit('Faltan parámetros: envía id, username o email/gmail.');
}
if ($rawId !== '' && !ctype_digit($rawId)) {
    http_response_code(400);
    exit('Parámetro id inválido.');
}

/* =======================
 * Lógica de baneo
 * ======================= */
try {
    $pdo = pdo();
    ensureBanTable($pdo);

    // Construir filtro (AND con lo que venga)
    $where  = [];
    $params = [];
    if ($rawId !== '')    { $where[] = 'user_id = :id';   $params[':id'] = (int)$rawId; }
    if ($username !== '') { $where[] = 'username = :u';   $params[':u']  = $username; }
    if ($email !== '')    { $where[] = 'email = :e';      $params[':e']  = $email; }

    $sqlFind = 'SELECT user_id, username, email FROM Users WHERE ' . implode(' AND ', $where) . ' LIMIT 1';
    $st = $pdo->prepare($sqlFind);
    $st->execute($params);
    $user = $st->fetch();

    if (!$user) {
        http_response_code(404);
        exit('Usuario no encontrado con los criterios dados.');
    }

    $uid = (int)$user['user_id'];
    $un  = (string)$user['username'];
    $em  = (string)$user['email'];

    // Quién banea
    $adminId = null;
    if (!empty($_SESSION['user']['user_id'])) {
        $adminId = (int)$_SESSION['user']['user_id'];
    } elseif (!empty($_SESSION['user_id']) && ctype_digit((string)$_SESSION['user_id'])) {
        $adminId = (int)$_SESSION['user_id'];
    }

    // Insert / Update
    $sqlBan = "
        INSERT INTO BanUsers (user_id, username, email, reason, banned_by, banned_at)
        VALUES (:uid, :un, :em, :rs, :by, NOW())
        ON DUPLICATE KEY UPDATE
            username  = VALUES(username),
            email     = VALUES(email),
            reason    = VALUES(reason),
            banned_by = VALUES(banned_by),
            banned_at = NOW()
    ";
    $pdo->prepare($sqlBan)->execute([
        ':uid' => $uid,
        ':un'  => $un,
        ':em'  => $em,
        ':rs'  => ($reason !== '' ? $reason : null),
        ':by'  => $adminId,
    ]);

    // Redirección
    $redir = isset($_GET['redirect']) ? (string)$_GET['redirect'] : '/usuarios';
    $sep   = (strpos($redir, '?') !== false) ? '&' : '?';
    header('Location: ' . $redir . $sep . 'banned=1&user=' . urlencode($un));
    exit;

} catch (PDOException $e) {
    http_response_code(500);
    echo "<h1>Error de base de datos</h1>";
    echo "<p>{$e->getMessage()}</p>";
    echo "<p><small>Comprueba que <code>App\\Core\\Database::getConnection()</code> esté disponible o que las variables de entorno DB_*
    (o el fallback appuser/apppass) sean correctas. Evita usar root con auth_socket.</small></p>";
    exit;
}

