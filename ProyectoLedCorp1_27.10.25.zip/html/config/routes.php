<?php
use App\Middleware\AuthMiddleware;
use App\Middleware\AdminMiddleware;

/* ======================= Rutas públicas ======================= */
$router->addRoute('GET',  '/',               'HomeController@index');
$router->addRoute('GET',  '/apicategorias',  'ApiController@index');
$router->addRoute('POST', '/apicategorias',  'ApiController@index');

$router->addRoute('GET',  '/login',          'AuthController@showLogin');
$router->addRoute('POST', '/login',          'AuthController@login');
$router->addRoute('GET',  '/logout',         'AuthController@logout');
$router->addRoute('GET',  '/register',       'AuthController@showRegister');
$router->addRoute('POST', '/register',       'AuthController@register');

/* =================== Recuperar contraseña ==================== */
$router->addRoute('GET',  '/forgot',         'AuthController@forgot');
$router->addRoute('POST', '/forgot',         'AuthController@forgotPost');
$router->addRoute('GET',  '/reset',          'AuthController@reset');
$router->addRoute('POST', '/reset',          'AuthController@resetPost');

/* ============================ Posts ========================== */
$router->addRoute('GET', '/post',                 'PostController@index',   [AuthMiddleware::class]);
$router->addRoute('GET', '/post/paginar/:pagina', 'PostController@index',   [AuthMiddleware::class]);

// ---- Rutas ESPECÍFICAS primero (evita que /post/:id las capture) ----
$router->addRoute('GET', '/post/detail',          'PostController@detail',  [AuthMiddleware::class]);
$router->addRoute('GET', '/post/detail.php',      'PostController@detail',  [AuthMiddleware::class]); // compat
$router->addRoute('GET', '/post/:id/comentar',    'PostController@comentar',[AuthMiddleware::class]); // comentar

// ---- Vista de post con comentarios ----
$router->addRoute('GET', '/post/:id',             'PostController@show',    [AuthMiddleware::class]);

/* ========================= Categorías ======================== */
$router->addRoute('GET',  '/categoria/:id',             'CategoriaController@show');
$router->addRoute('POST', '/categoria/:id/comentarios', 'CategoriaController@storeComment', [AuthMiddleware::class]);

/* ========================= Comentarios ======================= */
// Compat y ruta principal del formulario dentro del post
$router->addRoute('POST', '/comments',               'CommentController@store',        [AuthMiddleware::class]);
$router->addRoute('POST', '/posts/:id/comments',     'CommentController@storeForPost', [AuthMiddleware::class]);
$router->addRoute('POST', '/comments/:id/delete',    'CommentController@destroy',      [AuthMiddleware::class]);
$router->addRoute('POST', '/comment/delete',         'CommentController@delete',       [AuthMiddleware::class]);

/* =========================== Rating ========================== */
// Nuevo sistema de estrellas (PHP puro, sin JS)
$router->addRoute('POST', '/rating',                'RatingController@rate',        [AuthMiddleware::class]);
// Alias legacy para no romper nada existente (si algo sigue llamando al endpoint viejo)
$router->addRoute('POST', '/api/rate/simple',       'RatingController@rateSimple',  [AuthMiddleware::class]);

/* ========================== MiNuevo ========================== */
$router->addRoute('GET',  '/minuevo',          'MinuevoController@index');
$router->addRoute('GET',  '/minuevo/crear',    'MinuevoController@create', [AuthMiddleware::class]);
$router->addRoute('POST', '/minuevo/guardar',  'MinuevoController@store',  [AuthMiddleware::class]);
$router->addRoute('GET',  '/article/:slug',    'MinuevoController@show');
$router->addRoute('POST', '/article/:id/rate', 'MinuevoController@rate',   [AuthMiddleware::class]);

/* ============================ Mensajes ======================= */
$router->addRoute('GET',  '/messages/inbox',        'MessageController@inbox',    [AuthMiddleware::class]);
$router->addRoute('GET',  '/messages/sent',         'MessageController@sent',     [AuthMiddleware::class]);
$router->addRoute('GET',  '/messages/compose',      'MessageController@compose',  [AuthMiddleware::class]);
$router->addRoute('GET',  '/messages/reply',        'MessageController@reply',    [AuthMiddleware::class]);
$router->addRoute('GET',  '/messages/reply.php',    'MessageController@reply',    [AuthMiddleware::class]); // compat
$router->addRoute('GET',  '/messages/contact',      'MessageController@contact',  [AuthMiddleware::class]);
$router->addRoute('GET',  '/messages/contact.php',  'MessageController@contact',  [AuthMiddleware::class]); // compat
$router->addRoute('POST', '/messages',              'MessageController@store',    [AuthMiddleware::class]);
$router->addRoute('GET',  '/messages/:id',          'MessageController@show',     [AuthMiddleware::class]);
$router->addRoute('POST', '/messages/read/:id',     'MessageController@markRead', [AuthMiddleware::class]);
$router->addRoute('POST', '/messages/:id/reply',    'MessageController@replyPost',[AuthMiddleware::class]);
$router->addRoute('POST', '/messages/delete/:id',   'MessageController@delete',   [AuthMiddleware::class]);
$router->addRoute('GET',  '/messages/delete/:id',   'MessageController@delete',   [AuthMiddleware::class]); // compat GET

/* ====================== Admin: Usuarios ====================== */
$router->addRoute('GET', '/usuarios', 'UsuariosController@index', [AdminMiddleware::class]);
$router->addRoute('GET', '/users',    'UsuariosController@index', [AdminMiddleware::class]); // alias útil

// Banear
$router->addRoute('GET',  '/usuarios/ban/:id', 'UsuariosController@ban',     [AdminMiddleware::class]);
$router->addRoute('POST', '/usuarios/ban/:id', 'UsuariosController@banPost', [AdminMiddleware::class]);
$router->addRoute('GET',  '/usuarios/ban',     'UsuariosController@ban',     [AdminMiddleware::class]);
$router->addRoute('POST', '/usuarios/ban',     'UsuariosController@banPost', [AdminMiddleware::class]);

// Eliminar usuario (flujo principal + compat)
$router->addRoute('GET',  '/users/delete/:id', 'UsuariosController@delete',  [AdminMiddleware::class]);  // confirmación
$router->addRoute('POST', '/users/delete/:id', 'UsuariosController@destroy', [AdminMiddleware::class]);  // elimina
$router->addRoute('GET',  '/deleteuser',       'UsuariosController@destroy', [AdminMiddleware::class]); // /deleteuser?id=41
$router->addRoute('POST', '/deleteuser',       'UsuariosController@destroy', [AdminMiddleware::class]);
$router->addRoute('GET',  '/deleteuser.php',   'UsuariosController@destroy', [AdminMiddleware::class]); // compat
$router->addRoute('POST', '/deleteuser.php',   'UsuariosController@destroy', [AdminMiddleware::class]);

/* ============ Admin: Baneados (Index + Unban) ============ */
$router->addRoute('GET', '/usuarios/baneados',          'BanUsersController@index', [AdminMiddleware::class]);
$router->addRoute('GET', '/usuarios/BanUsersIndex',     'BanUsersController@index', [AdminMiddleware::class]);
$router->addRoute('GET', '/usuarios/BanUsersIndex.php', 'BanUsersController@index', [AdminMiddleware::class]); // compat
$router->addRoute('GET', '/banusers.php',               'BanUsersController@index', [AdminMiddleware::class]); // compat
$router->addRoute('GET', '/ban',                        'BanUsersController@index', [AdminMiddleware::class]); // atajo
$router->addRoute('POST','/unban',     'BanUsersController@unban', [AdminMiddleware::class]);
$router->addRoute('GET', '/unban',     'BanUsersController@unban', [AdminMiddleware::class]); // compat
$router->addRoute('GET', '/unban/:id', 'BanUsersController@unban', [AdminMiddleware::class]);
$router->addRoute('GET', '/unban.php', 'BanUsersController@unban', [AdminMiddleware::class]);

/* =========================== Otros =========================== */
$router->addRoute('GET',  '/dashboard',     'DashboardController@index',  [AuthMiddleware::class]);
$router->addRoute('GET',  '/dashboard/:id', 'DashboardController@show',   [AuthMiddleware::class]);
$router->addRoute('GET',  '/profile',       'ProfileController@index',    [AuthMiddleware::class]);
$router->addRoute('POST', '/profile',       'ProfileController@update',   [AuthMiddleware::class]);

