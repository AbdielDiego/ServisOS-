<link rel="stylesheet" href="/css/styles.css">
<?php
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$old   = $old   ?? [];
$error = $error ?? null;

// Prefills desde la URL: /messages/reply.php?to=...&subject=...
$prefillTo      = isset($_GET['to']) ? (string)$_GET['to'] : '';
$prefillSubject = isset($_GET['subject']) ? (string)$_GET['subject'] : '';
$title = 'Responder mensaje';
?>
<h1><?= h($title) ?></h1>

<?php if ($error): ?>
  <div class="alert error"><?= h($error) ?></div>
<?php endif; ?>

<form method="post" action="/messages">
  <label for="to_query"><strong>Para</strong> (usuario o email, separados por coma)</label>
  <input
    type="text"
    id="to_query"
    name="to_query"
    value="<?= h($old['to_query'] ?? $prefillTo) ?>"
    placeholder="p.ej. diego, maria@gmail.com, juanperez"
    style="width:100%;max-width:960px"
    required
  >

  <br><br>

  <label for="subject"><strong>Asunto</strong></label>
  <input
    type="text"
    id="subject"
    name="subject"
    value="<?= h($old['subject'] ?? $prefillSubject) ?>"
    style="width:100%;max-width:960px"
    required
  >

  <br><br>

  <label for="body"><strong>Mensaje</strong></label>
  <textarea
    id="body"
    name="body"
    rows="8"
    style="width:100%;max-width:960px"
    required
  ><?= h($old['body'] ?? '') ?></textarea>

  <br><br>
  <button type="submit">Enviar</button>
</form>

