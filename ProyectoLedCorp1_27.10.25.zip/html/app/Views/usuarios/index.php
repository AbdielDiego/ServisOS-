<?php
/** @var array  $datosTabla  */
/** @var string $titulo */
/** @var ?string $ok */
/** @var ?string $error */
/** @var ?string $emptyText */

if (!isset($titulo))     { $titulo = 'Usuarios'; }
if (!isset($emptyText))  { $emptyText = 'No hay usuarios'; }
?>
<section class="users-page">
  <h1 class="page-title"><?= htmlspecialchars($titulo) ?></h1>

  <div class="toolbar" style="margin:10px 0;">
    <a href="/usuarios/BanUsersIndex.php" class="btn btn-messages">Ver usuarios baneados</a>
  </div>

  <?php if (!empty($ok)): ?>
    <div class="alert alert-success"><?= htmlspecialchars($ok) ?></div>
  <?php endif; ?>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <?php if (empty($datosTabla)): ?>
    <h2 class="empty-state" style="font-weight:bold;"><?= htmlspecialchars($emptyText) ?></h2>
  <?php else: ?>

    <?php
      // Si tienes un componente de tabla, úsalo. Probamos mayúsculas/minúsculas.
      $tbUpper = defined('BASE_PATH') ? BASE_PATH . '/app/Views/components/tabla_usuarios.php' : __DIR__.'/../components/tabla_usuarios.php';
      $tbLower = defined('BASE_PATH') ? BASE_PATH . '/app/views/components/tabla_usuarios.php' : __DIR__.'/../components/tabla_usuarios.php';

      if (file_exists($tbUpper)) {
          require $tbUpper;
      } elseif (file_exists($tbLower)) {
          require $tbLower;
      } else {
          // Fallback: tabla mínima integrada
          ?>
          <table class="table">
            <thead>
              <tr>
                <th>Id del usuario</th>
                <th>Nombre del usuario</th>
                <th>Email del usuario</th>
                <th>Id del rol (1 admin)</th>
                <th>Fecha de creaciòn</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach ($datosTabla as $u): ?>
              <tr>
                <td><?= (int)$u['user_id'] ?></td>
                <td><?= htmlspecialchars($u['username']) ?></td>
                <td><?= htmlspecialchars($u['email']) ?></td>
                <td><?= (int)$u['role_id'] ?></td>
                <td><?= htmlspecialchars($u['created_at']) ?></td>
                <td>
                  <a href="/usuarios/ban/<?= (int)$u['user_id'] ?>">Banear</a>
                  &nbsp;|&nbsp;
                  <a href="/usuarios/delete/<?= (int)$u['user_id'] ?>" onclick="return confirm('¿Eliminar definitivamente?')">Eliminar</a>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
          <?php
      }
    ?>

  <?php endif; ?>
</section>

