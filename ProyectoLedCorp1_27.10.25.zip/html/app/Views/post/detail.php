<link rel="stylesheet" href="/css/contact.css">

<?php
/** @var array $post */
/** @var array $author */
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$title    = $post['title']   ?? $post['nombre'] ?? 'Detalle del servicio';
$desc     = $post['content'] ?? $post['descripcion'] ?? $post['description'] ?? '';
$username = $author['username'] ?? 'Desconocido';
$email    = $author['email']    ?? '';

/* ID real del post según tu esquema (Posts.post_id) con fallbacks */
$postId = (int)($post['post_id'] ?? ($post['id'] ?? ($_GET['id'] ?? 0)));

/* Querystring para /messages/contact */
$qs = http_build_query([
  'post_id' => $postId,
  'title'   => $title,
  // Si quieres forzar aún más (opcional):
  // 'username' => $username,
  // 'email'    => $email,
  // 'user_id'  => (int)($post['user_id'] ?? 0),
]);
?>
<h1><?= h($title) ?></h1>

<p>
  <strong>Creado por:</strong> <?= h($username) ?>
  <?php if ($email !== ''): ?>
    <small>(<?= h($email) ?>)</small>
  <?php endif; ?>
</p>

<hr>

<div class="post-body"><?= nl2br(h($desc)) ?></div>

<p style="margin-top:1rem">
  <!-- IMPORTANTE: ahora la URL incluye ?post_id=... -->
  <a class="btn-messages" href="/messages/contact?<?= $qs ?>">Enviar un mensaje</a>
</p>

<p style="margin-top:1rem">
  <a href="/post">Volver a servicios</a>
</p>

