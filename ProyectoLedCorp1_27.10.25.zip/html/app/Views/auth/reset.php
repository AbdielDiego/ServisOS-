<?php $this->layout('layouts/base', ['title' => $title ?? 'Restablecer contraseña']); ?>

<link rel="stylesheet" href="/css/styles.css">
<link rel="stylesheet" href="/css/login.css">

<h2>Restablecer contraseña</h2>

<form method="POST" action="/reset">
  <input type="hidden" name="email" value="<?= htmlspecialchars($email ?? '', ENT_QUOTES) ?>">
  <input type="hidden" name="token" value="<?= htmlspecialchars($token ?? '', ENT_QUOTES) ?>">

  <div class="field-pass">
    <label>Nueva contraseña:</label>
    <input type="password" name="password" required minlength="6" placeholder="Mínimo 6 caracteres">
    <button type="button" class="toggle-pass" aria-pressed="false" aria-label="Mostrar contraseña"></button>
    <small>Elige una contraseña segura.</small>
  </div>

  <div>
    <label>Confirmar contraseña:</label>
    <input type="password" name="password_confirm" required minlength="6" placeholder="Repite tu contraseña">
  </div>

  <div class="auth-extras" style="margin-top:-4px">
    <a href="/login">Ir al login</a>
  </div>

  <button type="submit"><span class="label">Guardar</span></button>
  <span class="shine" aria-hidden="true"></span>
</form>

<script>
  // ojito mostrar/ocultar
  const passField = document.querySelector('.field-pass input');
  const toggle = document.querySelector('.toggle-pass');
  if (toggle && passField){
    toggle.addEventListener('click', ()=>{
      const show = passField.type === 'password';
      passField.type = show ? 'text' : 'password';
      toggle.setAttribute('aria-pressed', show ? 'true' : 'false');
      passField.focus();
    });
  }
  // loader
  const btn = document.querySelector('button[type="submit"]');
  const form = document.querySelector('form');
  if (form && btn){
    form.addEventListener('submit', ()=>{
      btn.classList.add('is-loading');
      if (!btn.querySelector('.spinner')){
        const s = document.createElement('i'); s.className = 'spinner'; btn.appendChild(s);
      }
    }, {passive:true});
  }
</script>

