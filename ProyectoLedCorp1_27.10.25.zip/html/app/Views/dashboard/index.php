<?php
// $user viene normalizado desde el controller

// Función de ayuda para escapar valores HTML
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');

// Función local por si algún post no tiene 'slug'
$slugify = function (string $text): string {
    $text = trim($text);
    $text = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text) ?: $text;
    $text = strtolower($text);
    $text = preg_replace('/[^a-z0-9]+/i', '-', $text);
    $text = trim($text, '-');
    return $text ?: 'post';
};

// Construir link al último post (para botón "Ver mi último servicio")
$lastUrl = null;
if (!empty($my_posts)) {
    $p0   = $my_posts[0]; // primer post
    $slug = $p0['slug'] ?? ($slugify($p0['title'] ?? 'post') . '-' . (int)($p0['post_id'] ?? 0));
    $lastUrl = '/article/' . $slug;
}
?>
<!-- Enlazamos CSS global -->
<link rel="stylesheet" href="/css/styles.css">

<div class="dash-wrapper">
  <header class="dash-head">
    <h1>Mi perfil</h1>
    <?php if ($lastUrl): ?>
      <!-- Botón para ver el último servicio publicado -->
      <a class="btn" href="<?= $h($lastUrl) ?>">Ver mi último servicio</a>
    <?php endif; ?>
  </header>

  <!-- Bienvenida al usuario -->
  <p>Bienvenid@ a tu área privada, <strong class="username"><?= $h($user['username'] ?? '') ?></strong>.</p>
  <!-- Link al inicio con clase "active" si corresponde -->
  <a href="/" class="<?= ($currentUrl === '/' || $currentUrl === '') ? 'active' : '' ?>">Inicio</a>

  <!-- Enlaces al sistema de mensajería -->
  <p>Ahora puedes usar el sistema de mensajería interna:</p>
  <a href="/messages/compose" class="btn-messages">Enviar un mensaje</a>
  <a href="/messages/sent" class="btn-messages">Mensajes Enviados</a>
  <a href="/messages/inbox" class="btn-messages">Ver bandeja de entrada</a>

  <!-- Información del usuario -->
  <p>Tus datos:</p>
  <ul>
      <li>ID del Perfil: <?= $h($user['user_id'] ?? '') ?></li>
      <li>Fecha de Creación del perfil: <?= $h($user['created_at'] ?? '') ?></li>
      <li>Nombre de Usuario: <?= $h($user['username'] ?? '') ?></li>
      <li>Email: <?= $h($user['email'] ?? '') ?></li>
  </ul>

  <!-- Sección de publicaciones del usuario -->
  <section class="minuevo" style="margin-top:14px;">
    <h2>Mis publicaciones</h2>
    <p>Todas tus publicaciones <em>:)</em></p>

    <?php if (empty($my_posts)): ?>
      <!-- Mensaje si el usuario no tiene publicaciones -->
      <div class="card">
        <p class="meta">Todavía no publicaste nada.</p>
        <p style="margin-top:8px;">
          <a class="btn" href="/minuevo/crear"> Crear primera novedad</a>
        </p>
      </div>
    <?php else: ?>
      <!-- Listado de publicaciones -->
      <div class="list">
        <?php foreach ($my_posts as $p): ?>
          <?php
            // Normalizar datos del post
            $slug    = $p['slug'] ?? ($slugify($p['title'] ?? 'post') . '-' . (int)($p['post_id'] ?? 0));
            $title   = $p['title'] ?? '';
            $created = !empty($p['created_at']) ? date('Y-m-d', strtotime($p['created_at'])) : '';
            $excerpt = isset($p['content']) ? mb_strimwidth((string)$p['content'], 0, 160, '…') : '';
          ?>
          <!-- Tarjeta de publicación -->
          <article class="card">
            <h3><a href="/article/<?= $h($slug) ?>"><?= $h($title) ?></a></h3>
            <p class="meta">
              <?php if (!empty($p['category'])): ?>
                <strong>Categoría:</strong> <?= $h($p['category']) ?> &nbsp;|&nbsp;
              <?php endif; ?>
              <strong>Fecha:</strong> <?= $h($created) ?>
            </p>
            <p><?= nl2br($h($excerpt)) ?></p>
            <p style="margin-top:8px;">
              <a class="btn" href="/article/<?= $h($slug) ?>">Ver detalle</a>
            </p>
          </article>
        <?php endforeach; ?>
      </div>

      <!-- Paginador de publicaciones -->
      <?php if (!empty($my_posts_pagination)): ?>
        <?php
          $mp = $my_posts_pagination;
          $page    = (int)($mp['page']    ?? 1);
          $perPage = (int)($mp['perPage'] ?? 6);
          $total   = (int)($mp['total']   ?? 0);
          $hasPrev = !empty($mp['hasPrev']);
          $hasNext = !empty($mp['hasNext']);
          $pages   = max(1, (int)ceil($total / max(1, $perPage)));
          $prevUrl = $hasPrev ? ('/dashboard?mp=' . ($page - 1)) : null;
          $nextUrl = $hasNext ? ('/dashboard?mp=' . ($page + 1)) : null;
        ?>
        <div class="card pager">
          <span class="meta">Página <?= $page ?> de <?= $pages ?></span>
          <div class="pager-actions">
            <?php if ($prevUrl): ?><a class="btn" href="<?= $h($prevUrl) ?>">← Anterior</a><?php endif; ?>
            <?php if ($nextUrl): ?><a class="btn" href="<?= $h($nextUrl) ?>">Siguiente →</a><?php endif; ?>
          </div>
        </div>
      <?php endif; ?>
    <?php endif; ?>
  </section>
</div>


<style>
  .dash-head{
    display:flex; 
    justify-content:space-between; 
    align-items:center; 
    gap:12px;
    margin-bottom: 6px;
  }
</style>

