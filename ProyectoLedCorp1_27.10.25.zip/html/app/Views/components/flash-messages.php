<?php
// Siempre inicializar $flash para evitar undefined
$flash = $flash ?? ($_SESSION['flash'] ?? []);

// Si es un objeto tipo Session, normalizar a array
if ($flash instanceof \App\Core\Session) {
    $flash = $flash->all(); // o el método que devuelva todas las flashes
}
?>

<?php if (!empty($flash['error'])): ?>
    <!-- Mensaje de error -->
    <div class="alert alert-error" 
         style="background-color: #f8d7da; color: #721c24; padding: 10px; margin: 10px 0; border-radius: 4px;">
        <?= htmlspecialchars($flash['error'], ENT_QUOTES, 'UTF-8') ?>
    </div>
<?php endif; ?>

<?php if (!empty($flash['success'])): ?>
    <!-- Mensaje de éxito -->
    <div class="alert alert-success" 
         style="background-color: #d4edda; color: #155724; padding: 10px; margin: 10px 0; border-radius: 4px;">
        <?= htmlspecialchars($flash['success'], ENT_QUOTES, 'UTF-8') ?>
    </div>
<?php endif; ?>

<?php if (!empty($flash['info'])): ?>
    <!-- Mensaje informativo -->
    <div class="alert alert-info" 
         style="background-color: #cce5ff; color: #004085; padding: 10px; margin: 10px 0; border-radius: 4px;">
        <?= htmlspecialchars($flash['info'], ENT_QUOTES, 'UTF-8') ?>
    </div>
<?php endif; ?>

