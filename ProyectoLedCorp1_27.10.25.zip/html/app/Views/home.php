<?php
$title = $title ?? 'Chivita Recomienda';
?>
<link rel="stylesheet" href="/css/indexprincipal.css?v=<?= htmlspecialchars($cssMainVer ?? '1.0', ENT_QUOTES, 'UTF-8') ?>">

<h1><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></h1>

<p>Opiniones bien útiles sobre servicios de usuarios</p>

<?php if (!empty($auth['check'])): ?>
  <!-- Si el usuario está logueado -->
  <p>Bienvenido <?= htmlspecialchars($auth['user']['username'] ?? '', ENT_QUOTES, 'UTF-8') ?></p>
<?php else: ?>
  <!-- Si NO está logueado -->
  <p>Haz clic aquí para iniciar sesión <a href="/login">inicia sesión</a> y acceder a tu perfil </p>
  <p>Haz clic aquí para crearte una cuenta <a href="/register">registrarse</a> y comenzar tu aventura.</p>
<?php endif; ?>

<?php
if (method_exists($this, 'component')) {
    $this->component('gallery');
} else {
    // Fallback: incluir manualmente el archivo de la galería
    $gal = BASE_PATH . '/app/Views/components/gallery.php';
    if (file_exists($gal)) include $gal;
}
?>

<?php if (!empty($auth['check'])): ?>
  <div class="cta-under-gallery">
    <a class="btn glow" href="/minuevo/crear">Publicar un nuevo servicio</a>
  </div>
<?php endif; ?>


<section class="section lead">
  <h2>¿Qué es Chivita Recomienda?</h2>
  <p>
    Chivita Recomienda es una plataforma donde <strong>clientes</strong> y <strong>proveedores locales</strong>
    se encuentran. Aquí puedes descubrir servicios confiables, comparar opiniones reales y tomar decisiones 
    informadas en minutos.
  </p>
  <ul class="bullet-checks">
    <li>Reseñas verificadas y útiles.</li>
    <li>Perfiles de proveedores con información clara.</li>
    <li>Publicación rápida de tus propios servicios.</li>
  </ul>
</section>

<section class="section howitworks">
  <h2>Cómo funciona</h2>
  <div class="steps">
    <div class="step">
      <span class="step-num">1</span>
      <h3>Explora</h3>
      <p>Busca por categoría, zona o nombre del servicio y compara calificaciones.</p>
    </div>
    <div class="step">
      <span class="step-num">2</span>
      <h3>Elige</h3>
      <p>Lee reseñas de otros usuarios y revisa la reputación del proveedor.</p>
    </div>
    <div class="step">
      <span class="step-num">3</span>
      <h3>Contacta</h3>
      <p>Coordina directamente con el proveedor y deja tu opinión luego de contratar.</p>
    </div>
  </div>
</section>

<section class="section highlight-cards">
  <h2>Categorías destacadas</h2>
  <div class="cards">
    <article class="card">
      <h3>Transporte</h3>
      <p>Fletes, traslados locales y mudanzas.</p>
    </article>
    <article class="card">
      <h3>Construcción</h3>
      <p>Albañilería, pintura, electricidad y más.</p>
    </article>
    <article class="card">
      <h3>Tecnología</h3>
      <p>Soporte IT, desarrollo web y automatización.</p>
    </article>
    <article class="card">
      <h3>Hogar</h3>
      <p>Limpieza, jardinería y mantenimiento.</p>
    </article>
  </div>
</section>


<section class="section faq" id="faq">
  <h2>Preguntas frecuentes</h2>

  <details>
    <summary>¿Necesito una cuenta para usar la plataforma?</summary>
    <p>Puedes explorar sin cuenta, pero para publicar servicios, calificar y contactar a proveedores, sí necesitas registrarte.</p>
  </details>

  <details>
    <summary>¿Cómo publico mi servicio?</summary>
    <p>
      Una vez logueado, haz clic en <em>“Publicar un nuevo servicio”</em> (arriba, debajo de la galería) y completa los datos.
      Añade fotos, descripción y tu información de contacto.
    </p>
  </details>

  <details>
    <summary>¿Las reseñas son moderadas?</summary>
    <p>Sí. Buscamos mantener la comunidad segura. Las reseñas que incumplan las normas pueden ser removidas.</p>
  </details>

  <details>
    <summary>¿Tiene costo para los usuarios?</summary>
    <p>Explorar y publicar servicios básicos es gratuito. Funciones avanzadas, si existieran, se comunicarán claramente.</p>
  </details>

  <details>
    <summary>Tuve un problema con un proveedor, ¿qué hago?</summary>
    <p>
      Te sugerimos calificar tu experiencia y reportar el incidente desde el perfil del servicio. 
      Nuestro equipo revisará el caso para tomar medidas si corresponde.
    </p>
  </details>
</section>


<footer class="site-footer">
  <div class="footer-inner">
    <div class="brand">
      <strong>Chivita Recomienda</strong>
      <p>Encontrá el servicio ideal, con reseñas reales.</p>
    </div>
    <nav class="social">
      <a href="https://www.facebook.com" target="_blank" rel="noopener">Facebook</a>
      <a href="https://www.instagram.com" target="_blank" rel="noopener">Instagram</a>
      <a href="https://wa.me/59800000000" target="_blank" rel="noopener">WhatsApp</a>
      <a href="https://www.tiktok.com" target="_blank" rel="noopener">TikTok</a>
    </nav>
  </div>
  <div class="copy">
    © <?= date('Y') ?> Chivita Recomienda. Todos los derechos reservados.
  </div>
</footer>


