<?php
namespace App\Support;

final class Flash
{
    public static function set(string $type, string $message): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
    }

    public static function popAll(): array
    {
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        $all = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);
        return $all;
    }
}

