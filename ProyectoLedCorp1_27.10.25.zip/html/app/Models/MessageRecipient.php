<?php
namespace App\Models;

use App\Core\Model;
use App\Core\Database;
use PDO;

class MessageRecipient extends Model
{
    private const T_MR = 'message_recipients'; // destinatarios
    private const T_M  = 'messages';           // mensajes
    private const T_U  = 'Users';              // usuarios

    protected static function db(): PDO {
        return Database::getConnection();
    }

    /* ===========================
     * Bandeja / Listados
     * =========================== */

    /** Bandeja del usuario (solo SUS mensajes) */
    public static function findInboxForUser(int $userId, int $limit = 200): array
    {
        $pdo = static::db();
        $sql = "
            SELECT
                mr.message_id,
                mr.is_read,
                m.created_at AS created_at,
                m.subject,
                m.body       AS body,
                u.username   AS from_name,
                u.email      AS from_email
            FROM ".self::T_MR." mr
            INNER JOIN ".self::T_M." m
                ON m.id = mr.message_id
            INNER JOIN ".self::T_U." u
                ON u.user_id = m.sender_id
            WHERE mr.recipient_id = :uid
            ORDER BY m.created_at DESC
            LIMIT :lim
        ";
        $st = $pdo->prepare($sql);
        $st->bindValue(':uid', $userId, PDO::PARAM_INT);
        $st->bindValue(':lim', $limit,  PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Contador de mensajes no leídos */
    public static function countUnreadForUser(int $userId): int
    {
        $pdo = static::db();
        $st  = $pdo->prepare("
            SELECT COUNT(*)
            FROM ".self::T_MR."
            WHERE recipient_id = :uid AND is_read = 0
        ");
        $st->execute([':uid' => $userId]);
        return (int)$st->fetchColumn();
    }

    /** Marca como leído para un destinatario */
    public static function markRead(int $messageId, int $userId): void
    {
        $pdo = static::db();
        $st = $pdo->prepare("
            UPDATE ".self::T_MR."
               SET is_read = 1, read_at = NOW()
             WHERE message_id = :mid AND recipient_id = :uid
        ");
        $st->execute([':mid' => $messageId, ':uid' => $userId]);
    }

    /** ¿El usuario puede ver el mensaje? (destinatario o remitente) */
    public static function userCanSee(int $mid, int $uid): bool
    {
        $pdo = static::db();

        // ¿Es destinatario?
        $st = $pdo->prepare("
            SELECT 1 FROM ".self::T_MR."
            WHERE message_id = :mid AND recipient_id = :uid
            LIMIT 1
        ");
        $st->execute([':mid' => $mid, ':uid' => $uid]);
        if ($st->fetchColumn()) return true;

        // ¿Es remitente?
        $st = $pdo->prepare("
            SELECT 1 FROM ".self::T_M."
            WHERE id = :mid AND sender_id = :uid
            LIMIT 1
        ");
        $st->execute([':mid' => $mid, ':uid' => $uid]);
        return (bool)$st->fetchColumn();
    }

    /** Inserta destinatarios */
    public static function addRecipients(int $messageId, array $recipientIds): void
    {
        if (empty($recipientIds)) return;

        $pdo = static::db();
        $sql = "INSERT INTO ".self::T_MR." (message_id, recipient_id, is_read) VALUES (:mid, :rid, 0)";
        $st  = $pdo->prepare($sql);

        foreach ($recipientIds as $rid) {
            $st->execute([':mid' => $messageId, ':rid' => (int)$rid]);
        }
    }

    /* ===========================
     * Detalle del mensaje (show)
     * =========================== */

    /** Mensaje + remitente con alias que espera la vista */
    public static function findMessageWithDetails(int $messageId): ?array
    {
        $pdo = static::db();
        $sql = "
            SELECT
                m.id,
                m.subject,
                m.body,
                m.created_at,
                m.sender_id,
                u.username AS from_name,
                u.email    AS from_email
            FROM ".self::T_M." m
            INNER JOIN ".self::T_U." u
                ON u.user_id = m.sender_id
            WHERE m.id = :mid
            LIMIT 1
        ";
        $st = $pdo->prepare($sql);
        $st->execute([':mid' => $messageId]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /** Lista de destinatarios (si la necesitaras en otras vistas) */
    public static function findRecipientsForMessage(int $messageId): array
    {
        $pdo = static::db();
        $sql = "
            SELECT
                mr.recipient_id,
                mr.is_read,
                mr.read_at,
                u.username
            FROM ".self::T_MR." mr
            INNER JOIN ".self::T_U." u
                ON u.user_id = mr.recipient_id
            WHERE mr.message_id = :mid
            ORDER BY u.username
        ";
        $st = $pdo->prepare($sql);
        $st->execute([':mid' => $messageId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /* ===========================
     * Permisos / Borrado
     * =========================== */

    public static function userCanDelete(int $messageId, int $userId): bool
    {
        $pdo = static::db();
        $st  = $pdo->prepare('SELECT 1 FROM '.self::T_MR.' WHERE message_id = ? AND recipient_id = ? LIMIT 1');
        $st->execute([$messageId, $userId]);
        return (bool)$st->fetchColumn();
    }

    public static function deleteForUser(int $messageId, int $userId): bool
    {
        $pdo = static::db();
        $st  = $pdo->prepare('DELETE FROM '.self::T_MR.' WHERE message_id = ? AND recipient_id = ?');
        return $st->execute([$messageId, $userId]);
    }

    public static function remainingRecipients(int $messageId): int
    {
        $pdo = static::db();
        $st  = $pdo->prepare('SELECT COUNT(*) FROM '.self::T_MR.' WHERE message_id = ?');
        $st->execute([$messageId]);
        return (int)$st->fetchColumn();
    }

    public static function deleteMessageIfOrphan(int $messageId): void
    {
        $pdo = static::db();
        $sql = 'DELETE FROM '.self::T_M.'
                WHERE id = ?
                  AND NOT EXISTS (SELECT 1 FROM '.self::T_MR.' mr WHERE mr.message_id = '.self::T_M.'.id)';
        $st  = $pdo->prepare($sql);
        $st->execute([$messageId]);
    }
}

