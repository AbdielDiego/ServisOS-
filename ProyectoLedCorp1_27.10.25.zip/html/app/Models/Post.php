<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;

class Post
{
    private string $table = 'Posts';
    private string $pk    = 'post_id';

    private function pdo(): PDO
    {
        return Database::getConnection();
    }

    /** Lista todos los posts (campos de tu BD). */
    public function listAll(): array
    {
        $sql = "SELECT {$this->pk} AS post_id, user_id, category_id, title, content, created_at, updated_at
                FROM {$this->table}
                ORDER BY {$this->pk} DESC";
        return $this->pdo()->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Paginado simple (por si lo usas en otra parte) */
    public function sqlPaginado(int $page = 1, int $perPage = 10): array
    {
        $page   = max(1, $page);
        $offset = ($page - 1) * $perPage;

        $total = (int)$this->pdo()->query("SELECT COUNT(*) FROM {$this->table}")->fetchColumn();

        $st = $this->pdo()->prepare(
            "SELECT {$this->pk} AS post_id, user_id, category_id, title, content, created_at, updated_at
             FROM {$this->table}
             ORDER BY {$this->pk} DESC
             LIMIT :limit OFFSET :offset"
        );
        $st->bindValue(':limit',  $perPage, PDO::PARAM_INT);
        $st->bindValue(':offset', $offset,  PDO::PARAM_INT);
        $st->execute();
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);

        return [
            'posts'       => $rows,
            'total'       => $total,
            'perPage'     => $perPage,
            'currentPage' => $page,
        ];
    }

    public function findById(int $id): ?array
    {
        $st = $this->pdo()->prepare(
            "SELECT {$this->pk} AS post_id, user_id, category_id, title, content, created_at, updated_at
             FROM {$this->table} WHERE {$this->pk} = :id LIMIT 1"
        );
        $st->execute([':id' => $id]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /** Búsqueda flexible por array clave=>valor (1 fila) */
    public function find(array $where): ?array
    {
        if (empty($where)) return null;

        $clauses = [];
        $params  = [];
        foreach ($where as $k => $v) {
            $clauses[]        = "$k = :$k";
            $params[":$k"]    = $v;
        }
        $sql = "SELECT {$this->pk} AS post_id, user_id, category_id, title, content, created_at, updated_at
                FROM {$this->table}
                WHERE " . implode(' AND ', $clauses) . " LIMIT 1";

        $st = $this->pdo()->prepare($sql);
        $st->execute($params);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }
}

