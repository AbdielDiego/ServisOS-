<?php
namespace App\Core;

/**
 * Singleton de base de datos (compatible con código legado).
 *
 * - Usa config/database.php
 * - Soporta TCP (host/port) y UNIX socket (unix_socket)
 * - Expone:
 *     - Database::getInstance()
 *     - Database::getConnection(), ::connection(), ::getPdo()
 *     - Propiedades públicas $pdo y $connection (compatibilidad)
 * - Proxy amigable:
 *     - query($sql, array $params) => prepare+execute
 *     - query($sql)                => PDO::query($sql)
 *     - query($sql, $fetchMode, ...) => PDO::query con modo de fetch
 */
final class Database
{
    private static $instance = null;

    /** @var \PDO */
    public $pdo;
    public $connection;

    private function __construct()
    {
        $cfg = $this->loadConfig();

        // Aliases por si algún config usa otras claves
        if (isset($cfg['user']) && !isset($cfg['username']))   $cfg['username'] = $cfg['user'];
        if (isset($cfg['pass']) && !isset($cfg['password']))   $cfg['password'] = $cfg['pass'];
        if (isset($cfg['db'])   && !isset($cfg['database']))   $cfg['database'] = $cfg['db'];

        $driver  = $cfg['driver']     ?? 'mysql';
        $db      = $cfg['database']   ?? 'proyutu';
        $user    = $cfg['username']   ?? 'root';
        $pass    = $cfg['password']   ?? '';
        $charset = $cfg['charset']    ?? 'utf8mb4';
        $host    = $cfg['host']       ?? '127.0.0.1';
        $port    = $cfg['port']       ?? '3306';
        $socket  = $cfg['unix_socket'] ?? null;

        $dsn = !empty($socket)
            ? "{$driver}:unix_socket={$socket};dbname={$db};charset={$charset}"
            : "{$driver}:host={$host};port={$port};dbname={$db};charset={$charset}";

        $opts = [
            \PDO::ATTR_ERRMODE            => \PDO::ERRMODE_EXCEPTION,
            \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
            \PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        if (!empty($cfg['options']) && is_array($cfg['options'])) {
            $opts = $cfg['options'] + $opts;
        }

        $pdo = new \PDO($dsn, $user, $pass, $opts);
        $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
        $pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);

        $this->pdo        = $pdo;
        $this->connection = $pdo;
    }

    private function __clone() {}
    public function __wakeup() { throw new \RuntimeException('No se puede unserialize Database'); }

    public static function getInstance(): self
    {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    // Firmas estáticas típicas
    public static function getConnection(): \PDO { return self::getInstance()->pdo; }
    public static function connection(): \PDO    { return self::getInstance()->pdo; }
    public static function getPdo(): \PDO        { return self::getInstance()->pdo; }

    // PROXIES a PDO (compatible con Model->query($sql, $params))
    public function query(string $sql, $paramsOrFetchMode = null, ...$rest)
    {
        if (is_array($paramsOrFetchMode)) {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($paramsOrFetchMode);
            return $stmt;
        }
        if ($paramsOrFetchMode !== null) {
            return $this->pdo->query($sql, $paramsOrFetchMode, ...$rest);
        }
        return $this->pdo->query($sql);
    }

    public function prepare(string $sql, array $options = []): \PDOStatement { return $this->pdo->prepare($sql, $options); }
    public function exec(string $sql): int                                    { return $this->pdo->exec($sql); }
    public function beginTransaction(): bool                                  { return $this->pdo->beginTransaction(); }
    public function commit(): bool                                            { return $this->pdo->commit(); }
    public function rollBack(): bool                                          { return $this->pdo->rollBack(); }
    public function inTransaction(): bool                                     { return $this->pdo->inTransaction(); }
    public function lastInsertId(?string $name = null): string                { return $this->pdo->lastInsertId($name); }
    public function quote(string $string, int $type = \PDO::PARAM_STR): string{ return $this->pdo->quote($string, $type); }
    public function getAttribute(int $attr)                                   { return $this->pdo->getAttribute($attr); }
    public function setAttribute(int $attr, $value): bool                     { return $this->pdo->setAttribute($attr, $value); }
    public function errorCode(): ?string                                      { return $this->pdo->errorCode(); }
    public function errorInfo(): array                                        { return $this->pdo->errorInfo(); }

    public function __call(string $name, array $arguments)
    {
        if (method_exists($this->pdo, $name)) return $this->pdo->$name(...$arguments);
        throw new \BadMethodCallException("Método {$name} no existe en Database ni en PDO");
    }

    private function loadConfig(): array
    {
        $base = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 2);
        $file = $base . '/config/database.php';

        if (!is_file($file)) {
            return [
                'driver'   => 'mysql',
                'host'     => '127.0.0.1',
                'port'     => '3306',
                'database' => 'proyutu',
                'username' => 'root',
                'password' => '',
                'charset'  => 'utf8mb4',
                'options'  => [],
            ];
        }

        $cfg = require $file;
        if (!is_array($cfg)) throw new \RuntimeException('config/database.php debe retornar un array.');

        $cfg += [
            'driver'   => 'mysql',
            'host'     => '127.0.0.1',
            'port'     => '3306',
            'database' => 'proyutu',
            'username' => 'root',
            'password' => '',
            'charset'  => 'utf8mb4',
            'options'  => [],
        ];
        return $cfg;
    }
}

