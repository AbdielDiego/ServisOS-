<?php
namespace App\Services;


class AuthService {

    /**
     * Intenta autenticar al usuario con el email y contraseña proporcionados.
     *
     * @param string $email
     * @param string $password
     * @return bool
     */
    public function attempt($email, $password) {
        // Simulación: solo permite un usuario específico
        if ($email === 'admin@test.com' && $password === '1234') {
            // Si las credenciales coinciden, se guarda el ID del usuario en sesión
            $_SESSION['user_id'] = 1;
            return true;
        }
        // Si no coinciden, retorna false
        return false;
    }

    /**
     * Verifica si hay un usuario autenticado (basado en la sesión).
     *
     * @return bool
     */
    public function check() {
        // Retorna true si la sesión tiene un user_id
        return isset($_SESSION['user_id']);
    }

    /**
     * Cierra la sesión del usuario autenticado.
     *
     * @return void
     */
    public function logout() {
        // Elimina el user_id de la sesión
        unset($_SESSION['user_id']);
    }

    /**
     * Registra un nuevo usuario (simulado).
     * En un caso real, deberías guardar los datos en la base de datos.
     *
     * @param array $data
     * @return int ID simulado del nuevo usuario
     */
    public function register($data) {
        // Retorna un número aleatorio como ID simulado de usuario
        return rand(1000, 9999);
    }
}

