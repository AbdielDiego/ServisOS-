<?php
// Define el namespace del modelo Empresario
namespace App\Models;

// Importa la clase base Model que contiene métodos comunes (CRUD)
use App\Core\Model;

// Define la clase Empresario que extiende la funcionalidad de Model
class Empresario extends Model {

    // Define el nombre de la tabla en la base de datos asociada a este modelo
    protected $table = "empresarios";

    // Método para guardar un nuevo empresario en la base de datos
    public function guardar($data) {
        // Utiliza el método create() heredado del modelo base para insertar el registro
        return $this->create($data);
    }
}


