<?php
namespace App\Models;

// Importa la clase Database del núcleo del framework
use App\Core\Database;

class Servicios {

    // Propiedad privada para manejar la conexión a la base de datos
    private $db;

    // Constructor: obtiene la instancia única de conexión a la base de datos
    public function __construct() {
        $this->db = Database::getInstance();
    }

    // Método que retorna todos los registros de la tabla 'servicios'
    public function todosLosServicios() {
        $query = "SELECT * FROM servicios";
        return $this->db->query($query)->fetchAll(\PDO::FETCH_ASSOC);
    }

    // Método que busca un servicio específico por su ID
    public function find($id) {
        $query = "SELECT * FROM servicios WHERE id = :id";
        return $this->db->query($query, ['id' => $id])->fetch(\PDO::FETCH_ASSOC);
    }

    // Método que busca servicios por nombre (uso de LIKE)
    public function buscarPorNombre($texto) {
        $sql = "SELECT * FROM servicios WHERE nombre LIKE :nombre";
        $params = ['nombre' => '%' . $texto . '%'];
        return $this->db->query($sql, $params)->fetchAll(\PDO::FETCH_ASSOC);
    }

    // ✅ Método que obtiene los servicios filtrados por categoría
    public function obtenerPorCategoria($categoria) {
        $sql = "SELECT * FROM servicios WHERE categoria = :categoria";
        return $this->db->query($sql, ['categoria' => $categoria])->fetchAll(\PDO::FETCH_ASSOC);
    }
}

