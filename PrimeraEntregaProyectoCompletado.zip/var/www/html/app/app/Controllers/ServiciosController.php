<?php 
// Declaración del namespace correspondiente a la estructura del proyecto
namespace App\Controllers;

// Se importan las clases necesarias
use App\Core\Controller;
use App\Models\Servicios;

// Definición del controlador ServiciosController que extiende la clase base Controller
class ServiciosController extends Controller {

    // Propiedad privada para almacenar el modelo Servicios
    private $modelo;

    // Constructor del controlador
    public function __construct() {
        // Se instancia el modelo Servicios
        $this->modelo = new Servicios();
        // Se llama al constructor del controlador padre
        parent::__construct();
    }

    // Método principal que se ejecuta al acceder a /servicios
    public function index() {
        // Se captura el parámetro 'buscar' desde la URL (GET), o null si no existe
        $filtro = $_GET['buscar'] ?? null;

        // Si hay un filtro de búsqueda, se buscan los servicios por nombre
        if ($filtro) {
            $datos = $this->modelo->buscarPorNombre($filtro);
        } else {
            // Si no hay filtro, se obtienen todos los servicios
            $datos = $this->modelo->todosLosServicios();
        }

        // Se renderiza la vista 'servicios/index' y se le pasa la variable 'servicios'
        return $this->render("servicios/index", ["servicios" => $datos]);
    }

    // Método para mostrar un servicio específico por su ID
    public function showServicio($param) {
        // Se obtiene el ID desde el array de parámetros
        $id = $param['id'];
        // Se busca el servicio correspondiente usando el modelo
        $datos = $this->modelo->find($id);
        // Se renderiza la vista 'servicios/showservicios' y se le pasa la variable 'servicio'
        return $this->render("servicios/showservicios", ["servicio" => $datos]);
    }

    // Método para mostrar servicios filtrados por categoría
    public function porCategoria($param) {
        // Se obtiene la categoría desde los parámetros o null si no existe
        $categoria = $param['categoria'] ?? null;

        // Si no se especifica una categoría, se redirige a la página principal de servicios
        if (!$categoria) {
            $this->redirect('/servicios');
        }

        // Se obtienen los servicios filtrados por la categoría especificada
        $datos = $this->modelo->obtenerPorCategoria($categoria);
        
        // Se renderiza la vista 'servicios/categoria' y se le pasan las variables necesarias
        return $this->render("servicios/categoria", [
            'title' => "Servicios de " . ucfirst($categoria), // Se genera un título con la categoría en mayúscula inicial
            'servicios' => $datos, // Se pasan los servicios encontrados
            'categoria' => $categoria // Se pasa la categoría para referencia en la vista
        ]);
    }
}


