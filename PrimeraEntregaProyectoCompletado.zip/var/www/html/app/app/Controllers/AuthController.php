<?php
namespace App\Controllers;

// Importa clases necesarias para este controlador
use App\Core\Controller;
use App\Models\User;
use App\Services\AuthService;
use App\Core\Session;

// Controlador encargado de gestionar la autenticación de usuarios
class AuthController extends Controller {

    private $auth;    // Servicio de autenticación
    private $session; // Manejador de sesiones

    public function __construct() {
        parent::__construct();             // Llama al constructor del controlador base
        $this->auth = new AuthService();   // Instancia el servicio de autenticación
        $this->session = new Session();    // Instancia el manejo de sesión
    }

    // Muestra la vista de login si no hay sesión activa
    public function showLogin() {
        if ($this->auth && $this->auth->check()) {
            $this->redirect('/dashboard'); // Si ya está logueado, redirige al dashboard
        }

        // Renderiza la vista de login
        return $this->render('auth/login', [
            'title' => 'Iniciar Sesión'
        ]);
    }

    // Procesa el formulario de inicio de sesión
    public function login() {
        // Recoge los datos del formulario
        $email = $this->input('email');
        $password = $this->input('password');

        // Valida los campos requeridos
        $errors = $this->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        // Si hay errores, vuelve a mostrar el formulario con errores
        if (!empty($errors)) {
            return $this->render('auth/login', [
                'title' => 'Iniciar Sesión',
                'errors' => $errors,
                'input' => ['email' => $email]
            ]);
        }

        // Intenta autenticar al usuario
        if ($this->auth && $this->auth->attempt($email, $password)) {
            $this->session->flash('success', 'Has iniciado sesión correctamente');
            $this->redirect('/dashboard'); // Si lo logra, redirige al dashboard
        }

        // Si falla la autenticación, muestra error
        $this->session->flash('error', 'Credenciales incorrectas');
        return $this->render('auth/login', [
            'title' => 'Iniciar Sesión',
            'input' => ['email' => $email]
        ]);
    }

    // Muestra el formulario de registro si no hay sesión activa
    public function showRegister() {
        if ($this->auth && $this->auth->check()) {
            $this->redirect('/dashboard');
        }

        return $this->render('auth/register', [
            'title' => 'Registro de Usuario'
        ]);
    }

    // Procesa el formulario de registro de usuario
    public function register() {
        // Recoge datos del formulario
        $name = $this->input('name');
        $email = $this->input('email');
        $password = $this->input('password');
        $passwordConfirm = $this->input('password_confirm');

        // Valida los campos
        $errors = $this->validate([
            'name' => 'required|min:3',
            'email' => 'required|email',
            'password' => 'required|min:4'
        ]);

        // Verifica que las contraseñas coincidan
        if ($password !== $passwordConfirm) {
            $errors['password_confirm'] = 'Las contraseñas no coinciden';
        }

        // Verifica que el email no esté registrado
        $user = (new User())->findByEmail($email);
        if ($user) {
            $errors['email'] = 'Este email ya está registrado';
        }

        // Si hay errores, renderiza nuevamente el formulario
        if (!empty($errors)) {
            return $this->render('auth/register', [
                'title' => 'Registro de Usuario',
                'errors' => $errors,
                'input' => [
                    'name' => $name,
                    'email' => $email
                ]
            ]);
        }

        // Registra al nuevo usuario con rol "user" por defecto
        $userId = $this->auth->register([
            'name' => $name,
            'email' => $email,
            'password' => $password,
            'role' => 'user'
        ]);

        // Si el registro fue exitoso, lo loguea automáticamente
        if ($userId) {
            $this->auth->attempt($email, $password);
            $this->session->flash('success', 'Te has registrado correctamente');
            $this->redirect('/dashboard');
        }

        // Si falla, vuelve al formulario con error
        $this->session->flash('error', 'Error al registrar el usuario');
        return $this->render('auth/register', [
            'title' => 'Registro de Usuario',
            'input' => [
                'name' => $name,
                'email' => $email
            ]
        ]);
    }

    // Cierra la sesión del usuario
    public function logout() {
        if ($this->auth) {
            $this->auth->logout(); // Cierra sesión con el servicio
        }

        $this->session->flash('success', 'Has cerrado sesión correctamente');
        $this->redirect('/');
    }

    // Muestra el formulario de registro de empresarios
    public function registroEmpresario() {
        return $this->render('registro/registro_empresario', [
            'title' => 'Registro para Empresarios'
        ]);
    }
}

