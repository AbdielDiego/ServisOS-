<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Capturamos el email y la contraseña enviados por el formulario.
    // Si no vienen, asumimos cadena vacía para evitar errores.
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Aquí simulamos un login con credenciales fijas (muy original).
    // En producción esto sería consultar en una base de datos.
    if ($email === 'jvdeoli@gmail.com' && $password === 'mi password') {
        
        // Si las credenciales son correctas, guardamos el email en sesión,
        // para recordarle al sistema quién es el usuario que se ha logueado.
        $_SESSION['usuario'] = $email;

        // También guardamos un mensaje de éxito para mostrar luego.
        $_SESSION['mensaje'] = 'Cuenta logueada';

        // Ahora, redireccionamos a la misma página para evitar que al refrescar
        // el navegador se reenvíe el formulario (y que te explote el server).
        header("Location: /login");
        exit; // Cortamos la ejecución para que no siga más código.
    } else {
        // Si las credenciales no coinciden, guardamos un mensaje de error
        // para que el usuario sepa que la metió mal (pero sin insultos).
        $_SESSION['mensaje'] = 'Credenciales incorrectas';
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión</title>
    


    <style>
       /* Estilos para que la página no parezca un PowerPoint de los 90 */
        body {
            margin: 0;
            padding: 0;
            background: radial-gradient(circle at top, #1a1a2e, #16213e);
            color: #fff;
            font-family: 'Roboto', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            min-height: 100vh;
        }

        h2 {
            margin-top: 40px;
        }

        form {
            max-width: 300px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            padding: 20px;
            backdrop-filter: blur(6px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.3);
            margin-top: 20px;
        }

        label, input {
            display: block;
            width: 100%;
            margin-bottom: 10px;
        }

        input {
            padding: 8px;
            border-radius: 5px;
            border: none;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #00ffe1;
            color: #111;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            box-shadow: 0 0 12px #00ffe1;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background-color: #00e0c6;
        }

        .mensaje {
            margin-top: 10px;
            background-color: #00ffe120; /* Transparente para no molestar */
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #00ffe1;
            color: #00ffe1;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h2>Iniciar sesión</h2>

    <!-- Aquí mostramos mensajes guardados en sesión (éxito o error) -->
    <?php if (isset($_SESSION['mensaje'])): ?>
        <div class="mensaje"><?= $_SESSION['mensaje'] ?></div>
        <?php unset($_SESSION['mensaje']); // Limpiamos para que no aparezca siempre ?>
    <?php endif; ?>

    <!-- Formulario de login -->
    <form method="POST">
        <div>
            <label>Email:</label>
            <!-- El value predeterminado para que no tengas que escribirlo siempre -->
            <input type="email" name="email" required value="jvdeoli@gmail.com">
        </div>

        <div>
            <label>Contraseña:</label>
            <!-- Igual acá, aunque poner password en valor no es buena práctica en producción -->
            <input type="password" name="password" required value="mi password">
        </div>

        <button type="submit">Ingresar</button>
    </form>

</body>
</html>



