<html>
	<head>
		<!-- Vincula la hoja de estilos principal -->
		<link rel="stylesheet" href="/css/style.css">
	</head>

	<body>
		<!-- Muestra el título dinámico que se pasa desde el controlador -->
		<h1><?= $titulo ?></h1>

		<!-- Recorre el array $datos (puede venir desde la base de datos, por ejemplo) -->
		<?php foreach($datos as $i => $row): ?>

			<?php
			// Abre una etiqueta <pre> para mostrar los datos con formato legible
			echo "<pre>";
			
			// Imprime todo el contenido del array $row (una fila de datos)
			print_r($row);	

			// Cierra la etiqueta <pre>
			echo "</pre>";
			?>

		<!-- Fin del bucle foreach -->
		<?php endforeach; ?>

	</body>
</html>


