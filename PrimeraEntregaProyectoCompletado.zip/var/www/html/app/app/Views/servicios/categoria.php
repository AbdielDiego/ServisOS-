<!DOCTYPE html>
<html lang="es">
<head>
    <!-- Configuración básica del documento -->
    <meta charset="UTF-8">
    
    <!-- Título de la página, dinámico según la categoría actual -->
    <title><?= htmlspecialchars($categoria ?? 'Categoría') ?></title>
    
    <!-- Importación de fuentes desde Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&family=Roboto&display=swap" rel="stylesheet">

    <!-- Estilos CSS directamente embebidos -->
    <style>
        body {
            margin: 0;
            padding: 0;
            background: radial-gradient(circle at top, #1a1a2e, #16213e); /* Fondo oscuro con gradiente */
            color: #fff;
            font-family: 'Roboto', sans-serif; /* Fuente principal */
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh; /* Altura mínima del viewport */
        }

        h1 {
            font-family: 'Orbitron', sans-serif; /* Fuente de títulos */
            font-size: 2.5rem;
            color: #00ffe1;
            margin: 40px 0 10px;
            text-shadow: 0 0 10px #00ffe1; /* Efecto de brillo */
            text-transform: uppercase;
        }

        .card {
            background: rgba(255, 255, 255, 0.08); /* Fondo translúcido */
            border: 1px solid rgba(255, 255, 255, 0.2); /* Borde sutil */
            border-radius: 10px;
            padding: 20px 30px;
            margin: 20px;
            width: 90%;
            max-width: 500px;
            backdrop-filter: blur(6px); /* Efecto de desenfoque */
            box-shadow: 0 8px 16px rgba(0,0,0,0.3);
            transition: transform 0.3s ease; /* Transición suave al hacer hover */
        }

        .card:hover {
            transform: translateY(-5px); /* Levanta la tarjeta al pasar el mouse */
        }

        .card p {
            margin: 10px 0;
            font-size: 1.1rem;
        }

        .rating {
            display: flex;
            justify-content: start;
            gap: 8px;
            margin-top: 10px;
        }

        .rating input {
            display: none; /* Oculta los botones de radio */
        }

        .rating label {
            font-size: 25px;
            color: #555;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .rating input:checked ~ label,
        .rating label:hover,
        .rating label:hover ~ label {
            color: #00ffe1; /* Color brillante cuando se selecciona o pasa el mouse */
            text-shadow: 0 0 5px #00ffe1;
        }
    </style>
</head>
<body>

    <!-- Título principal con el nombre de la categoría -->
    <h1>Servicios de <?= htmlspecialchars($categoria) ?></h1>

    <!-- Si no hay servicios disponibles, se muestra un mensaje -->
    <?php if (empty($servicios)): ?>
        <p>No hay servicios en esta categoría aún.</p>
    <?php else: ?>
        <!-- Se recorre cada servicio y se muestra en una tarjeta -->
        <?php foreach ($servicios as $i => $serv): ?>
            <div class="card">
                <!-- Muestra el ID del servicio -->
                <p><strong>ID:</strong> <?= htmlspecialchars($serv["id"]) ?></p>
                
                <!-- Muestra el nombre del servicio -->
                <p><strong>Nombre:</strong> <?= htmlspecialchars($serv["nombre"]) ?></p>
                
                <!-- Muestra la descripción -->
                <p><strong>Descripción:</strong> <?= htmlspecialchars($serv["descripcion"]) ?></p>
                
                <!-- Muestra el precio con el signo de dólar -->
                <p><strong>Precio:</strong> $<?= htmlspecialchars($serv["precio"]) ?></p>

                <!-- Sistema de rating visual (estrellas) -->
                <div class="rating">
                    <?php for ($star = 5; $star >= 1; $star--): ?>
                        <!-- Input tipo radio para cada estrella -->
                        <input type="radio" name="rating_<?= $i ?>" id="star<?= $star ?>_<?= $i ?>" value="<?= $star ?>">
                        
                        <!-- Etiqueta visual de la estrella -->
                        <label for="star<?= $star ?>_<?= $i ?>">★</label>
                    <?php endfor; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

</body>
</html>


