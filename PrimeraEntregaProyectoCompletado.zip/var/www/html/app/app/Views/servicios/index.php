<!DOCTYPE html>
<html>
<head>
    <!-- Configuración básica del documento -->
    <meta charset="UTF-8">
    <title>Listado de Servicios</title>

    <!-- Fuente Orbitron para títulos y Roboto para cuerpo -->
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&family=Roboto&display=swap" rel="stylesheet">

    <style>
        /* Estilos visuales modernos, con fondo oscuro y tipografía tecnológica */
        body {
            margin: 0;
            padding: 0;
            background: radial-gradient(circle at top, #1a1a2e, #16213e);
            color: #fff;
            font-family: 'Roboto', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            min-height: 100vh;
        }
        h1 {
            font-family: 'Orbitron', sans-serif;
            font-size: 2.5rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: #00ffe1;
            text-shadow: 0 0 10px #00ffe1;
            margin-top: 40px;
        }
        .card {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            padding: 20px 30px;
            margin: 20px;
            width: 90%;
            max-width: 500px;
            backdrop-filter: blur(6px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.3);
            transition: transform 0.3s ease;
        }
        .card:hover { transform: translateY(-5px); }
        .card p { margin: 10px 0; font-size: 1.1rem; }

        /* Estilo para las estrellas de rating */
        .rating {
            display: flex;
            justify-content: start;
            gap: 8px;
            margin-top: 10px;
        }
        .rating input { display: none; } /* Oculta los radio buttons */
        .rating label {
            font-size: 25px;
            color: #555;
            cursor: pointer;
            transition: color 0.3s ease;
        }
        .rating input:checked ~ label,
        .rating label:hover,
        .rating label:hover ~ label {
            color: #00ffe1;
            text-shadow: 0 0 5px #00ffe1;
        }

        /* Pie de página (aunque no está incluido en el HTML visual) */
        footer {
            margin-top: auto;
            padding: 15px;
            text-align: center;
            color: #aaa;
            font-size: 0.9rem;
        }

        /* Alinea a la derecha opcionalmente una tarjeta */
        .right-align {
            align-self: flex-end;
            margin-right: 5%;
        }

        /* Formulario de búsqueda */
        .search-form {
            margin-bottom: 20px;
            width: 90%;
            max-width: 500px;
        }
        .search-form input {
            width: 100%;
            padding: 10px 15px;
            border-radius: 8px;
            border: none;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.15);
            color: #fff;
            box-shadow: 0 0 8px #00ffe1;
            outline: none;
        }

        /* Botones de categoría */
        .btn-toggle {
            background-color: #00ffe1;
            color: #111;
            padding: 10px 20px;
            margin: 10px;
            font-weight: bold;
            border-radius: 6px;
            cursor: pointer;
            border: none;
            box-shadow: 0 0 10px #00ffe1;
        }
        .btn-toggle:hover {
            background-color: #00e0c6;
        }
    </style>
</head>
<body>

<h1>Servicios</h1>

<!-- Formulario de búsqueda GET -->
<form method="GET" class="search-form">
    <input type="text" name="buscar" placeholder="Buscar servicio..." value="<?= htmlspecialchars($_GET['buscar'] ?? '') ?>">
</form>

<!-- Botones para filtrar por categoría -->
<div id="botones-categorias">
    <button type="button" class="btn-toggle" onclick="mostrarCategoria('Transporte')">Transporte</button>
    <button type="button" class="btn-toggle" onclick="mostrarCategoria('Construccion')">Construcción</button>
    <button type="button" class="btn-toggle" onclick="mostrarCategoria('Informatica')">Informática</button>
    <button type="button" class="btn-toggle" onclick="mostrarCategoria('Educacion')">Educación</button>
    <button type="button" class="btn-toggle" onclick="mostrarCategoria('VentaRopa')">Venta de Ropa</button>
    <button type="button" class="btn-toggle" onclick="mostrarCategoria('Seguridad')">Seguridad</button>
    <button type="button" class="btn-toggle" onclick="mostrarCategoria('Limpieza')">Limpieza</button>
    <button type="button" class="btn-toggle" onclick="mostrarCategoria('Mantenimiento')">Mantenimiento</button>
    <button type="button" class="btn-toggle" onclick="mostrarCategoria('Electrodomesticos')">Electrodomésticos</button>
    <button type="button" class="btn-toggle" onclick="mostrarCategoria('Turismo')">Turismo</button>
    <button id="btnTodos" type="button" class="btn-toggle" onclick="mostrarTodos()" style="display: none;">Ver todos los servicios</button>
</div>

<!-- Sección para mostrar todos los servicios -->
<div id="todos">
    <?php if (count($servicios) == 0): ?>
        <h2>NO HAY SERVICIOS</h2>
    <?php else: ?>
        <?php foreach ($servicios as $i => $serv): ?>
            <div class="card <?= $i === 1 ? 'right-align' : '' ?>">
                <?php
                // Imagen por defecto, cambia según el nombre del servicio
                $imagen = '/imagenes/default.png';
                if ($serv['nombre'] === 'Carpintería') $imagen = '/imagenes/ChivitaCarpintera.jpeg';
                elseif ($serv['nombre'] === 'Electricidad') $imagen = '/imagenes/ChivitaElectricista.png';
                ?>
                <img src="<?= $imagen ?>" alt="Imagen del servicio" style="width: 15%; border-radius: 10px; margin-bottom: 15px;">
                <p><strong>ID:</strong> <?= htmlspecialchars($serv["id"]) ?></p>
                <p><strong>Nombre:</strong> <?= htmlspecialchars($serv["nombre"]) ?></p>
                <p><strong>Descripción:</strong> <?= htmlspecialchars($serv["descripcion"]) ?></p>
                <p><strong>Precio:</strong> $<?= htmlspecialchars($serv["precio"]) ?></p>
                <div class="rating">
                    <?php for ($star = 5; $star >= 1; $star--): ?>
                        <input type="radio" name="rating_<?= $i ?>" id="star<?= $star ?>_<?= $i ?>" value="<?= $star ?>">
                        <label for="star<?= $star ?>_<?= $i ?>">★</label>
                    <?php endfor; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Secciones individuales por categoría (se muestran con JS) -->
<?php
$categorias = ['Transporte', 'Construccion', 'Informatica', 'Educacion', 'VentaRopa', 'Seguridad', 'Limpieza', 'Mantenimiento', 'Electrodomesticos', 'Turismo'];
foreach ($categorias as $cat):
?>
<div id="<?= $cat ?>" style="display: none;">
    <h2>Servicios de <?= ucfirst($cat) ?></h2>
    <?php foreach ($servicios as $s): ?>
        <?php if (strtolower($s['categoria']) === strtolower($cat)): ?>
            <div class="card">
                <p><strong>ID:</strong> <?= htmlspecialchars($s["id"]) ?></p>
                <p><strong>Nombre:</strong> <?= htmlspecialchars($s["nombre"]) ?></p>
                <p><strong>Descripción:</strong> <?= htmlspecialchars($s["descripcion"]) ?></p>
                <p><strong>Precio:</strong> $<?= htmlspecialchars($s["precio"]) ?></p>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
</div>
<?php endforeach; ?>

<!-- JavaScript para control de visibilidad por categoría -->
<script>
    window.onload = function() {
        mostrarTodos();       // Al cargar la página, se muestran todos
        cargarRatings();      // Y se cargan las calificaciones guardadas
    }

    function mostrarCategoria(nombre) {
        const categorias = ['todos', 'Transporte', 'Construccion', 'Informatica', 'Educacion', 'VentaRopa', 'Seguridad', 'Limpieza', 'Mantenimiento', 'Electrodomesticos', 'Turismo'];
        categorias.forEach(c => {
            const el = document.getElementById(c);
            if(el) el.style.display = (c === nombre) ? 'block' : 'none';
        });

        // Solo muestra el botón "Ver todos" al seleccionar una categoría
        document.getElementById('botones-categorias').querySelectorAll('button').forEach(btn => {
            btn.style.display = (btn.id === 'btnTodos') ? 'inline-block' : 'none';
        });
    }

    function mostrarTodos() {
        const categorias = ['todos', 'Transporte', 'Construccion', 'Informatica', 'Educacion', 'VentaRopa', 'Seguridad', 'Limpieza', 'Mantenimiento', 'Electrodomesticos', 'Turismo'];
        categorias.forEach(c => {
            const el = document.getElementById(c);
            if(el) el.style.display = (c === 'todos') ? 'block' : 'none';
        });

        // Oculta el botón "Ver todos" al estar ya en esa vista
        document.getElementById('botones-categorias').querySelectorAll('button').forEach(btn => {
            btn.style.display = (btn.id === 'btnTodos') ? 'none' : 'inline-block';
        });
    }

    // Guarda en localStorage la puntuación marcada por el usuario
    document.addEventListener('change', function(e) {
        if(e.target.matches('.rating input[type="radio"]')) {
            localStorage.setItem(e.target.name, e.target.value);
        }
    });

    // Al recargar la página, restaura el rating desde localStorage
    function cargarRatings() {
        const inputs = document.querySelectorAll('.rating input[type="radio"]');
        inputs.forEach(input => {
            const savedValue = localStorage.getItem(input.name);
            if(savedValue === input.value) {
                input.checked = true;
            }
        });
    }
</script>

</body>
</html>

