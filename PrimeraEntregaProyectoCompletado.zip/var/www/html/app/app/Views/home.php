<!DOCTYPE html>
<html lang="es">
<head>
    <!-- Configuración básica del documento -->
    <meta charset="UTF-8">
    <!-- Título dinámico con valor por defecto -->
    <title><?= $title ?? 'LED Dashboard' ?></title>

    <!-- Enlace al CSS externo -->
    <link rel="stylesheet" href="/css/style.css">
    <!-- Fuente futurista y moderna desde Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Orbitron&family=Roboto&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Estilos embebidos para diseño moderno y oscuro -->
    <style>
        /* Estilo general del cuerpo */
        body {
            margin: 0;
            padding: 0;
            background: radial-gradient(circle at top, #1a1a2e, #16213e);
            color: #fff;
            font-family: 'Roboto', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            min-height: 100vh;
        }

        /* Encabezado con fondo translúcido y sombra */
        header {
            padding: 40px;
            text-align: center;
            background: rgba(255, 255, 255, 0.05);
            width: 100%;
            box-shadow: 0 0 15px #0f0c29;
        }

        /* Título llamativo y futurista */
        h1 {
            font-family: 'Orbitron', sans-serif;
            font-size: 2.5rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: #00ffe1;
            text-shadow: 0 0 10px #00ffe1;
        }

        /* Párrafos generales */
        p {
            font-size: 1.2rem;
            text-align: center;
        }

        /* Tarjeta visual para contenido destacado */
        .card {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            padding: 20px 30px;
            margin: 20px;
            max-width: 500px;
            backdrop-filter: blur(6px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.3);
            transition: transform 0.3s ease;
        }

        /* Efecto de flotación al pasar el mouse */
        .card:hover {
            transform: translateY(-5px);
        }

        /* Botón con efecto neón */
        .neon-btn {
            margin-top: 15px;
            display: inline-block;
            background: #00ffe1;
            color: #111;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            text-decoration: none;
            box-shadow: 0 0 12px #00ffe1;
            transition: background 0.3s ease;
        }

        .neon-btn:hover {
            background: #00e0c6;
        }

        /* Pie de página sencillo */
        footer {
            margin-top: auto;
            padding: 15px;
            text-align: center;
            color: #aaa;
            font-size: 0.9rem;
        }

        /* Contenedor del formulario flotante oculto */
        .form-container {
            background-color: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 40vw;
            max-height: 60vh;
            overflow-y: auto;
            display: none; /* Oculto por defecto */
            position: fixed;
            top: 30px;
            right: 10px;
            z-index: 999;
        }

        /* Título del formulario */
        .form-title {
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        /* Grupo de elementos del formulario */
        .form-group {
            margin-bottom: 15px;
        }

        /* Etiquetas de los campos */
        .form-label {
            display: block;
            font-size: 14px;
            color: #333;
            margin-bottom: 5px;
            font-weight: normal;
        }

        /* Campos de entrada */
        .form-input {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            background-color: #fff;
            transition: border-color 0.3s ease;
        }

        /* Estilo cuando el input está enfocado */
        .form-input:focus {
            outline: none;
            border-color: #007bff;
        }

        /* Estilo para el input de archivo */
        .file-input-container {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .file-input {
            padding: 6px 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            background-color: #f8f9fa;
            font-size: 12px;
            cursor: pointer;
        }

        .file-input:hover {
            background-color: #e9ecef;
        }

        .file-text {
            font-size: 12px;
            color: #666;
        }

        /* Botón para enviar formulario */
        .submit-btn {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        /* Texto gris claro para campos opcionales */
        .website-placeholder {
            color: #999;
        }
    </style>

    <!-- Encabezado del sitio -->
    <header>
        <h1><?= $title ?></h1>
        <p> Equipo LED | Trabajo en Proceso 🚀</p>
    </header>

    <!-- Botón flotante para mostrar formulario de empresarios -->
    <button onclick="toggleFormulario()" 
        style="position: fixed; top: 20px; right: 20px; z-index: 1000; background-color: #00ffe1; color: #111; border: none; padding: 10px 15px; border-radius: 6px; cursor: pointer; font-weight: bold; box-shadow: 0 0 8px #00ffe1;">
        Registro Empresario
    </button>

    <!-- Formulario oculto para registro de empresarios -->
    <div id="formularioEmpresario" class="form-container">
        <h1 class="form-title">Registro para Empresarios</h1>

        <form>
            <!-- Campos del formulario -->
            <div class="form-group">
                <label class="form-label" for="nombre-representante">Nombre del representante:</label>
                <input type="text" id="nombre-representante" class="form-input">
            </div>

            <div class="form-group">
                <label class="form-label" for="nombre-empresa">Nombre de la empresa:</label>
                <input type="text" id="nombre-empresa" class="form-input">
            </div>

            <div class="form-group">
                <label class="form-label" for="ruc-cif">RUC / CIF:</label>
                <input type="text" id="ruc-cif" class="form-input">
            </div>

            <div class="form-group">
                <label class="form-label" for="telefono">Teléfono de contacto:</label>
                <input type="tel" id="telefono" class="form-input">
            </div>

            <div class="form-group">
                <label class="form-label" for="direccion">Dirección:</label>
                <input type="text" id="direccion" class="form-input">
            </div>

            <div class="form-group">
                <label class="form-label" for="sector">Sector / Rubro:</label>
                <input type="text" id="sector" class="form-input">
            </div>

            <div class="form-group">
                <label class="form-label" for="sitio-web">Sitio web:</label>
                <input type="url" id="sitio-web" class="form-input website-placeholder" placeholder="https://ejemplo.com">
            </div>

            <div class="form-group">
                <label class="form-label" for="logo">Logo de la empresa:</label>
                <div class="file-input-container">
                    <input type="file" id="logo" accept="image/*" style="display: none;">
                    <button type="button" class="file-input" onclick="document.getElementById('logo').click();">
                        Elegir archivo
                    </button>
                    <span class="file-text">No se ha seleccionado ningún archivo</span>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="email">Correo electrónico:</label>
                <input type="email" id="email" class="form-input">
            </div>

            <div class="form-group">
                <label class="form-label" for="password">Contraseña:</label>
                <input type="password" id="password" class="form-input">
            </div>

            <button type="submit" class="submit-btn">Registrarse como Empresario</button>
        </form>
    </div>

    <!-- Script para mostrar/ocultar el formulario y manejar el archivo -->
    <script>
        function toggleFormulario() {
            const form = document.getElementById('formularioEmpresario');
            form.style.display = (form.style.display === 'none' || form.style.display === '') ? 'block' : 'none';
        }

        // Muestra el nombre del archivo elegido
        document.getElementById('logo').addEventListener('change', function(e) {
            const fileText = document.querySelector('.file-text');
            fileText.textContent = e.target.files.length > 0 ? e.target.files[0].name : 'No se ha seleccionado ningún archivo';
        });

        // Prevención del envío real del formulario (solo demo)
        document.querySelector('form').addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Formulario enviado (esto es solo una demostración)');
        });
    </script>

    <!-- Contenido dinámico adicional (inyectado desde controlador) -->
    <?= $content ?? '' ?>

    <!-- Pie de página con año dinámico -->
    <footer>
        &copy; <?= date("Y") ?> — Equipo LED
    </footer>
</body>
</html>


