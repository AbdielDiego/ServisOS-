<?php
namespace App\Models;

use App\Core\Model;

class PasswordReset extends Model
{
    // Nombre de la tabla asociada
    protected $table = 'password_resets';

    // Clave primaria de la tabla
    protected $primaryKey = 'id';

    /**
     * Crea un registro de reseteo de contraseña para un email.
     * - Genera un hash del token en claro.
     * - Define fecha de expiración (por defecto 30 minutos).
     * - Inserta un registro en la tabla password_resets.
     *
     * @param string $email      Correo del usuario
     * @param string $tokenPlain Token en claro (se hashea antes de guardar)
     * @param int    $ttlMinutes Tiempo de vida en minutos
     * @return bool              True si la inserción fue exitosa
     */
    public static function createForEmail(string $email, string $tokenPlain, int $ttlMinutes = 30): bool
    {
        $instance = new static();
        $hash = hash('sha256', $tokenPlain); // Hash seguro del token
        $expires = (new \DateTime("+{$ttlMinutes} minutes"))->format('Y-m-d H:i:s'); // Fecha de expiración

        $sql = "INSERT INTO password_resets (email, token_hash, expires_at) VALUES (?, ?, ?)";
        return (bool) $instance->db->query($sql, [$email, $hash, $expires]);
    }

    /**
     * Busca un token válido para un email.
     * - Verifica que el token hash coincida y que no esté expirado.
     * - Devuelve el registro o null si no es válido.
     *
     * @param string $email      Correo del usuario
     * @param string $tokenPlain Token en claro recibido del enlace
     * @return array|null        Datos del registro o null si no es válido
     */
    public static function findValid(string $email, string $tokenPlain): ?array
    {
        $instance = new static();
        $hash = hash('sha256', $tokenPlain); // Se calcula el hash del token
        $sql = "SELECT * 
                  FROM password_resets 
                 WHERE email = ? 
                   AND token_hash = ? 
                   AND expires_at > NOW() 
              ORDER BY id DESC 
                 LIMIT 1";

        $row = $instance->db->query($sql, [$email, $hash])->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * Elimina todos los registros de reseteo de un email específico.
     *
     * @param string $email Correo del usuario
     */
    public static function deleteForEmail(string $email): void
    {
        $instance = new static();
        $instance->db->query("DELETE FROM password_resets WHERE email = ?", [$email]);
    }
}

