<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Model;
use App\Core\Database;
use PDO;

class Comment extends Model
{
    public function __construct()
    {
        // Respetamos el constructor del padre si existe
        if (is_callable([Model::class, '__construct'])) {
            parent::__construct();
        }

        // NO redeclaramos propiedades tipadas del padre.
        // Solo las seteamos en runtime para evitar el fatal "Type must not be defined".
        $this->table = 'Comments';
        if (property_exists($this, 'primaryKey')) {
            $this->primaryKey = 'comment_id';
        }
    }

    /* ---------------------------------------------------------
     * Fallback para obtener un PDO funcional desde el wrapper
     * --------------------------------------------------------- */
    protected function pdo(): PDO
    {
        // 1) Si el padre ya tiene PDO
        if ($this->db instanceof PDO) {
            return $this->db;
        }
        // 2) Algunos wrappers exponen ->pdo
        if (is_object($this->db) && property_exists($this->db, 'pdo') && $this->db->pdo instanceof PDO) {
            return $this->db->pdo;
        }
        // 3) Conexión directa
        $pdo = Database::getConnection();
        $pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    }

    /* ---------------------------------------------------------
     * Crear comentario (acepta ambas firmas):
     *   - create(['post_id'=>..., 'user_id'=>..., 'comment_text'=>...])
     *   - create($postId, $userId, $text)
     * Devuelve el ID insertado (comment_id)
     * --------------------------------------------------------- */
    public function create($dataOrPostId, ?int $userId = null, ?string $text = null): int
    {
        if (is_array($dataOrPostId)) {
            $postId      = (int)($dataOrPostId['post_id'] ?? 0);
            $userIdInput = $dataOrPostId['user_id'] ?? null;
            $commentText = (string)($dataOrPostId['comment_text'] ?? ($dataOrPostId['comment'] ?? ''));
            $uid         = ($userIdInput === '' || $userIdInput === null) ? null : (int)$userIdInput;
        } else {
            $postId      = (int)$dataOrPostId;
            $uid         = $userId;
            $commentText = (string)($text ?? '');
        }

        if ($postId <= 0 || $commentText === '') {
            throw new \InvalidArgumentException('Datos de comentario incompletos');
        }

        $sql = "INSERT INTO `{$this->table}` (`post_id`,`user_id`,`comment_text`)
                VALUES (:post_id, :user_id, :comment_text)";

        // 1) Si hay wrapper con insert(...)
        if (is_object($this->db) && method_exists($this->db, 'insert')) {
            return (int)$this->db->insert($sql, [
                'post_id'      => $postId,
                'user_id'      => $uid,
                'comment_text' => $commentText,
            ]);
        }

        // 2) Wrapper con query(...)
        if (is_object($this->db) && method_exists($this->db, 'query')) {
            try {
                $this->db->query($sql, [
                    'post_id'      => $postId,
                    'user_id'      => $uid,
                    'comment_text' => $commentText,
                ]);
            } catch (\Throwable $e) {
                // Algunos wrappers requieren los dos puntos
                $this->db->query($sql, [
                    ':post_id'      => $postId,
                    ':user_id'      => $uid,
                    ':comment_text' => $commentText,
                ]);
            }

            if (method_exists($this->db, 'lastInsertId')) {
                return (int)$this->db->lastInsertId();
            }
            if (property_exists($this->db, 'pdo') && $this->db->pdo instanceof PDO) {
                return (int)$this->db->pdo->lastInsertId();
            }
            // Fallback "truthy" si el controlador solo valida éxito
            return 1;
        }

        // 3) PDO nativo
        $pdo  = $this->pdo();
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':post_id', $postId, PDO::PARAM_INT);
        if ($uid === null) $stmt->bindValue(':user_id', null, PDO::PARAM_NULL);
        else               $stmt->bindValue(':user_id', $uid, PDO::PARAM_INT);
        $stmt->bindValue(':comment_text', $commentText, PDO::PARAM_STR);
        $stmt->execute();
        return (int)$pdo->lastInsertId();
    }

    /* ---------------------------------------------------------
     * Alias claro si lo prefieres en controladores
     * --------------------------------------------------------- */
    public function createForPost(int $postId, ?int $userId, string $text): int
    {
        return $this->create($postId, $userId, $text);
    }

    /* ---------------------------------------------------------
     * Listar comentarios por post (últimos primero)
     * Devuelve: comment_id, post_id, user_id, username, comment_text, created_at
     * También expone 'body' como alias legacy del texto.
     * --------------------------------------------------------- */
    public function findByPostId(int $postId): array
    {
        $sql = "SELECT
                    c.comment_id,
                    c.post_id,
                    c.user_id,
                    c.comment_text,
                    c.comment_text AS body,   -- alias para vistas antiguas
                    c.created_at,
                    u.username
                FROM `{$this->table}` c
                LEFT JOIN `Users` u ON u.user_id = c.user_id
               WHERE c.post_id = :post_id
            ORDER BY c.created_at DESC, c.comment_id DESC";

        // Wrapper
        if (is_object($this->db) && method_exists($this->db, 'query')) {
            try {
                $res = $this->db->query($sql, ['post_id' => $postId]);
            } catch (\Throwable $e) {
                $res = $this->db->query($sql, [':post_id' => $postId]);
            }
            if (is_object($res) && method_exists($res, 'fetchAll')) {
                return $res->fetchAll();
            }
            return (array)$res;
        }

        // PDO
        $pdo  = $this->pdo();
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':post_id', $postId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    /* ---------------------------------------------------------
     * Utilidades: dueño y post del comentario, y borrado
     * --------------------------------------------------------- */
    public function getOwnerAndPost(int $commentId): ?array
    {
        $pk  = $this->primaryKey ?? 'comment_id';
        $sql = "SELECT {$pk} AS comment_id, user_id, post_id
                  FROM {$this->table}
                 WHERE {$pk} = :id";

        // Wrapper
        if (is_object($this->db) && method_exists($this->db, 'query')) {
            try {
                $res = $this->db->query($sql, ['id' => $commentId]);
            } catch (\Throwable $e) {
                $res = $this->db->query($sql, [':id' => $commentId]);
            }
            if (is_object($res) && method_exists($res, 'fetch')) {
                $row = $res->fetch();
            } else {
                $row = is_array($res[0] ?? null) ? $res[0] : null;
            }
            return $row ?: null;
        }

        // PDO
        $pdo  = $this->pdo();
        $st   = $pdo->prepare($sql);
        $st->bindValue(':id', $commentId, PDO::PARAM_INT);
        $st->execute();
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public function deleteById(int $commentId): bool
    {
        $pk  = $this->primaryKey ?? 'comment_id';
        $sql = "DELETE FROM {$this->table} WHERE {$pk} = :id";

        // Wrapper
        if (is_object($this->db) && method_exists($this->db, 'query')) {
            try {
                $res = $this->db->query($sql, ['id' => $commentId]);
            } catch (\Throwable $e) {
                $res = $this->db->query($sql, [':id' => $commentId]);
            }
            if (is_int($res)) return $res > 0;      // algunos wrappers devuelven filas afectadas
            return $this->getOwnerAndPost($commentId) === null; // fallback
        }

        // PDO
        $pdo = $this->pdo();
        $st  = $pdo->prepare($sql);
        $st->bindValue(':id', $commentId, PDO::PARAM_INT);
        $st->execute();
        return $st->rowCount() > 0;
    }
}

