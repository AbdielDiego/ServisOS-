<?php
namespace App\Models;

use App\Core\Model;
use App\Core\Database;
use PDO;

class User extends Model
{
    /** Nombres reales en la BD (ojo a mayúsculas/minúsculas) */
    protected $table = 'Users';
    protected $primaryKey = 'user_id';

    protected function pdo(): PDO
    {
        $pdo = Database::getConnection();
        $pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    }

    /**
     * Lista SOLO usuarios NO baneados (según tabla BanUsers).
     * Filtros: ['user' => string, 'email' => string]
     */
    public function listActive(array $filters = []): array
    {
        $sql = "SELECT
                    u.{$this->primaryKey} AS user_id,
                    u.username,
                    u.email,
                    u.rol_id AS role_id,
                    u.created_at
                FROM {$this->table} u
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM BanUsers b
                    WHERE b.user_id = u.{$this->primaryKey}
                )";

        $params = [];

        if (!empty($filters['user'])) {
            $sql .= " AND u.username LIKE :user";
            $params[':user'] = '%'.$filters['user'].'%';
        }
        if (!empty($filters['email'])) {
            $sql .= " AND u.email LIKE :email";
            $params[':email'] = '%'.$filters['email'].'%';
        }

        $sql .= " ORDER BY u.{$this->primaryKey} DESC";

        $st = $this->pdo()->prepare($sql);
        $st->execute($params);
        return $st->fetchAll();
    }

    /** Obtener usuario por ID (exponiendo rol como role_id) */
    public function getById(int $id): ?array
    {
        $st = $this->pdo()->prepare(
            "SELECT user_id, username, email, rol_id AS role_id, created_at
             FROM {$this->table}
             WHERE {$this->primaryKey} = :id
             LIMIT 1"
        );
        $st->execute([':id' => $id]);
        $row = $st->fetch();
        return $row ?: null;
    }

    /** === NUEVO ===: Buscar por email incluyendo el hash de contraseña */
    public function findByEmail(string $email): ?array
    {
        $st = $this->pdo()->prepare(
            "SELECT user_id, username, email, password, rol_id AS role_id, created_at
             FROM {$this->table}
             WHERE email = :email
             LIMIT 1"
        );
        $st->execute([':email' => $email]);
        $row = $st->fetch();
        return $row ?: null;
    }

    /** ¿Está baneado este usuario? (tabla BanUsers) */
    public function isBanned(int $userId): bool
    {
        $st = $this->pdo()->prepare("SELECT 1 FROM BanUsers WHERE user_id = :id LIMIT 1");
        $st->execute([':id' => $userId]);
        return (bool) $st->fetchColumn();
    }
}


