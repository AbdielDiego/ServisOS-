<link rel="stylesheet" href="/css/minuevo.css">
<main class="minuevo">
  <article class="card">
    <h1 style="margin:0 0 12px;"><?= htmlspecialchars($post['title'], ENT_QUOTES, 'UTF-8') ?></h1>
    <p class="meta">
      <strong>Autor:</strong> <?= htmlspecialchars($post['author'], ENT_QUOTES, 'UTF-8') ?>
      <?php if (!empty($post['category'])): ?>
        &nbsp;|&nbsp; <strong>Categoría:</strong> <?= htmlspecialchars($post['category'], ENT_QUOTES, 'UTF-8') ?>
      <?php endif; ?>
      &nbsp;|&nbsp; <strong>Fecha:</strong> <?= htmlspecialchars(date('Y-m-d', strtotime($post['created_at'])), ENT_QUOTES, 'UTF-8') ?>
    </p>

    <p class="meta"><strong>Rating promedio:</strong> <?= number_format((float)($avgRating ?? 0), 2) ?> / 5</p>

    <div style="margin-top:10px;">
      <?= nl2br(htmlspecialchars($post['content'], ENT_QUOTES, 'UTF-8')) ?>
    </div>
  </article>

  <?php
    $uid = $_SESSION['auth']['user']['user_id'] ?? $_SESSION['user']['user_id'] ?? null;
    $esPropio = $uid && isset($post['author_id']) && ((int)$post['author_id'] === (int)$uid);
  ?>

  <?php if ($uid && !$esPropio): ?>
    <form action="/article/<?= (int)$post['post_id'] ?>/rate" method="post" class="card form" style="margin-top:16px;">
      <div class="field">
        <label for="rating">Tu puntaje (1–5)</label>
        <select id="rating" name="rating" required>
          <?php for ($i=1;$i<=5;$i++): ?>
            <option value="<?= $i ?>" <?= (isset($userRating) && (int)$userRating === $i) ? 'selected' : '' ?>><?= $i ?></option>
          <?php endfor; ?>
        </select>
      </div>
      <button class="btn">Guardar puntaje</button>
    </form>
  <?php elseif ($uid && $esPropio): ?>
    <div class="card" style="margin-top:16px;">
      <p class="meta">No podés puntuar tu propio artículo.</p>
    </div>
  <?php else: ?>
    <div class="card" style="margin-top:16px;">
      <p class="meta">¿Querés puntuar este artículo? <a href="/login">Inicia sesión</a>.</p>
    </div>
  <?php endif; ?>

  <p style="margin-top:16px;"><a class="btn" href="/minuevo">← Volver</a></p>
</main>

