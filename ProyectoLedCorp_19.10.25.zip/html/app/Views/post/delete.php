<?php
if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

$postId   = (int)($_GET['post_id'] ?? 0);
$flashOk  = $_SESSION['flash_ok']   ?? $_SESSION['flash_success'] ?? null;
$flashErr = $_SESSION['flash_error'] ?? null;

// Limpiar flashes para no reaparecer
unset($_SESSION['flash_ok'], $_SESSION['flash_success'], $_SESSION['flash_error']);
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Comentario eliminado</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Si tienes un styles.css global, enlázalo aquí -->
  <link rel="stylesheet" href="/css/styles.css">
  <style>
    /* Estilos mínimos por si no cargas tu CSS global */
    body { background:#0b1420; color:#e8f0ff; font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu; margin:0; }
    .wrap{ max-width:800px; margin:6rem auto; padding:2rem; text-align:center; }
    .card{ background:#111a29; border-radius:16px; padding:2rem; box-shadow:0 10px 30px rgba(0,0,0,.25); }
    .ok{ background:#0b2e2a; color:#8ff3d9; padding:.75rem 1rem; border-radius:10px; margin-bottom:1rem; display:inline-block;}
    .err{ background:#3a1216; color:#ff9aa3; padding:.75rem 1rem; border-radius:10px; margin-bottom:1rem; display:inline-block;}
    .btn{ display:inline-block; padding:.8rem 1.2rem; border-radius:12px; text-decoration:none; background:#10e7e0; color:#052029; margin:.4rem; font-weight:600;}
    .btn.secondary{ background:#2b3344; color:#e8f0ff; }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>Comentario eliminado</h1>

      <?php if ($flashOk): ?>
        <div class="ok"><?= htmlspecialchars($flashOk, ENT_QUOTES, 'UTF-8') ?></div>
      <?php endif; ?>

      <?php if ($flashErr): ?>
        <div class="err"><?= htmlspecialchars($flashErr, ENT_QUOTES, 'UTF-8') ?></div>
      <?php endif; ?>

      <p>Tu comentario fue procesado correctamente.</p>

      <p>
        <?php if ($postId > 0): ?>
          <a class="btn" href="/post/<?= $postId ?>#comentarios">Volver al post</a>
        <?php endif; ?>
        <a class="btn secondary" href="/">Ir al inicio</a>
      </p>
    </div>
  </div>
</body>
</html>

