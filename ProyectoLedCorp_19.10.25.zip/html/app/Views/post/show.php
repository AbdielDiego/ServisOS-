<?php
/** @var array $post */
/** @var array $comments */
/** @var bool  $focusForm */
/** @var string|null $commentAction */

if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }

// Helper de escape
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$postId  = (int)($post['post_id'] ?? 0);
$title   = h($post['title'] ?? 'Post');
$content = nl2br(h($post['content'] ?? ''));

// Acción del formulario de comentario:
// prioriza $commentAction (enviado por el controlador) y hace fallback a /posts/{id}/comments
$formAction = isset($commentAction) && $commentAction
  ? (string)$commentAction
  : "/posts/{$postId}/comments";

// ---- Autenticación y permisos (compat con varios formatos de sesión) ----
$viewerId = (int)(
    $_SESSION['user']['user_id'] ?? $_SESSION['user_id'] ?? ($_SESSION['auth']['user_id'] ?? 0)
);

$viewerRol   = (string)($_SESSION['rol'] ?? ($_SESSION['user']['rol_name'] ?? ''));
$viewerRolId = (int)   ($_SESSION['rol_id'] ?? ($_SESSION['user']['rol_id'] ?? 0));
$isAdmin     = ($viewerRol === 'Admin') || ($viewerRolId === 1);
$isAuth      = $viewerId > 0;

// Flash (compat)
$flashOk    = $_SESSION['flash_ok']    ?? null;
$flashError = $_SESSION['flash_error'] ?? null;
unset($_SESSION['flash_ok'], $_SESSION['flash_error']);
?>
<section class="post-show" style="max-width:980px;margin:0 auto;padding:24px;">
  <h1 style="margin:0 0 6px 0;"><?= $title ?></h1>
  <p style="opacity:.85;margin:0 0 16px 0;"><?= $content ?></p>

  <?php if (!empty($flashOk)): ?>
    <div class="alert alert-success" style="background:#064e3b;color:#d1fae5;padding:10px 12px;border-radius:10px;margin:10px 0;">
      <?= h($flashOk) ?>
    </div>
  <?php endif; ?>
  <?php if (!empty($flashError)): ?>
    <div class="alert alert-danger" style="background:#3f1d1d;color:#fee2e2;padding:10px 12px;border-radius:10px;margin:10px 0;">
      <?= h($flashError) ?>
    </div>
  <?php endif; ?>

  <!-- ====== Formulario: Comentar ====== -->
  <h2 id="comentar" style="margin-top:22px;">Comentar</h2>

  <?php if ($isAuth): ?>
    <form action="<?= h($formAction) ?>" method="post" style="margin:10px 0 24px 0;">
      <!-- El endpoint /posts/:id/comments no requiere post_id, pero lo incluimos por compat -->
      <input type="hidden" name="post_id" value="<?= $postId ?>">
      <textarea name="comment_text" rows="4" required minlength="2"
        placeholder="Escribe tu comentario..."
        style="width:100%;padding:12px;border-radius:10px;background:#1f2937;color:#e5e7eb;border:1px solid #374151;"></textarea>
      <button type="submit"
        style="margin-top:10px;width:100%;padding:12px;border-radius:999px;background:#06b6d4;color:#022;font-weight:700;border:0;">
        Publicar
      </button>
    </form>
  <?php else: ?>
    <p><a href="/login">Inicia sesión</a> para comentar.</p>
  <?php endif; ?>

  <!-- ====== Listado de comentarios ====== -->
  <h2 id="comentarios" style="margin-top:24px;">Comentarios</h2>

  <?php if (empty($comments)): ?>
    <p>No hay comentarios aún.</p>
  <?php else: ?>
    <ul style="list-style:none;padding:0;margin:0;display:grid;gap:12px;">
      <?php foreach ($comments as $c): ?>
        <?php
          $cid    = (int)($c['comment_id'] ?? 0);
          $owner  = (int)($c['user_id'] ?? 0);
          $uname  = h($c['username'] ?? 'Anónimo');
          $texto  = nl2br(h($c['comment_text'] ?? ($c['body'] ?? '')));
          $fecha  = h($c['created_at'] ?? '');
          $canDel = ($isAdmin || ($owner > 0 && $owner === $viewerId));
        ?>
        <li style="background:#0f172a;border-radius:12px;padding:12px 14px;">
          <div style="font-size:.95rem;margin-bottom:6px;display:flex;gap:8px;align-items:center;justify-content:space-between;">
            <div>
              <strong><?= $uname ?></strong>
              <small style="opacity:.6;"> — <?= $fecha ?></small>
            </div>

            <?php if ($canDel && $cid > 0): ?>
              <form action="/comment/delete" method="POST"
                    onsubmit="return confirm('¿Eliminar este comentario?')"
                    style="margin:0;">
                <input type="hidden" name="comment_id" value="<?= $cid ?>">
                <button type="submit"
                        style="padding:6px 10px;border-radius:999px;border:1px solid #dc2626;background:transparent;color:#fecaca;">
                  Eliminar
                </button>
              </form>
            <?php endif; ?>
          </div>
          <div><?= $texto ?></div>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>

<?php if (!empty($focusForm)): ?>
<script>
  // Si vienes desde /post/:id/comentar, enfoca el formulario
  const el = document.getElementById('comentar');
  if (el) el.scrollIntoView({behavior:'smooth', block:'start'});
</script>
<?php endif; ?>

