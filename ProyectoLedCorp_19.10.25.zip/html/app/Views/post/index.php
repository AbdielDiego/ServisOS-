<?php
/** @var array  $posts */
/** @var string $titulo (opcional) */
/** @var string $basePath (opcional) */

// Base para armar links relativos si lo necesitas
$BASE = htmlspecialchars(rtrim($basePath ?? '', '/'), ENT_QUOTES, 'UTF-8');
if ($BASE === '' || $BASE === '.') { $BASE = ''; }

/** Utilidad para extraer un rating (1..5) desde varias columnas posibles */
$pickRating = static function(array $row): int {
    foreach (['average_rating','avg','promedio','rating'] as $col) {
        if (array_key_exists($col, $row) && is_numeric($row[$col])) {
            $val = (int)round((float)$row[$col]);
            return max(1, min(5, $val));
        }
    }
    return 1;
};
?>
<section class="services">
  <h1 class="page-title"><?= htmlspecialchars($titulo ?? 'Servicios', ENT_QUOTES, 'UTF-8') ?></h1>

  <?php if (empty($posts)): ?>
    <p class="empty-state">No hay servicios.</p>
  <?php else: ?>
    <ul class="service-list" style="list-style:none; padding:0; margin:0;">
      <?php foreach ($posts as $p): ?>
        <?php
          $id      = (int)($p['post_id'] ?? 0);
          $rating  = $pickRating($p);
          $title   = (string)($p['title']      ?? '');
          $content = (string)($p['content']    ?? '');
          $created = (string)($p['created_at'] ?? '');
        ?>
        <li class="service-item" style="margin:14px 0; padding:16px; border-radius:12px; background:#0e1a23;">
          <div class="service-header" style="display:flex; align-items:center; justify-content:space-between; gap:12px;">
            <h3 style="margin:0; font-size:1.15rem;"><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></h3>
            <small><?= htmlspecialchars($created, ENT_QUOTES, 'UTF-8') ?></small>
          </div>

          <p style="margin:10px 0 14px;">
            <?= nl2br(htmlspecialchars(function_exists('mb_strimwidth') ? mb_strimwidth($content, 0, 160, '…') : (strlen($content) > 160 ? substr($content, 0, 157).'…' : $content), ENT_QUOTES, 'UTF-8')) ?>
          </p>

          <div class="actions" style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
            <!-- Comentar (lleva al mismo show con foco en el form) -->
            <a class="btn" href="<?= $BASE ?>/post/<?= $id ?>/comentar"
               style="padding:8px 14px; border-radius:999px; background:#23b8c0; color:#022; text-decoration:none; font-weight:600;">
              Comentar
            </a>

            <!-- Ver detalles (vista ligera sin comentarios) -->
            <a class="btn" href="<?= $BASE ?>/post/detail?id=<?= $id ?>"
               style="padding:8px 14px; border-radius:999px; background:#22d3ee; color:#022; text-decoration:none; font-weight:600;">
              Ver detalles
            </a>

            <!-- Ver comentarios (show) -->
            <a class="btn" href="<?= $BASE ?>/post/<?= $id ?>"
               style="padding:8px 14px; border-radius:999px; background:#18c6a3; color:#022; text-decoration:none; font-weight:600;">
              Ver comentarios
            </a>

            <!-- Enviar un mensaje al autor (si aplicara) -->
            <a class="btn" href="<?= $BASE ?>/messages/contact?post_id=<?= $id ?>"
               style="padding:8px 14px; border-radius:999px; background:#93c5fd; color:#022; text-decoration:none; font-weight:600;">
              Enviar un mensaje
            </a>

            <!-- Rating 1→5 con envío simple -->
            <span class="rating-simple" data-id="<?= $id ?>" style="margin-left:6px; color:#cfe;">
              <span class="rating-value"><?= $rating ?></span>/5
              <form action="<?= $BASE ?>/api/rate/simple" method="post" class="rating-form" style="display:inline">
                <input type="hidden" name="id" value="<?= $id ?>">
                <input type="hidden" name="rating" class="rating-input" value="<?= $rating ?>">
                <button type="button" class="btn btn-sm btn-increment"
                        style="padding:4px 10px; border-radius:999px; background:#22d3ee; color:#022; font-weight:700;"
                        title="Subir rating">➕</button>
              </form>
            </span>
          </div>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>

<script>
(function(){
  document.querySelectorAll('.rating-simple').forEach(function(box){
    var valueEl = box.querySelector('.rating-value');
    var inputEl = box.querySelector('.rating-input');
    var btn     = box.querySelector('.btn-increment');
    if (!btn || !valueEl || !inputEl) return;

    btn.addEventListener('click', function(){
      var form = btn.closest('form');
      var val  = parseInt(valueEl.textContent, 10) || 1;
      val = (val >= 5) ? 1 : (val + 1); // 1→5 cíclico
      valueEl.textContent = val;
      inputEl.value = val;

      fetch(form.action, { method: 'POST', body: new FormData(form) })
        .then(function(r){ return r.json().catch(function(){ return {ok:false}; }); })
        .then(function(data){
          if (!data || data.ok !== true) {
            alert((data && data.msg) ? data.msg : "Error al guardar rating");
          }
        })
        .catch(function(err){ console.error(err); });
    });
  });
})();
</script>








