<?php
/** @var string $title */
/** @var array  $flashes */
/** @var string $next */
/** @var array  $input */

$title    = $title ?? 'Iniciar sesión';
$emailVal = htmlspecialchars($input['email'] ?? '', ENT_QUOTES, 'UTF-8');
$nextVal  = isset($next) && $next !== '' ? htmlspecialchars($next, ENT_QUOTES, 'UTF-8') : '';
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="/css/styles.css" rel="stylesheet">
  <link href="/css/login.css" rel="stylesheet">
</head>
<body class="login-page">
  <main class="auth-container">
    <h1 class="auth-title"><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></h1>

    <?php
      // Mostrar mensajes (incluye el de "Usted está baneado..." si corresponde)
      $flashes = $flashes ?? [];
      include __DIR__ . '/../partials/flash.php';
    ?>

    <form class="auth-form" method="POST" action="/login" novalidate>
      <div class="field">
        <label for="email">Email</label>
        <input id="email" type="email" name="email" required autocomplete="username" value="<?= $emailVal ?>">
        <small>Ingrese su email</small>
      </div>

      <div class="field field-pass">
        <label for="password">Contraseña</label>
        <input id="password" type="password" name="password" required autocomplete="current-password" placeholder="Ingresa tu contraseña">
        <button type="button" class="toggle-pass" aria-pressed="false" aria-label="Mostrar u ocultar contraseña"></button>
        <small>Ingrese su contraseña</small>
      </div>

      <div class="auth-extras">
        <label class="remember"><input type="checkbox" name="remember" value="1"> Recuérdame</label>
        <a class="forgot" href="/forgot">Olvidé mi contraseña</a>
      </div>

      <?php if ($nextVal !== ''): ?>
        <input type="hidden" name="next" value="<?= $nextVal ?>">
      <?php endif; ?>

      <button type="submit" class="btn btn-primary">Ingresar</button>
    </form>

    <p class="back-home"><a href="/">Volver al inicio</a></p>
  </main>

  <script>
    (function () {
      var btn = document.querySelector('.toggle-pass');
      var input = document.getElementById('password');
      if (!btn || !input) return;
      btn.addEventListener('click', function () {
        var show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        this.setAttribute('aria-pressed', show ? 'true' : 'false');
      });
    })();
  </script>
</body>
</html>




