<?php
declare(strict_types=1);

/**
 * Banear usuario (mueve sus datos a BanUsers sin borrar Users)
 * Acepta:  ?id=  |  ?username=  |  ?email=  (también alias ?gmail=)
 * Opcionales: ?reason=  |  ?redirect=/usuarios
 */

if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

/* =========================================
 * Bootstrap mínimo para usar tu Database
 * ========================================= */
$ROOT = dirname(__DIR__);

// 1) Autoload (si usas Composer/PSR-4)
$autoload = $ROOT . '/vendor/autoload.php';
if (is_file($autoload)) {
    require_once $autoload;
}

// 2) Incluir Database si no se cargó por autoload
if (!class_exists('\App\Core\Database')) {
    $dbClass = $ROOT . '/app/Core/Database.php';
    if (is_file($dbClass)) require_once $dbClass;
    // por si tienes configuración separada
    $dbCfg1 = $ROOT . '/config/database.php';  if (is_file($dbCfg1)) require_once $dbCfg1;
    $dbCfg2 = $ROOT . '/app/config/database.php'; if (is_file($dbCfg2)) require_once $dbCfg2;
}

/* =========================================
 * Conexión PDO consistente con el proyecto
 * ========================================= */
function pdo(): PDO {
    // Usa SIEMPRE la conexión centralizada de la app
    if (class_exists('\App\Core\Database') && method_exists('\App\Core\Database', 'getConnection')) {
        $pdo = \App\Core\Database::getConnection();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    }

    // Fallback: variables de entorno (si existieran)
    $DB_HOST = getenv('DB_HOST') ?: '127.0.0.1';
    $DB_NAME = getenv('DB_NAME') ?: 'proyutu';
    $DB_USER = getenv('DB_USER') ?: 'appuser';   // <-- crea este usuario en tu BD
    $DB_PASS = getenv('DB_PASS') ?: 'apppass';   // <-- y esta contraseña

    $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4";
    return new PDO($dsn, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
}

/* =========================================
 * Crear tabla BanUsers si no existe
 * ========================================= */
function ensureBanTable(PDO $pdo): void {
    $sql = <<<SQL
CREATE TABLE IF NOT EXISTS `BanUsers` (
  `user_id`   INT(11)      NOT NULL,
  `username`  VARCHAR(50)  NOT NULL,
  `email`     VARCHAR(100) NOT NULL,
  `reason`    VARCHAR(255) DEFAULT NULL,
  `banned_by` INT(11)      DEFAULT NULL,
  `banned_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  KEY `email` (`email`),
  KEY `banned_by` (`banned_by`),
  CONSTRAINT `BanUsers_user_fk`   FOREIGN KEY (`user_id`)   REFERENCES `Users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `BanUsers_admin_fk`  FOREIGN KEY (`banned_by`) REFERENCES `Users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;
    $pdo->exec($sql);
}

/* =========================================
 * Entrada
 * ========================================= */
$rawId    = isset($_REQUEST['id']) ? trim((string)$_REQUEST['id']) : '';
$username = isset($_REQUEST['username']) ? trim((string)$_REQUEST['username']) : '';
$email    = isset($_REQUEST['email']) ? trim((string)$_REQUEST['email']) : '';
if ($email === '' && isset($_REQUEST['gmail'])) {
    $email = trim((string)$_REQUEST['gmail']); // alias admitido
}
$reason   = isset($_REQUEST['reason']) ? trim((string)$_REQUEST['reason']) : '';

if ($rawId === '' && $username === '' && $email === '') {
    http_response_code(400);
    exit('Faltan parámetros: envía id, username o email/gmail.');
}
if ($rawId !== '' && !ctype_digit($rawId)) {
    http_response_code(400);
    exit('Parámetro id inválido.');
}

/* =========================================
 * Lógica
 * ========================================= */
try {
    $pdo = pdo();
    ensureBanTable($pdo);

    // Buscar el usuario (AND estricto con lo que venga)
    $where  = [];
    $params = [];
    if ($rawId !== '')    { $where[] = 'user_id = :id';   $params[':id'] = (int)$rawId; }
    if ($username !== '') { $where[] = 'username = :u';   $params[':u']  = $username; }
    if ($email !== '')    { $where[] = 'email = :e';      $params[':e']  = $email; }

    $sqlFind = 'SELECT user_id, username, email FROM Users WHERE ' . implode(' AND ', $where) . ' LIMIT 1';
    $st = $pdo->prepare($sqlFind);
    $st->execute($params);
    $user = $st->fetch();

    if (!$user) {
        http_response_code(404);
        exit('Usuario no encontrado con los criterios dados.');
    }

    $uid = (int)$user['user_id'];
    $un  = (string)$user['username'];
    $em  = (string)$user['email'];

    // Quién banea (si hay sesión)
    $adminId = null;
    if (!empty($_SESSION['user']['user_id'])) {
        $adminId = (int)$_SESSION['user']['user_id'];
    } elseif (!empty($_SESSION['user_id']) && ctype_digit((string)$_SESSION['user_id'])) {
        $adminId = (int)$_SESSION['user_id'];
    }

    // Insert/Update en BanUsers
    $sqlBan = "
        INSERT INTO BanUsers (user_id, username, email, reason, banned_by, banned_at)
        VALUES (:uid, :un, :em, :rs, :by, NOW())
        ON DUPLICATE KEY UPDATE
            username  = VALUES(username),
            email     = VALUES(email),
            reason    = VALUES(reason),
            banned_by = VALUES(banned_by),
            banned_at = NOW()
    ";
    $pdo->prepare($sqlBan)->execute([
        ':uid' => $uid,
        ':un'  => $un,
        ':em'  => $em,
        ':rs'  => ($reason !== '' ? $reason : null),
        ':by'  => $adminId,
    ]);

    // Redirigir
    $redir = isset($_GET['redirect']) ? (string)$_GET['redirect'] : '/usuarios';
    $sep   = (strpos($redir, '?') !== false) ? '&' : '?';
    header('Location: ' . $redir . $sep . 'banned=1&user=' . urlencode($un));
    exit;

} catch (PDOException $e) {
    // Error de conexión o SQL: mostrar un mensaje útil
    http_response_code(500);
    echo "<h1>Error de base de datos</h1>";
    echo "<p>{$e->getMessage()}</p>";
    echo "<p><small>Si ves 'Access denied for user', asegúrate de que <code>App\Core\Database</code> esté cargando credenciales válidas, o crea un usuario/app con permisos en la BD (no uses root con auth_socket).</small></p>";
    exit;
}

