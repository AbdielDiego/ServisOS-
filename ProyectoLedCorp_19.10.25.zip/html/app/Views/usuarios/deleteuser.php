<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

/* =======================
 * 1) Seguridad mínima (opcional)
 *    Descomenta si querés exigir admin en sesión (rol_id=1)
 * ======================= */
// if (empty($_SESSION['rol_id']) || (int)$_SESSION['rol_id'] !== 1) {
//     http_response_code(403);
//     exit('Acceso denegado: se requiere rol Admin.');
// }

/* =======================
 * 2) Conexión PDO
 *    Usa App\Core\Database si existe; si no, credenciales locales
 * ======================= */
function pdo(): PDO {
    if (class_exists('\App\Core\Database')) {
        $pdo = \App\Core\Database::getConnection();
    } else {
        $DB_HOST = '127.0.0.1';
        $DB_NAME = 'proyutu';
        $DB_USER = 'root';
        $DB_PASS = ''; // ajusta si corresponde
        $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4";
        $pdo = new PDO($dsn, $DB_USER, $DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    // Por si acaso
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    return $pdo;
}

/* =======================
 * 3) Leer parámetros (GET/POST)
 * ======================= */
$rawId   = isset($_REQUEST['id']) ? trim((string)$_REQUEST['id']) : '';
$userIn  = isset($_REQUEST['username']) ? trim((string)$_REQUEST['username']) : '';
$emailIn = isset($_REQUEST['email']) ? trim((string)$_REQUEST['email']) : '';

if ($rawId === '' && $userIn === '' && $emailIn === '') {
    http_response_code(400);
    exit('Faltan parámetros: envía id, username o email.');
}

if ($rawId !== '' && !ctype_digit($rawId)) {
    http_response_code(400);
    exit('Parámetro id inválido.');
}

/* =======================
 * 4) Buscar usuario exacto (los filtros se combinan con AND)
 * ======================= */
$pdo = pdo();
$where = [];
$params = [];

if ($rawId !== '')   { $where[] = 'user_id = :id';      $params[':id'] = (int)$rawId; }
if ($userIn !== '')  { $where[] = 'username = :u';      $params[':u']  = $userIn; }
if ($emailIn !== '') { $where[] = 'email = :e';         $params[':e']  = $emailIn; }

$sqlFind = 'SELECT user_id, username, email FROM Users WHERE ' . implode(' AND ', $where) . ' LIMIT 1';
$st = $pdo->prepare($sqlFind);
$st->execute($params);
$user = $st->fetch();

if (!$user) {
    http_response_code(404);
    exit('Usuario no encontrado con los criterios dados.');
}

$uid    = (int)$user['user_id'];
$uemail = (string)$user['email'];

/* =======================
 * 5) Eliminación en orden seguro (transacción)
 *    - Comentarios del usuario
 *    - Posts del usuario (y sus dependencias: comments, ratings, tags)
 *    - Ratings & categorías del usuario
 *    - Resets por email
 *    - Mensajes enviados/recibidos (opcional limpieza)
 *    - Usuario
 * ======================= */
try {
    $pdo->beginTransaction();

    // 5.1 Comentarios escritos por el usuario
    $pdo->prepare('DELETE FROM Comments WHERE user_id = ?')->execute([$uid]);

    // 5.2 Posts del usuario y dependencias
    $q = $pdo->prepare('SELECT post_id FROM Posts WHERE user_id = ?');
    $q->execute([$uid]);
    $postIds = $q->fetchAll(PDO::FETCH_COLUMN, 0);

    if (!empty($postIds)) {
        $in = implode(',', array_fill(0, count($postIds), '?'));

        // Comments en esos posts (de cualquier autor)
        $pdo->prepare("DELETE FROM Comments WHERE post_id IN ($in)")->execute($postIds);
        // post_ratings de esos posts
        $pdo->prepare("DELETE FROM post_ratings WHERE post_id IN ($in)")->execute($postIds);
        // PostTags de esos posts
        $pdo->prepare("DELETE FROM PostTags WHERE post_id IN ($in)")->execute($postIds);
        // Finalmente los posts
        $pdo->prepare("DELETE FROM Posts WHERE post_id IN ($in)")->execute($postIds);
    }

    // 5.3 Ratings y categorías asociados al usuario
    $pdo->prepare('DELETE FROM post_ratings WHERE user_id = ?')->execute([$uid]);
    $pdo->prepare('DELETE FROM category_ratings WHERE user_id = ?')->execute([$uid]);

    // 5.4 Resets de contraseña por email
    $pdo->prepare('DELETE FROM password_resets WHERE email = ?')->execute([$uemail]);

    // 5.5 Mensajes (opcional: limpiar huellas)
    //    - Como no hay FK de messages->Users, no es obligatorio, pero se limpia igual.
    $pdo->prepare('DELETE FROM message_recipients WHERE recipient_id = ?')->execute([$uid]);
    // Si querés conservar mensajes, comenta la línea siguiente.
    $pdo->prepare('DELETE FROM messages WHERE sender_id = ?')->execute([$uid]);

    // 5.6 Finalmente, el usuario
    $pdo->prepare('DELETE FROM Users WHERE user_id = ?')->execute([$uid]);

    $pdo->commit();

    // Redirección opcional
    $redir = isset($_GET['redirect']) ? (string)$_GET['redirect'] : '/usuarios';
    header('Location: ' . $redir . '?deleted=1&user=' . urlencode($user['username']));
    exit;

} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo 'Error al eliminar usuario: ' . $e->getMessage();
    exit;
}

