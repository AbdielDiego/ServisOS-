<link rel="stylesheet" href="/css/styles.css">
<?php
// contact.php (vista) - SOLO PHP

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// Datos del controlador o como fallback por GET
$recipient = $recipient ?? [];
$username  = $recipient['username'] ?? ($_GET['username'] ?? $_GET['user'] ?? '');
$email     = $recipient['email']    ?? ($_GET['email']    ?? $_GET['gmail'] ?? '');
$userId    = $recipient['user_id']  ?? ($_GET['user_id']  ?? $_GET['uid']   ?? '');
$postTitle = $post['title']         ?? ($_GET['title']    ?? '');
$postId    = (int)($_GET['post_id'] ?? 0);

// Valor que usa el backend para resolver destinatario
$toQuery = $username !== '' ? $username : $email;

// Asunto por defecto (lo puede sobreescribir el backend si marcas “Contratar”)
$autoSubject = 'Consulta sobre tu servicio' . ($postTitle ? (': ' . $postTitle) : '');

// Mensaje previo o errores
$old   = $old   ?? [];
$error = $error ?? null;

if ($toQuery === '') {
  $error = $error ?: 'No se pudo identificar al destinatario. Vuelve desde el servicio para contactar.';
}
?>
<section style="max-width:960px;margin:0 auto;padding:24px;">
  <h1>Contactar</h1>

  <?php if ($error): ?>
    <div class="alert error"><?= h($error) ?></div>
  <?php endif; ?>

  <div style="margin:10px 0 18px 0;line-height:1.6">
    <div><strong>Usuario:</strong> <?= h($username ?: '—') ?></div>
    <div><strong>Email:</strong> <?= h($email ?: '—') ?></div>
    <?php if ($postTitle): ?>
      <div><strong>Servicio:</strong> <?= h($postTitle) ?></div>
    <?php endif; ?>
  </div>

  <form method="post" action="/messages">
    <!-- Ocultos para el backend -->
    <input type="hidden" name="to_query" value="<?= h($toQuery) ?>">
    <input type="hidden" name="subject"  value="<?= h($autoSubject) ?>">
    <?php if ($postId > 0): ?>
      <input type="hidden" name="post_id" value="<?= (int)$postId ?>">
    <?php endif; ?>

    <!-- Checkbox SOLO PHP -->
    <label style="display:flex;align-items:center;gap:.6rem;margin:10px 0 12px 0;cursor:pointer">
      <input type="checkbox" name="contract_service" value="1" />
      <span><strong>Contratar servicio</strong> <small style="opacity:.75">(al enviar, se notificará “Servicio contratado” y se registrará en la base de datos)</small></span>
    </label>

    <label for="body"><strong>Mensaje</strong></label>
    <textarea
      id="body"
      name="body"
      rows="8"
      style="width:100%;max-width:960px"
      required
    ><?= h($old['body'] ?? '') ?></textarea>

    <br><br>
    <button type="submit">Enviar</button>
  </form>
</section>


