<link rel="stylesheet" href="/css/inbox.css">
<?php
/** @var array  $items */
/** @var int    $newCount */
/** @var string $title */

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/** Devuelve el primer dato no vacío entre posibles claves */
function firstNonEmpty(array $row, array $keys, $default = 'Desconocido'){
    foreach ($keys as $k){ if (isset($row[$k]) && $row[$k] !== '' && $row[$k] !== null) return $row[$k]; }
    return $default;
}
?>
<div>
  <h1><?= h($title ?? 'Inbox') ?></h1>

  <?php if (!empty($_SESSION['flash_ok'])): ?>
    <div class="alert ok"><?= h($_SESSION['flash_ok']); unset($_SESSION['flash_ok']); ?></div>
  <?php endif; ?>
  <?php if (!empty($_SESSION['flash_error'])): ?>
    <div class="alert error"><?= h($_SESSION['flash_error']); unset($_SESSION['flash_error']); ?></div>
  <?php endif; ?>
  <?php if (!empty($_SESSION['flash_info'])): ?>
    <div class="alert info"><?php echo $_SESSION['flash_info']; unset($_SESSION['flash_info']); ?></div>
  <?php endif; ?>

  <?php if (($newCount ?? 0) > 0): ?>
    <div class="alert info">
      Tienes <?= (int)$newCount ?> mensaje<?= $newCount==1?'':'s' ?> nuevo<?= $newCount==1?'':'s' ?>.
    </div>
  <?php endif; ?>

  <?php if (empty($items)): ?>
    <p>No hay mensajes.</p>
  <?php else: ?>
    <div class="inbox-list">
      <?php foreach ($items as $row): ?>
        <?php
          // Soporta from_name, from_username o from_email
          $from    = firstNonEmpty($row, ['from_name','from_username','from_email','email','username'], 'Desconocido');
          // Soporta varios alias del cuerpo
          $bodyRaw = firstNonEmpty($row, ['body','message','content','text'], '');
          // Soporta message_id o id
          $mid     = (int) firstNonEmpty($row, ['message_id','id'], 0);
          // Fecha: created_at o date
          $created = firstNonEmpty($row, ['created_at','date'], '');
          // is_read puede venir como 0/"0"/null
          $isUnread = empty($row['is_read']) || $row['is_read'] === '0';
        ?>
        <article class="msg-card<?= $isUnread ? ' is-unread' : '' ?>">

          <!-- Botón Eliminar (POST -> /messages/delete/:id) -->
          <form class="msg-delete-form" method="post" action="/messages/delete/<?= $mid ?>">
            <button type="submit" class="msg-delete-btn" title="Eliminar">Eliminar</button>
          </form>

          <a class="msg-card-link" href="/messages/<?= $mid ?>">
            <div class="msg-subject">
              <?= h($row['subject'] ?? '(sin asunto)') ?><?php if ($isUnread): ?> (nuevo)<?php endif; ?>
            </div>
            <div class="msg-meta">
              · De: <?= h($from) ?><?= $created !== '' ? ' · '.h($created) : '' ?>
            </div>
            <?php if ($bodyRaw !== ''): ?>
              <div class="msg-body"><?= nl2br(h($bodyRaw)) ?></div>
            <?php endif; ?>
          </a>
        </article>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>


