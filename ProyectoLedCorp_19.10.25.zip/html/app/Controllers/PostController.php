<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Post;
use App\Models\Comment;

class PostController extends Controller
{
    private Post $modelo;
    private Comment $comment;

    public function __construct()
    {
        if (is_callable([parent::class, '__construct'])) {
            parent::__construct();
        }
        $this->modelo  = new Post();
        $this->comment = new Comment();
        if (session_status() !== \PHP_SESSION_ACTIVE) {
            @session_start();
        }
    }

    /** ======================== GET /post ======================== */
    public function index(array $params = []): void
    {
        $pagina = (int)($params['pagina'] ?? ($_GET['pagina'] ?? 1));
        $pagina = max(1, $pagina);

        // Soporta ambos estilos de modelo: sqlPaginado() o listAll()
        if (method_exists($this->modelo, 'sqlPaginado')) {
            $data  = $this->modelo->sqlPaginado($pagina);
            $posts = $data['posts']
                ?? ($data['items']     ?? null)
                ?? ($data['rows']      ?? null)
                ?? ($data['data']      ?? null)
                ?? ($data['registros'] ?? null)
                ?? [];
        } else {
            $posts = $this->modelo->listAll();
        }

        $this->renderCompat('post/index', [
            'titulo' => 'Servicios',
            'posts'  => $posts,
        ]);
    }

    /** ============== GET /post/:id  (detalle + comentarios) ============== */
    public function show($id): void
    {
        $postId = is_array($id) ? (int)($id['id'] ?? 0) : (int)$id;
        if ($postId <= 0) { $this->redirect('/post'); return; }

        $post = $this->getPostById($postId);
        if (!$post) { $this->redirect('/post'); return; }

        $comments = $this->comment->findByPostId($postId);

        $this->renderCompat('post/show', [
            'title'         => $post['title'] ?? 'Servicio',
            'post'          => $post,
            'comments'      => $comments,
            'focusForm'     => false,                           // la vista puede hacer scroll al form si true
            'commentAction' => "/posts/{$postId}/comments",     // lo usa el <form> para guardar
        ]);
    }

    /** ========== GET /post/:id/comentar  (mismo show pero con foco en form) ========== */
    public function comentar($id): void
    {
        $postId = (int)$id;
        if ($postId <= 0) { $this->redirect('/post'); return; }

        $post = $this->getPostById($postId);
        if (!$post) { $this->redirect('/post'); return; }

        $comments = $this->comment->findByPostId($postId);

        $this->renderCompat('post/show', [
            'title'         => 'Comentar: ' . ($post['title'] ?? 'Servicio'),
            'post'          => $post,
            'comments'      => $comments,
            'focusForm'     => true,                            // la vista enfoca/ancla el formulario
            'commentAction' => "/posts/{$postId}/comments",
        ]);
    }

    /** ====== GET /post/detail[.php]?id=...  (detalle “limpio”, sin formulario) ====== */
    public function detail(): void
    {
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) { $this->redirect('/post'); return; }

        $post = $this->getPostById($id);
        if (!$post) {
            $_SESSION['flash_error'] = 'Servicio no encontrado.';
            $this->redirect('/post');
            return;
        }

        // Autor (opcional)
        $author = ['username' => 'Desconocido', 'email' => ''];
        $authorId = (int)($post['user_id'] ?? 0);
        if ($authorId > 0) {
            $pdo = Database::getConnection();
            $st  = $pdo->prepare('SELECT username, email FROM Users WHERE user_id = :id LIMIT 1');
            $st->execute([':id' => $authorId]);
            if ($row = $st->fetch(\PDO::FETCH_ASSOC)) {
                $author['username'] = (string)($row['username'] ?? 'Desconocido');
                $author['email']    = (string)($row['email'] ?? '');
            }
        }

        $this->renderCompat('post/detail', [
            'title'  => 'Detalle del servicio',
            'post'   => $post,
            'author' => $author,
        ]);
    }

    /* ============================ Helpers ============================ */

    /** Obtiene un post por ID soportando findById() o find([...]) */
    private function getPostById(int $id): ?array
    {
        if (method_exists($this->modelo, 'findById')) {
            return $this->modelo->findById($id) ?: null;
        }

        // Fallback a find(['post_id' => ...]) ó find($id)
        if (method_exists($this->modelo, 'find')) {
            $post = $this->modelo->find(['post_id' => $id]);
            if (!$post) {
                $tmp = $this->modelo->find($id);
                if (is_array($tmp)) $post = $tmp;
            }
            return $post ?: null;
        }
        return null;
    }

    /**
     * Render compatible: usa $this->render() si existe; si no, hace require del archivo de vista.
     * Asegura el prefijo **post/** (no **posts/**) para evitar el error de ruta.
     */
    private function renderCompat(string $view, array $vars = []): void
    {
        if (method_exists($this, 'render')) {
            /** @phpstan-ignore-next-line */
            echo $this->render($view, $vars);
            return;
        }
        extract($vars, EXTR_SKIP);
        $path = __DIR__ . '/../../Views/' . str_replace('.', '/', $view) . '.php';
        require $path;
    }
}

