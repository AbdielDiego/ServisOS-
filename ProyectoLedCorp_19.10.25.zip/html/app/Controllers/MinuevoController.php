<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Minuevo;

class MinuevoController extends Controller
{
    /** @var \PDO */
    private $pdo;
    /** @var Minuevo */
    private $model;

    public function __construct()
    {
        parent::__construct();

        // Conexión PDO
        $this->pdo = Database::getConnection();
        $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);

        // Modelo
        $this->model = new Minuevo($this->pdo);
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
    }

    public function index()
    {
        $posts = $this->model->latest(12);
        return $this->render('minuevo/index', ['posts' => $posts]); // <— render()
    }

    public function create()
    {
        $cats = $this->model->categories();
        return $this->render('minuevo/create', ['categories' => $cats]); // <— render()
    }

    public function store()
    {
        $userId = $_SESSION['auth']['user']['user_id'] ?? $_SESSION['user']['user_id'] ?? null;
        if (!$userId) { $this->setFlash('error', 'Debes iniciar sesión.'); return $this->redirect('/login'); }

        $title   = trim($_POST['title']   ?? '');
        $content = trim($_POST['content'] ?? '');
        $catId   = isset($_POST['category_id']) && ctype_digit((string)$_POST['category_id']) ? (int)$_POST['category_id'] : null;

        if ($title === '' || $content === '') {
            $this->setFlash('error', 'Título y contenido son obligatorios.');
            return $this->redirect('/minuevo/create');
        }

        $postId = $this->model->create((int)$userId, $catId, $title, $content);
        $slug   = $this->slugify($title) . '-' . (int)$postId;
        return $this->redirect('/article/' . $slug);
    }

    public function show($slugOrId)
    {
        $slugOrId = $this->firstString($slugOrId);

        if ($slugOrId !== '' && ctype_digit($slugOrId)) {
            $post = $this->model->findById((int)$slugOrId);
        } else {
            $id   = $this->extractId($slugOrId);
            $post = $id ? $this->model->findById($id) : $this->model->findByLooseTitle($slugOrId);
        }
        if (!$post) return $this->redirect('/minuevo');

        $userId = $_SESSION['auth']['user']['user_id'] ?? $_SESSION['user']['user_id'] ?? null;
        $avg    = $this->model->avgRating((int)$post['post_id']);
        $mine   = $userId ? $this->model->userRating((int)$post['post_id'], (int)$userId) : null;

        return $this->render('minuevo/show', [   // <— render()
            'post'       => $post,
            'avgRating'  => $avg,
            'userRating' => $mine,
        ]);
    }

    /** POST /article/{id}/rate */
    public function rate($id)
    {
        // 1) Usuario logueado
        $userId = $_SESSION['auth']['user']['user_id'] ?? $_SESSION['user']['user_id'] ?? null;
        if (!$userId) {
            $this->setFlash('error', 'Debes iniciar sesión para puntuar.');
            return $this->redirect('/login?next=' . urlencode('/article/' . $this->firstString($id)));
        }

        // 2) Normalizar ID y buscar post (acepta slug o numérico)
        $slugOrId = $this->firstString($id);
        if ($slugOrId !== '' && ctype_digit($slugOrId)) {
            $post = $this->model->findById((int)$slugOrId);
        } else {
            $postIdFromSlug = $this->extractId($slugOrId);
            $post = $postIdFromSlug ? $this->model->findById($postIdFromSlug) : $this->model->findByLooseTitle($slugOrId);
        }
        if (!$post) { $this->setFlash('error', 'Artículo no encontrado.'); return $this->redirect('/minuevo'); }

        // 3) Bloqueo: no permitir puntuar el propio post
        if ((int)$post['author_id'] === (int)$userId) {
            $this->setFlash('error', 'No podés puntuar tu propio artículo.');
            $slug = $this->slugify($post['title']) . '-' . (int)$post['post_id'];
            return $this->redirect('/article/' . $slug);
        }

        // 4) Validar rango
        $rating = (int)$this->firstString($_POST['rating'] ?? '');
        if ($rating < 1 || $rating > 5) {
            $this->setFlash('error', 'El puntaje debe estar entre 1 y 5.');
            $slug = $this->slugify($post['title']) . '-' . (int)$post['post_id'];
            return $this->redirect('/article/' . $slug);
        }

        // 5) Guardar (upsert)
        try {
            $this->model->upsertRating((int)$post['post_id'], (int)$userId, (int)$rating);
            $this->setFlash('ok', 'Tu puntaje fue registrado.');
        } catch (\Throwable $e) {
            $this->setFlash('error', 'No se pudo registrar tu voto.');
        }

        // 6) Volver al detalle
        $slug = $this->slugify($post['title']) . '-' . (int)$post['post_id'];
        return $this->redirect('/article/' . $slug);
    }

    /* -------- utilidades -------- */

    private function slugify(string $text): string
    {
        $text = trim($text);
        $text = @iconv('UTF-8','ASCII//TRANSLIT',$text) ?: $text;
        $text = strtolower(preg_replace('/[^a-z0-9]+/i','-',$text));
        return trim($text, '-');
    }

    private function extractId(string $slug): ?int
    {
        if (preg_match('~-(\d+)$~', $slug, $m)) return (int)$m[1];
        return null;
    }

    private function firstString($v): string
    {
        if (is_array($v)) $v = reset($v);
        return is_string($v) ? trim($v) : '';
    }

    private function setFlash(string $key, string $msg): void
    {
        $_SESSION['flash_'.$key] = $msg;
    }
}

