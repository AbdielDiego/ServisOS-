<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\MessageRecipient; // si no existe, hay fallback SQL
use PDO;

class MessageController extends Controller
{
    /* ============================
     * Helpers de sesión / auth
     * ============================ */
    private function user(): ?array {
        if (session_status() !== \PHP_SESSION_ACTIVE) { @session_start(); }
        return $_SESSION['auth']['user'] ?? $_SESSION['user'] ?? null;
    }

    private function currentUserId(): int {
        $u = $this->user();
        if (is_array($u)) {
            $id = (int)($u['user_id'] ?? $u['id'] ?? 0);
        } elseif (isset($_SESSION['user_id'])) {
            $id = (int)$_SESSION['user_id'];
        } else {
            $id = 0;
        }
        return $id > 0 ? $id : 0;
    }

    private function requireAuth(): int {
        $uid = $this->currentUserId();
        if ($uid <= 0) { $this->redirect('/login'); exit; }
        return $uid;
    }

    /* ============================
     * Bandejas
     * ============================ */

    /** GET /messages/inbox */
    public function inbox() {
        $uid = $this->requireAuth();

        if (class_exists(MessageRecipient::class) && method_exists(MessageRecipient::class, 'findInboxForUser')) {
            $items    = MessageRecipient::findInboxForUser($uid, 200);
            $newCount = MessageRecipient::countUnreadForUser($uid);
        } else {
            $pdo = Database::getConnection();
            $sql = "
                SELECT mr.id AS recipient_row_id, m.id AS message_id, m.subject, m.body, m.created_at,
                       u.username AS from_username, u.email AS from_email, mr.is_read
                  FROM message_recipients mr
                  JOIN messages m ON m.id = mr.message_id
                  JOIN Users u    ON u.user_id = m.sender_id
                 WHERE mr.recipient_id = :uid
                 ORDER BY m.created_at DESC, m.id DESC
                 LIMIT 200
            ";
            $st = $pdo->prepare($sql);
            $st->execute([':uid'=>$uid]);
            $items = $st->fetchAll(PDO::FETCH_ASSOC);

            $sql2 = "SELECT COUNT(*) FROM message_recipients WHERE recipient_id=:uid AND is_read=0";
            $st2  = $pdo->prepare($sql2);
            $st2->execute([':uid'=>$uid]);
            $newCount = (int)($st2->fetchColumn() ?: 0);
        }

        return $this->render('messages/inbox', [
            'title'    => 'Inbox',
            'items'    => $items,
            'newCount' => $newCount,
        ]);
    }

    /** GET /messages/sent */
    public function sent() {
        $uid = $this->requireAuth();
        $pdo = Database::getConnection();

        $sql = "
            SELECT
                m.id AS message_id,
                m.subject,
                m.created_at,
                COALESCE(
                    GROUP_CONCAT(
                        DISTINCT COALESCE(NULLIF(u.username, ''), u.email)
                        ORDER BY u.username SEPARATOR ', '
                    ),
                    ''
                ) AS to_names
            FROM messages m
            LEFT JOIN message_recipients mr ON mr.message_id = m.id
            LEFT JOIN Users u              ON u.user_id      = mr.recipient_id
            WHERE m.sender_id = :uid
            GROUP BY m.id, m.subject, m.created_at
            ORDER BY m.created_at DESC
        ";
        $st = $pdo->prepare($sql);
        $st->execute([':uid' => $uid]);
        $items = $st->fetchAll(PDO::FETCH_ASSOC);

        return $this->render('messages/sent', [
            'title' => 'Mensajes enviados',
            'items' => $items,
        ]);
    }

    /** GET /messages/compose */
    public function compose() {
        $this->requireAuth();
        return $this->render('messages/compose', [
            'title' => 'Nuevo mensaje',
            'old'   => [
                'to_query' => $_POST['to_query'] ?? '',
                'subject'  => $_POST['subject']  ?? '',
                'body'     => $_POST['body']     ?? '',
            ],
        ]);
    }

    /** GET /messages/reply  ó  GET /messages/:id/reply */
    public function reply($id = null)
    {
        $this->requireAuth();
        $uid = $this->currentUserId();

        if (is_array($id)) { $id = $id['id'] ?? reset($id); }
        $mid = $id !== null ? (int)$id : 0;

        $to = '';
        $subject = '';

        if ($mid > 0) {
            if (class_exists(MessageRecipient::class) && method_exists(MessageRecipient::class, 'userCanSee')) {
                if (!MessageRecipient::userCanSee($mid, $uid)) {
                    $_SESSION['flash_error'] = 'No autorizado para responder este mensaje.';
                    $this->redirect('/messages/inbox'); return;
                }
                $m = MessageRecipient::findMessageWithDetails($mid);
                if ($m) {
                    $to      = !empty($m['from_username']) ? $m['from_username'] : ($m['from_email'] ?? '');
                    $subject = (string)($m['subject'] ?? '');
                }
            }
        }

        if (!empty($_GET['to']))      { $to = (string)$_GET['to']; }
        if (!empty($_GET['subject'])) { $subject = (string)$_GET['subject']; }

        $subject = trim($subject);
        if ($subject !== '' && !preg_match('/^re:/i', $subject)) {
            $subject = 'Re: ' . $subject;
        }

        return $this->render('messages/compose', [
            'title' => 'Responder mensaje',
            'old'   => [
                'to_query' => $to,
                'subject'  => $subject,
                'body'     => '',
            ],
            'error' => null,
        ]);
    }

    /** POST /messages/:id/reply -> reutiliza store() sin retornar valor */
    public function replyPost($id) { $this->store(); }

    /* ============================
     * CONTACTAR (desde un post)
     * ============================ */

    public function contact($id = null)
    {
        $this->requireAuth();
        $pdo = Database::getConnection();

        if (is_array($id)) { $id = $id['id'] ?? reset($id); }
        $postId = 0;
        if ($id !== null && $id !== '') { $postId = (int)$id; }
        $postId = $postId ?: (int)($_GET['post_id'] ?? $_GET['id'] ?? 0);

        $recipient = [
            'user_id'  => (int)($_GET['user_id'] ?? $_GET['uid'] ?? 0),
            'username' => (string)($_GET['username'] ?? $_GET['user'] ?? ''),
            'email'    => (string)($_GET['email']    ?? $_GET['gmail'] ?? ''),
        ];
        $postTitle = (string)($_GET['title'] ?? $_GET['post_title'] ?? '');

        if ($postId > 0) {
            $sql = "
                SELECT p.post_id, p.user_id AS author_id, p.title,
                       u.username, u.email
                  FROM Posts p
             LEFT JOIN Users u ON u.user_id = p.user_id
                 WHERE p.post_id = :id
                 LIMIT 1
            ";
            $st = $pdo->prepare($sql);
            $st->execute([':id' => $postId]);
            if ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                if (empty($recipient['user_id']))  { $recipient['user_id']  = (int)($row['author_id'] ?? 0); }
                if (empty($recipient['username'])) { $recipient['username'] = (string)($row['username'] ?? ''); }
                if (empty($recipient['email']))    { $recipient['email']    = (string)($row['email'] ?? ''); }
                if ($postTitle === '')             { $postTitle             = (string)($row['title'] ?? ''); }
            }
        }

        $toQuery = $recipient['username'] ?: $recipient['email'];
        $error = null;
        if ($toQuery === '') {
            $error = 'No se pudo identificar al destinatario. Vuelve desde el servicio para contactar.';
        }

        return $this->render('messages/contact', [
            'title'     => 'Contactar',
            'recipient' => $recipient,
            'post'      => ['id' => $postId, 'title' => $postTitle],
            'old'       => ['body' => $_POST['body'] ?? ''],
            'error'     => $error,
        ]);
    }

    /* ============================
     * Utilidades de destinatarios
     * ============================ */

    private function resolveRecipientIdsFromQuery(string $raw, int $currentUserId): array {
        $tokens = preg_split('/[,\s]+/', $raw, -1, PREG_SPLIT_NO_EMPTY);
        if (empty($tokens)) return [[], []];

        $needles = [];
        foreach ($tokens as $t) {
            $t = strtolower(trim($t));
            if ($t !== '') $needles[$t] = true;
        }
        if (empty($needles)) return [[], []];

        $pdo = Database::getConnection();

        $placeholders = implode(',', array_fill(0, count($needles), '?'));
        $params = array_keys($needles);
        $params = array_merge($params, $params);

        $sql = "
            SELECT user_id, LOWER(username) AS uname, LOWER(email) AS uemail
              FROM Users
             WHERE LOWER(username) IN ($placeholders)
                OR LOWER(email)    IN ($placeholders)
        ";
        $st = $pdo->prepare($sql);
        $st->execute($params);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);

        $map = [];
        foreach ($rows as $r) {
            if (!empty($r['uname']))  $map[$r['uname']]  = (int)$r['user_id'];
            if (!empty($r['uemail'])) $map[$r['uemail']] = (int)$r['user_id'];
        }

        $ids = [];
        $unknown = [];
        foreach (array_keys($needles) as $tok) {
            if (isset($map[$tok])) {
                $id = (int)$map[$tok];
                if ($id > 0 && $id !== $currentUserId) $ids[$id] = true;
            } else {
                $unknown[] = $tok;
            }
        }

        return [array_keys($ids), $unknown];
    }

    /* ============================
     * Crear mensaje (UNIFICADO)
     * ============================ */

    /** POST /messages */
    public function store(): void
    {
        if (session_status() !== \PHP_SESSION_ACTIVE) @session_start();

        $uid     = $this->requireAuth();
        $pdo     = Database::getConnection();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

        $toQuery    = trim((string)($_POST['to_query'] ?? ''));
        $subject    = trim((string)($_POST['subject']  ?? ''));
        $body       = trim((string)($_POST['body']     ?? ''));
        $postId     = (int)($_POST['post_id'] ?? 0);
        $isContract = isset($_POST['contract_service']) && $_POST['contract_service'] === '1';

        if ($subject === '') { $subject = 'Mensaje de contacto'; }

        if ($toQuery === '' || $body === '') {
            $_SESSION['flash_error'] = 'Completa destinatario(s) y mensaje.';
            if ($postId > 0 || isset($_POST['from_contact'])) { $this->redirect('/messages/contact'); return; }
            $this->redirect('/messages/compose'); return;
        }

        [$recips, $unknown] = $this->resolveRecipientIdsFromQuery($toQuery, $uid);

        if (!empty($unknown)) {
            $_SESSION['flash_error'] = 'No se encontraron: ' . implode(', ', $unknown);
            $this->redirect('/messages/compose'); return;
        }
        if (empty($recips)) {
            $_SESSION['flash_error'] = 'No hay destinatarios válidos (no puedes enviarte a ti mismo).';
            $this->redirect('/messages/compose'); return;
        }

        if ($isContract) {
            $marker = "✅ Servicio contratado";
            if (mb_strpos($body, $marker) !== 0) {
                $body = $marker . "\n\n" . $body;
            }
            if (mb_strpos($subject, '(Contratación)') === false) {
                $subject .= ' (Contratación)';
            }
        }

        try {
            $pdo->beginTransaction();

            $st = $pdo->prepare("INSERT INTO messages (sender_id, subject, body) VALUES (:sid, :sub, :bod)");
            $st->execute([':sid'=>$uid, ':sub'=>$subject, ':bod'=>$body]);
            $mid = (int)$pdo->lastInsertId();

            if (class_exists(MessageRecipient::class) && method_exists(MessageRecipient::class, 'addRecipients')) {
                MessageRecipient::addRecipients($mid, $recips);
            } else {
                $ins = $pdo->prepare("INSERT INTO message_recipients (message_id, recipient_id) VALUES (:mid, :rid)");
                foreach ($recips as $rid) {
                    $ins->execute([':mid'=>$mid, ':rid'=>$rid]);
                }
            }

            if ($isContract) {
                $cs = $pdo->prepare("INSERT INTO ContractedService (sender_id, subject, body) VALUES (:sid,:sub,:bod)");
                $cs->execute([':sid'=>$uid, ':sub'=>$subject, ':bod'=>$body]);
            }

            $pdo->commit();

            $_SESSION['flash_ok'] = $isContract
                ? 'Mensaje enviado y contratación registrada.'
                : 'Mensaje enviado correctamente.';
            $this->redirect('/messages/sent'); return;
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('[MessageController@store] ' . $e->getMessage());
            $_SESSION['flash_error'] = 'No se pudo enviar el mensaje.';
            if ($postId > 0) { $this->redirect('/messages/contact?post_id=' . $postId); return; }
            $this->redirect('/messages/compose'); return;
        }
    }

    /* ============================
     * Ver y borrar
     * ============================ */

    /** GET /messages/:id */
    public function show($id) {
        $uid = $this->requireAuth();

        if (is_array($id)) { $id = $id['id'] ?? reset($id); }
        $mid = filter_var($id, FILTER_VALIDATE_INT) ?: 0;
        if ($mid <= 0) { $this->redirect('/messages/inbox'); return; }

        if (class_exists(MessageRecipient::class) && method_exists(MessageRecipient::class, 'userCanSee')) {
            if (!MessageRecipient::userCanSee($mid, $uid)) {
                $_SESSION['flash_error'] = 'No autorizado para ver este mensaje.';
                $this->redirect('/messages/inbox'); return;
            }
            $message = MessageRecipient::findMessageWithDetails($mid);
        } else {
            $pdo = Database::getConnection();
            $sql = "
                SELECT m.*, u.username AS from_username, u.email AS from_email
                  FROM messages m
                  JOIN Users u ON u.user_id = m.sender_id
                 WHERE m.id = :id
                 LIMIT 1
            ";
            $st = $pdo->prepare($sql);
            $st->execute([':id'=>$mid]);
            $message = $st->fetch(PDO::FETCH_ASSOC);
        }

        if (!$message) { $this->redirect('/messages/inbox'); return; }

        if (class_exists(MessageRecipient::class) && method_exists(MessageRecipient::class, 'userCanDelete')) {
            if (MessageRecipient::userCanDelete($mid, $uid)) {
                MessageRecipient::markRead($mid, $uid);
            }
        }

        return $this->render('messages/show', [
            'title'   => 'Mensaje',
            'message' => $message,
        ]);
    }

    /** GET|POST /messages/delete/:id */
    public function delete($id)
    {
        $this->requireAuth();
        $uid = $this->currentUserId();
        if (is_array($id)) { $id = $id['id'] ?? reset($id); }
        $id  = (int)$id;

        $confirm = $_GET['confirm'] ?? null;

        if ($confirm === null && ($_SERVER['REQUEST_METHOD'] === 'POST')) {
            $_SESSION['pending_delete_message_id'] = $id;
            $_SESSION['flash_info'] =
                '¿Quieres eliminar el mensaje? ' .
                '<a class="btn btn-xs btn-danger" href="/messages/delete/'.$id.'?confirm=yes">Sí</a> ' .
                '<a class="btn btn-xs" href="/messages/delete/'.$id.'?confirm=no">No</a>';
            $this->redirect('/messages/inbox'); return;
        }

        if ($confirm === 'no') {
            unset($_SESSION['pending_delete_message_id']);
            $_SESSION['flash_ok'] = 'Operación cancelada. El mensaje no fue eliminado.';
            $this->redirect('/messages/inbox'); return;
        }

        if ($confirm === 'yes') {
            if (class_exists(MessageRecipient::class) && method_exists(MessageRecipient::class, 'userCanDelete')) {
                if (!MessageRecipient::userCanDelete($id, $uid)) {
                    $_SESSION['flash_error'] = 'No tienes permiso para borrar este mensaje.';
                    $this->redirect('/messages/inbox'); return;
                }

                MessageRecipient::deleteForUser($id, $uid);

                if (MessageRecipient::remainingRecipients($id) === 0) {
                    MessageRecipient::deleteMessageIfOrphan($id);
                }
            } else {
                $pdo = Database::getConnection();
                $st  = $pdo->prepare("UPDATE message_recipients SET deleted_at = NOW() WHERE message_id=:mid AND recipient_id=:uid");
                $st->execute([':mid'=>$id, ':uid'=>$uid]);
            }

            unset($_SESSION['pending_delete_message_id']);
            $_SESSION['flash_ok'] = 'Mensaje eliminado correctamente.';
            $this->redirect('/messages/inbox'); return;
        }

        $this->redirect('/messages/inbox'); return;
    }
}

