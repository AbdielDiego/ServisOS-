<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Models\User;
use App\Models\BanUser;
use PDO;
use Throwable;

class UsuariosController extends Controller
{
    private User $userModel;
    private ?PDO $pdo = null;

    public function __construct()
    {
        if (is_callable([parent::class, '__construct'])) {
            parent::__construct();
        }

        $this->userModel = new User();
        if (class_exists('\App\Core\Database')) {
            $this->pdo = \App\Core\Database::getConnection();
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
            $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        }
    }

    /** GET /usuarios  -> lista SOLO no-baneados */
    public function index(): void
    {
        $filters = [
            'user'  => $_GET['user']  ?? '',
            'email' => $_GET['email'] ?? '',
        ];

        $users = $this->userModel->listActive($filters);

        // Mensajes flash
        $ok    = $_SESSION['flash_ok']    ?? null;
        $error = $_SESSION['flash_error'] ?? null;
        unset($_SESSION['flash_ok'], $_SESSION['flash_error']);

        // Si venimos de un ban y no hay filas, cambiar el texto vacío por "Listo"
        $emptyText = 'No hay usuarios';
        if (!empty($_GET['after_ban']) || $ok) {
            $emptyText = $ok ?: 'Listo';
        }

        $this->renderCompat('usuarios/index', [
            'titulo'     => 'Usuarios',
            'datosTabla' => $users,
            'ok'         => $ok,
            'error'      => $error,
            'emptyText'  => $emptyText,
        ]);
    }

    /** GET /usuarios/ban/:id -> (opcional) formulario con motivo */
    public function ban(array $params = []): void
    {
        $id = (int)($params['id'] ?? 0);
        if ($id <= 0) { header('Location: /usuarios'); exit; }

        $user = $this->userModel->getById($id);
        if (!$user) { header('Location: /usuarios'); exit; }

        $this->renderCompat('usuarios/ban', ['user' => $user]);
    }

    /** POST /usuarios/ban/:id -> ejecuta el ban y REDIRIGE al índice de baneados */
    public function banPost(array $params = []): void
    {
        $id = (int)($params['id'] ?? 0);
        if ($id <= 0) { $_SESSION['flash_error'] = 'ID inválido.'; header('Location: /usuarios'); exit; }

        $reason    = trim($_POST['reason'] ?? '');
        $adminId   = (int)($_SESSION['user']['user_id'] ?? 0);
        $adminName = (string)($_SESSION['user']['username'] ?? 'admin');

        try {
            (new BanUser())->banUser($id, $reason, $adminId, $adminName);
            $_SESSION['flash_ok'] = "Usuario #{$id} baneado.";
            // ✅ Ir al listado de baneados (como en tu 3ra captura)
            header('Location: /usuarios/BanUsersIndex.php');
            exit;
        } catch (Throwable $e) {
            $_SESSION['flash_error'] = 'No se pudo banear: ' . $e->getMessage();
            // Si por alguna razón vuelves al índice de usuarios, muestra “Listo/Realizado”
            header('Location: /usuarios?after_ban=1');
            exit;
        }
    }

    /** GET /usuarios/baneados -> versión MVC del listado (opcional) */
    public function bannedIndex(): void
    {
        $filters = [
            'user'   => $_GET['user']   ?? '',
            'email'  => $_GET['email']  ?? '',
            'reason' => $_GET['reason'] ?? '',
        ];
        $rows = (new BanUser())->list($filters);

        $ok    = $_SESSION['flash_ok']    ?? null;
        $error = $_SESSION['flash_error'] ?? null;
        unset($_SESSION['flash_ok'], $_SESSION['flash_error']);

        $this->renderCompat('usuarios/BanUsersIndex', [
            'rows'  => $rows,
            'ok'    => $ok,
            'error' => $error,
        ]);
    }

    /** GET /usuarios/unban/:id */
    public function unban(array $params = []): void
    {
        $id = (int)($params['id'] ?? 0);
        if ($id <= 0) { $_SESSION['flash_error'] = 'ID inválido.'; header('Location: /usuarios/BanUsersIndex.php'); exit; }

        try {
            (new BanUser())->unbanByUserId($id);
            $_SESSION['flash_ok'] = 'Usuario desbaneado.';
        } catch (Throwable $e) {
            $_SESSION['flash_error'] = 'No se pudo desbanear: ' . $e->getMessage();
        }
        header('Location: /usuarios/BanUsersIndex.php');
        exit;
    }

    /* ===== Eliminar usuario (igual que antes, sin tocar tu BD) ===== */

    public function destroy(array $params = []): void
    {
        $id       = $this->param($params, 'id', 'user_id');
        $username = $this->input('username');
        $email    = $this->input('email');

        if ($id === null && $username === '' && $email === '') {
            http_response_code(400);
            exit('Faltan parámetros: envía id, username o email.');
        }

        [$user, $uid, $uemail, $uname] = $this->findUserStrict($id, $username, $email);
        if (!$user) { http_response_code(404); exit('Usuario no encontrado con los criterios dados.'); }

        try {
            $this->pdo->beginTransaction();

            $this->pdo->prepare('DELETE FROM Comments WHERE user_id = ?')->execute([$uid]);

            $postIdsSt = $this->pdo->prepare('SELECT post_id FROM Posts WHERE user_id = ?');
            $postIdsSt->execute([$uid]);
            $postIds = $postIdsSt->fetchAll(PDO::FETCH_COLUMN, 0);

            if (!empty($postIds)) {
                $in = implode(',', array_fill(0, count($postIds), '?'));
                $this->pdo->prepare("DELETE FROM Comments     WHERE post_id IN ($in)")->execute($postIds);
                $this->pdo->prepare("DELETE FROM post_ratings WHERE post_id IN ($in)")->execute($postIds);
                $this->pdo->prepare("DELETE FROM PostTags     WHERE post_id IN ($in)")->execute($postIds);
                $this->pdo->prepare("DELETE FROM Posts        WHERE post_id IN ($in)")->execute($postIds);
            }

            $this->pdo->prepare('DELETE FROM post_ratings     WHERE user_id = ?')->execute([$uid]);
            $this->pdo->prepare('DELETE FROM category_ratings WHERE user_id = ?')->execute([$uid]);
            $this->pdo->prepare('DELETE FROM password_resets  WHERE email = ?')->execute([$uemail]);
            $this->pdo->prepare('DELETE FROM message_recipients WHERE recipient_id = ?')->execute([$uid]);
            $this->pdo->prepare('DELETE FROM messages           WHERE sender_id    = ?')->execute([$uid]);
            $this->pdo->prepare('DELETE FROM BanUsers          WHERE user_id      = ?')->execute([$uid]);
            $this->pdo->prepare('DELETE FROM Users             WHERE user_id      = ?')->execute([$uid]);

            $this->pdo->commit();

            $redir = $this->input('redirect', '/usuarios');
            $sep   = (strpos($redir, '?') !== false) ? '&' : '?';
            header('Location: ' . $redir . $sep . 'deleted=1&user=' . urlencode($uname));
            exit;

        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            http_response_code(500);
            echo 'Error al eliminar usuario: ' . $e->getMessage();
            exit;
        }
    }

    public function delete(array $params = []): void
    {
        $this->destroy($params);
    }

    /* ======================= Helpers internos ======================= */

    private function param(array $params, string ...$keys): ?int
    {
        foreach ($keys as $k) {
            if (isset($params[$k]) && ctype_digit((string)$params[$k])) {
                return (int)$params[$k];
            }
            if (isset($_REQUEST[$k]) && ctype_digit((string)$_REQUEST[$k])) {
                return (int)$_REQUEST[$k];
            }
        }
        return null;
    }

    protected function input($key, $default = '')
    {
        if (!isset($_REQUEST[$key])) return $default;
        $val = trim((string)$_REQUEST[$key]);
        return ($val === '') ? $default : $val;
    }

    private function findUserStrict(?int $id, string $username, string $email): array
    {
        $where  = [];
        $params = [];

        if ($id !== null)     { $where[] = 'user_id = :id'; $params[':id'] = $id; }
        if ($username !== '') { $where[] = 'username = :u'; $params[':u']  = $username; }
        if ($email !== '')    { $where[] = 'email = :e';    $params[':e']  = $email; }

        $sql = 'SELECT user_id, username, email FROM Users WHERE ' . implode(' AND ', $where) . ' LIMIT 1';
        $st  = $this->pdo->prepare($sql);
        $st->execute($params);
        $user = $st->fetch();

        if (!$user) return [null, 0, '', ''];

        return [$user, (int)$user['user_id'], (string)$user['email'], (string)$user['username']];
    }

    private function renderCompat(string $view, array $vars = []): void
    {
        if (method_exists($this, 'render')) {
            echo $this->render($view, $vars);
            return;
        }
        extract($vars, EXTR_SKIP);
        $path = __DIR__ . '/../../views/' . str_replace('.', '/', $view) . '.php';
        require $path;
    }
}

