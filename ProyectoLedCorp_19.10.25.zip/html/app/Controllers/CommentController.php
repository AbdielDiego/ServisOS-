<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Comment;

class CommentController extends Controller
{
    private Comment $comment;

    public function __construct()
    {
        // Respetar constructor del padre si existe
        if (is_callable([Controller::class, '__construct'])) {
            parent::__construct();
        }
        if (session_status() !== \PHP_SESSION_ACTIVE) {
            @session_start();
        }
        $this->comment = new Comment();
    }

    /* =========================================================
     * POST /posts/:id/comments  -> guarda comentario para un post
     * ========================================================= */
    public function storeForPost($id): void
    {
        $postId = (int)$id;
        if ($postId <= 0) {
            $this->redirect($this->basePath() . '/post');
            return;
        }

        $text = $this->readText();
        if ($text === '') {
            $_SESSION['flash_error'] = 'Escribe un comentario.';
            $this->redirect($this->basePath() . '/post/' . $postId . '#comentar');
            return;
        }

        $userId = $this->currentUserId(); // puede ser null (Comments.user_id admite NULL)
        $this->comment->create($postId, $userId, $text);

        $_SESSION['flash_ok'] = 'Comentario publicado.';
        $this->redirect($this->basePath() . '/post/' . $postId . '#comentarios');
    }

    /* =========================================================
     * POST /comments  -> compat para formularios genéricos
     * ========================================================= */
    public function store(): void
    {
        $postId = (int)($_POST['post_id'] ?? 0);
        if ($postId <= 0) {
            $this->redirect($this->basePath() . '/post');
            return;
        }

        $text = $this->readText();
        if ($text === '') {
            $_SESSION['flash_error'] = 'Escribe un comentario.';
            $this->redirect($this->basePath() . '/post/' . $postId . '#comentar');
            return;
        }

        $userId = $this->currentUserId();
        $this->comment->create($postId, $userId, $text);

        $_SESSION['flash_ok'] = 'Comentario publicado.';
        $this->redirect($this->basePath() . '/post/' . $postId . '#comentarios');
    }

    /* =========================================================
     * POST /comments/:id/delete  -> elimina un comentario
     * POST /comment/delete       -> compat (recibe comment_id)
     * ========================================================= */
    public function destroy($id): void
    {
        $commentId = (int)$id;
        $this->deleteCommon($commentId);
    }

    public function delete(): void
    {
        $commentId = (int)($_POST['comment_id'] ?? 0);
        $this->deleteCommon($commentId);
    }

    /* ====================== Helpers ====================== */

    /** Obtiene el texto del comentario tolerando nombres de campo distintos */
    private function readText(): string
    {
        $text = trim((string)($_POST['comment_text'] ?? $_POST['comment'] ?? $_POST['body'] ?? ''));
        return $text;
    }

    /** ID de usuario desde sesión en distintos formatos; puede devolver null */
    private function currentUserId(): ?int
    {
        if (isset($_SESSION['user']['user_id'])) return (int)$_SESSION['user']['user_id'];
        if (isset($_SESSION['user_id']))         return (int)$_SESSION['user_id'];
        if (isset($_SESSION['auth']['user_id'])) return (int)$_SESSION['auth']['user_id'];
        return null; // en tu esquema Comments.user_id permite NULL
    }

    /** Base path calculado según el front-controller */
    private function basePath(): string
    {
        $script = (string)($_SERVER['SCRIPT_NAME'] ?? '');
        $dir    = rtrim(str_replace('\\', '/', dirname($script)), '/');
        return ($dir === '.' || $dir === '/') ? '' : $dir;
    }

    /** Lógica común de borrado con verificación básica */
    private function deleteCommon(int $commentId): void
    {
        $bp = $this->basePath();

        if ($commentId <= 0) {
            $_SESSION['flash_error'] = 'Comentario inválido.';
            $this->redirect($bp . '/');
            return;
        }

        // obtener post_id para redirigir de vuelta
        $row = $this->comment->getOwnerAndPost($commentId);
        if (!$row) {
            $_SESSION['flash_error'] = 'El comentario no existe.';
            $this->redirect($bp . '/');
            return;
        }
        $postId  = (int)$row['post_id'];
        $ownerId = (int)($row['user_id'] ?? 0);

        // permiso sencillo: autor o admin (admin: rol_id=1)
        $current = $this->currentUserId() ?? 0;
        $rolId   = (int)($_SESSION['rol_id'] ?? ($_SESSION['user']['rol_id'] ?? 0));
        $isAdmin = ($rolId === 1);
        $isOwner = ($current > 0 && $current === $ownerId);

        if (!$isOwner && !$isAdmin) {
            $_SESSION['flash_error'] = 'No tienes permiso para borrar este comentario.';
            $this->redirect($bp . '/post/' . $postId . '#comentarios');
            return;
        }

        if ($this->comment->deleteById($commentId)) {
            $_SESSION['flash_ok'] = 'Comentario eliminado.';
        } else {
            $_SESSION['flash_error'] = 'No se pudo eliminar el comentario.';
        }

        $this->redirect($bp . '/post/' . $postId . '#comentarios');
    }
}

