<?php
namespace App\Core;

/**
 * Core mínimo para el módulo "Minuevo".
 * Se puede usar sin modificar tu Core global.
 *
 * Prioridad de conexión:
 *  1) $this->container['db'] (si existe)
 *  2) $this->pdo() del Controller base (si existe)
 *  3) App\Core\Database (getInstance()->getConnection / connection / ->pdo)
 *  4) ENV: DB_DSN  |  DB_SOCKET  |  TCP (DB_HOST:DB_PORT)  (defaults listos para Ubuntu)
 */
trait MinuevoCore
{
    /** @var \PDO|null */
    protected $minuevoPdo = null;

    /** @var array */
    protected $minuevoContainer = [];

    /** Llamar desde el constructor del controlador si querés pasar el container */
    protected function minuevoSetContainer(array $container = []): void
    {
        $this->minuevoContainer = $container;
    }

    /** Devuelve una conexión PDO lista para usar */
    protected function minuevoDb(): \PDO
    {
        if ($this->minuevoPdo instanceof \PDO) {
            return $this->minuevoPdo;
        }

        // 1) Contenedor
        if (!empty($this->minuevoContainer['db']) && $this->minuevoContainer['db'] instanceof \PDO) {
            return $this->minuevoPdo = $this->decorate($this->minuevoContainer['db']);
        }

        // 2) Base Controller que expone pdo()
        if (method_exists($this, 'pdo')) {
            try {
                $p = $this->pdo();
                if ($p instanceof \PDO) return $this->minuevoPdo = $this->decorate($p);
            } catch (\Throwable $e) {}
        }

        // 3) App\Core\Database (múltiples firmas)
        if (class_exists('\App\Core\Database')) {
            $Db = '\App\Core\Database';
            try {
                if (method_exists($Db, 'getInstance')) {
                    $inst = $Db::getInstance();
                    foreach (['getConnection', 'connection'] as $m) {
                        if (method_exists($inst, $m)) {
                            $pdo = $inst->$m();
                            if ($pdo instanceof \PDO) return $this->minuevoPdo = $this->decorate($pdo);
                        }
                    }
                    if (property_exists($inst, 'pdo') && $inst->pdo instanceof \PDO) {
                        return $this->minuevoPdo = $this->decorate($inst->pdo);
                    }
                }
            } catch (\Throwable $e) {}
        }

        // 4) ENV/constantes → DSN directo (DB_DSN | DB_SOCKET | TCP)
        $cfg = $this->minuevoReadCfg();

        // 4.a) DSN completo
        if (!empty($cfg['dsn'])) {
            try {
                return $this->minuevoPdo = $this->decorate(new \PDO(
                    $cfg['dsn'], $cfg['user'], $cfg['pass'], $this->minuevoOpts()
                ));
            } catch (\Throwable $e) {}
        }

        // 4.b) UNIX socket (por defecto en Ubuntu/MariaDB)
        if (!empty($cfg['socket'])) {
            $dsn = "mysql:unix_socket={$cfg['socket']};dbname={$cfg['name']};charset={$cfg['charset']}";
            try {
                return $this->minuevoPdo = $this->decorate(new \PDO(
                    $dsn, $cfg['user'], $cfg['pass'], $this->minuevoOpts()
                ));
            } catch (\Throwable $e) {}
        }

        // 4.c) TCP clásico
        $host = $cfg['host'] ?: '127.0.0.1';
        $port = $cfg['port'] ?: '3306';
        $dsn  = "mysql:host={$host};port={$port};dbname={$cfg['name']};charset={$cfg['charset']}";
        return $this->minuevoPdo = $this->decorate(new \PDO(
            $dsn, $cfg['user'], $cfg['pass'], $this->minuevoOpts()
        ));
    }

    /** Decora el PDO con atributos seguros (idempotente) */
    private function decorate(\PDO $pdo): \PDO
    {
        $pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
        $pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);
        return $pdo;
    }

    /** Lee configuración desde ENV/constantes y defaults amables para dev Ubuntu */
    private function minuevoReadCfg(): array
    {
        $get = function ($k, $def = null) {
            if (getenv($k) !== false) return getenv($k);
            if (isset($_ENV[$k])) return $_ENV[$k];
            if (defined($k)) return constant($k);
            return $def;
        };

        return [
            'dsn'     => $get('DB_DSN', null),
            'socket'  => $get('DB_SOCKET', '/var/run/mysqld/mysqld.sock'),
            'host'    => $get('DB_HOST', '127.0.0.1'),
            'port'    => $get('DB_PORT', '3306'),
            'name'    => $get('DB_NAME', 'proyutu'),
            'user'    => $get('DB_USER', 'root'),
            'pass'    => $get('DB_PASS', ''),
            'charset' => $get('DB_CHARSET', 'utf8mb4'),
        ];
    }

    /** Opciones por defecto para PDO */
    private function minuevoOpts(): array
    {
        return [
            \PDO::ATTR_ERRMODE            => \PDO::ERRMODE_EXCEPTION,
            \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
            \PDO::ATTR_EMULATE_PREPARES   => false,
        ];
    }
}

