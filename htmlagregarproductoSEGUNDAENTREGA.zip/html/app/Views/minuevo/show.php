<article class="card article-detail">
  <h1><?= $this->e($post['title']); ?></h1>
  <p class="meta">
    <strong>Fecha:</strong> <?= date('Y-m-d', strtotime($post['created_at'])) ?>
    &nbsp;|&nbsp;
    <strong>Autor:</strong> <?= $this->e($post['author']); ?>
  </p>
  <div class="content">
    <p><?= nl2br($this->e($post['content'])); ?></p>
  </div>

  <div class="rating">
    <h3>Puntuación</h3>
    <?php if ($avg !== null): ?>
      <p>Promedio: <strong><?= $this->e($avg) ?></strong> (<?= $this->e($total) ?> votos)</p>
    <?php else: ?>
      <p>Sin votos aún.</p>
    <?php endif; ?>

    <?php if (!empty($_SESSION['user'])): ?>
      <form method="post" action="/article/<?= (int)$post['post_id'] ?>/rate" class="rate-form">
        <label>Tu voto:</label>
        <select name="rating" required>
          <?php for ($i=1; $i<=5; $i++): ?>
            <option value="<?= $i ?>" <?= ($userVote==$i?'selected':'') ?>><?= $i ?></option>
          <?php endfor; ?>
        </select>
        <button class="btn small">Enviar</button>
      </form>
    <?php else: ?>
      <p><a href="/login">Inicia sesión</a> para votar.</p>
    <?php endif; ?>
  </div>
</article>

