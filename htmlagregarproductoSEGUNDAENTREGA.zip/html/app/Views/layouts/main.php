<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= htmlspecialchars($title ?? 'Chivita Recomienda', ENT_QUOTES, 'UTF-8') ?></title>
<?php
  // Base pública robusta (soporta subcarpeta)
  $PUBLIC_BASE = rtrim(str_replace('\\','/', dirname($_SERVER['SCRIPT_NAME'])), '/');
  if ($PUBLIC_BASE === '.' || $PUBLIC_BASE === '/') $PUBLIC_BASE = '';

  // Rutas FÍSICAS reales (no URLs) para cache-busting
  $ROOT = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 3); // .../ (raíz del proyecto)
  $cssMainPath = $ROOT . '/public/css/styles.css';
  $cssUCPath   = $ROOT . '/public/css/user-corner.css';

  $cssMainVer  = @filemtime($cssMainPath) ?: time();
  $cssUCVer    = @filemtime($cssUCPath)   ?: $cssMainVer;
?>
<link rel="stylesheet" href="<?= $PUBLIC_BASE ?>/css/styles.css?v=<?= $cssMainVer ?>">
<link rel="stylesheet" href="<?= $PUBLIC_BASE ?>/css/user-corner.css?v=<?= $cssUCVer ?>">
<link rel="stylesheet" href="<?= $PUBLIC_BASE ?>/css/minuevo.css?v=<?= $cssUCVer ?>">


</head>

<body class="theme-clean">
  <header>
    <?php $this->component('navigation') ?>
  </header>

  <main class="container">
    <?php $this->component('flash-messages') ?>
    <?= $content ?>
  </main>

  <?php $this->component('user-corner') ?>
</body>
</html>

