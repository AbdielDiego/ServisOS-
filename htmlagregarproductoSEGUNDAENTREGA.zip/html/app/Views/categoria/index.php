<?php
// Mostrar el título dinámico recibido desde el controlador
echo "<h1>$titulo</h1>";

// Incluir el componente de tabla (renderiza los datos en HTML)
require BASE_PATH ."/app/Views/components/tabla.php";


