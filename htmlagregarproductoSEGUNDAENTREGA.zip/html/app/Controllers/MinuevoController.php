<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Minuevo;

class MinuevoController extends Controller
{
    /** @var \PDO */
    private $pdo;
    /** @var Minuevo */
    private $model;

    public function __construct()
    {
        if (method_exists('App\Core\Controller', '__construct')) {
            parent::__construct();
        }

        // MISMA conexión que el resto (Singleton)
        $this->pdo = Database::getConnection();
        $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
        $this->pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);

        $this->model = new Minuevo($this->pdo);
    }

    /** GET /minuevo — listado */
    public function index()
    {
        $posts = $this->model->latest(10);
        return $this->view('minuevo/index', ['posts' => $posts]);
    }

    /** GET /minuevo/crear — formulario (AuthMiddleware en rutas) */
    public function create()
    {
        $cats = $this->model->categories();
        return $this->view('minuevo/create', ['categories' => $cats]);
    }

    /** POST /minuevo/guardar — inserta en Posts */
    public function store()
    {
        $userId = $_SESSION['user']['user_id'] ?? null;
        if (!$userId) {
            $this->flash('error', 'Debes iniciar sesión.');
            return $this->redirect('/login');
        }

        $title   = trim($_POST['title']   ?? '');
        $content = trim($_POST['content'] ?? '');
        $cidRaw  = $_POST['category_id']  ?? '';

        if ($title === '' || $content === '') {
            $this->flash('error', 'Título y contenido son obligatorios.');
            return $this->redirect('/minuevo/crear');
        }

        $categoryId = ($cidRaw === '' ? null : (int)$cidRaw);

        try {
            $this->model->create((int)$userId, $categoryId, $title, $content);
            $this->flash('ok', 'Artículo creado con éxito.');
            return $this->redirect('/minuevo');
        } catch (\Throwable $e) {
            $this->flash('error', 'No se pudo crear el artículo.');
            return $this->redirect('/minuevo/crear');
        }
    }

    /* ========================
       Fallbacks de utilidades
       (firmas compatibles)
       ======================== */

    // Hacemos públicas y SIN type hints para que coincidan con el Controller base
    public function view($template, $data = [])
    {
        // Si el Controller base tiene view(), úsala
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent, 'view')) {
            return parent::view($template, $data);
        }

        // Fallback propio
        $base = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 2);
        $file = $base . '/app/Views/' . ltrim($template, '/') . '.php';
        if (!is_file($file)) {
            http_response_code(500);
            echo "<h1>Vista no encontrada</h1><p>{$template}.php</p>";
            return null;
        }

        extract(is_array($data) ? $data : [], EXTR_SKIP);

        ob_start();
        include $file;
        $out = ob_get_clean();
        echo $out;
        return null;
    }

    // Firma EXACTA compatible con App\Core\Controller::redirect($url)
    public function redirect($url)
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent, 'redirect')) {
            return parent::redirect($url);
        }
        header('Location: ' . $url);
        exit;
    }

    public function flash($key, $message)
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent, 'flash')) {
            return parent::flash($key, $message);
        }
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        $_SESSION['flash'][$key] = $message;
        return null;
    }
}

