<?php
namespace App\Models;

use App\Core\Model;

class Api extends Model{

    public function __construct(){
        $this->table = "Categories";
        $this->primaryKey = "category_id";
        parent::__construct();
    }

    /**
     * Devuelve todos los registros de la tabla Categories
     */
    public function all(): array {
        $sql = "SELECT * FROM {$this->table}";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * Ejecuta una consulta cruda y devuelve todos los resultados
     */
    public function executeRawQuery(string $sql, array $params = []): array {
        $stmt = $this->db->query($sql, $params);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
}

