<?php
namespace App\Models;

class Minuevo
{
    private \PDO $pdo;

    public function __construct(\PDO $pdo) { $this->pdo = $pdo; }

    public function latest(int $limit = 10): array
    {
        $sql = "SELECT p.post_id, p.title, p.content, p.created_at,
                       u.username AS author, c.name AS category
                FROM Posts p
                JOIN Users u ON u.user_id = p.user_id
                LEFT JOIN Categories c ON c.category_id = p.category_id
                ORDER BY p.created_at DESC
                LIMIT :lim";
        $st = $this->pdo->prepare($sql);
        $st->bindValue(':lim', $limit, \PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }

    public function categories(): array
    {
        $st = $this->pdo->query("SELECT category_id, name FROM Categories ORDER BY name ASC");
        return $st->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }

    public function create(int $userId, ?int $categoryId, string $title, string $content): int
    {
        $sql = "INSERT INTO Posts (user_id, category_id, title, content, created_at, updated_at)
                VALUES (:uid, :cid, :title, :content, NOW(), NOW())";
        $st = $this->pdo->prepare($sql);
        $st->bindValue(':uid', $userId, \PDO::PARAM_INT);
        $st->bindValue(':title', $title, \PDO::PARAM_STR);
        $st->bindValue(':content', $content, \PDO::PARAM_STR);
        if ($categoryId) $st->bindValue(':cid', $categoryId, \PDO::PARAM_INT);
        else             $st->bindValue(':cid', null, \PDO::PARAM_NULL);
        $st->execute();
        return (int)$this->pdo->lastInsertId();
    }
}

