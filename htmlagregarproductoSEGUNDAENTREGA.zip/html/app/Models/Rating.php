<?php
namespace App\Models;

use App\Core\Model;

class Rating extends Model
{
    protected string $table = ''; // se setea dinámicamente
    protected array  $fillable = ['user_id','rating'];

    public function setTable(string $table): void { $this->table = $table; }

    public function upsertByUser(array $where, array $data): bool
    {
        // upsert manual: si existe (where), update; si no, insert
        $exists = $this->firstWhere($where);
        if ($exists) {
            return $this->updateWhere($where, $data);
        }
        return $this->insert(array_merge($where, $data));
    }
}

