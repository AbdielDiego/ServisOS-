<?php
namespace App\Models;

use App\Core\Model;

/**
 * Modelo User
 * Representa la tabla "Users" y provee métodos de consulta.
 */
class User extends Model {
    // Tabla y clave primaria
    protected $table = 'Users';
    protected $primaryKey = "user_id";

    /**
     * Buscar un usuario por su email
     */
    public function findByEmail($email) {
        $query = $this->db->query(
            "SELECT * FROM {$this->table} WHERE email = ? LIMIT 1",
            [$email]
        );
        return $query->fetch(\PDO::FETCH_ASSOC);
    }

    /**
     * Obtener todos los usuarios
     */
    public function all(): array {
        $sql = "SELECT * FROM {$this->table}";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * Ejecutar una consulta SQL cruda
     * Útil para listados con filtros o joins
     */
    public function executeRawQuery(string $sql, array $params = []): array {
        $stmt = $this->db->query($sql, $params);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * Contar total de usuarios
     * (se usa, por ejemplo, para asignar al primero como Admin)
     */
    public function countAll(): int {
        $stmt = $this->db->query("SELECT COUNT(*) AS c FROM {$this->table}");
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return (int)($row['c'] ?? 0);
    }
}

