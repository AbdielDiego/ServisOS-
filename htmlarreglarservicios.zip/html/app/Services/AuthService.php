
 <?php
namespace App\Services;

use App\Core\Session;
use App\Models\User;

class AuthService
{
    protected $session;
    protected $userModel;

    /**
     * Clave canónica que define "usuario autenticado" en toda la app.
     * ¡No la cambies a menos que actualices Core\Auth y el middleware!
     */
    protected $sessionKey = 'auth_user_id';

    public function __construct(Session $session)
    {
        $this->session   = $session;
        $this->userModel = new User();
    }

    /**
     * Intentar iniciar sesión.
     * Devuelve el usuario (array) si OK, o null si falla.
     * También deja seteada la sesión en $this->sessionKey.
     */
    public function attempt(string $email, string $password): ?array
    {
        $user = $this->userModel->findByEmail($email);

        if ($user && $this->verifyPassword($password, $user['password'])) {
            // Seteamos la clave canónica de login
            $this->session->set($this->sessionKey, $user['user_id']);

            // (Opcional) datos útiles para la UI
            if (isset($user['username'])) {
                $this->session->set('username', $user['username']);
            }
            if (isset($user['rol_name'])) {
                $this->session->set('rol', $user['rol_name']);
            }

            return $user;
        }

        return null;
    }

    /**
     * Registrar un usuario y devolver su ID.
     * Espera al menos: username, email, password (plano).
     */
    public function register(array $data): ?int
    {
        // Normalizo nombre de campo
        if (isset($data['name']) && !isset($data['username'])) {
            $data['username'] = $data['name'];
            unset($data['name']);
        }

        // Saneos mínimos
        $data['username'] = trim($data['username'] ?? '');
        $data['email']    = trim($data['email'] ?? '');
        $data['password'] = $this->hashPassword($data['password'] ?? '');

        // Crear en BD
        $newId = $this->userModel->create($data);
        return is_numeric($newId) ? (int)$newId : null;
    }

    /**
     * ¿Hay usuario autenticado?
     */
    public function check(): bool
    {
        return $this->session->has($this->sessionKey);
    }

    /**
     * Obtener el usuario actual desde BD.
     */
    public function user(): ?array
    {
        if (!$this->check()) {
            return null;
        }
        // Model::find espera array de condiciones
        return $this->userModel->find(['user_id' => $this->session->get($this->sessionKey)]);
    }

    /**
     * Cerrar sesión.
     */
    public function logout(): void
    {
        $this->session->remove($this->sessionKey);
        // Limpieza opcional de extras usados en UI
        $this->session->remove('username');
        $this->session->remove('rol');
    }

    /**
     * Helpers de password
     */
    protected function hashPassword(string $plain): string
    {
        return password_hash($plain, PASSWORD_BCRYPT);
    }

    protected function verifyPassword(string $plain, string $hash): bool
    {
        return password_verify($plain, $hash);
    }
}

