<?php
/**
 * Punto de entrada principal de la aplicación
 * Inicializa componentes esenciales y despacha las peticiones
 */

use Dotenv\Dotenv;
use App\Models\MessageRecipient;

// ---------------------------------------------------------
// Rutas base y Autoload
// ---------------------------------------------------------
define('BASE_PATH', dirname(__DIR__));
require BASE_PATH . '/vendor/autoload.php';

// ---------------------------------------------------------
// Cargar variables de entorno (.env)
// ---------------------------------------------------------
$dotenv = Dotenv::createImmutable(BASE_PATH);
$dotenv->load();

// ---------------------------------------------------------
// PHP session (para auth/flash)
// ---------------------------------------------------------
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// ---------------------------------------------------------
// Modo desarrollo (mostrar errores)
// ---------------------------------------------------------
error_reporting(E_ALL);
ini_set('display_errors', '1');

// ---------------------------------------------------------
// Contenedor / servicios core
// ---------------------------------------------------------
$session = new App\Core\Session();
App\Core\Container::set('session', $session);

$db = App\Core\Database::getInstance();
App\Core\Container::set('db', $db);

$userModel = new App\Models\User();
App\Core\Container::set('userModel', $userModel);

$auth = new App\Core\Auth($session, $userModel);
App\Core\Container::set('auth', $auth);

$view = new App\Core\View();
App\Core\Container::set('view', $view);

// ---------------------------------------------------------
// Request actual
// ---------------------------------------------------------
$request = [
    'get'    => $_GET,
    'post'   => $_POST,
    'uri'    => isset($_GET['url']) ? trim($_GET['url'], '/') : 'home',
    'method' => $_SERVER['REQUEST_METHOD'] ?? 'GET',
];
App\Core\Container::set('request', $request);

// ---------------------------------------------------------
// Datos compartidos con TODAS las vistas
// (auth desde $_SESSION, contador de no leídos y flashes)
// ---------------------------------------------------------
$authShared = [
    'check' => !empty($_SESSION['auth']['check']) && !empty($_SESSION['auth']['user']),
    'user'  => $_SESSION['auth']['user'] ?? null,
];

$unread = 0;
if ($authShared['check'] && !empty($authShared['user']['user_id'])) {
    try {
        $unread = (int) MessageRecipient::unreadCount((int) $authShared['user']['user_id']);
    } catch (\Throwable $e) {
        error_log('[bootstrap] unreadCount: ' . $e->getMessage());
    }
}

$flashShared = [
    'error'   => $_SESSION['flash']['error']   ?? null,
    'success' => $_SESSION['flash']['success'] ?? null,
    'info'    => $_SESSION['flash']['info']    ?? null,
];

// Publicar en el motor de vistas
$view->share([
    'auth'       => $authShared,
    'unread'     => $unread,
    'currentUrl' => parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH),
    'flash'      => $flashShared,
]);

// ---------------------------------------------------------
// Enrutador
// ---------------------------------------------------------
$router = new App\Core\Router($view, $request);
App\Core\Container::set('router', $router);

// Rutas
require BASE_PATH . '/config/routes.php';

// Despachar
$router->dispatch();

