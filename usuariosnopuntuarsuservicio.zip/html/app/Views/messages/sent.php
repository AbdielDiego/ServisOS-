<link rel="stylesheet" href="/css/styles.css">
<?php
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
?>
<h1><?= h($title ?? 'Enviados') ?></h1>

<?php if (empty($items)): ?>
  <p>No has enviado mensajes.</p>
<?php else: ?>
  <ul>
    <?php foreach ($items as $r): ?>
      <?php
        // Mostrar el/los destinatarios
       $to = $r['to_names'] ?? $r['username'] ?? '';
     if ($to === null || trim($to) === '') { $to = '(sin destinatarios)'; }

      ?>
      <li>
        <a href="/messages/<?= (int)($r['message_id'] ?? $r['id'] ?? 0) ?>">
          <?= h($r['subject'] ?? '(sin asunto)') ?>
        </a>
        · Para: <?= h($to) ?> · <?= h($r['created_at'] ?? '') ?>
      </li>
    <?php endforeach; ?>
  </ul>
<?php endif; ?>

