<link rel="stylesheet" href="/css/login.css">
<!-- Título de la página -->
<h2>Iniciar sesión</h2>

<!-- Formulario de login (método POST) -->
<form method="POST" >

    <!-- Campo Email -->
    <div>
        <label>Email:</label>
        <input type="email" name="email" required value="">
        <small>Ingrese su email</small>
    </div>
    
    <!-- Campo Contraseña -->
    <div class="field-pass">
  <label>Contraseña:</label>
  <input type="password" name="password" required placeholder="Ingresa tu contraseña">
  <button type="button" class="toggle-pass" aria-pressed="false" aria-label="Mostrar contraseña"></button>
  <small>Ingrese su contraseña</small>
   </div>
   
   <div class="auth-extras">
  <label class="remember"><input type="checkbox" name="remember"> Recuérdame</label>
  <a href="/forgot">Olvidé mi contraseña</a>
  </div>


    
   <!-- Botón de envío -->
    <button type="submit">Ingresar</button>
</form>





