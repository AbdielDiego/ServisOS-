<!-- Título principal -->
<h1>Detalles de Usuario</h1>

<!-- Datos básicos del usuario -->
<p>ID de usuario: <?= $userId ?? 'N/A' ?></p>
<p>Nombre: <?= htmlspecialchars($user['username']) ?></p>
<p>Email: <?= htmlspecialchars($user['email']) ?></p>

<!-- Enlace para regresar al dashboard -->
<p><a href="/dashboard">← Volver a mi perfil</a></p>


