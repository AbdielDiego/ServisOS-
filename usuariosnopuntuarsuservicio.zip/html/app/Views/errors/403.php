<?php
/** @var string $title */
/** @var string $message */
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title><?= h($title ?? '403 - Acceso denegado') ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; background:#0f172a; color:#e2e8f0; margin:0; }
    .wrap { max-width: 820px; margin: 48px auto; padding: 0 16px; }
    .card { border:1px solid #ef444422; background:#ef444411; border-radius:12px; padding:16px 18px; }
    h1 { margin:0 0 8px; font-size: 28px; }
    p  { margin:0; opacity:.9; }
    a.btn { display:inline-block; margin-top:14px; padding:8px 12px; border:1px solid #22d3ee; border-radius:10px; text-decoration:none; color:#22d3ee; }
    a.btn:hover { background:#22d3ee22; }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>403 · Acceso denegado</h1>
      <p><?= h($message ?? 'No autorizado.') ?></p>
      <a class="btn" href="/messages/inbox">Volver al Inbox</a>
    </div>
  </div>
</body>
</html>

