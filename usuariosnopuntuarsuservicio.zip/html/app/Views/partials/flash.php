<?php
if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
$flashes = $_SESSION['flash'] ?? [];
if (!empty($flashes)):
?>
<div class="flash-container">
  <?php foreach ($flashes as $k => $msg): ?>
    <div class="flash flash-<?= htmlspecialchars($k,ENT_QUOTES,'UTF-8') ?>">
      <?= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') ?>
    </div>
  <?php endforeach; unset($_SESSION['flash']); ?>
</div>
<style>
.flash-container{position:relative;margin:.75rem 0}
.flash{padding:.65rem .9rem;border-radius:.75rem;margin-bottom:.5rem;font-weight:600}
.flash-info{background:#0ea5e9;color:#00121c}
.flash-success{background:#22c55e;color:#00180a}
.flash-error{background:#ef4444;color:#1f0000}
</style>
<script>setTimeout(()=>{document.querySelectorAll('.flash').forEach(n=>n.remove())}, 4000);</script>
<?php endif; ?>

