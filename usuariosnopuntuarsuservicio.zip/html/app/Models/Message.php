<?php
namespace App\Models;

use App\Core\Database;
use PDO;

class Message
{
    private static function pdo(): PDO
    {
        return Database::getConnection();
    }

    /**
     * Crea un mensaje y devuelve su ID.
     */
    public static function create(int $senderId, string $subject, string $body): int
    {
        $pdo = self::pdo();

        // created_at tiene default CURRENT_TIMESTAMP en tu dump,
        // pero no molesta setearlo explícito si quieres.
        $sql = "INSERT INTO messages (sender_id, subject, body, created_at)
                VALUES (:sid, :subj, :body, NOW())";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':sid'  => $senderId,
            ':subj' => $subject,
            ':body' => $body,
        ]);

        return (int)$pdo->lastInsertId();
    }

    /**
     * Lista de mensajes enviados por un usuario (con destinatarios).
     */
    public static function sentBy(int $userId): array
    {
        $pdo = self::pdo();

        $sql = "SELECT 
                    m.id,
                    m.sender_id,
                    m.subject,
                    m.body,
                    m.created_at,
                    GROUP_CONCAT(u.username ORDER BY u.username SEPARATOR ', ') AS to_names
                FROM messages m
                JOIN message_recipients mr ON mr.message_id = m.id
                JOIN Users u              ON u.user_id = mr.recipient_id
                WHERE m.sender_id = :uid
                GROUP BY m.id
                ORDER BY m.created_at DESC";

        $st = $pdo->prepare($sql);
        $st->execute([':uid' => $userId]);
        return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }
}

