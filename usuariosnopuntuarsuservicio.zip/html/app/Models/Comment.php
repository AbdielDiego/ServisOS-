<?php
namespace App\Models;

use App\Core\Model;
use PDO;

class Comment extends Model
{
    public function __construct()
    {
        parent::__construct();
        
        $this->table = 'Comments';
    }

    /**
     * Crea un comentario y devuelve su ID (comment_id).
     * Acepta 'comment_text' (preferido) o 'comment'.
     * - post_id: int > 0
     * - user_id: int|null (FK permite NULL)
     */
    public function create(array $data): int
    {
        $postId      = (int)($data['post_id'] ?? 0);
        $userIdInput = $data['user_id'] ?? null;
        $userId      = ($userIdInput === '' || $userIdInput === null) ? null : (int)$userIdInput;
        $commentText = (string)($data['comment_text'] ?? ($data['comment'] ?? ''));

        if ($postId <= 0 || $commentText === '') {
            throw new \InvalidArgumentException('Datos de comentario incompletos');
        }

        $sql = "INSERT INTO `{$this->table}` (`post_id`,`user_id`,`comment_text`)
                VALUES (:post_id, :user_id, :comment_text)";

        // 1) Si tu wrapper tiene insert(...)
        if (method_exists($this->db, 'insert')) {
            return (int)$this->db->insert($sql, [
                'post_id'      => $postId,
                'user_id'      => $userId,
                'comment_text' => $commentText,
            ]);
        }

        // 2) Wrapper query(...): probamos sin ":" y, si falla, con ":"
        if (method_exists($this->db, 'query')) {
            try {
                $this->db->query($sql, [
                    'post_id'      => $postId,
                    'user_id'      => $userId,
                    'comment_text' => $commentText,
                ]);
            } catch (\Throwable $e) {
                $this->db->query($sql, [
                    ':post_id'      => $postId,
                    ':user_id'      => $userId,
                    ':comment_text' => $commentText,
                ]);
            }

            if (method_exists($this->db, 'lastInsertId')) {
                return (int)$this->db->lastInsertId();
            }
            if (property_exists($this->db, 'pdo') && $this->db->pdo instanceof PDO) {
                return (int)$this->db->pdo->lastInsertId();
            }
            return 1; // truthy si tu controlador solo chequea if ($ok)
        }

        // 3) Fallback PDO nativo
        if ($this->db instanceof PDO) {
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':post_id', $postId, PDO::PARAM_INT);
            if ($userId === null) $stmt->bindValue(':user_id', null, PDO::PARAM_NULL);
            else $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindValue(':comment_text', $commentText, PDO::PARAM_STR);
            $stmt->execute();
            return (int)$this->db->lastInsertId();
        }

        throw new \RuntimeException('No hay método compatible para ejecutar el INSERT');
    }

    /**
     * Devuelve los comentarios de un post (más nuevos primero).
     */
    public function findByPostId(int $postId): array
    {
        $sql = "SELECT
                    c.comment_id,
                    c.comment_text AS comment_text,
                    c.comment_text AS body,   -- alias para vistas viejas
                    c.created_at,
                    u.username
                FROM `{$this->table}` c
                LEFT JOIN `Users` u ON u.user_id = c.user_id
                WHERE c.post_id = :post_id
                ORDER BY c.created_at DESC, c.comment_id DESC";

        if (method_exists($this->db, 'query')) {
            try {
                $res = $this->db->query($sql, ['post_id' => $postId]);
            } catch (\Throwable $e) {
                $res = $this->db->query($sql, [':post_id' => $postId]);
            }
            if (is_object($res) && method_exists($res, 'fetchAll')) return $res->fetchAll();
            return (array)$res;
        }

        if ($this->db instanceof PDO) {
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':post_id', $postId, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        }

        return [];
    }
}

