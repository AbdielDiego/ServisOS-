<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\MessageRecipient;

class MessageController extends Controller
{
    /* ============================
     * Sesión / Auth helpers
     * ============================ */

    private function user(): ?array {
        if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
        return $_SESSION['auth']['user'] ?? $_SESSION['user'] ?? null;
    }

    private function currentUserId(): ?int {
        $u = $this->user();
        if (is_array($u)) {
            return (int)($u['user_id'] ?? $u['id'] ?? 0);
        }
        if (isset($_SESSION['user_id'])) return (int)$_SESSION['user_id'];
        return null;
    }

    private function requireAuth(): int {
        $uid = $this->currentUserId();
        if (!$uid) { header('Location: /login'); exit; }
        return $uid;
    }

    /* ============================
     * Bandejas
     * ============================ */

    /** GET /messages/inbox */
    public function inbox() {
        $uid = $this->requireAuth();

        // Inbox: solo mensajes del usuario logueado
        $items    = MessageRecipient::findInboxForUser($uid, 200);
        $newCount = MessageRecipient::countUnreadForUser($uid);

        return $this->render('messages/inbox', [
            'title'    => 'Inbox',
            'items'    => $items,
            'newCount' => $newCount,
        ]);
    }

    /** GET /messages/sent */
    public function sent() {
        $uid = $this->requireAuth();
        $pdo = Database::getConnection();

        $sql = "
            SELECT
                m.id AS message_id,
                m.subject,
                m.created_at,
                COALESCE(
                    GROUP_CONCAT(
                        DISTINCT COALESCE(NULLIF(u.username, ''), u.email)
                        ORDER BY u.username SEPARATOR ', '
                    ),
                    ''
                ) AS to_names
            FROM messages m
            LEFT JOIN message_recipients mr ON mr.message_id = m.id
            LEFT JOIN Users u              ON u.user_id      = mr.recipient_id
            WHERE m.sender_id = :uid
            GROUP BY m.id, m.subject, m.created_at
            ORDER BY m.created_at DESC
        ";
        $st = $pdo->prepare($sql);
        $st->execute([':uid' => $uid]);
        $items = $st->fetchAll(\PDO::FETCH_ASSOC);

        return $this->render('messages/sent', [
            'title' => 'Mensajes enviados',
            'items' => $items,
        ]);
    }

    /** GET /messages/compose */
    public function compose() {
        $this->requireAuth();
        return $this->render('messages/compose', [
            'title' => 'Nuevo mensaje',
            'old'   => [
                'to_query' => $_POST['to_query'] ?? '',
                'subject'  => $_POST['subject']  ?? '',
                'body'     => $_POST['body']     ?? '',
            ],
        ]);
    }

    /* ============================
     * Crear mensaje
     * ============================ */

    private function resolveRecipientIdsFromQuery(string $raw, int $currentUserId): array {
        $tokens = preg_split('/[,\s]+/', $raw, -1, PREG_SPLIT_NO_EMPTY);
        if (empty($tokens)) return [[], []];

        $needles = [];
        foreach ($tokens as $t) {
            $t = strtolower(trim($t));
            if ($t !== '') $needles[$t] = true;
        }
        if (empty($needles)) return [[], []];

        $pdo = Database::getConnection();

        $placeholders = implode(',', array_fill(0, count($needles), '?'));
        $params = array_keys($needles);
        $params = array_merge($params, $params);

        $sql = "
            SELECT user_id, LOWER(username) AS uname, LOWER(email) AS uemail
            FROM Users
            WHERE LOWER(username) IN ($placeholders)
               OR LOWER(email)    IN ($placeholders)
        ";
        $st = $pdo->prepare($sql);
        $st->execute($params);
        $rows = $st->fetchAll(\PDO::FETCH_ASSOC);

        $map = [];
        foreach ($rows as $r) {
            if (!empty($r['uname']))  $map[$r['uname']]  = (int)$r['user_id'];
            if (!empty($r['uemail'])) $map[$r['uemail']] = (int)$r['user_id'];
        }

        $ids = [];
        $unknown = [];
        foreach (array_keys($needles) as $tok) {
            if (isset($map[$tok])) {
                $id = (int)$map[$tok];
                if ($id > 0 && $id !== $currentUserId) $ids[$id] = true;
            } else {
                $unknown[] = $tok;
            }
        }

        return [array_keys($ids), $unknown];
    }

    /** POST /messages */
    public function store() {
        $uid     = $this->requireAuth();
        $pdo     = Database::getConnection();
        $toQuery = trim($_POST['to_query'] ?? '');
        $subject = trim($_POST['subject']  ?? '');
        $body    = trim($_POST['body']     ?? '');

        if ($subject === '' || $body === '' || $toQuery === '') {
            return $this->render('messages/compose', [
                'title' => 'Nuevo mensaje',
                'error' => 'Completa destinatarios, asunto y mensaje.',
                'old'   => ['to_query'=>$toQuery, 'subject'=>$subject, 'body'=>$body],
            ]);
        }

        [$recips, $unknown] = $this->resolveRecipientIdsFromQuery($toQuery, $uid);

        if (!empty($unknown)) {
            return $this->render('messages/compose', [
                'title' => 'Nuevo mensaje',
                'error' => 'No se encontraron: ' . implode(', ', $unknown),
                'old'   => ['to_query'=>$toQuery, 'subject'=>$subject, 'body'=>$body],
            ]);
        }

        if (empty($recips)) {
            return $this->render('messages/compose', [
                'title' => 'Nuevo mensaje',
                'error' => 'No hay destinatarios válidos (no puedes enviarte a ti mismo).',
                'old'   => ['to_query'=>$toQuery, 'subject'=>$subject, 'body'=>$body],
            ]);
        }

        $st = $pdo->prepare("INSERT INTO messages (sender_id, subject, body) VALUES (:sid, :sub, :bod)");
        $st->execute([':sid'=>$uid, ':sub'=>$subject, ':bod'=>$body]);
        $mid = (int)$pdo->lastInsertId();

        MessageRecipient::addRecipients($mid, $recips);

        return $this->redirect('/messages/sent');
    }

    /* ============================
     * Ver mensaje
     * ============================ */

    /** GET /messages/:id */
    public function show($id) {
        $uid = $this->requireAuth();

        // ⚠️ Normalizar ID desde el router (puede venir como array)
        if (is_array($id)) { $id = $id['id'] ?? reset($id); }
        $mid = filter_var($id, FILTER_VALIDATE_INT) ?: 0;

        if ($mid <= 0) return $this->redirect('/messages/inbox');

        if (!MessageRecipient::userCanSee($mid, $uid)) {
            $_SESSION['flash_error'] = 'No autorizado para ver este mensaje.';
            return $this->redirect('/messages/inbox');
        }

        // Traer datos con alias correctos
        $message = MessageRecipient::findMessageWithDetails($mid);
        if (!$message) return $this->redirect('/messages/inbox');

        // Si es destinatario, marcar como leído
        if (MessageRecipient::userCanDelete($mid, $uid)) {
            MessageRecipient::markRead($mid, $uid);
        }

        return $this->render('messages/show', [
            'title'   => 'Mensaje',
            'message' => $message, // from_name, from_email, created_at, subject, body
        ]);
    }

    /* ============================
     * Eliminar mensaje
     * ============================ */

    /** GET|POST /messages/delete/:id */
    public function delete($id)
    {
        if (is_array($id)) { $id = $id['id'] ?? reset($id); }
        $id  = (int)$id;

        $this->requireAuth();
        $uid = $this->currentUserId();
        if (!$uid) return $this->redirect('/login');

        $confirm = $_GET['confirm'] ?? null;

        if ($confirm === null && ($_SERVER['REQUEST_METHOD'] === 'POST')) {
            $_SESSION['pending_delete_message_id'] = $id;
            $_SESSION['flash_info'] =
                '¿Quieres eliminar el mensaje? ' .
                '<a class="btn btn-xs btn-danger" href="/messages/delete/'.$id.'?confirm=yes">Sí</a> ' .
                '<a class="btn btn-xs" href="/messages/delete/'.$id.'?confirm=no">No</a>';
            return $this->redirect('/messages/inbox');
        }

        if ($confirm === 'no') {
            unset($_SESSION['pending_delete_message_id']);
            $_SESSION['flash_ok'] = 'Operación cancelada. El mensaje no fue eliminado.';
            return $this->redirect('/messages/inbox');
        }

        if ($confirm === 'yes') {
            if (!MessageRecipient::userCanDelete($id, $uid)) {
                $_SESSION['flash_error'] = 'No tienes permiso para borrar este mensaje.';
                return $this->redirect('/messages/inbox');
            }

            MessageRecipient::deleteForUser($id, $uid);

            if (MessageRecipient::remainingRecipients($id) === 0) {
                MessageRecipient::deleteMessageIfOrphan($id);
            }

            unset($_SESSION['pending_delete_message_id']);
            $_SESSION['flash_ok'] = 'Mensaje eliminado correctamente.';
            return $this->redirect('/messages/inbox');
        }

        return $this->redirect('/messages/inbox');
    }
}

