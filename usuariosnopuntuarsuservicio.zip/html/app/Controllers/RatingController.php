<?php
namespace App\Controllers;

use App\Core\Controller;

class RatingController extends Controller
{
    /**
     * Obtiene una conexión PDO de distintas formas.
     * Intenta buscar primero en el contenedor, después en Database, luego en Model, 
     * y como fallback crea una nueva conexión usando constantes globales.
     */
    private function pdo(): \PDO
    {
        // 1) Si el contenedor tiene un objeto PDO válido
        if (isset($this->container['db']) && $this->container['db'] instanceof \PDO) {
            return $this->container['db'];
        }

        // 2) Intenta obtener desde App\Core\Database
        $Db = '\App\Core\Database';
        if (class_exists($Db)) {
            if (method_exists($Db, 'getInstance')) {
                $inst = $Db::getInstance();
                if (is_object($inst)) {
                    if (method_exists($inst, 'getConnection')) {
                        $pdo = $inst->getConnection();
                        if ($pdo instanceof \PDO) return $pdo;
                    }
                    if (property_exists($inst, 'pdo') && $inst->pdo instanceof \PDO) {
                        return $inst->pdo;
                    }
                }
            }
            if (property_exists($Db, 'pdo') && isset($Db::$pdo) && $Db::$pdo instanceof \PDO) {
                return $Db::$pdo;
            }
        }

        // 3) Intenta obtener desde App\Core\Model
        $Model = '\App\Core\Model';
        if (class_exists($Model)) {
            if (method_exists($Model, 'pdo')) {
                $pdo = $Model::pdo();
                if ($pdo instanceof \PDO) return $pdo;
            }
            if (method_exists($Model, 'getPDO')) {
                $pdo = $Model::getPDO();
                if ($pdo instanceof \PDO) return $pdo;
            }
            if (property_exists($Model, 'pdo') && isset($Model::$pdo) && $Model::$pdo instanceof \PDO) {
                return $Model::$pdo;
            }
        }

        // 4) Intenta función global db()
        if (function_exists('db')) {
            $pdo = db();
            if ($pdo instanceof \PDO) return $pdo;
        }

        // 5) Como último recurso usa constantes de configuración
        if (defined('DB_HOST') && defined('DB_NAME') && defined('DB_USER')) {
            $dsn  = defined('DB_DSN') ? DB_DSN : ('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4');
            $pass = defined('DB_PASS') ? DB_PASS : '';
            return new \PDO($dsn, DB_USER, $pass, [
                \PDO::ATTR_ERRMODE            => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
            ]);
        }

        // Si no pudo obtener nada, lanza excepción
        throw new \RuntimeException('No pude obtener una conexión PDO.');
    }

    /**
     * Obtiene el ID del usuario actual de diferentes formas.
     * Revisa Auth, objetos en sesión o devuelve null si no encuentra.
     */
    private function currentUserId(): ?int
    {
        // 1) Si existe clase Auth y su método user()
        if (class_exists('\App\Core\Auth')) {
            try {
                $auth = new \App\Core\Auth();
                if (method_exists($auth, 'user')) {
                    $u = $auth->user();
                    if (is_array($u)) {
                        if (isset($u['user_id']) && is_numeric($u['user_id'])) return (int)$u['user_id'];
                        if (isset($u['id'])      && is_numeric($u['id']))      return (int)$u['id'];
                    } elseif (is_object($u)) {
                        if (isset($u->user_id) && is_numeric($u->user_id)) return (int)$u->user_id;
                        if (isset($u->id)      && is_numeric($u->id))      return (int)$u->id;
                    }
                }
            } catch (\Throwable $e) {}
        }

        // 2) Si existe usuario en sesión
        if (!empty($_SESSION['user']['user_id'])) return (int)$_SESSION['user']['user_id'];
        if (!empty($_SESSION['user']['id']))      return (int)$_SESSION['user']['id'];

        // 3) No hay usuario
        return null;
    }

    /**
     * POST /api/rate/simple
     * Cicla la calificación de un post en la tabla post_ratings:
     * 1 → 2 → 3 → 4 → 5 → vuelve a 1.
     */
    public function rateSimple(): void
    {
        // ID del post recibido por POST
        $postId = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        if ($postId <= 0) { $this->redirectBack(); }

        // ID del usuario actual
        $userId = $this->currentUserId();
        if (!$userId) { $this->redirectBack(); }

        try {
            $pdo = $this->pdo();

            // Verificar si ya tiene un rating previo
            $sel = $pdo->prepare("SELECT rating FROM post_ratings WHERE post_id = ? AND user_id = ? LIMIT 1");
            $sel->execute([$postId, $userId]);
            $row = $sel->fetch();

            // Rating actual
            $curr = isset($row['rating']) ? (int)$row['rating'] : 0;
            if ($curr < 1 || $curr > 5) $curr = 0;

            // Calcula siguiente valor de rating
            $next = ($curr >= 5) ? 1 : ($curr + 1);

            // Si ya existía, actualiza
            if ($row) {
                $upd = $pdo->prepare("UPDATE post_ratings SET rating = ?, updated_at = CURRENT_TIMESTAMP WHERE post_id = ? AND user_id = ?");
                $upd->execute([$next, $postId, $userId]);
            } else {
                // Si no existía, inserta
                $ins = $pdo->prepare("INSERT INTO post_ratings (post_id, user_id, rating) VALUES (?, ?, ?)");
                $ins->execute([$postId, $userId, $next]);
            }
        } catch (\Throwable $e) {
            // Registra errores en log
            error_log('rateSimple error: '.$e->getMessage());
        }

        // Redirige de vuelta a la página anterior
        $this->redirectBack();
    }

    /**
     * Redirige al usuario a la página anterior (HTTP_REFERER)
     * o al listado de posts si no existe.
     */
    private function redirectBack(): void
    {
        $back = $_SERVER['HTTP_REFERER'] ?? '/post';
        header('Location: '.$back);
        exit;
    }
}


