<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Minuevo;

class DashboardController extends Controller
{
    private \PDO $pdo; // Conexión a la base de datos

    public function __construct()
    {
        // Llama al constructor del padre si existe
        if (method_exists('App\Core\Controller', '__construct')) {
            parent::__construct();
        }

        // Asegura que la sesión esté iniciada
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

        // Configura la conexión PDO
        $this->pdo = Database::getConnection();
        $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC);
        $this->pdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);
    }

    /**
     * GET /dashboard
     * Muestra el panel del usuario logueado con sus publicaciones
     */
    public function index()
    {
        // 1) Obtiene el usuario actual, si no existe redirige a login
        $user = $this->currentUser();
        if (!$user) {
            return $this->redirect('/login');
        }

        // 2) Carga publicaciones del usuario con paginado
        $minuevo = new Minuevo($this->pdo);
        $page    = max(1, (int)($_GET['mp'] ?? 1)); // Página actual
        $perPage = 6;                               // Cantidad de posts por página
        $offset  = ($page - 1) * $perPage;          // Desde qué registro empezar

        // Posts del usuario y total
        $mine  = $minuevo->byUser($user['user_id'], $perPage, $offset);
        $total = $minuevo->countByUser($user['user_id']);

        // Genera slug amigable para cada post
        foreach ($mine as &$p) {
            $p['slug'] = $this->slugify($p['title']) . '-' . (int)$p['post_id'];
        }

        // Renderiza la vista dashboard/index con datos
        return $this->view('dashboard/index', [
            'user'     => $user,
            'my_posts' => $mine,
            'my_posts_pagination' => [
                'page'    => $page,
                'perPage' => $perPage,
                'total'   => $total,
                'hasPrev' => $page > 1,
                'hasNext' => ($offset + count($mine)) < $total,
            ],
        ]);
    }

    /* ---------------- utilidades ---------------- */

    // Obtiene el usuario actual desde sesión o base de datos
    private function currentUser(): ?array
    {
        $cand = null;

        // Intenta primero en auth->user, luego en user directo
        if (!empty($_SESSION['auth']['check']) && !empty($_SESSION['auth']['user'])) {
            $cand = $_SESSION['auth']['user'];
        } elseif (!empty($_SESSION['user'])) {
            $cand = $_SESSION['user'];
        }

        // Convierte a array si es objeto
        if (is_object($cand)) $cand = (array)$cand;
        if (!is_array($cand)) $cand = [];

        // Determina ID del usuario
        $id = $cand['user_id'] ?? $cand['id'] ?? null;

        // Si no hay ID, intenta resolver con email o username
        if (!$id && (!empty($cand['email']) || !empty($cand['username']))) {
            $st = $this->pdo->prepare("SELECT user_id, username, email, created_at
                                       FROM Users
                                       WHERE email = :email OR username = :username
                                       LIMIT 1");
            $st->execute([
                ':email'    => $cand['email']    ?? '',
                ':username' => $cand['username'] ?? '',
            ]);
            $row = $st->fetch();
            if ($row) {
                $id = (int)$row['user_id'];
                $cand = array_merge($row, $cand); // Fusiona datos
            }
        }

        if (!$id) return null;

        // Normaliza datos desde DB
        $st = $this->pdo->prepare("SELECT user_id, username, email, created_at
                                   FROM Users WHERE user_id = :id");
        $st->execute([':id' => $id]);
        $row = $st->fetch();
        if (!$row) return null;

        return [
            'user_id'    => (int)$row['user_id'],
            'username'   => (string)$row['username'],
            'email'      => (string)$row['email'],
            'created_at' => (string)$row['created_at'],
        ];
    }

    // Convierte un texto en slug amigable para URLs
    private function slugify(string $text): string
    {
        $text = trim($text);
        $text = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text) ?: $text;
        $text = strtolower($text);
        $text = preg_replace('/[^a-z0-9]+/i', '-', $text);
        $text = trim($text, '-');
        return $text ?: 'post';
    }

    /* ===== fallbacks si el Controller base no los trae ===== */

    // Renderiza una vista
    public function view($template, $data = [])
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent, 'view')) {
            return parent::view($template, $data);
        }
        $templateName = is_string($template) ? $template : (is_array($template) ? '[array]' : strval($template));
        $base = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__, 2);
        $file = $base . '/app/Views/' . ltrim($templateName, '/') . '.php';
        if (!is_file($file)) {
            http_response_code(500);
            echo "<h1>Vista no encontrada</h1><p>" . htmlspecialchars($templateName, ENT_QUOTES, 'UTF-8') . ".php</p>";
            return null;
        }
        extract(is_array($data) ? $data : [], EXTR_SKIP);
        ob_start(); include $file; $out = ob_get_clean(); echo $out;
        return null;
    }

    // Redirige a otra ruta
    public function redirect($url)
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent, 'redirect')) {
            return parent::redirect($url);
        }
        if (is_array($url)) {
            $path=''; $query=[];
            if (isset($url['path'])) $path=(string)$url['path'];
            elseif (isset($url[0]))  $path=(string)$url[0];
            if (isset($url['query']) && is_array($url['query'])) $query=$url['query'];
            elseif (isset($url[1]) && is_array($url[1]))         $query=$url[1];
            $url = $path . ($query ? ('?' . http_build_query($query)) : '');
        } else {
            $url = (string)$url;
        }
        header('Location: '.$url); exit;
    }

    // Maneja mensajes flash en sesión
    public function flash($key, $message)
    {
        $parent = get_parent_class($this) ?: '';
        if ($parent && method_exists($parent, 'flash')) {
            return parent::flash($key, $message);
        }
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        $_SESSION['flash'][$key] = $message;
        return null;
    }
}

