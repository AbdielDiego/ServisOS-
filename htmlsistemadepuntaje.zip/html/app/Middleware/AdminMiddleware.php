<?php
namespace App\Middleware;

use App\Core\Middleware;

class AdminMiddleware extends Middleware {
    /**
     * Verifica que el usuario esté autenticado y tenga rol Admin.
     * Acepta rol_name/rol = 'Admin' o rol_id = 1.
     * Si no lo está o no es admin, redirige con mensaje.
     */
    public function handle() {
        // Debe estar logueado
        if (!$this->auth->check()) {
            $this->session->flash('error', 'ERROR debe registrarse o iniciar seccion.');
            $this->redirect('/login');
        }

        // Obtener usuario y derivar rol
        $user  = $this->auth->user();
        $rol   = $user['rol_name'] ?? ($user['rol'] ?? ($_SESSION['rol'] ?? 'User'));
        $rolId = isset($user['rol_id']) ? (int)$user['rol_id'] : 0;

        // Reglas para Admin:
        // - rol_name/rol == 'Admin' (case-insensitive)  O  rol_id == 1
        $isAdminByName = (strtolower((string)$rol) === 'admin');
        $isAdminById   = ($rolId === 1);

        if (!$isAdminByName && !$isAdminById) {
            $this->session->flash('error', 'Acceso denegado: se requiere rol Admin.');
            $this->redirect('/');
        }
    }
}


