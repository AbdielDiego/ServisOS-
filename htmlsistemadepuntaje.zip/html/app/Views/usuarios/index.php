<?php
/** @var array $datosTabla  Lista de usuarios */
?>
<section class="users-page">
  <h1 class="page-title">Usuarios</h1>

  <?php if (empty($datosTabla)): ?>
    <h2 class="empty-state">No hay usuarios</h2>
  <?php else: ?>
    <?php 
      // Reutilizamos tu componente de tabla, sin <link> internos
      $tb = BASE_PATH . "/app/Views/components/tabla_usuarios.php";
     
      // Asegúrate de tener $datosTabla definido antes de requerir
      require $tb;
    ?>
  <?php endif; ?>
</section>

