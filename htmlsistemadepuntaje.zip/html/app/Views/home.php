<!-- Título dinámico con fallback -->
<h1><?= htmlspecialchars($title ?? 'Chivita Recomienda', ENT_QUOTES, 'UTF-8') ?></h1>

<!-- Descripción introductoria -->
<p>Opiniones bien útiles sobre servicios de usuarios</p>

<?php if (!empty($auth['check'])): ?>
  <!-- Si el usuario está logueado -->
  <p>Bienvenido <?= htmlspecialchars($auth['user']['username'] ?? '', ENT_QUOTES, 'UTF-8') ?></p>
<?php else: ?>
  <!-- Si NO está logueado -->
  <p>Haz clic aquí para iniciar sesión <a href="/login">inicia sesión</a> y acceder a tu dashboard.</p>
  <p>Haz clic aquí para crearte una cuenta <a href="/register">registrarse</a> y comenzar tu aventura.</p>
<?php endif; ?>

<?php
// Galería de imágenes
// Si existe el sistema de componentes, usarlo
if (method_exists($this, 'component')) {
    $this->component('gallery');
} else {
    // Fallback: incluir manualmente el archivo de la galería
    $gal = BASE_PATH . '/app/Views/components/gallery.php';
    if (file_exists($gal)) include $gal;
}
?>


