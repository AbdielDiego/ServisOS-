 <link rel="stylesheet" href="css/styles.css">
<?php
echo "<h1>$titulo</h1>";

require BASE_PATH ."/app/Views/components/tabla.php";

