 <link rel="stylesheet" href="css/styles.css">
    <h2>Iniciar sesión</h2>

    <form method="POST" style="max-width: 300px;">
        <div>
            <label>Email:</label>
            <input type="email" name="email" required value="">
            <small>Ingrese su email </small>
        </div>
        
        <div>
            <label>Contraseña:</label>
            <input type="password" name="password" required value="">
            <small> Ingrese su contraseña </small>
        </div>
        
        <button type="submit">Ingresar</button>
    </form>

