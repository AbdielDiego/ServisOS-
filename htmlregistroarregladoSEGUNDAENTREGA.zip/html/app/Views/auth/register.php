<?php
// app/Views/auth/register.php

// Asegura variables para evitar notices
$errors = $errors ?? [];
$input  = $input  ?? [];
$title  = $title  ?? 'Registro de Usuario';
?>


<h2><?= $this->e($title) ?></h2>
 <link rel="stylesheet" href="css/styles.css">
 


<!-- Flash SOLO en la página de registro -->
<?php require __DIR__ . '/../components/flash-messages.php'; ?>

<form method="POST" action="/register" style="max-width: 400px;" novalidate>
    <div>
        <label for="name">Nombre:</label>
        <input
            type="text"
            id="name"
            name="name"
            required
            value="<?= $this->e($input['name'] ?? '') ?>"
        >
        <?php if (!empty($errors['name'])): ?>
            <small class="error"><?= $this->e($errors['name']) ?></small>
        <?php endif; ?>
    </div>
    
    <div>
        <label for="email">Email:</label>
        <input
            type="email"
            id="email"
            name="email"
            required
            value="<?= $this->e($input['email'] ?? '') ?>"
        >
        <?php if (!empty($errors['email'])): ?>
            <small class="error"><?= $this->e($errors['email']) ?></small>
        <?php endif; ?>
    </div>
    
    <div>
        <label for="password">Contraseña:</label>
        <input
            type="password"
            id="password"
            name="password"
            required
        >
        <?php if (!empty($errors['password'])): ?>
            <small class="error"><?= $this->e($errors['password']) ?></small>
        <?php endif; ?>
    </div>
    
    <div>
        <label for="password_confirm">Confirmar Contraseña:</label>
        <input
            type="password"
            id="password_confirm"
            name="password_confirm"
            required
        >
        <?php if (!empty($errors['password_confirm'])): ?>
            <small class="error"><?= $this->e($errors['password_confirm']) ?></small>
        <?php endif; ?>
    </div>
    
    <button type="submit">Registrarse</button>
</form>

<p>¿Ya tienes una cuenta? <a href="/login">Inicia sesión</a></p>



