<?php

namespace App\Controllers;
use App\Core\Controller;
use App\Models\Api;

class ApiController extends Controller{

	 private $modelo;		

    public function __construct(){
		$this->modelo = new Api();
		parent::__construct();
	}

public function index() {

    
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && (isset($_GET['nombre']) || isset($_GET['estado']))) {
        $filtros = [];

        if (!empty($_GET['nombre'])) {
            $nombre = addslashes($_GET['nombre']); // protección básica
            $filtros[] = "nombre LIKE '%{$nombre}%'";
        }

        if (!empty($_GET['estado'])) {
            $estado = addslashes($_GET['estado']);
            $filtros[] = "estado = '{$estado}'";
        }

        $sql = "SELECT * FROM categorias";
        if (!empty($filtros)) {
            $sql .= " WHERE " . implode(" AND ", $filtros);
        }

        $datos = $this->modelo->executeRawQuery($sql);
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'success',
            'message' => 'Datos filtrados obtenidos correctamente.',
            'data' => $datos
        ]);
        exit();
    }
    

    if (isset($_POST["miDato"])) {
        $miDato = $_POST["miDato"];
        header('Content-Type: application/json');

        $datos = $this->modelo->find(["name" => $miDato]);

        if (isset($datos["name"])) {
            $sql = sprintf("SELECT * FROM Posts WHERE category_id = %s", $datos["category_id"]);
            $datos = $this->modelo->executeRawQuery($sql);
        } else {
            $datos = [
                ["name" => "No existe la categoria"]
            ];
        }

        $response = [
            'status' => 'success',
            'message' => 'Datos obtenidos correctamente.',
            'data' => [$datos]
        ];

        echo json_encode($response);
        exit();
    } else {
        $datos = $this->modelo->all();
        $this->render("api/index", ["titulo" => "Categorias: Mostrar Articulos", "datosTabla" => $datos]);
    } } }
