<?php
namespace App\Core;

use App\Models\User;

/**
 * Wrapper de autenticación para vistas/middleware.
 * Alineado con la clave canónica 'auth_user_id' que usa AuthService.
 */
class Auth
{
    protected $session;
    protected $userModel;
    protected $sessionKey = 'auth_user_id';

    public function __construct(Session $session = null)
    {
        $this->session   = $session ?: Container::get('session');
        $this->userModel = new User();
    }

    /**
     * ¿Hay usuario autenticado?
     */
    public function check(): bool
    {
        return $this->session->has($this->sessionKey);
    }

    /**
     * Devuelve el usuario actual desde BD (o null si no hay sesión).
     */
    public function user(): ?array
    {
        if (!$this->check()) {
            return null;
        }
        $id = $this->session->get($this->sessionKey);
        // Model::find espera un array de condiciones (columna => valor)
        return $this->userModel->find(['user_id' => $id]);
    }

    /**
     * Cerrar sesión de forma canónica.
     */
    public function logout(): void
    {
        $this->session->remove($this->sessionKey);
        // Limpieza opcional de extras usados en UI
        $this->session->remove('username');
        $this->session->remove('rol');
    }
}

