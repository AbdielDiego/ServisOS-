<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Post;
use App\Models\Comment;

class PostController extends Controller
{
    /** @var Post */
    private $modelo;
    /** @var Comment */
    private $comment;

    public function __construct()
    {
        parent::__construct();
        $this->modelo  = $this->modelo  ?? new Post();
        $this->comment = $this->comment ?? new Comment();
    }

    /**
     * GET /post
     * GET /post/paginar/:pagina
     */
    public function index(array $params = []): void
    {
        // Página segura (int >= 1)
        $pagina = (int)($params['pagina'] ?? ($_GET['pagina'] ?? 1));
        $pagina = max(1, $pagina);

        // Paginado desde el modelo
        $datos = $this->modelo->sqlPaginado($pagina);

        // Normalización: garantizamos $datos['posts']
        $datos['posts'] = $datos['posts']
            ?? ($datos['items']     ?? null)
            ?? ($datos['rows']      ?? null)
            ?? ($datos['data']      ?? null)
            ?? ($datos['registros'] ?? null)
            ?? [];

        // Datos para la vista
        $datos['baseUrl'] = '/post/paginar';
        $datos['titulo']  = 'Todos los Post ingresados';

        // Render
        $this->render('post/index', $datos);
    }

    /**
     * GET /post/:id/comentar
     * (Opcional: si usás una vista de comentar aparte)
     */
    public function comentar($id)
    {
        $id = (int)$id;

        // Preferí un método explícito si existe:
        if (method_exists($this->modelo, 'findById')) {
            $post = $this->modelo->findById($id);
        } else {
            $post = $this->modelo->find(['post_id' => $id]);
        }

        if (!$post) {
            return $this->redirect('/post');
        }

        // basePath por si la vista arma rutas relativas
        $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
        $basePath   = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
        if ($basePath === '.' || $basePath === '/') { $basePath = ''; }

        return $this->render('post/comentar', [
            'title'    => 'Comentar: ' . ($post['title'] ?? 'Post'),
            'post'     => $post,
            'basePath' => $basePath,
        ]);
    }

    /**
     * GET /post/:id
     * Detalle del post + comentarios (del post correcto).
     */
    public function show($id)
    {
        // El router te pasa :id; lo normalizamos a int.
        $id = is_array($id) ? (int)($id['id'] ?? 0) : (int)$id;
        if ($id <= 0) {
            return $this->redirect('/post');
        }

        // 1) Traer el post por id (usa findById si tu modelo lo tiene)
        if (method_exists($this->modelo, 'findById')) {
            $post = $this->modelo->findById($id);
        } else {
            $post = $this->modelo->find(['post_id' => $id]);
            // fallback prudente si tu find() acepta int
            if (!$post && method_exists($this->modelo, 'find')) {
                $tmp = $this->modelo->find($id);
                if (is_array($tmp)) { $post = $tmp; }
            }
        }

        if (!$post) {
            return $this->redirect('/post');
        }

        // 2) Comentarios del mismo post
        if (method_exists($this->comment, 'findByPostId')) {
            $comments = $this->comment->findByPostId($id);
        } else {
            // Si tu modelo Comment no tiene ese método, añadilo; mientras tanto:
            $comments = [];
        }

        // basePath por si la vista arma rutas relativas
        $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
        $basePath   = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
        if ($basePath === '.' || $basePath === '/') { $basePath = ''; }

        // 3) Render de la vista correcta
        return $this->render('post/show', [
            'title'    => $post['title'] ?? 'Post',
            'post'     => $post,
            'comments' => $comments,
            'basePath' => $basePath,
        ]);
    }
}


