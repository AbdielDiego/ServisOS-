<!-- Enlace a la hoja de estilos específica para esta página -->
<link rel="stylesheet" href="css/homepage.css">

<!-- Título principal -->
<h1>Detalles de Usuario</h1>

<!-- Datos básicos del usuario -->
<p>ID de usuario: <?= $userId ?? 'N/A' ?></p>
<p>Nombre: <?= htmlspecialchars($user['username']) ?></p>
<p>Email: <?= htmlspecialchars($user['email']) ?></p>

<!-- Enlace para regresar al dashboard -->
<p><a href="/dashboard">← Volver al dashboard</a></p>


