 <!-- Enlace a la hoja de estilos -->
<link rel="stylesheet" href="css/styles.css">

<!-- Título principal -->
<h1>Dashboard</h1>

<!-- Mensaje de bienvenida con el nombre de usuario -->
<p>Bienvenid@ a tu área privada, <?= htmlspecialchars($user['username']) ?>.</p>

<!-- Datos básicos del usuario logueado -->
<p>Datos del usuario:</p>
<ul>
    <!-- ID único del usuario -->
    <li>ID del Perfil: <?= $user['user_id'] ?></li>

    <!-- Fecha de creación de la cuenta -->
    <li>Fecha de Creación del perfil: <?= $user['created_at'] ?></li>

    <!-- Nombre de usuario -->
    <li>Nombre de Usuario: <?= $user['username'] ?></li>

    <!-- Email protegido con htmlspecialchars para evitar XSS -->
    <li>Email: <?= htmlspecialchars($user['email']) ?></li>
</ul>

   

