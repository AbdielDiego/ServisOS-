<?php
// === Galería de imágenes ===

// Base pública
$BASE = defined('BASE_URL') ? rtrim(BASE_URL, '') : '';

// Ruta física a /public/imagenes (ajustá si querés usar un subdirectorio)
$projectRoot = dirname(__DIR__, 3); // components → Views → app → raíz
$imgDirDisk  = $projectRoot . '/public/imagenes/galeria/imagenes'; 


// URL base de las imágenes
$imgBaseUrl  = $BASE . '/imagenes/galeria/imagenes';


// Versionado del CSS
$galleryCssPath = $projectRoot . '/public/css/gallery.css';
$galleryCssVer  = @filemtime($galleryCssPath) ?: time();

// Extensiones válidas
$validExt = ['png','jpg','jpeg','gif','webp','svg'];

// Buscar imágenes
$imagenes = [];
if (is_dir($imgDirDisk)) {
    foreach (scandir($imgDirDisk) as $file) {
        if ($file === '.' || $file === '..') continue;
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($ext, $validExt, true)) {
            $imagenes[] = $imgBaseUrl . '/' . rawurlencode($file);
        }
    }
}
?>

<link rel="stylesheet" href="<?= $BASE ?>/css/gallery.css?v=<?= $galleryCssVer ?>">

<section class="users-page">
  <h2 class="page-title">¡Servicios que puedes optener!</h2>

  <?php if (!empty($imagenes)): ?>
    <div class="gallery-grid">
      <?php foreach ($imagenes as $img): ?>
        <div class="gallery-item">
          <img src="<?= htmlspecialchars($img, ENT_QUOTES, 'UTF-8') ?>" alt="Imagen de la galería" />
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <p>No hay imágenes en <code><?= htmlspecialchars($imgDirDisk, ENT_QUOTES, 'UTF-8') ?></code>.</p>
  <?php endif; ?>
</section>

