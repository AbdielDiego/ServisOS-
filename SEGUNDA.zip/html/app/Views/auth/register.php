<?php
// app/Views/auth/register.php

// Inicialización de variables para evitar errores "notice"
$errors = $errors ?? [];
$input  = $input  ?? [];
$title  = $title  ?? 'Registro de Usuario';
?>

<!-- Título de la página -->
<h2><?= $this->e($title) ?></h2>

<!-- Hoja de estilos -->
<link rel="stylesheet" href="css/styles.css">

<!-- Sección de mensajes flash (ej: éxito o error al registrar) -->
<?php require __DIR__ . '/../components/flash-messages.php'; ?>

<!-- Formulario de registro -->
<form method="POST" action="/register" style="max-width: 400px;" novalidate>

    <!-- Campo Nombre -->
    <div>
        <label for="name">Nombre:</label>
        <input
            type="text"
            id="name"
            name="name"
            required
            value="<?= $this->e($input['name'] ?? '') ?>"
        >
        <!-- Mensaje de error en caso de validación fallida -->
        <?php if (!empty($errors['name'])): ?>
            <small class="error"><?= $this->e($errors['name']) ?></small>
        <?php endif; ?>
    </div>
    
    <!-- Campo Email -->
    <div>
        <label for="email">Email:</label>
        <input
            type="email"
            id="email"
            name="email"
            required
            value="<?= $this->e($input['email'] ?? '') ?>"
        >
        <?php if (!empty($errors['email'])): ?>
            <small class="error"><?= $this->e($errors['email']) ?></small>
        <?php endif; ?>
    </div>
    
    <!-- Campo Contraseña -->
    <div>
        <label for="password">Contraseña:</label>
        <input
            type="password"
            id="password"
            name="password"
            required
        >
        <?php if (!empty($errors['password'])): ?>
            <small class="error"><?= $this->e($errors['password']) ?></small>
        <?php endif; ?>
    </div>
    
    <!-- Campo Confirmar Contraseña -->
    <div>
        <label for="password_confirm">Confirmar Contraseña:</label>
        <input
            type="password"
            id="password_confirm"
            name="password_confirm"
            required
        >
        <?php if (!empty($errors['password_confirm'])): ?>
            <small class="error"><?= $this->e($errors['password_confirm']) ?></small>
        <?php endif; ?>
    </div>
    
    <!-- Botón de envío -->
    <button type="submit">Registrarse</button>
</form>

<!-- Enlace a login para usuarios existentes -->
<p>¿Ya tienes una cuenta? <a href="/login">Inicia sesión</a></p>



