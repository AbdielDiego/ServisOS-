<link rel="stylesheet" href="css/styles.css">



<?php

require BASE_PATH . "/app/Views/components/paginar.php";
?>
<td>
  <?php if ($id > 0): ?>
    <!-- Botón "Comentar" (navega al anchor #comentar) -->
    <form action="<?= $basePath ?>/post/<?= (int)$id ?>#comentar" method="get" style="display:inline">
      <button type="submit">Comentar</button>
    </form>

    <!-- Botón "Ver comentarios" (navega al anchor #comentarios) -->
    <form action="<?= $basePath ?>/post/<?= (int)$id ?>#comentarios" method="get" style="display:inline">
      <button type="submit">Ver comentarios</button>
    </form>
  <?php else: ?>
    —
  <?php endif; ?>
</td>

