<?php
// Variables que llegan: $title, $categoria, $posts, $basePath
?>
<section class="users-page">
  <h2 class="page-title">
    <?= htmlspecialchars($title ?? 'Categoría', ENT_QUOTES, 'UTF-8') ?>
  </h2>

  <?php if (!empty($categoria)): ?>
    <p class="muted">ID: <?= (int)$categoria['category_id'] ?> ·
       Nombre: <strong><?= htmlspecialchars($categoria['name'], ENT_QUOTES, 'UTF-8') ?></strong>
    </p>
  <?php endif; ?>

  <?php if (!empty($posts)): ?>
    <div class="table-wrap users-wrap">
      <table class="tabla users-table tabla-compact">
        <thead>
          <tr>
            <th>ID</th>
            <th>Título</th>
            <th>Creado</th>
            <th>Comentarios</th>
            <th style="white-space:nowrap;">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($posts as $p): ?>
            <tr>
              <td><?= (int)$p['post_id'] ?></td>
              <td><?= htmlspecialchars($p['title'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($p['created_at'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= (int)($p['comments_count'] ?? 0) ?></td>
              <td class="td-actions">
                <a class="btn btn-sm" href="<?= $basePath ?>/post/<?= (int)$p['post_id'] ?>">Ver</a>
                <a class="btn btn-sm" href="<?= $basePath ?>/post/<?= (int)$p['post_id'] ?>#comentar">Comentar</a>
                <a class="btn btn-sm" href="<?= $basePath ?>/post/<?= (int)$p['post_id'] ?>#comentarios">Ver comentarios</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- Form rápido para comentar desde la categoría (opcional) -->
    <div id="comentar" style="margin-top:18px;">
      <h3>Comentar un post de esta categoría</h3>
      <form method="post" action="<?= $basePath ?>/categoria/<?= (int)$categoria['category_id'] ?>/comentarios">
        <div>
          <label for="post_id">Post</label>
          <select id="post_id" name="post_id" required>
            <?php foreach ($posts as $p): ?>
              <option value="<?= (int)$p['post_id'] ?>">
                #<?= (int)$p['post_id'] ?> — <?= htmlspecialchars($p['title'], ENT_QUOTES, 'UTF-8') ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label for="comment_text">Comentario</label>
          <textarea id="comment_text" name="comment_text" rows="3" required style="width:100%;"></textarea>
        </div>
        <button type="submit" class="btn">Publicar</button>
      </form>
    </div>

  <?php else: ?>
    <p class="empty-state">No hay posts en esta categoría.</p>
  <?php endif; ?>
</section>

