<!-- Enlace a hoja de estilos -->
<link rel="stylesheet" href="css/styles.css">

<?php
// Contenedor principal de la vista
echo '
       <div class="container">
        <h1>Servicios</h1>
        <p>Aca puedes encontrar todos los servicios </p>

        <!-- Buscador con input y botón -->
        <h2></h2>
        <label for="portinput">Buscar:</label>
        <input type="text" id="postInput" value= >
        <button id="fetchPostData" class="post">Enviar Datos (POST)</button>

        <!-- Contenedor donde se mostrará el resultado del POST -->
        <div id="postResult" class="result-box">... ' ;

// Título dinámico
echo "<h2>$titulo</h2>";    

// Incluir tabla de servicios (componente separado)
require BASE_PATH ."/app/Views/components/tabla_servicios.php"; 

// Cierre de contenedor
echo '</div>
	</div>

    <!-- Script JS para manejar API -->
    <script src="js/api.js"></script>';

