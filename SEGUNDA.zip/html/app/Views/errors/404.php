 <link rel="stylesheet" href="css/styles.css">
 <div style="text-align: center; margin-top: 50px;">
        <h1>404 - Página no encontrada</h1>
        <p>Lo sentimos, la página que buscas no existe.</p>
        <a href="/" style="display: inline-block; margin-top: 20px; padding: 10px 20px; background: #333; color: white; text-decoration: none;">Volver al inicio</a>
    </div>

