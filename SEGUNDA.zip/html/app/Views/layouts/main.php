<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  
  <!-- Título dinámico -->
  <title><?= htmlspecialchars($title ?? 'Chivita Recomienda', ENT_QUOTES, 'UTF-8') ?></title>

  <?php
    // Definir base URL
    $BASE = defined('BASE_URL') ? rtrim(BASE_URL, '') : '';

    // Versionado de CSS principal (cache-busting con filemtime)
    $cssMainPath = __DIR__ . '/../../public/css/styles.css';
    $cssMainVer  = @filemtime($cssMainPath) ?: time();

    // Versionado de CSS del user-corner
    $cssUCPath = __DIR__ . '/../../public/css/user-corner.css';
    $cssUCVer  = @filemtime($cssUCPath) ?: $cssMainVer;
  ?>

  <!-- CSS de user-corner con control de versión -->
  <link rel="stylesheet" href="<?= $BASE ?>/css/user-corner.css?v=<?= $cssUCVer ?>" />
  <!-- CSS principal con control de versión -->
  <link rel="stylesheet" href="<?= $BASE ?>/css/styles.css?v=<?= $cssMainVer ?>" />
</head>

<body class="theme-clean">
  <!-- Encabezado con navegación -->
  <header>
    <?php $this->component('navigation') ?>
  </header>

  <!-- Contenedor principal -->
  <main class="container">
    <!-- Mensajes flash (éxito/error) -->
    <?php $this->component('flash-messages') ?>
    
    <!-- Contenido dinámico de cada vista -->
    <?= $content ?>
  </main>

  <!-- Esquina de usuario (info sesión activa) -->
  <?php $this->component('user-corner') ?>
  
</body>
</html>


