<?php
use App\Middleware\AuthMiddleware;
use App\Middleware\AdminMiddleware;

// =======================
// Rutas públicas
// =======================
$router->addRoute('GET',  '/',               'HomeController@index');
$router->addRoute('GET',  '/apicategorias',  'ApiController@index');
$router->addRoute('POST', '/apicategorias',  'ApiController@index');

$router->addRoute('GET',  '/login',          'AuthController@showLogin');
$router->addRoute('POST', '/login',          'AuthController@login');
$router->addRoute('GET',  '/logout',         'AuthController@logout');
$router->addRoute('GET',  '/register',       'AuthController@showRegister');
$router->addRoute('POST', '/register',       'AuthController@register');

// =======================
// Posts
// =======================
$router->addRoute('GET', '/post',                  'PostController@index', [AuthMiddleware::class]);
$router->addRoute('GET', '/post/paginar/:pagina',  'PostController@index', [AuthMiddleware::class]);
$router->addRoute('GET', '/post/:id',              'PostController@show',  [AuthMiddleware::class]);

// =======================
// Categorías (nuevo)
// =======================
// Ver una categoría y sus posts (público)
$router->addRoute('GET',  '/categoria/:id',             'CategoriaController@show');
// Crear comentario dentro de una categoría (requiere login)
$router->addRoute('POST', '/categoria/:id/comentarios', 'CategoriaController@storeComment', [AuthMiddleware::class]);

// =======================
// Comentarios (sobre posts)
// =======================
$router->addRoute('POST', '/comments',           'CommentController@store',        [AuthMiddleware::class]);
$router->addRoute('POST', '/posts/:id/comments', 'CommentController@storeForPost', [AuthMiddleware::class]);

// =======================
// Otros
// =======================
$router->addRoute('GET',  '/dashboard',          'DashboardController@index', [AuthMiddleware::class]);
$router->addRoute('GET',  '/dashboard/:id',      'DashboardController@show',  [AuthMiddleware::class]);
$router->addRoute('GET',  '/profile',            'ProfileController@index',   [AuthMiddleware::class]);
$router->addRoute('POST', '/profile',            'ProfileController@update',  [AuthMiddleware::class]);
$router->addRoute('GET',  '/usuarios',           'UsuariosController@index',  [AdminMiddleware::class]);



