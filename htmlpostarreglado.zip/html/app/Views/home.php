   <img src="/imagenes/ChivitaRecomiendaHomeLogo-removebg-preview.png" 
     alt="Chivita Recomienda Logo" 
     class="logo-neon">
     <h1><?= $title ?></h1>
     <link rel="stylesheet" href="/css/homepage.css">

    
    <p> Opiniones bien utiles sobre servicios de usuarios</p>
     
    
    <?php if ($auth['check']): ?>
        <p>Bienvenido <?= htmlspecialchars($auth['user']['username']) ?></p>
    <?php else: ?>
        <p>Por favor <a href="/login">inicia sesión</a> para acceder al dashboard.</p>
    <?php endif; ?>

