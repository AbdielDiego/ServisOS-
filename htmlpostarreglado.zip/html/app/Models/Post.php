<?php
namespace App\Models;

use App\Core\Model;

class Post extends Model {
    // Ajusta si tu DB usa otros nombres:
    protected $table = 'Posts';
    protected $primaryKey = 'post_id';

    /**
     * Paginación robusta: castea y valida tipos.
     * Acepta valores string/mixtos desde la ruta y los convierte a int seguros.
     */
    public function sqlPaginado($pagina = 1, $porPagina = 10): array {
        // Cast seguro
        $pagina    = (int) (is_numeric($pagina) ? $pagina : 1);
        $porPagina = (int) (is_numeric($porPagina) ? $porPagina : 10);

        // Límites mínimos
        $pagina    = max(1, $pagina);
        $porPagina = max(1, $porPagina);

        $offset = ($pagina - 1) * $porPagina;

        $sql = "SELECT SQL_CALC_FOUND_ROWS * 
                FROM {$this->table} 
                ORDER BY {$this->primaryKey} DESC 
                LIMIT {$offset}, {$porPagina}";
        $stmt  = $this->db->query($sql);
        $datos = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $totalRow = $this->db->query("SELECT FOUND_ROWS() AS total")->fetch(\PDO::FETCH_ASSOC);
        $total    = isset($totalRow['total']) ? (int)$totalRow['total'] : 0;
        $totalPaginas = $porPagina > 0 ? (int)ceil($total / $porPagina) : 1;

        return [
            'pagina'       => $pagina,
            'totalPaginas' => $totalPaginas,
            'datosTabla'   => $datos
        ];
    }
}

