<?php 
// Define el espacio de nombres para ubicar correctamente el controlador
namespace App\Controllers;

// Importa la clase base del controlador y el modelo de Servicios
use App\Core\Controller;
use App\Models\Servicios;

// Define el controlador de Servicios que extiende de la clase Controller
class ServiciosController extends Controller {

    // Propiedad privada para manejar el modelo de servicios
    private $modelo;

    // Constructor de la clase
    public function __construct() {
        // Crea una instancia del modelo Servicios
        $this->modelo = new Servicios();

        // Llama al constructor de la clase padre (Controller base)
        parent::__construct();
    }

    // Método principal que se ejecuta al acceder a la ruta de servicios
    public function index() {
        // Captura el parámetro de búsqueda desde la URL, si existe
        $filtro = $_GET['buscar'] ?? null;

        // Si hay filtro, busca por nombre en la base de datos
        if ($filtro) {
            $datos = $this->modelo->buscarPorNombre($filtro);
        } else {
            // Si no hay filtro, muestra todos los servicios
            $datos = $this->modelo->todosLosServicios();
        }

        // Renderiza la vista 'servicios/index' y le pasa los datos
        return $this->render("servicios/index", ["servicios" => $datos]);
    }

    // Método para mostrar un solo servicio según su ID
    public function showServicio($param) {
        // Obtiene el ID desde los parámetros
        $id = $param['id'];

        // Busca el servicio correspondiente en la base de datos
        $datos = $this->modelo->find($id);

        // Renderiza la vista de un solo servicio, pasando los datos encontrados
        return $this->render("servicios/showservicios", ["servicio" => $datos]);
    }
}

