<?php
namespace App\Controllers;

// Importa la clase base Controller y el modelo Empresario
use App\Core\Controller;
use App\Models\Empresario;

// Define el controlador para manejar acciones relacionadas al registro empresarial
class RegistroController extends Controller {

    // Muestra el formulario de registro empresarial
    public function registroEmpresario() {
        // Renderiza la vista "registro_empresario" dentro de la carpeta /registro/
        return $this->render("registro/registro_empresario", [
            "title" => "Registro Empresarial"
        ]);
    }

    // Guarda los datos del formulario en la base de datos
    public function guardarEmpresario() {
        // Captura los datos enviados por el formulario (método POST)
        $data = [
            'representante' => $_POST['nombre_representante'],
            'empresa' => $_POST['nombre_empresa'],
            'ruc' => $_POST['ruc_cif'],
            'telefono' => $_POST['telefono'],
            'direccion' => $_POST['direccion'],
            'sector' => $_POST['sector'],
            'sitio_web' => $_POST['sitio_web'],
            'logo' => '', // Campo reservado para futura implementación de carga de logo
            'email' => $_POST['email'],
            // Se guarda la contraseña cifrada para seguridad
            'password' => password_hash($_POST['password'], PASSWORD_DEFAULT)
        ];

        // Instancia del modelo Empresario
        $modelo = new Empresario();

        // Guarda los datos en la base de datos
        $modelo->guardar($data);

        // Redirige a la página de inicio después del guardado
        $this->redirect('/');
    }

    // Muestra la lista de empresarios registrados en una vista
    public function showRegistro() {
        // Crea una instancia del modelo Empresario
        $modelo = new \App\Models\Empresario();

        // Obtiene todos los registros de empresarios desde la base de datos
        $empresarios = $modelo->all();

        // Renderiza la vista 'showRegistro' y pasa los datos obtenidos
        return $this->render('registro/showRegistro', [
            'title' => 'Empresarios Registrados',
            'empresarios' => $empresarios
        ]);
    }
}

