<?php

namespace App\Models;

class Model {

	private $con; // Conexión a la base de datos

	// Constructor: establece conexión con la base de datos usando PDO
	public function __construct(){
	
		$dsn = 'mysql:host=localhost;dbname=proyutu'; // Dirección del servidor y nombre de base de datos
		$user = 'proyutu'; // Usuario de la base de datos
		$password = '12345678'; // Contraseña de la base de datos

		try{
			// Se intenta conectar a la base de datos
			$this->con = new \PDO($dsn, $user, $password);
		}catch(Exception $e ){
			// Si hay un error, lo muestra
			echo $e->getMessage();
		}
	}

	// Devuelve todos los usuarios en un array asociativo
	public function userAll(){
		try{
			$stmt = $this->con->query("SELECT * FROM users"); // Ejecuta la consulta
			$result = $stmt->fetchAll(\PDO::FETCH_ASSOC); // Obtiene todos los resultados
		}catch(Exception $e){
			$e->getMessage(); // Captura cualquier error
		}
		return($result);  // Devuelve los datos obtenidos
	}

	// Devuelve un usuario específico por su ID
	public function userId($id){
		try{
			$stmt = $this->con->query("SELECT * FROM users WHERE id = $id"); // Consulta por ID
			$result = $stmt->fetchAll(\PDO::FETCH_ASSOC); // Resultado como array
		}catch(Exception $e){
			$e->getMessage(); // Captura el error
		}
		return($result);  // Devuelve los datos del usuario
	}

	// Verifica si un usuario existe con el email y contraseña dados
	public function checkUser($email,$password){
    	$user = ''; // Inicializa el resultado como cadena vacía

		try{
			// Consulta que busca un usuario por email y contraseña (no recomendado usar así por seguridad)
			$sql = "SELECT username FROM users WHERE email = '".$email. "' and password = '" .$password ."'";
			$stmt = $this->con->query($sql); // Ejecuta la consulta
			$result = $stmt->fetchAll(\PDO::FETCH_ASSOC); // Devuelve el resultado

			// Si encuentra resultado, extrae el username
			if ( $result !== false ){
				$user = $result[0]['username'];
			}
		}catch(Exception $e){
			$e->getMessage(); // Captura errores
		}
		return($user); // Devuelve el nombre de usuario o vacío
	}

	// Guarda (actualiza) los datos de un usuario por ID usando los valores del formulario
	public function userSaveId($id){
		$result = false; // Inicializa el resultado

		try{
			// Prepara el SQL con los datos recibidos por POST (cuidado: no es seguro si no se sanitiza)
			$sql = "UPDATE users set username= '".$_POST['username']."' ,email= '".$_POST['email']."' ,role= '".$_POST['role']. "' where id = ".$id;

			$result = $this->con->exec($sql); // Ejecuta la consulta
		}catch(Exception $e){
			$e->getMessage(); // Captura errores
		}
		return($result); // Devuelve true/false según éxito
	}
}

