<?php
namespace App\Models;

// Importa la clase Database del núcleo del framework
use App\Core\Database;

class Servicios {

    // Propiedad privada para manejar la conexión a la base de datos
    private $db;

    // Constructor: obtiene la instancia única de conexión a la base de datos
    public function __construct() {
        $this->db = Database::getInstance();
    }

    // Método que retorna todos los registros de la tabla 'servicios'
    public function todosLosServicios() {
        $query = "SELECT * FROM servicios"; // Consulta SQL
        return $this->db->query($query)->fetchAll(\PDO::FETCH_ASSOC); // Ejecuta y retorna todos los resultados como array asociativo
    }

    // Método que busca un servicio específico por su ID
    public function find($id) {
        $query = "SELECT * FROM servicios WHERE id = :id"; // Consulta con marcador de parámetro
        return $this->db->query($query, ['id' => $id])->fetch(\PDO::FETCH_ASSOC); // Ejecuta y devuelve un solo resultado
    }

    // Método que busca servicios cuyo nombre coincida parcialmente con el texto ingresado
    public function buscarPorNombre($texto) {
        $sql = "SELECT * FROM servicios WHERE nombre LIKE :nombre"; // Consulta con búsqueda parcial usando LIKE
        $params = ['nombre' => '%' . $texto . '%']; // Parámetro con comodines para búsqueda flexible
        return $this->db->query($sql, $params)->fetchAll(\PDO::FETCH_ASSOC); // Ejecuta y devuelve todos los resultados coincidentes
    }
}




