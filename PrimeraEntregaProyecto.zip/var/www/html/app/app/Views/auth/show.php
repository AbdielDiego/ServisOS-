<html>
	<head>
	</head>
	<body>
		<!-- Muestra el contenido de la variable $titulo como encabezado principal -->
		<h1><?= $titulo ?></h1>

		<!-- Muestra el contenido de la variable $datos usando var_dump() -->
		<!-- Esto imprime información detallada sobre el tipo y valor de la variable -->
		<?php echo var_dump($datos); ?>

	</body>
</html>

