<html>
	<head>
	</head>
	<body>
		<!-- Mostramos el título en pantalla usando PHP corto -->
		<h1><?= $titulo ?></h1>

		<!-- Mostramos el contenido de la variable $datos -->
		<?php echo var_dump($datos); ?>

	</body>
</html>

