<html>
	<head>
		<!-- Aquí podrías agregar metadatos o estilos si fueran necesarios -->
	</head>
	<body>

		<!-- Título dinámico pasado desde el controlador -->
		<h1><?= $titulo ?></h1>

		<!-- Extrae las variables del primer registro en el array $datos -->
		<?php $dat = extract($datos[0]); ?>
		<!-- Ahora podés usar directamente $id, $username, $email, $role -->

		<!-- Formulario de edición de usuario -->
		<!-- Se envía mediante POST a la ruta /save/id/[id_actual] -->
		<form method="post" action="/save/id/<?=$id?>">

			<!-- Campo de ID (solo lectura) -->
			<label for="id">ID:</label><br>
			<input type="text" id="id" name="id" value="<?=$id?>" readonly><br><br>

			<!-- Campo para editar el nombre de usuario -->
			<label for="name">Nombre de usuario:</label><br>
			<input type="text" id="username" name="username" value="<?=$username?>"><br><br>

			<!-- Campo para editar el correo electrónico -->
			<label for="email">Email:</label><br>
			<input type="email" id="email" name="email" value="<?=$email?>"><br><br>

			<!-- Campo para editar el rol del usuario -->
			<label for="password">Role:</label><br>
			<input type="role" id="role" name="role" value="<?=$role?>"><br><br>

			<!-- Botón para enviar el formulario -->
			<input type="submit" value="Enviar">
		</form>

	</body>
</html>

