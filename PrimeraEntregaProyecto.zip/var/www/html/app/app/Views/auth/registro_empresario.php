<?php

?>
<div class="form-container" style="position: fixed; top: 80px; right: 20px; z-index: 999;">
    <h1 class="form-title">Registro para Empresarios</h1>

    <form>
        <!-- Nombre del representante legal de la empresa -->
        <div class="form-group">
            <label class="form-label" for="nombre-representante">Nombre del representante:</label>
            <input type="text" id="nombre-representante" class="form-input">
        </div>

        <!-- Nombre oficial de la empresa -->
        <div class="form-group">
            <label class="form-label" for="nombre-empresa">Nombre de la empresa:</label>
            <input type="text" id="nombre-empresa" class="form-input">
        </div>

        <!-- RUC o CIF para identificar fiscalmente a la empresa -->
        <div class="form-group">
            <label class="form-label" for="ruc-cif">RUC / CIF:</label>
            <input type="text" id="ruc-cif" class="form-input">
        </div>

        <!-- Teléfono de contacto, en formato "tel" para móvil y validación básica -->
        <div class="form-group">
            <label class="form-label" for="telefono">Teléfono de contacto:</label>
            <input type="tel" id="telefono" class="form-input">
        </div>

        <!-- Dirección física o legal de la empresa -->
        <div class="form-group">
            <label class="form-label" for="direccion">Dirección:</label>
            <input type="text" id="direccion" class="form-input">
        </div>

        <!-- Sector o rubro donde opera la empresa -->
        <div class="form-group">
            <label class="form-label" for="sector">Sector / Rubro:</label>
            <input type="text" id="sector" class="form-input">
        </div>

        <!-- Sitio web oficial, input tipo URL con placeholder para guiar -->
        <div class="form-group">
            <label class="form-label" for="sitio-web">Sitio web:</label>
            <input type="url" id="sitio-web" class="form-input website-placeholder" placeholder="https://ejemplo.com">
        </div>

        <!-- Selector personalizado para subir el logo de la empresa -->
        <div class="form-group">
            <label class="form-label" for="logo">Logo de la empresa:</label>
            <div class="file-input-container">
                <!-- Input file oculto, se activa con botón -->
                <input type="file" id="logo" accept="image/*" style="display: none;">
                <button type="button" class="file-input" onclick="document.getElementById('logo').click();">
                    Elegir archivo
                </button>
                <!-- Aquí se muestra el nombre del archivo elegido -->
                <span class="file-text">No se ha seleccionado ningún archivo</span>
            </div>
        </div>

        <!-- Email para contacto o login -->
        <div class="form-group">
            <label class="form-label" for="email">Correo electrónico:</label>
            <input type="email" id="email" class="form-input">
        </div>

        <!-- Contraseña para la cuenta del empresario -->
        <div class="form-group">
            <label class="form-label" for="password">Contraseña:</label>
            <input type="password" id="password" class="form-input">
        </div>

        <!-- Botón para enviar el formulario -->
        <button type="submit" class="submit-btn">Registrarse como Empresario</button>
    </form>
</div>

<script>
    // Actualiza el texto que muestra el nombre del archivo cuando cambias la selección
    document.getElementById('logo').addEventListener('change', function(e) {
        const fileText = document.querySelector('.file-text');
        fileText.textContent = e.target.files.length > 0 ? e.target.files[0].name : 'No se ha seleccionado ningún archivo';
    });

    // Captura el envío del formulario para evitar recarga y mostrar alert (demo)
    document.querySelector('form').addEventListener('submit', function(e) {
        e.preventDefault(); // ¡No te vayas, que esto es demo!
        alert('Formulario enviado (esto es solo una demostración)');
    });
</script>

<style>
    /* Estilos generales para que el formulario se vea moderno y ordenado */
    .form-container {
        background-color: white; /* Fondo blanco para contraste */
        padding: 30px;
        border-radius: 8px; /* Bordes redondeados para suavizar */
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Sombra sutil para destacar */
        width: 100%;
        max-width: 400px; /* Tamaño máximo para que no quede gigante */
    }
    .form-title {
        font-size: 18px;
        font-weight: bold;
        text-align: center;
        margin-bottom: 25px;
        color: #333; /* Color gris oscuro para buen contraste */
    }
    .form-group {
        margin-bottom: 15px; /* Espacio entre campos */
    }
    .form-label {
        display: block;
        font-size: 14px;
        color: #333;
        margin-bottom: 5px;
        font-weight: normal;
    }
    .form-input {
        width: 100%;
        padding: 8px 12px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 14px;
        background-color: #fff;
        transition: border-color 0.3s ease;
    }
    .form-input:focus {
        outline: none;
        border-color: #007bff; /* Azul al enfocarse, cool y profesional */
    }
    .file-input-container {
        display: flex;
        align-items: center;
        gap: 10px; /* Espacio entre botón y texto */
    }
    .file-input {
        padding: 6px 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        background-color: #f8f9fa;
        font-size: 12px;
        cursor: pointer;
    }
    .file-input:hover {
        background-color: #e9ecef; /* Cambio suave al pasar mouse */
    }
    .file-text {
        font-size: 12px;
        color: #666; /* Texto gris para no robar protagonismo */
    }
    .submit-btn {
        width: 100%;
        padding: 12px;
        background-color: #007bff; /* Azul fuerte, botón destacado */
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer;
        margin-top: 10px;
        transition: background-color 0.3s ease;
    }
    .submit-btn:hover {
        background-color: #0056b3; /* Azul más oscuro al pasar mouse */
    }
    .website-placeholder {
        color: #999; /* Color gris tenue para el placeholder */
    }
</style>

<?php
// FIN del formulario y estilos. Por ahora solo UI, sin backend ni validaciones reales.
// Para hacerlo funcional, habría que:
// - Agregar name="" a los inputs para enviar datos por POST
// - Procesar en PHP el POST para guardar en base de datos o enviar mail
// - Validar campos, manejar carga de imagen, seguridad, etc.

// Pero por ahora, ¡este formulario está listo para que lo veas y disfrutes!
// ¡Ya casi sos el Tony Stark del desarrollo web!
?>

