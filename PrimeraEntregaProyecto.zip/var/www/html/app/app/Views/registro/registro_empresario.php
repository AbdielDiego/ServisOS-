<?php
// Este archivo muestra un formulario de registro para empresarios
// El formulario se muestra en una tarjeta flotante, fija en la esquina superior derecha
?>

<!-- Contenedor del formulario flotante -->
<div class="form-container" style="position: fixed; top: 80px; right: 20px; z-index: 999;">
    <!-- Título del formulario -->
    <h1 class="form-title">Registro para Empresarios</h1>

    <!-- Formulario que se enviará al backend por método POST -->
    <form method="POST" action="/registro/guardar" enctype="multipart/form-data">
        <!-- Campo: Nombre del representante -->
        <div class="form-group">
            <label class="form-label" for="nombre-representante">Nombre del representante:</label>
            <input type="text" name="nombre-representante" class="form-input">
        </div>

        <!-- Campo: Nombre de la empresa -->
        <div class="form-group">
            <label class="form-label" for="nombre-empresa">Nombre de la empresa:</label>
            <input type="text" name="nombre-empresa" class="form-input">
        </div>

        <!-- Campo: RUC / CIF de la empresa -->
        <div class="form-group">
            <label class="form-label" for="ruc-cif">RUC / CIF:</label>
            <input type="text" name="ruc-cif" class="form-input">
        </div>

        <!-- Campo: Teléfono de contacto -->
        <div class="form-group">
            <label class="form-label" for="telefono">Teléfono de contacto:</label>
            <input type="tel" name="telefono" class="form-input">
        </div>

        <!-- Campo: Dirección -->
        <div class="form-group">
            <label class="form-label" for="direccion">Dirección:</label>
            <input type="text" name="direccion" class="form-input">
        </div>

        <!-- Campo: Sector o rubro de la empresa -->
        <div class="form-group">
            <label class="form-label" for="sector">Sector / Rubro:</label>
            <input type="text" name="sector" class="form-input">
        </div>

        <!-- Campo: Sitio web -->
        <div class="form-group">
            <label class="form-label" for="sitio-web">Sitio web:</label>
            <input type="url" name="sitio-web" class="form-input website-placeholder" placeholder="https://ejemplo.com">
        </div>

        <!-- Campo: Logo de la empresa (archivo) -->
        <div class="form-group">
            <label class="form-label" for="logo">Logo de la empresa:</label>
            <div class="file-input-container">
                <!-- Input de tipo archivo (oculto) -->
                <input type="file" name="logo" id="logo" accept="image/*" style="display: none;">
                <!-- Botón que dispara el input de archivo -->
                <button type="button" class="file-input" onclick="document.getElementById('logo').click();">
                    Elegir archivo
                </button>
                <!-- Texto que muestra el nombre del archivo seleccionado -->
                <span class="file-text">No se ha seleccionado ningún archivo</span>
            </div>
        </div>

        <!-- Campo: Correo electrónico -->
        <div class="form-group">
            <label class="form-label" for="email">Correo electrónico:</label>
            <input type="email" name="email" class="form-input">
        </div>

        <!-- Campo: Contraseña -->
        <div class="form-group">
            <label class="form-label" for="password">Contraseña:</label>
            <input type="password" name="password" class="form-input">
        </div>

        <!-- Botón para enviar el formulario -->
        <button type="submit" class="submit-btn">Registrarse como Empresario</button>
    </form>
</div>

<!-- Script que actualiza el nombre del archivo seleccionado -->
<script>
    document.getElementById('logo').addEventListener('change', function(e) {
        const fileText = document.querySelector('.file-text');
        fileText.textContent = e.target.files.length > 0
            ? e.target.files[0].name
            : 'No se ha seleccionado ningún archivo';
    });
</script>

<!-- Estilos visuales del formulario -->
<style>
    .form-container {
        background-color: white;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 400px;
    }
    .form-title {
        font-size: 18px;
        font-weight: bold;
        text-align: center;
        margin-bottom: 25px;
        color: #333;
    }
    .form-group {
        margin-bottom: 15px;
    }
    .form-label {
        display: block;
        font-size: 14px;
        color: #333;
        margin-bottom: 5px;
    }
    .form-input {
        width: 100%;
        padding: 8px 12px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 14px;
        background-color: #fff;
        transition: border-color 0.3s ease;
    }
    .form-input:focus {
        outline: none;
        border-color: #007bff;
    }
    .file-input-container {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .file-input {
        padding: 6px 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        background-color: #f8f9fa;
        font-size: 12px;
        cursor: pointer;
    }
    .file-input:hover {
        background-color: #e9ecef;
    }
    .file-text {
        font-size: 12px;
        color: #666;
    }
    .submit-btn {
        width: 100%;
        padding: 12px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer;
        margin-top: 10px;
        transition: background-color 0.3s ease;
    }
    .submit-btn:hover {
        background-color: #0056b3;
    }
    .website-placeholder {
        color: #999;
    }
</style>

