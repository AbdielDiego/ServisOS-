<?php
/**
 * Definición de rutas de la aplicación
 * Formato: $router->addRoute(método, ruta, controlador@método, [middleware])
 */

use App\Middleware\AuthMiddleware; // 🛡️ Middleware de autenticación

// 🟢 Rutas públicas (no requieren estar logueado)
$router->addRoute("GET", "/", "HomeController@index");                      // Página de inicio
$router->addRoute("GET", "/login", "AuthController@showLogin");            // Formulario de login
$router->addRoute("POST", "/login", "AuthController@login");               // Procesar login
$router->addRoute("GET", "/logout", "AuthController@logout");             // Cerrar sesión
$router->addRoute("GET", "/register", "AuthController@showRegister");     // Formulario de registro
$router->addRoute("POST", "/register", "AuthController@register");        // Procesar registro

// 📦 Rutas personalizadas para otros controladores
$router->addRoute("GET", "/minuevo", "MinuevoController@index");          // Nueva página personalizada
$router->addRoute("GET", "/minv/id/:id", "MinuevoController@index");      // Mismo controlador, con ID como parámetro
$router->addRoute("GET", "/clientes", "ClientesController@index");        // Página de clientes

// 🔒 Rutas protegidas (requieren estar autenticado)
$router->addRoute("GET", "/dashboard", "DashboardController@index", [AuthMiddleware::class]);        // Panel principal
$router->addRoute("GET", "/dashboard/:id", "DashboardController@show", [AuthMiddleware::class]);     // Ver un dashboard con ID
$router->addRoute("GET", "/profile", "ProfileController@index", [AuthMiddleware::class]);            // Ver perfil
$router->addRoute("POST", "/profile", "ProfileController@update", [AuthMiddleware::class]);          // Actualizar perfil

