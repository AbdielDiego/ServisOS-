<?php


class View{


	public function render($vista,$dat){
	
		extract($dat);
		include(__DIR__."/$vista/$vista".".php");
	
	}


}

