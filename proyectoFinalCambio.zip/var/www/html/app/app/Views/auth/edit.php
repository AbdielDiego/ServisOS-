<html>
	<head>
	</head>
	<body>
	<h1><?= $titulo ?></h1>
<?php $dat = extract($datos[0]); ?>

	
<form method="post" action="/save/id/<?=$id?>">
  <label for="id">ID:</label><br>
  <input type="text" id="id" name="id" value="<?=$id?>" readonly><br><br>

  <label for="name">Nombre de usuario:</label><br>
  <input type="text" id="username" name="username" value="<?=$username?>"><br><br>

  <label for="email">Email:</label><br>
  <input type="email" id="email" name="email" value="<?=$email?>"><br><br>

  <label for="password">Role:</label><br>
  <input type="role" id="role" name="role" value="<?=$role?>"><br><br>


  <input type="submit" value="Enviar">
</form>


	</body>
</html>


