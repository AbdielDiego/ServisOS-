<!-- Sección de navegación principal -->
<nav>

	<!-- Enlace al inicio del sitio -->
	<a href="/" >Inicio</a>
    
	<!-- Si el usuario ha iniciado sesión, muestra enlaces relacionados al usuario -->
	<?php if ( isset($_SESSION['user'] ) ): ?>
    	
    	<!-- Enlace al perfil del usuario autenticado -->
    	<a href="/Perfil" >Perfil</a>
    	
    	<!-- Enlace para cerrar sesión -->
    	<a href="/auth/logout" >Cerrar sesión</a>
	
	<!-- Si NO hay sesión activa, muestra opciones de acceso público -->
	<?php else: ?>

 		<!-- Enlace para ir al login -->
 		<a href="/auth/login" >Login</a>

 		<!-- Enlace a la sección de clientes -->
 		<a href="/app/clientes" >Clientes</a>

 		<!-- Enlace a la sección de servicios -->
 		<a href="/app/servicios" >Servicios</a>
 		
 		<a href="/app/registro" >Registro Empresario</a>


  	<?php endif; ?>

</nav>

