<?php 
// Esta línea imprime en pantalla el texto "show clientes "
echo "show registro_Empresario ";
?>
