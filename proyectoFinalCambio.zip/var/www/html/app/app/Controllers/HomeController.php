<?php
// Define el espacio de nombres del controlador
namespace App\Controllers;

// Importa la clase base Controller desde el núcleo del framework
use App\Core\Controller;

// Define la clase HomeController que extiende de Controller
class HomeController extends Controller {

    // Método principal que se ejecuta cuando se accede a la ruta '/'
    public function index() {
        // Renderiza la vista 'home' y le pasa un array con el título de la página
        return $this->render('home', [
            'title' => 'ServisOs'
        ]);
    }
}

