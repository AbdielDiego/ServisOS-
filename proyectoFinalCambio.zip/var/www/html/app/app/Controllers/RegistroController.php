<?php
namespace App\Controllers;

use App\Core\Controller;

class RegistroController extends Controller {

    public function registroEmpresario() {
        return $this->render("registro/registro_empresario", [
            'title' => 'Registro Empresario'
        ]);
    }

    public function showRegistro() {
        return $this->render("registro/showRegistro", [
            'title' => 'Datos del Registro'
        ]);
    }
}

